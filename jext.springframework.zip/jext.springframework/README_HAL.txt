Spring follow the specification
    https://en.wikipedia.org/wiki/Hypertext_Application_Language



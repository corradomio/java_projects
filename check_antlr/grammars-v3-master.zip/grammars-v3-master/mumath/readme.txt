Dan Stanger Wed Mar 10, 2004 16:49
This is a crude parser for muMath, a almost extinct language which has evolved into Derive. It can be used under the same license as Antlr.

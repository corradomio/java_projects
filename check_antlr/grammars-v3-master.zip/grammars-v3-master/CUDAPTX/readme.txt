Ken Domino Thu Aug 26, 2010 14:55
This Antlr v3 grammar recognizes the Nvidia CUDA PTX (parallel thread execution) assembly language v2.1, and creates a tree. This grammar is used in an emulator for CUDA programs.

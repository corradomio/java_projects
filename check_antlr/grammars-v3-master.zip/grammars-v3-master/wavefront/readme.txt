Edward Ames Thu Jun 14, 2007 20:38
Recognizes Wavefront .obj files. These are ASCII files for exchanging 3D graphical information. Blender can import/export these type of files as well.

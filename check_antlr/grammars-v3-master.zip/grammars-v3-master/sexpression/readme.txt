Robert Stehwien Thu Sep 25, 2008 13:10
A Lisp s-expression parser that is part of a lisp interpreter I'm working on. Dot notation isn't yet working (A . B) but other expressions should work. Updates will be posted or made available as time permits. Feel free to use under the MIT/X license.

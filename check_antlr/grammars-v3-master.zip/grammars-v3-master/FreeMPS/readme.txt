Tue Nov 16, 2010 05:58
The grammar defines the structure of the mps format.

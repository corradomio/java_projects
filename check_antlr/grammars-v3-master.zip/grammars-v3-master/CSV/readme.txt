Nathaniel Harward Fri May 13, 2011 10:08
While looking for a simple CSV grammar I saw the one in the ANTLR wiki but wanted a cleaner version, plus one that didn't eat white space (not allowed per RFC4180).

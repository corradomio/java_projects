Jesus Zazueta Mon Jun 15, 2009 10:46
This grammar is an ANTLR v3 port of the XPath 1.0 grammar defined by the W3C.

Terence Parr Wed Jul 19, 2006 18:18
Haven't tested a bunch, but it's a good start. :)
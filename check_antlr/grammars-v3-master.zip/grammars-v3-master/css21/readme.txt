Jim Idle Tue Apr 28, 2009 10:53
Written for a customer who cancelled, this is a commercial level parser, which I am now donating for ANTLR users. It follows the spec for CSS 2.1 exactly, but has not had extensive testing. It should easily adapt to CSS3 as it was intended to do so. Please report any bugs so that all may benefit.

Dong Nguyen Fri Feb 22, 2008 05:52
Translated from OMG IDL spec at http://www.omg.org/docs/formal/02-06-07.pdf.

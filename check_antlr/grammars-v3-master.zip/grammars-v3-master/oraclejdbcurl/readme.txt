Nathaniel Harward ( at gmail dot com) Fri Jul 2, 2004 15:52
A very simple parser for Oracle JDBC URLs, includes production rules for parsing a TNSNAMES.ORA stream as well since TNS entries and JDBC URLs can potentially share the same format, so I figured why not include that as well.

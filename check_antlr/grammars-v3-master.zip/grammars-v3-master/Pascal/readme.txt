Marton Papp Thu Jul 15, 2010 11:04
It contains a Pascal grammar file in ANTLR 3 format. It was made by exising ANTLR 2 grammar file that can be downloaded at ANTLR site. There is Eclipse project that can be opened in Eclipse and run.

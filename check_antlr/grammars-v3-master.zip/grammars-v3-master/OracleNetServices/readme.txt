Nathaniel Harward Mon Jun 18, 2007 10:51
A grammar for Oracle Net Services configuration files, like tnsnames.ora, sqlnet.ora, listener.ora, etc. Based on the syntax for Oracle 10g.

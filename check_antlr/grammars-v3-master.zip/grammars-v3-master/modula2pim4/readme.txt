Benjamin Kowarsch Fri Jul 10, 2009 01:12
ANTLR v3 grammar for Modula-2 adapted from the syntax given in the fourth edition of "Programming in Modula-2" by N. Wirth, refactored to satisfy LL(1) constraints.

Nathaniel Harward Fri Mar 21, 2008 17:53
A basic grammar for the memcached network protocol as described at http://code.sixapart.com/svn/memcached/trunk/server/doc/protocol.txt. Please email me (address is inside the grammar itself) if you find any problems with it.

Kunle Odutola Fri Feb 10, 2006 02:31
This updated grammar file includes a fix for parsing nested #region and #if preprocessor directive blocks. Thanks to Paul Foster for reporting the issue (and supplying test cases).

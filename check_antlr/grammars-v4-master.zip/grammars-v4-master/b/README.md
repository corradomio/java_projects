B Grammar
====

Summary
----

A first attempt at a grammar for the programming language [B](https://en.wikipedia.org/wiki/B_(programming_language))

Examples are from [https://www.bell-labs.com/usr/dmr/www/btut.html](https://www.bell-labs.com/usr/dmr/www/btut.html)




# Argus Grammar

A simple ANTLR4 grammar for [Argus](https://en.wikipedia.org/wiki/Argus_(programming_language)).  

# AGC Grammar

An ANTLR4 grammar for [AGC (Apollo Guidance Computer)](http://www.ibiblio.org/apollo/) files.
The grammar was tested on Apollo4 [Solarium055](http://www.ibiblio.org/apollo/listings/Solarium055/) files,
pulled from [https://github.com/avtobiff/virtualagc](https://github.com/avtobiff/virtualagc).

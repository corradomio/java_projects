# GUIDO Grammar

An ANTLR4 grammar for [GUIDO](https://en.wikipedia.org/wiki/GUIDO_music_notation) files.

[[noreturn]] void f(){
    while(true){
        
    }
}
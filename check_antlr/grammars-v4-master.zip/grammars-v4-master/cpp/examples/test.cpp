#include <iostream> 
#include <regex> 
#include<string.h>
#include<stack>
#include<conio.h>
using namespace std;
int main()
{
	//CPP14 grammar:parse error when writing a string in multiple lines #1381
	string str1 = "rafeeque_"
		"Aazam"
		"Ansar";
	cout << str1;


	_getch();
	return 0;
}

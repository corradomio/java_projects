int f()
{
	MyClass *test= new MyClass;
	test->foo();
}

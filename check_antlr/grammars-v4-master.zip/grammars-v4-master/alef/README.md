# Alef Grammar

A simple ANTLR4 grammar for [Alef](https://en.wikipedia.org/wiki/Alef_(programming_language)).  

# DGOL (Directed Graph Oriented Language) Grammar

An ANTLR4 grammar for [DGOL](https://esolangs.org/wiki/DGOL) files.


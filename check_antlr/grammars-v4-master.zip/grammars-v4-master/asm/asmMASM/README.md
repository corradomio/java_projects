# MASM Assembler Grammar

An ANTLR4 grammar for [MASM](https://en.wikipedia.org/wiki/Microsoft_Macro_Assembler) files.  

This grammar is not currently complete.  Pull Requests are welcome.


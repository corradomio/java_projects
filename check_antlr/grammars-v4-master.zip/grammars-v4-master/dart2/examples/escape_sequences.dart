class MyClass {
  var newline = '\n';
  var dollar = '$';
  var escaped_dollar = "\$";
}

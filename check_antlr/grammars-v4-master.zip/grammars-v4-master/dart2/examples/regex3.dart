class MyClass {
  final regex = new RegExp(r'''[ \t\r\n"'\\/]''');
}

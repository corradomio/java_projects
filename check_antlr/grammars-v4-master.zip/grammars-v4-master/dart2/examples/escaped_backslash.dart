class MyClass {
  final separator = '\\';
  final separators = const ['/', '\\'];
}

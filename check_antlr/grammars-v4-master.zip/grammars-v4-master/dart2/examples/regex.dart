class MyClass {
  final regex = new RegExp(r'^--([a-zA-Z\-_0-9]+)(=(.*))?$');
}

module Test where

amethod::[a]->[a]
amethod x = x
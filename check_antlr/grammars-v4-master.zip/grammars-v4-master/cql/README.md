# CQL Grammar
A simple ANTLR4 grammar for [Z39.5 CQL](https://en.wikipedia.org/wiki/Contextual_Query_Language).  


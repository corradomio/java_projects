package samples

// func BodylessFunction()
# AngelScript Grammar

A simple ANTLR4 grammar for [angelscript](http://angelcode.com/angelscript/sdk/docs/manual/doc_script_bnf.html).

# GEDCOM Grammar

A simple ANTLR4 grammar for [GEDCOM](https://en.wikipedia.org/wiki/GEDCOM)  

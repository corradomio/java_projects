https://cassandra.apache.org/doc/latest/cql/


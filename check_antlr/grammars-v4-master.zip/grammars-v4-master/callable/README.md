# Callable Grammar

A simple ANTLR4 grammar for [callable](https://esolangs.org/wiki/Callable).  

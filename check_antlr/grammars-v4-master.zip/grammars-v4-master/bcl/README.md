# BCL Grammar

A simple ANTLR4 grammar for [BCL](https://en.wikipedia.org/wiki/Binary_combinatory_logic).  


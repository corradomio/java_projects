# databank Grammar

An ANTLR4 grammar for [databank](https://en.wikipedia.org/wiki/Databank_format) files.

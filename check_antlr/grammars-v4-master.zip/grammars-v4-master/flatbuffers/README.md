ANTLR v4 grammar for the FlatBuffers schema language: https://google.github.io/flatbuffers/flatbuffers_grammar.html

## License
Apache License 2.0: http://www.apache.org/licenses/LICENSE-2.0.txt

# DOI URI Grammar

An ANTLR4 grammar for [DOI URI](https://tools.ietf.org/id/draft-paskin-doi-uri-04.txt)


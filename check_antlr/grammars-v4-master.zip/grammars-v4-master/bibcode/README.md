# Bibcode Grammar

A simple ANTLR4 grammar for [Bibcode](https://en.wikipedia.org/wiki/Bibcode).  

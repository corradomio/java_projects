
#region connection_f

class foo
{
}

class Multiple
{
	void Foo()
	{
		var a = 3, b = 2;
	}
}


class foo
{
}

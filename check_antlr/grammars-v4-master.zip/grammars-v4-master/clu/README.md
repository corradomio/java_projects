# CLU Grammar

An ANTLR4 grammar for [CLU](https://en.wikipedia.org/wiki/CLU_(programming_language))



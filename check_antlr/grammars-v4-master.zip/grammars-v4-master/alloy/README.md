# Alloy Grammar

An ANTLR4 grammar for [Alloy](https://en.wikipedia.org/wiki/Alloy_(specification_language))

Examples are from [https://alloytools.org/](https://alloytools.org/)

Grammar from [here](https://alloytools.org/download/alloy-language-reference.pdf)

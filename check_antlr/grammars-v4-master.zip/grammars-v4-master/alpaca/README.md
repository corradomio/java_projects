# ALPACA Grammar

An ANTLR4 grammar for [Alpaca](https://catseye.tc/article/Languages.md#alpaca) files.

See also: https://github.com/catseye/ALPACA

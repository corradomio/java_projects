# Brainflak Grammar

A simple ANTLR4 grammar for [Brainflak](https://esolangs.org/wiki/Brain-Flak)

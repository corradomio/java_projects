# CTL Grammar

A simple ANTLR4 grammar for [CTL](https://en.wikipedia.org/wiki/Computation_tree_logic).  

simple query language SQL like indipendent on the graphdb.

data types:
    simple type
        bool
        int/long
        float/double
    collections
        set
            size()
            contains(key)
            add(key)
            remove(key)
            clear()
        map:string -> any
            size()
            at(key)
            containsKey(key)
            add(key, value)
            remove(key)
            clear()
        array
            size()
            at(index)
            resize(nsize)
            clear()


where clause

    field = value
    field in [values]
    field < | <= | == | != | >= | > value
    field in [min, max]             min <= field <= max
    field ~= regexp

    exists(field)

    <pred> and <pred>
    <pred> or <pred>
    not <pred>

    <pred>(field, ...)                  call a predicate on a field
    where("...")                        "where" clause passed directly to the database

    (predicate)

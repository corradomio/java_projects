package ae.ebtic.spl.server.controller.runtime;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.managers.splrepos.SPLReposManager;
import ae.ebtic.spl.managers.uploads.UploadsService;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.RuntimeModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebModelModel;
import ae.ebtic.spl.server.webmodels.WebModelsFactory;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import ae.ebtic.spl.server.webmodels.runtime.WebEntryPointsCount;
import ae.ebtic.spl.tasks.ProjectTask;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@Controller
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/runtime/entryPoints")
public class EntryPointsController extends SPLRestController {

    private static final String TYPE = "runtime";

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // @Autowired private ApplicationContext ctx;
    @Autowired private SPLReposManager reposManager;
    @Autowired private UploadsService uploadsService;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected EntryPointsController() {
        super(TYPE);
    }

    // ----------------------------------------------------------------------
    // Web services
    // ----------------------------------------------------------------------

    // -- get

    @GetMapping(value="", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> getEntryPointsCount(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        return ResponseEntity.ok(new WebEntryPointsCount(model, requestUrl));

    }

    // -- delete

    // DEBUG
    @GetMapping(value="reset", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> resetEntryPointsByGet(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        // remove ONLY components & features
        Managers.getExecutorService().submit(() -> {
            model.resetEntryPoints();
        });

        return ResponseEntity.ok(new WebEntryPointsCount(model, requestUrl));
    }


    // DEBUG
    @GetMapping(value="delete", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> deleteEntryPointsByGet(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        return deleteEntryPoints(repoName, projectName);
    }

    @DeleteMapping(value="", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> deleteEntryPoints(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        Managers.getExecutorService().submit(() -> {
            model.delete();
        });

        return ResponseEntity.ok(new WebEntryPointsCount(model, requestUrl));
    }

    // -- create entry points

    // DEBUG
    @GetMapping(value = "create", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createEntryPointsByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "files", defaultValue = "") String files,
        @RequestParam(value = "test", defaultValue = "0") double test) {

        EntryPointsConfig config = new EntryPointsConfig()
            .setUploaded(true)
            .setTest(test)
            .addFiles(files);

        return createEntryPoints(repoName, projectName, config);
    }

    /**
     * Start a new "runtime analysis"
     */
    @PostMapping(value="", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createEntryPoints(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody EntryPointsConfig config) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        config.setRepository(repoName).setProject(projectName);

        if (config.isUploaded())
            config.setParentDir(uploadsService.getUploadDir());

        // SPRING TEST!
        // check if the repository/project exists
        // SPLReposManager reposManager = Managers.getSPLReposManager();
        // SPLReposManager reposManager = ctx.getBean("reposManager", SPLReposManager.class);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        ModelCreateParams params = new ModelCreateParams();
        params.addParameter("config", config);

        ProjectTask task = model.create(params);

        WebModelModel webmodel = WebModelsFactory.of(model, requestUrl);
        if (task == null)
            return new ResponseEntity<>(webmodel, HttpStatus.FORBIDDEN);

        Managers.getTaskManager().submit(task);
        return ResponseEntity.ok(new WebEntryPointsCount(model, requestUrl));
    }


    // -- update entry points

    // DEBUG
    @GetMapping(value="update", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> updateEntryPointsByGet(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        return updateEntryPoints(repoName, projectName);
    }

    @PutMapping(value="", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> updateEntryPoints(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        Managers.getExecutorService().submit(() -> {
            model.updateEntryPoints();
        });

        return ResponseEntity.ok(new WebEntryPointsCount(model, requestUrl));
    }

    // ----------------------------------------------------------------------
    // Queries
    // ----------------------------------------------------------------------

    @GetMapping(value="types", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> getEntryPointTypes(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        List<WebTypeModel> types = model.getEntryPointTypes()
            .stream()
            .map(type -> new WebTypeModel(type, requestUrl))
            .collect(Collectors.toList());

        return ResponseEntity.ok(types);
    }

    @GetMapping(value="components", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> getEntryPointComponentsList(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        List<WebComponentModel> components = model.getEntryPointComponents()
            .stream()
            .map(component -> new WebComponentModel(component, requestUrl))
            .collect(Collectors.toList());

        return ResponseEntity.ok(components);
    }

    @GetMapping(value="features", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> getEntryPointFeaturesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        RuntimeModel model = reposManager
            .newRepository(repoName)
            .newProject(projectName)
            .getRuntimeModel();

        List<WebFeatureModel> types = model.getEntryPointFeatures()
            .stream()
            .map(feature -> new WebFeatureModel(feature, requestUrl))
            .collect(Collectors.toList());

        return ResponseEntity.ok(types);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

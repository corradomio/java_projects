package ae.ebtic.spl.server;

public class Version {

    public static String VERSION = "Software Product Line, v2.7";
}

package ae.ebtic.spl.server.controller.source;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.source.WebLibraryModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/source/libraries")
public class SourceLibrariesController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourceLibrariesController() {
        super(SourceModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public  ResponseEntity<?> getLibrariesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        List<WebLibraryModel> mlibraries = sm.getLibraries()
            .stream()
            .map(library -> new WebLibraryModel(library, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(mlibraries, HttpStatus.OK);
    }

    @GetMapping(value = "{libraryId}")
    @ResponseBody
    public ResponseEntity<?> getLibrary(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String libraryId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Library library = sm.getLibrary(libraryId);

        return new ResponseEntity<>((ae.ebtic.spl.server.webmodels.source.WebLibraryModel)new WebLibraryModel(library, requestUrl).detailed(), HttpStatus.OK);
    }

}

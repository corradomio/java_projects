package ae.ebtic.spl.server.webmodels.dependency;

import ae.ebtic.spl.analysis.dependencies.LibraryNode;
import ae.ebtic.spl.analysis.dependencies.MethodNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.server.webmodels.WebDetailedModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebLink;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class WebMethodModel extends WebDetailedModel implements GraphConstants {

    private Method method;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public WebMethodModel(Method method, String prefixUrl) {
        super(prefixUrl);
        this.method = method;
        this.href = WebHrefMapper.of(prefixUrl).getMethodHref(method.getId());
        populate();
    }

    // ----------------------------------------------------------------------
    // Populate
    // ----------------------------------------------------------------------

    @Override
    protected void populate() {
        super.populate();

        put(ID, method.getId());
        put(NAME, method.getName().getName());
        put(SIGNATURE, method.getSignature());
        put(TYPE_ID, method.getTypeId());
        put(OWNER_TYPE_ID, method.getOwnerTypeId());
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // public String getHref() { return href; }

    // public String getId() { return method.getId(); }

    // public String getName() { return method.getName().getName(); }

    // public String getSignature() { return method.getSignature(); }

    // public WebRefTypeModel getType() { return new WebRefTypeModel(method.getType(), prefixUrl); }

    // public String getTypeId() { return method.getTypeId(); }

    // public String getOwnerTypeId() { return method.getOwnerTypeId(); }

    // public List<WebParameterModel> getParameters() {
    //     if (!detailed)
    //         return Collections.emptyList();
    //
    //     return method.getParameters()
    //         .stream()
    //         .map(parameter -> new WebParameterModel(parameter, method.getId(), ownerTypeId, prefixUrl))
    //         .collect(Collectors.toList());
    // }

    // public Map<String, Object> getValues() {
    //     if (!detailed)
    //         return Collections.emptyMap();
    //     else
    //         return ((MethodNode) method).getValues();
    // }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected List<WebLink> getLinks() {
        if (!detailed)
            return Collections.emptyList();

        String typeId = method.getTypeId();
        String ownerTypeId = method.getOwnerTypeId();

        return Arrays.asList(
            new WebLink("type", WebHrefMapper.of(href).getTypeHref(typeId)),
            new WebLink("ownerType", WebHrefMapper.of(href).getTypeHref(ownerTypeId)),
            WebLink.of(href, "parameters"),
            new WebLink(href)
        );
    }

    @Override
    protected  Map<String, Object> readValues() {
        return ((MethodNode) method).getValues();
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

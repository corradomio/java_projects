package ae.ebtic.spl.managers.services.rtanalysis;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.server.controller.runtime.EntryPointsConfig;
import ae.ebtic.spl.tasks.EntryPointsAnalysisTask;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class RuntimeAnalyzerManagerImpl implements RTAnalysisManager {

    // ----------------------------------------------------------------------
    // Configuration
    // ----------------------------------------------------------------------

    @Override
    public String getName() { return RTAnalysisManager.MANAGER; }

    @Override
    public void configure(Configuration config) throws ConfigurationException {

    }

    @Override
    public void destroy() {

    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public EntryPointsAnalysisTask analyzeProject(EntryPointsConfig config) {
        // Operation inf background!

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(config.getRepository())
            .newProject(config.getProject());

        EntryPointsAnalysisTask task = new EntryPointsAnalysisTask(project);
        task.setConfig(config);

        return task;

        // if (config.isSync())
        //     task.run();
        // else
        //     Managers.getTaskManager().submit(task);
    }
}

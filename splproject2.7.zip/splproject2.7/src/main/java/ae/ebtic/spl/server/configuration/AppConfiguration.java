package ae.ebtic.spl.server.configuration;

import jext.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.*;

import javax.annotation.PostConstruct;

@Configuration
@PropertySource(value = "file:${spring.app.root:./web}/WEB-INF/application.properties", ignoreResourceNotFound = true)
@EnableWebMvc
@ComponentScan("ae.ebtic.spl.server")
public class AppConfiguration implements WebMvcConfigurer {

    private static Logger logger = Logger.getLogger(AppConfiguration.class);

    @Value("${spring.app.root}")
    private String appRoot;

    @Override
    public void configurePathMatch(PathMatchConfigurer configurer) {
        configurer.setUseSuffixPatternMatch(false);
    }

    @Override
    public void addViewControllers(ViewControllerRegistry registry) {
        registry.addViewController("/").setViewName("forward:/index.html");
        registry.addViewController("/wslogger").setViewName("forward:/wslogger.html");
    }

    @Override
    public void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry
            .addResourceHandler("/**")
            // .addResourceHandler("/*.html", "/js/*.js")
            .addResourceLocations("/")
            // .addResourceLocations("/WEB-INF/pages/")
        ;
    }

    @Override
    public void addCorsMappings(CorsRegistry registry) {
        registry.addMapping("/**");
        //
        // NON FUNZIONA!!!!!
        //
        // registry.addMapping("/**")
        //     .allowedOrigins("*")
        //     // .allowedMethods("*")
        //     .allowedHeaders("Content-Type, Access-Control-Allow-Origin, Access-Control-Allow-Headers, Authorization, X-Requested-With, requestId, Correlation-Id")
        //     // .allowedMethods("*")
        //     .allowedMethods("GET, PUT, POST, DELETE")
        //     .maxAge(3600);
    }

    @PostConstruct
    public void init() {
        logger.info("Initialized");
    }
}

package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class SourceModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourceModelConfig() { }

    @Override
    public long getTimestamp() {
        return super.getTimestamp();
    }

    public static SourceModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(SourceModelConfig.class);

        if (configFile.exists())
        try {
            return (SourceModelConfig) JSONUtils.load(configFile, SourceModelConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
        }

        return (SourceModelConfig) new SourceModelConfig().configIn(configFile);
    }

}

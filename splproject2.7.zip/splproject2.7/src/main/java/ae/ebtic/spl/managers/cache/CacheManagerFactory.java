package ae.ebtic.spl.managers.cache;

import ae.ebtic.spl.managers.system.SystemManager;
import ae.ebtic.spl.managers.system.SystemManagerImpl;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class CacheManagerFactory {

    public static CacheManager createManager(Configuration config) throws ConfigurationException {
        CacheManager manager = new CacheManagerImpl();
        manager.configure(config);
        return manager;
    }
}

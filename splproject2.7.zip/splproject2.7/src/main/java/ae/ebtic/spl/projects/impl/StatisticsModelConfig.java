package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class StatisticsModelConfig extends ModelConfig {

    public StatisticsModelConfig(){super(); }

    public static StatisticsModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(StatisticsModelConfig.class);

        if (configFile.exists())
            try {
                return (StatisticsModelConfig) JSONUtils.load(configFile, StatisticsModelConfig.class).configIn(configFile);
            }
            catch (Exception e) {
                logger.error(e, e);
            }

        return (StatisticsModelConfig) new StatisticsModelConfig().configIn(configFile);
    }
}

package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;
import java.util.UUID;

public class ProjectModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static final String PROJECT_CONFIG = "project-config.json";
    // private String projectId = "";

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectModelConfig() { }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // public boolean hasId() {
    //     return projectId != null && projectId.length() > 0;
    // }

    // public String getId() {
    //     return projectId;
    // }

    // public ProjectModelConfig setId(String id) {
    //     projectId = id;
    //     return this;
    // }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    public static ProjectModelConfig loadForProject(File projectSpl) {
        File configFile = getFile(projectSpl);
        return loadOrDefault(configFile);
    }

    public synchronized static ProjectModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(ProjectModelConfig.class);

        ProjectModelConfig config = null;
        if (configFile.exists()) {
            try {
                config = (ProjectModelConfig) JSONUtils.load(configFile, ProjectModelConfig.class)
                    .configIn(configFile);
            }
            catch (Exception e) {
                logger.error(e, e);
                config = (ProjectModelConfig) new ProjectModelConfig()
                    .configIn(configFile);
            }
        }
        else {
            config = (ProjectModelConfig) new ProjectModelConfig()
                .configIn(configFile);
        }

        // if (config.exists() && !config.hasId()) {
        //     logger.warnf("Generated an ID for the project %s", config);
        //     config.generateId().save();
        //
        //     if (!config.isValid())
        //         logger.warnf("Invalid configuration file %s", config);
        // }

        return config;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    // public ProjectModelConfig generateId() {
    //     projectId = UUID.randomUUID().toString();
    //     return this;
    // }

    public static File getFile(File projectSpl) {
        return new File(projectSpl, PROJECT_CONFIG);
    }

}

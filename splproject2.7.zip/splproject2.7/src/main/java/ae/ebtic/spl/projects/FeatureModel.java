package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.features.FeatureGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.tasks.CreateManualFeatureTask;

import java.util.List;
import java.util.Map;

public interface FeatureModel extends ProjectModel {

    String TYPE = "feature";

    FeatureGraph getFeatureGraph();

    // -----------------------------------------------------------------------

    int getFeaturesCount();

    List<Feature> getFeatures();

    Feature getFeature(String featureId);

    Feature findFeatureByName(String featureName);

    // -----------------------------------------------------------------------

    List<Component> getFeatureComponents(String featureId);

    List<Component> getFeaturesComponents(List<String> ids);

    // -----------------------------------------------------------------------

    List<Type> getFeatureTypes(String featureId);

    List<Type> getFeaturesTypes(List<String> ids);

    // -----------------------------------------------------------------------

    List<Type> addContext(List<Type> types, boolean interfaces, boolean links, boolean implementations);

    // -----------------------------------------------------------------------

    Feature newFeature(String fullName);

    // -----------------------------------------------------------------------

    @Deprecated
    Map<String, Object> getModelGraph();

    @Deprecated
    Map<String, Object> getSmallModelGraph();

    // -----------------------------------------------------------------------

    @Deprecated
    Map<String, Object> findIntegrationPoints(List<String> featureIds);

    // -----------------------------------------------------------------------

    @Deprecated
    void setTypesCount();

    @Deprecated
    Map<String, Object> getTypesCount();

    // -----------------------------------------------------------------------
    // The following methods are DEPRECATED
    // It is necessary to replace them with methods that return the correct
    // type of objects

    @Deprecated
    List<Feature> getFeaturesByComponents(List<Integer> componentIds);

    @Deprecated
    List<Map<String, Object>> getComponents(String featureId);

    // @Deprecated
    CreateManualFeatureTask manualCreate(List<String> features, List< List<String> > components);

    @Deprecated
    Map<String, Object> getTypes(String featureId);

    @Deprecated
    Map<String, Object> getTypesWInterfaces(String featureId, boolean links, boolean implementation);

    @Deprecated
    Map<String, Object> exportFeatureToXLSX(String featureId, boolean implementation, double coreThreshold, boolean fullName);

}

package ae.ebtic.spl.server.controller.component;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/component/components/{componentId}")
public class ComponentController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ComponentController() {
        super(ComponentModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getComponent(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        Component c = cm.getComponent(componentId);

        return new ResponseEntity<>((WebComponentModel)new WebComponentModel(c, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping("types")
    @ResponseBody
    public ResponseEntity<?> getComponentTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        List<WebTypeModel> types = cm.getComponentTypes(componentId)
            .stream()
            .map(dt -> new WebTypeModel(dt, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }

    @GetMapping(value = "members")
    @ResponseBody
    public ResponseEntity<?> getComponentMembersList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        List<WebComponentModel> members = cm.getComponentMembers(componentId)
            .stream()
            .map(member -> new WebComponentModel(member, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(members, HttpStatus.OK);
    }

    @GetMapping(value = "features")
    @ResponseBody
    public ResponseEntity<?> getComponentFeaturesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        List<WebFeatureModel> features = cm.getComponentFeatures(componentId)
            .stream()
            .map(feature -> new WebFeatureModel(feature, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(features, HttpStatus.OK);
    }

}

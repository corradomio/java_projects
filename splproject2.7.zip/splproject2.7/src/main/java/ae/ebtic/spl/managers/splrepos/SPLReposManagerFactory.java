package ae.ebtic.spl.managers.splrepos;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class SPLReposManagerFactory {

    /**
     * Create the manager based on the configuration
     *
     * @param config configuration
     * @return
     * @throws ConfigurationException
     */
    public static SPLReposManager createManager(Configuration config) throws ConfigurationException {
        SPLReposManager manager = new SPLReposManagerImpl();
        manager.configure(config);
        return manager;
    }
}

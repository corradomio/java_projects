package ae.ebtic.spl.projects;

public enum ModelStatus {

    // the module doesn't exist
    NOT_EXISTENT,

    // a task is running and changing the model
    TASK_RUNNING,

    // the model is valid: the task used to create it is terminated with onSuccess
    VALID,

    // the model is not valid: the task used to create it is terminated with error
    // or it was aborted
    INVALID,

    // the model is valid but has missing parts.
    // If a part is INVALID, the model is INVALID
    PARTIAL
}

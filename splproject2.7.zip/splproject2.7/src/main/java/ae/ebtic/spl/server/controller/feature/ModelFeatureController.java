package ae.ebtic.spl.server.controller.feature;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.util.IdList;
import ae.ebtic.spl.server.webmodels.WebModelsFactory;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebModelModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/feature")
public class ModelFeatureController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelFeatureController() {
        super(FeatureModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    /**
     * List of features
     */
    @GetMapping("features")
    @ResponseBody
    public ResponseEntity<?> getFeaturesList(
            @PathVariable String repoName,
            @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getFeatureModel();

        List<WebFeatureModel> features = fm.getFeatures()
                .stream()
                .map(f -> new WebFeatureModel(f, requestUrl))
                .collect(Collectors.toList());

        return new ResponseEntity<>(features, HttpStatus.OK);
    }

    /**
     * List of components
     */
    @PostMapping("components")
    @ResponseBody
    public ResponseEntity<?> getComponentsByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody IdList ids) {
        return getFeaturesComponentsList(repoName, projectName, ids);
    }

    @GetMapping("components")
    @ResponseBody
    public ResponseEntity<?> getFeaturesComponentsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody IdList ids) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        List<WebComponentModel> components = fm.getFeaturesComponents(ids.getIds())
            .stream()
            .map(component -> new WebComponentModel(component, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(components, HttpStatus.OK);
    }

    /**
     * List of components
     */

    @PostMapping("types")
    @ResponseBody
    public ResponseEntity<?> getTypesByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody IdList ids) {
        return getTypesList(repoName, projectName, ids);
    }

    @GetMapping("types")
    @ResponseBody
    public ResponseEntity<?> getTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody IdList ids) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        List<WebTypeModel> types = fm.getFeaturesTypes(ids.getIds())
            .stream()
            .map(type -> new WebTypeModel(type, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // (DEPRECATED) typesCount
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     *
     * Set the number of classes inside the features
     */
    @GetMapping(value = "setTypesCount")
    @ResponseBody
    public ResponseEntity<?> setTypesCount(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        if (!fm.exists()) {
            logger.errorf("FeatureModel %s not existent", fm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        fm.setTypesCount();

        WebModelModel webmodel = WebModelsFactory.of(fm, requestUrl);
        return new ResponseEntity<>(webmodel, HttpStatus.OK);
    }

    /**
     * (DEPRECATED)
     *
     * Retrieve the number of classes inside the features
     */
    @GetMapping(value = "getTypesCount")
    @ResponseBody
    public ResponseEntity<?> getTypesCountDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        if (!fm.exists()) {
            logger.errorf("FeatureModel %s not existent", fm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(fm.getTypesCount(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Create features from components
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     *
     * Retrieve the features that use specific components
     */
    @PostMapping(value = "getByComponents")
    @ResponseBody
    public ResponseEntity<?> getByComponentsDeprecated(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestBody List<Integer> componentIds)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        if (!fm.exists()) {
            logger.errorf("FeatureModel %s not existent", fm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        List<Map<String, Object>> response = fm.getFeaturesByComponents(componentIds)
            .stream()
            // .map(feature -> new WebFeatureModel(feature, requestUrl))
            .map(feature -> {
                Map<String, Object> data = new HashMap<>();
                data.put("id", feature.getId());
                data.put("values", feature.getValues());
                data.put("count", feature.getCount());

                Map<String, Object> name = new HashMap<>();
                name.put("name", feature.getName().getName());
                name.put("fullname", feature.getName().getFullName());

                data.put("name", name);
                return data;
            })
            .collect(Collectors.toList());

        return new ResponseEntity<>(response, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // findIntegrationPoints
    // ----------------------------------------------------------------------

    @PostMapping(value = "findIntegrationPoints")               // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> getIntegrationPointsDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody List<String> featureIds)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getFeatureModel();

        return new ResponseEntity<>(fm.findIntegrationPoints(featureIds), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------
}

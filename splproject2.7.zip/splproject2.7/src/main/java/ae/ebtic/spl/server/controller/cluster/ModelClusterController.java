package ae.ebtic.spl.server.controller.cluster;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ClusterModel;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import jext.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;
import java.util.Collections;


@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/cluster")
public class ModelClusterController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelClusterController() {
        super(ClusterModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping(value = "clusters/{model}")
    @ResponseBody
    public ResponseEntity<?> getClusters(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String model,
            @RequestParam(value = "technique", defaultValue = "1") int technique)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ClusterModel cm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getClusterModel();

        if (!cm.exists()) {
            logger.errorf("ClusterModel %s not existent", cm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        return ResponseEntity.ok(cm.getClusters(model, technique));
    }
}

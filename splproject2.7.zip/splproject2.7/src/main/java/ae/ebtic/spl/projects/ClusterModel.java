package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.clustering.ClusteringGraph;
import java.util.Map;

public interface ClusterModel extends ProjectModel {

    String TYPE = "cluster";

    ClusteringGraph getClusterGraph();

    Map<String, Object> getClusters(String model, int technique);
}
package ae.ebtic.spl.projects;


import ae.ebtic.spl.statistics.StatisticsElement;

import java.util.List;

public interface StatisticsModel extends ProjectModel {

    String TYPE = "statistics";

    void registerStatisticsElement(StatisticsElement element);

    List<StatisticsElement> getElements();

    StatisticsElement newElement(String elementType);

    boolean createElement(String elementType);

    boolean deleteElement(String elementType);

}


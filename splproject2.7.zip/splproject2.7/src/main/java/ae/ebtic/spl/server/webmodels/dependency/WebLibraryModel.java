package ae.ebtic.spl.server.webmodels.dependency;

import ae.ebtic.spl.analysis.dependencies.LibraryNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryType;
import ae.ebtic.spl.server.webmodels.WebDetailedModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebLink;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class WebLibraryModel extends WebDetailedModel implements GraphConstants {

    private Library library;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public WebLibraryModel(Library library, String prefixUrl) {
        super(prefixUrl);
        this.library = library;
        this.href = WebHrefMapper.of(prefixUrl).getDependencyLibraryHref(library.getId());
        populate();
    }

    // ----------------------------------------------------------------------
    // Populate
    // ----------------------------------------------------------------------

    @Override
    protected void populate() {
        super.populate();

        put(ID, library.getId());
        put(NAME, library.getName().getName());
        if (isSelected(FULL_NAME))
            put(FULL_NAME, library.getName().getFullName());
        if (isSelected(PATH))
            put(PATH, library.getPath());
        put(LIBRARY_TYPE, library.getLibraryType());

        // if (isSelected("latest"))
        if (library.getLibraryType().equals(LibraryType.MAVEN)) {
            MavenDownloader md = library.getProject().getLibraryDownloader();
            MavenCoords coords = new MavenCoords(library.getName().getFullName());
            MavenCoords latest = md.getLatest(coords);
            put("latest", latest.getName());
        }
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // public String getHref() { return href; }

    // public String getId() { return library.getId(); }

    // public String getName() { return library.getName().getName(); }

    // public String getFullName() { return library.getName().getFullName(); }

    // public String getPath() { return library.getPath(); }

    // public String getLibraryType() { return library.getLibraryType().toString(); }

    // public Map<String, Object> getValues() {
    //     if (!detailed)
    //         return Collections.emptyMap();
    //
    //     return ((LibraryNode) library).getValues();
    // }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected List<WebLink> getLinks() {
        if (!detailed)
            return Collections.emptyList();

        List<WebLink> links = new ArrayList<>(Arrays.asList(
            WebLink.of(href, "types"),
            new WebLink(href)
        ));

        String moduleId = library.getModuleId();

        if (moduleId != null) {
            links.add(new WebLink("module", WebHrefMapper.of(href).getDependencyModuleHref(moduleId)));
        }

        return links;
    }

    @Override
    protected  Map<String, Object> readValues() {
        return ((LibraryNode) library).getValues();
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

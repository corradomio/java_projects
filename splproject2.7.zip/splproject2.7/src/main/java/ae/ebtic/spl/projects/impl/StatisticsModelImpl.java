package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.*;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.statistics.StatisticsElement;
import ae.ebtic.spl.statistics.impl.CoreElementImpl;
import ae.ebtic.spl.tasks.SPLProjectTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StatisticsModelImpl extends ProjectModelImpl implements StatisticsModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "statistics-config.json";

    private Map<String, StatisticsElement> elements = new HashMap<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected StatisticsModelImpl(SPLProject project) {
        super(project, StatisticsModel.TYPE);

        createElements();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl) super.getInfo();

        Map<String, Object> counts = new HashMap<>();
        counts.put("elements", elements.size());

        info.put("count", counts);

        return info;
    }

    @Override
    public void registerStatisticsElement(StatisticsElement element) {
        elements.put(element.getType(), element);
    }

    // ----------------------------------------------------------------------
    // Element Properties
    // ----------------------------------------------------------------------

    private void createElements() {
        CoreElementImpl.newCoreElement(this);
    }

    @Override
    public List<StatisticsElement> getElements() {
        return new ArrayList<>(this.elements.values());
    }

    @Override
    public StatisticsElement newElement(String elementType) {

        if (elements.containsKey(elementType))
            return elements.get(elementType);
        else
            throw new RuntimeException(String.format("Unknown element type '%s'", elementType));
    }

    @Override
    public boolean createElement(String elementType) {
        modelCreateParams = new ModelCreateParams(WSTaskStatusListener.instance);
        SPLProjectTask task;
        if (elements.containsKey(elementType)){
            if(elements.get(elementType).canCreate()) {
                task = elements.get(elementType).createTask();
                task.addListeners(modelCreateParams.listeners());
                task.setParameters(modelCreateParams.parameters());
                Managers.getTaskManager().submit(task);
                //Managers.getTaskManager().submit(elements.get(elementType).createTask());
                return true;
            }
            else
                return false;
        }
        else
            throw new RuntimeException(String.format("Unknown element type '%s'", elementType));
    }

    @Override
    public boolean deleteElement(String elementType) {
        if (elements.containsKey(elementType)){
            elements.get(elementType).delete();
            return true;
        }
        else
            throw new RuntimeException(String.format("Unknown element type '%s'", elementType));
    }

    @Override
    public long getTimestamp(){
        return getSPLProject().getFeatureModel().getFeatureGraph().getTimestamp();
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        for(StatisticsElement element: getElements()){
            element.delete();
        }
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkModelStatus() {
        FeatureModel fm = project.getFeatureModel();
        setStatus(fm.getStatus(), fm.getReason());
    }

}

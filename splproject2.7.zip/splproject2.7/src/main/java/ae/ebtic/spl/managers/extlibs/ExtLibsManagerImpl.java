package ae.ebtic.spl.managers.extlibs;

import ae.ebtic.spl.analysis.sourcecode.extlibs.JavaLibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.common.ConfigurationUtils;
import jext.logging.Logger;
import jext.maven.MavenDownloader;
import jext.util.FileUtils;
import jext.util.HashMap;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.HierarchicalConfiguration;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class ExtLibsManagerImpl implements ExtLibsManager {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static class LibraryFinderConfig {
        // List<File> librariesDirs = new ArrayList<>();
        Map<String, File> namedLibraries = new HashMap<>();
    }

    private static class MavenConfig {
        long downloadTimeout;
        long checkTimeout;
        List<String> mavenRepos = new ArrayList<>();
        File downloadsDir;
    }

    private static Logger logger = Logger.getLogger(ExtLibsManager.class);

    private Configuration config;
    private MavenConfig mavenConfig;
    private LibraryFinderConfig lfinderConfig;

    //private JavaLibraryFinder lfinder = new JavaLibraryFinder();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ExtLibsManagerImpl() { }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------
    /*
        <extlibsManager>
            <maven downloadTimeout="500"
               checkTimeout="86400"
            >
                <repository url="https://repo1.maven.org/maven2"/>
                <repository url="https://repo.maven.apache.org/maven2"/>
                <repository url="http://central.maven.org/maven2/"/>
            </maven>

            <downloads path="${sys:user.home}/.spl/.extlib"/>

            <language name="java">
                <path name="jdk8"  value="D:/Java/Jdk1.8.0.x64"/>
                <path name="jdk11" value="D:/Java/Jdk11.0.x64"/>
                <path name="jdk12" value="D:/Java/Jdk12.0.x64"/>
                <path name="jdk14" value="D:/Java/Jdk14.0.x64"/>
            </language>
        </extlibsManager>
     */

    @Override
    public String getName() {
        return ExtLibsManager.MANAGER;
    }

    @Override
    public void configure(Configuration config) {

        this.config = config;

        logger.info("configure");

        String homePath = config.getString("homePath");

        //
        // scan for the programming languages
        //
        lfinderConfig = new LibraryFinderConfig();

        for (Object lconfig : ((HierarchicalConfiguration)config).configurationsAt("language")) {
            Configuration languageConfig = (Configuration) lconfig;
            String language = languageConfig.getString("[@name]");

            for (Object libconfig : ((HierarchicalConfiguration)languageConfig).configurationsAt("path")) {
                Configuration libraryConfig = (Configuration) libconfig;

                String nameList = libraryConfig.getString("[@name]");
                String[] names = nameList.split(",");
                String path = libraryConfig.getString("[@value]");

                if (names.length == 0) {
                    logger.errorf("Invalid library name list: '%s' -> '%s'", nameList, path);
                    continue;
                }

                File directory = FileUtils.toFile(homePath, path);
                for (String name : names)
                    if (name.length() > 0)
                        lfinderConfig.namedLibraries.put(name, directory);

                // if (name.length() == 0)
                //     lfinderConfig.librariesDirs.add(directory);
                // else
                //     lfinderConfig.namedLibraries.put(name, directory);
            }
        }

        //
        // Configure the MavenDownloader
        //
        mavenConfig = new MavenConfig();

        mavenConfig.mavenRepos = ConfigurationUtils.loadUrls(config,"maven.repository");
        mavenConfig.downloadTimeout = config.getLong("downloadTimeout", 500);
        mavenConfig.checkTimeout = config.getLong("checkTimeout", 86400);

        File downloadsDir = FileUtils.toFile(homePath, config.getString("downloads[@path]", "/.m2/repository"));
        if (!downloadsDir.exists() && !downloadsDir.mkdirs())
            logger.errorf("Unable to create the directory %s", downloadsDir);
        mavenConfig.downloadsDir = downloadsDir;

        // MavenDownloader downloader = MavenDownloader.newDownloader()
        //     .download(downloadsDir)
        //     .repositories(mavenRepos)
        //     .checkTimeout(checkTimeout)
        //     .downloadTimeout(downloadTimeout);

        // lfinder.mavenDownloader(downloader);

        logger.info("done");
    }

    @Override
    public void destroy() {

    }

    /**
     * Each project MUST HAVE a proprietary library finder
     */
    @Override
    public LibraryFinder getLibraryFinder() {

        MavenDownloader downloader = new MavenDownloader()
            .setDownload(mavenConfig.downloadsDir)
            .addRepositories(mavenConfig.mavenRepos)
            .setCheckTimeout(mavenConfig.checkTimeout)
            .setDownloadTimeout(mavenConfig.downloadTimeout)
            .initialize();

        JavaLibraryFinder lfinder = new JavaLibraryFinder()
            .setDownloader(downloader)
            // .addLibrariesDirs(lfinderConfig.librariesDirs)
            .setNamedLibraries(lfinderConfig.namedLibraries)
            .initialize();

        return lfinder;
    }
}

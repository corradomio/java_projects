package ae.ebtic.spl.server.controller.versioning;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.VersioningModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.versioning.WebProjectVersionConfig;
import ae.ebtic.spl.server.webmodels.versioning.WebProjectVersionModel;
import ae.ebtic.spl.versioning.ProjectVersion;
import ae.ebtic.spl.versioning.impl.ProjectVersionConfig;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;
@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/versioning")
public class ModelVersioningController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelVersioningController() {
        super(VersioningModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------


    /**
     * List of types
     */
    @GetMapping("versions")
    @ResponseBody
    public  ResponseEntity<?> getVersionsList(
            @PathVariable String repoName,
            @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        List<WebProjectVersionModel> vl = vh.getVersions()
               .stream()
               .map(pv -> new WebProjectVersionModel(pv, requestUrl))
               .collect(Collectors.toList());

        return new ResponseEntity<>(vl, HttpStatus.OK);
    }

    /**
     * (DEPRECATED)
     *
     * Create a project version
     */
    @PutMapping(value="{versionName}", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProjectVersion(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionName,
            @RequestBody WebProjectVersionConfig config) throws Exception {

        config.setVersionName(versionName)
            .setRepository(repoName)
            .setProject(projectName);

        return _createProjectVersion(config);
    }

    @PostMapping(value="", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProjectVersion(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestBody WebProjectVersionConfig config) throws Exception {

        config.setRepository(repoName).setProject(projectName);

        return _createProjectVersion(config);
    }

    private ResponseEntity<?> _createProjectVersion(WebProjectVersionConfig config)
            throws IOException {

        String repoName = config.getRepository();
        String projectName = config.getProject();
        String versionName = config.getVersionName();

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectVersion pv = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel()
                .newVersion(versionName);

        ProjectVersionConfig pconfig = new ProjectVersionConfig()
                .setName(config.getName())
                .setOriginalProject(projectName)
                .setProjectId(pv.getOriginalProject().getDependencyModel().getProject().getId())
                .setFeatures(config.getFeatures())
                .setComponents(config.getComponents())
                .setInterfaces(config.getInterfaces())
                .setVersions(config.getVersions())
                .setIsGroup(config.isGroup())
                .setCreateGlobalLib(config.isCreateGlobalLib())
                .setCreateSubLib(config.isCreateSubLib())
                .setLastChanged(System.currentTimeMillis());


        if (pv.create(pconfig))
            return new ResponseEntity<>(new WebProjectVersionModel(pv, requestUrl), HttpStatus.ACCEPTED);
        else
            return new ResponseEntity<>(new WebProjectVersionModel(pv, requestUrl), HttpStatus.FORBIDDEN);
    }
}

package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.common.ProjectTaskManager;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ModelConfig;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.VersioningModel;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.tasks.CreateVersionsSourceTask;
import ae.ebtic.spl.tasks.CreateGroupVersionSourceTask;
import ae.ebtic.spl.tasks.DeleteVersionSourceTask;
import ae.ebtic.spl.tasks.DeleteVersionTask;
import ae.ebtic.spl.tasks.ProjectTask;
import ae.ebtic.spl.versioning.ProjectVersion;
import ae.ebtic.spl.versioning.impl.ProjectVersionImpl;
import jext.util.FileUtils;

import java.io.File;
import java.util.*;
import java.util.stream.Collectors;

public class VersioningModelImpl extends ProjectModelImpl implements VersioningModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "version-config.json";

    private static final String VERSIONS = "versions";

    private File versionsFolder;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public VersioningModelImpl(SPLProject project){
        super(project, VersioningModel.TYPE);
        this.versionsFolder = new File(project.getSPLDirectory(), VERSIONS);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl) super.getInfo();

        Map<String, Object> counts = new HashMap<>();
        counts.put("versions", getVersions().size());

        info.put("count", counts);

        return info;
    }

    @Override
    public File getHomeFolder(){ return versionsFolder;}

    @Override
    public ModelConfig getConfiguration() {
        return configuration;
    }

    @Override
    protected boolean hasDependenciesResolved() {
        return getSPLProject().getFeatureModel().getStatus() == ModelStatus.VALID;
    }

    @Override
    public List<ProjectVersion> getVersions() {

        if(!versionsFolder.exists())
            return Collections.emptyList();

        return Arrays.asList(versionsFolder.listFiles(File::isDirectory))
                .stream()
                .filter(vFolder -> Arrays.asList(vFolder.listFiles()).stream().map(i -> i.getName()).anyMatch(i -> i.equals(MODEL_CONFIG))) //Folder must contain version-config.json to be a version folder
                .map(vFile -> new ProjectVersionImpl(this, vFile.getName() ))
                .filter(version -> version.getProjectId().equals(project.getDependencyModel().getProject().getId()) || version.getProjectId().equals(""))
                .sorted(Comparator.comparing(ProjectVersion::isGroup))
                .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Status handling
    // ----------------------------------------------------------------------

    @Override
    public long getTimestamp() { return configuration.getTimestamp(); }

    // @Override
    // public void setStatus(ModelStatus status, String message) {
    //     configuration.setStatus(status, message);
    // }

    // ----------------------------------------------------------------------
    // Task handling
    // ----------------------------------------------------------------------

    // @Override
    // public String getTaskId() {
    //     return configuration.getTaskId();
    // }

    // ----------------------------------------------------------------------
    // Model handling
    // ----------------------------------------------------------------------

    @Override
    protected ProjectTask createThis() {

        if(versionsFolder.mkdirs() || versionsFolder.exists()) {
            File configFile = new File(project.getSPLDirectory(), MODEL_CONFIG);
            if(!configFile.exists()) {
                checkStatus();
                configuration.save();
            }
            logger.info("Created versioning directory for " + project.getName());
            setStatus(ModelStatus.VALID, "Success");
        }
        else {
            logger.error("Failed to create versioning directory for " + project.getName());
            setStatus(ModelStatus.INVALID, "Failed");
        }

        return super.createThis();
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        ArrayList<ProjectVersion> versions = (ArrayList<ProjectVersion>) getVersions();
        for(ProjectVersion pv: versions){
            File source = new File(pv.getSourceFolder().getAbsolutePath());
            FileUtils.deleteAll(source);
            logger.debug("PV: "+source.exists());
        }

        FileUtils.deleteAll(versionsFolder);
        logger.debug("Versions: "+versionsFolder.exists());
        configuration.delete();
        setStatus(ModelStatus.NOT_EXISTENT, "Deleted");
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public ProjectVersion newVersion(String name) {
        return new ProjectVersionImpl(this, name);
    }

    @Override
    public void createVersionCode(ProjectVersion pv){
        modelCreateParams = new ModelCreateParams(WSTaskStatusListener.instance);
        CreateVersionsSourceTask task;

        if(pv.isGroup()) {
            task = new CreateGroupVersionSourceTask(pv);
        }
        else{
            task = new CreateVersionsSourceTask(pv);
        }
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());
        Managers.getTaskManager().submit(task);
    }

    @Override
    public void deleteVersionCode(ProjectVersion pv){
        DeleteVersionSourceTask task = new DeleteVersionSourceTask(pv);
        Managers.getTaskManager().submit(task);
    }

    @Override
    public void deleteVersion(ProjectVersion pv){
        DeleteVersionTask task = new DeleteVersionTask(pv);
        Managers.getTaskManager().submit(task);
    }


    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkStatus() {
        if (configuration == null) {

            File projectSpl = project.getSPLDirectory();
            File configFile = new File(projectSpl, MODEL_CONFIG);
            configuration = VersioningModelConfig.loadOrDefault(configFile);
        }
        super.checkStatus();
    }

    @Override
    public void checkModelStatus(){
        super.checkModelStatus();

        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        if (ProjectTaskManager.getTaskManager().hasRunning(this)) {
            setStatus(ModelStatus.TASK_RUNNING, null);
            return;
        }

        if (!versionsFolder.exists()) {
            setStatus(ModelStatus.NOT_EXISTENT, "versionsFolder not existent");
            return;
        }

        if (!configuration.exists()) {
            setStatus(ModelStatus.NOT_EXISTENT, "configuration not existent");
            return;
        }

        if(configuration.getStatus() != ModelStatus.VALID)
            setStatus(ModelStatus.VALID,"Success");
    }

}

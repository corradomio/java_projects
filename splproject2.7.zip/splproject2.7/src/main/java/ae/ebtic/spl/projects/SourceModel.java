package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.tasks.CommitSourcesTask;
import ae.ebtic.spl.tasks.UpdateSourcesTask;

import java.io.File;
import java.util.List;

public interface SourceModel extends ProjectModel {

    String TYPE = "source";

    /**
     * Local directory where the source code of the project is saved
     */
    File getSourceHome();

    /**
     * Source project: the implementation of this interface is specific for
     * different type of projects:
     *
     * - maven
     * - gradle
     * - netbeans
     * - ...
     *
     */
    Project getSourceProject() throws Exception;

    // ----------------------------------------------------------------------
    // Modules
    // ----------------------------------------------------------------------

    List<Module> getModules();

    Module getModule(String moduleName);

    // ----------------------------------------------------------------------
    // Sources
    // ----------------------------------------------------------------------

    List<Source> getSources();

    Source getSource(String sourceId);

    // ----------------------------------------------------------------------
    // Sources
    // ----------------------------------------------------------------------

    List<Library> getLibraries();

    Library getLibrary(String libraryId);

    // ----------------------------------------------------------------------
    // Versioning operations
    // ----------------------------------------------------------------------

    /** update the local model with the content of the remote repository */
    UpdateSourcesTask update();

    /** update the remote repository with the content of the local model */
    CommitSourcesTask commit();
}

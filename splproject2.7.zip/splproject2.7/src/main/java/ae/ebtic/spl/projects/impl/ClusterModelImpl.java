package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.clustering.ClusteringGraph;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.*;
import ae.ebtic.spl.tasks.ClusterNodesTask;
import ae.ebtic.spl.tasks.ProjectTask;

import java.util.Map;

public class ClusterModelImpl extends ProjectModelImpl implements ClusterModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "feature-config.json";

    private ClusteringGraph cg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ClusterModelImpl(SPLProject project) {
        super(project, ClusterModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public long getTimestamp() {
        return cg.getTimestamp();
    }

    @Override
    public ClusteringGraph getClusterGraph() {
        return cg;
    }

    @Override
    public Map<String, Object> getClusters(String model, int technique) {
        return cg.getClusters(model, technique);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected boolean hasDependenciesResolved() {
        return getSPLProject().getFeatureModel().getStatus() == ModelStatus.VALID;
    }

    @Override
    protected void checkStatus() {
        if (cg == null) {
            GraphConfig config = new GraphConfig()
                    .setGraphDatabase(Managers.getGraphDatabase())
                    .setProjectName(project.getName());
            //pg = cg = ClusteringGraph.newClusteringGraph(config);
            cg = ProjectGraphAccess.newProjectGraphAccess(config).getClusteringGraph();
            setProjectGraphAccess(cg);
        }
    }

    // ----------------------------------------------------------------------

    @Override
    protected ProjectTask createThis() {
        ClusterNodesTask task = new ClusterNodesTask(this);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());
        // Managers.getTaskManager().submit(task);
        return task;
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        cg.delete();
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkModelStatus() {

        // if (!cg.exists()) {
        //     setStatus(ModelStatus.NOT_EXISTENT, null);
        //     return;
        // }
        if (!STATUS_VALID.equals(cg.getStatus())) {
            setStatus(ModelStatus.valueOf(cg.getStatus()), String.format("Graph in status %s", cg.getStatus()));
            return;
        }

        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        FeatureModel featureModel = getSPLProject().getFeatureModel();

        // check the status of the dependency model
        if (featureModel.getStatus() != ModelStatus.VALID) {
            setStatus(ModelStatus.INVALID, String.format("Feature Model has status %s", featureModel.getStatus()));
            return;
        }

        // check the models timestamps
        if (featureModel.getTimestamp() > getTimestamp()) {
            logger.warnf("INVALID because the Feature Model is more recent");
            setStatus(ModelStatus.INVALID, "Feature Model is more recent");
            return;
        }
    }

}

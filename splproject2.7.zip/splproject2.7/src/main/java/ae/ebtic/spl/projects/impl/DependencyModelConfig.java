package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class DependencyModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public DependencyModelConfig() {
        super();
    }

    public static DependencyModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(DependencyModelConfig.class);

        if (configFile.exists())
        try {
            return (DependencyModelConfig) JSONUtils.load(configFile, DependencyModelConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
        }

        return (DependencyModelConfig) new DependencyModelConfig().configIn(configFile);
    }

}

package ae.ebtic.spl.managers.system;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class SystemManagerFactory {

    public static SystemManager createManager(Configuration config) throws ConfigurationException {
        SystemManager manager = new SystemManagerImpl();
        manager.configure(config);
        return manager;
    }
}

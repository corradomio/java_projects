package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.sourcecode.model.Parameter;
import ae.ebtic.spl.managers.Managers;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.logging.Logger;
import jext.security.StringCipher;
import jext.util.JSONUtils;
import jext.util.Parameters;

import java.io.File;
import java.io.IOException;
import java.util.Properties;

/**
 * Project configuration.
 *
 * It is necessary to define:
 *
 *      1) URL from where to download the sources
 *          git
 *          svn
 *          ftp
 *          file
 *      2) version, if supported
 *
 *
 * It is possible to create a LINK to another project already present
 * in the current filesystem, using the procolo:
 *
 *      "link:///..."
 *
 * This must be considered similar to "file:///...", BUT
 *
 */

public class SPLProjectConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static final String LINK_PROTOCOL = "link:///";
    private static final String PASSWORD = "password";

    private String url = ".";
    private String description = "";
    private Parameters parameters = new Parameters();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLProjectConfig() { }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- url

    public String getURL() { return url; }

    public SPLProjectConfig setURL(String url) {
        this.url = url; return this;
    }

    // -- description

    public String getDescription() {
        return description;
    }

    public SPLProjectConfig setDescription(String description) {
        this.description = description; return this;
    }

    // -- properties

    public SPLProjectConfig setParameters(Parameters params) {
        parameters.putAll(params);
        return this;
    }

    public Parameters getParameters() {
        return parameters;
    }

    // ----------------------------------------------------------------------
    // 'link:///' protocol support
    // ----------------------------------------------------------------------

    @JsonIgnore
    public boolean isLinkedProject() {
        return url.startsWith(LINK_PROTOCOL);
    }

    @JsonIgnore
    public File getProjectRoot() {
        if (!url.startsWith(LINK_PROTOCOL))
            return null;

        String path = url.substring(LINK_PROTOCOL.length());
        return new File(path);
    }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    public ModelConfig save() {
        try {
            configFile.getParentFile().mkdirs();

            encryptPasswords();
            JSONUtils.save(configFile, this);
            decriptPasswords();
        }
        catch (IOException e) {
            logger.error(e, e);
        }

        return this;
    }

    public static SPLProjectConfig loadOrDefault(File configFile) {
        if (configFile.exists())
        try {
            SPLProjectConfig config = JSONUtils.load(configFile, SPLProjectConfig.class).configIn(configFile);
            return config.decriptPasswords();
        }
        catch (Exception e) {
            Logger.getLogger(SPLProject.class).errorf("Unable to read %s: %s", configFile, e);
        }

        return new SPLProjectConfig().configIn(configFile);
    }

    // Used just to have the correct return type
    public SPLProjectConfig configIn(File configFile) {
        super.configIn(configFile);
        return this;
    }

    // ----------------------------------------------------------------------
    // Password handling
    // ----------------------------------------------------------------------

    private SPLProjectConfig encryptPasswords() {
        if (parameters.containsKey(PASSWORD)){
            String systemPassword = Managers.getConfidentialManager().getSystemPassword();
            String password = parameters.getString(PASSWORD);
            parameters.put(PASSWORD, StringCipher.encrypt(systemPassword, password));
        }
        return this;
    }

    private SPLProjectConfig decriptPasswords() {
        if (parameters.containsKey(PASSWORD)) {
            String systemPassword = Managers.getConfidentialManager().getSystemPassword();
            String password = parameters.getString(PASSWORD);
            parameters.put(PASSWORD, StringCipher.decrypt(systemPassword, password));
        }
        return this;
    }

}

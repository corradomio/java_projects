package ae.ebtic.spl.projects;

import ae.ebtic.spl.versioning.ProjectVersion;

import java.io.File;
import java.util.List;


public interface VersioningModel extends ProjectModel {

    // ----------------------------------------------------------------------
    // Version Handler Properties
    // ----------------------------------------------------------------------

    String TYPE = "versioning";

    File getHomeFolder();

    // ----------------------------------------------------------------------
    // Project Versions Properties
    // ----------------------------------------------------------------------

    List<ProjectVersion> getVersions();

    ProjectVersion newVersion(String name);

    void createVersionCode(ProjectVersion pv);

    void deleteVersionCode(ProjectVersion pv);

    void deleteVersion(ProjectVersion pv);

}

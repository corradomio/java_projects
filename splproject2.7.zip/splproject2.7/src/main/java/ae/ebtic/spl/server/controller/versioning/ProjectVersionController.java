package ae.ebtic.spl.server.controller.versioning;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.VersioningModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.versioning.WebProjectVersionModel;
import ae.ebtic.spl.versioning.ProjectVersion;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/versioning/versions/{versionId}")
public class ProjectVersionController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectVersionController() {
        super("version");
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getVersion(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);

        return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv, requestUrl).detailed(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Delete
    // ----------------------------------------------------------------------

    @GetMapping("delete")   // (DEBUG)
    @ResponseBody
    public ResponseEntity<?> deleteVersionByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId)
    {
        return deleteVersion(repoName, projectName, versionId);
    }

    @DeleteMapping("")
    @ResponseBody
    public ResponseEntity<?> deleteVersion(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();


        ProjectVersion pv = vh.newVersion(versionId);

        if(pv == null)
            return null;

        if(pv.delete())
            return new ResponseEntity<WebProjectVersionModel>((WebProjectVersionModel)new WebProjectVersionModel(pv, requestUrl), HttpStatus.OK);
        else
            return new ResponseEntity<WebProjectVersionModel>((WebProjectVersionModel)new WebProjectVersionModel(pv, requestUrl), HttpStatus.FORBIDDEN);

    }

    // ----------------------------------------------------------------------
    // createSC
    // ----------------------------------------------------------------------

    //TODO: add webconfig
    @GetMapping("createSC")  // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> createSC(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectVersion pv = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel()
                .newVersion(versionId);

        boolean isCreated = false;
        try {
            isCreated = pv.createSC();
        }
        catch (IOException e) {
            logger.error(e);
            return new ResponseEntity<>(HttpStatus.FORBIDDEN);
        }

        if(isCreated)
            return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv, requestUrl).detailed(), HttpStatus.OK);
        else
            return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv, requestUrl).detailed(), HttpStatus.FORBIDDEN);

    }

    // ----------------------------------------------------------------------
    // Elements
    // ----------------------------------------------------------------------

    @GetMapping("elements")
    @ResponseBody
    public ResponseEntity<?> getElementsList(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);

        Map<String, Object> elements = new HashMap<>();

        if(pv.isGroup()) {
            List<WebProjectVersionModel> versions = pv.getConfiguration().getVersions()
                    .stream()
                    .map(v -> vh.newVersion(v))
                    .map(v -> new WebProjectVersionModel(v, requestUrl))
                    .collect(Collectors.toList());

            elements.put("versions", versions);
            elements.put("createGlobalLib", pv.isCreateGlobalLibrary());
            elements.put("createSubLib", pv.isCreateSubLibrary());
        }
        else{
            List<WebFeatureModel> features = pv.getConfiguration().getFeatures()
                    .stream()
                    .map(f -> pv.getOriginalProject().getFeatureModel().getFeature(f))
                    .map(f -> new WebFeatureModel(f, requestUrl))
                    .collect(Collectors.toList());

            List<WebComponentModel> components = pv.getConfiguration().getComponents()
                    .stream()
                    .map(c -> pv.getOriginalProject().getComponentModel().getComponent(c))
                    .map(c -> new WebComponentModel(c, requestUrl))
                    .collect(Collectors.toList());

            List<WebTypeModel> interfaces = pv.getConfiguration().getInterfaces()
                    .stream()
                    .map(i -> pv.getOriginalProject().getDependencyModel().getType(i))
                    .map(i -> new WebTypeModel(i, requestUrl))
                    .collect(Collectors.toList());

            elements.put("features", features);
            elements.put("components", components);
            elements.put("interfaces", interfaces);
        }

        return new ResponseEntity<>(elements, HttpStatus.OK);
    }

    @PostMapping("editElements")  // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> editElementsDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId,
        @RequestBody  Map<String, Object> elements) {
        return editElements(repoName, projectName, versionId, elements);
    }

    @PutMapping("elements/edit")
    @ResponseBody
    public ResponseEntity<?> editElements(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId,
        @RequestBody  Map<String, Object> elements)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);
        if (pv == null) {
            logger.errorf("Project Version %s not existent", versionId);
            return null;
        }

        if(pv.isGroup()){
            List<String> versions = (List<String>) elements.getOrDefault("versions", pv.getConfiguration().getVersions());
            boolean createGlobalLib = (boolean) elements.getOrDefault("createGlobalLib", pv.isCreateGlobalLibrary());
            boolean createSubLib = (boolean) elements.getOrDefault("createSubLib", pv.isCreateSubLibrary());

            pv.setVersions(versions)
                    .setCreateGlobalLibrary(createGlobalLib)
                    .setCreateSubLibrary(createSubLib);
        }
        else {
            List<String> features = (List<String>) elements.get("features");
            List<String> components = (List<String>) elements.get("components");
            List<String> interfaces = (List<String>) elements.get("interfaces");

            pv.setFeatures(features)
                    .setComponents(components)
                    .setInterfaces(interfaces);
        }

        pv.getConfiguration().setLastChanged(System.currentTimeMillis());

        pv.getConfiguration().save();

        pv.deleteSC();

        return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv,requestUrl).detailed(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Features
    // ----------------------------------------------------------------------

    @GetMapping("features")
    @ResponseBody
    public ResponseEntity<?> getFeaturesList(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);

        List<WebFeatureModel> features = pv.getConfiguration().getFeatures()
            .stream()
            .map(f -> pv.getOriginalProject().getFeatureModel().findFeatureByName(f))
            .map(f -> new WebFeatureModel(f, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(features, HttpStatus.OK);
    }


    @PostMapping("removeFeatures")  // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> removeFeaturesDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId,
        @RequestBody ArrayList<String> features) {
        return removeFeatures(repoName, projectName,versionId, features);
    }


    @DeleteMapping("features")
    @ResponseBody
    public ResponseEntity<?> removeFeatures(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId,
            @RequestBody ArrayList<String> features)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);

        for(String f: features){
            pv.remove(f);
        }

        pv.getConfiguration().save();
        pv.deleteSC();

        return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv,requestUrl).detailed(), HttpStatus.OK);
    }

    @PostMapping("addFeatures")  // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> addFeaturesDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId,
        @RequestBody ArrayList<String> features) {
        return addFeatures(repoName, projectName,versionId, features);
    }

    @PutMapping("features")
    @ResponseBody
    public ResponseEntity<?> addFeatures(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId,
            @RequestBody ArrayList<String> features)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);

        for(String f: features){
            pv.add(f,"feature");
        }

        pv.getConfiguration().save();
        pv.deleteSC();

        return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv,requestUrl).detailed(), HttpStatus.OK);
    }

    @PostMapping("editFeatures")    // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> editFeaturesDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String versionId,
        @RequestBody  ArrayList<String> features) {
        return editFeatures(repoName, projectName, versionId, features);
    }

    @PutMapping("features/edit")
    @ResponseBody
    public ResponseEntity<?> editFeatures(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId,
            @RequestBody  ArrayList<String> features)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);
        if (pv == null) {
            logger.errorf("Project Version %s not existent", versionId);
            return null;
        }

        pv.clearFeatures();

        for(String f: features){
            pv.add(f,"feature");
        }

        pv.getConfiguration().save();

        pv.deleteSC();

        return new ResponseEntity<>((WebProjectVersionModel)new WebProjectVersionModel(pv,requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping("download")
    @ResponseBody
    public ResponseEntity<?> downloadVersion(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String versionId)
    {
        logger.infof("%s.%s.versioning.versions.download(%s)", repoName, projectName, versionId);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        VersioningModel vh = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getVersioningModel();

        if (!vh.exists()) {
            ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance);
            vh.create(params);
            if(!vh.exists()) {
                logger.errorf("Versioning Handler not existent");
                return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
            }
        }

        ProjectVersion pv = vh.newVersion(versionId);
        if (pv == null) {
            logger.errorf("Project Version %s not existent", versionId);
            return null;
        }

        byte[] versionFile = pv.getSC();
        HttpHeaders header = new HttpHeaders();
        header.setContentType(new MediaType("application", "zip"));
        header.setContentLength(versionFile.length);
        return new ResponseEntity<>(versionFile, HttpStatus.OK);

    }

}

package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.tasks.ProjectTask;

import java.util.concurrent.TimeUnit;

public interface ProjectModel extends Named {

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    /**
     * Retrieve the SPL project owner of this model
     */
    SPLProject getSPLProject();

    /**
     * Information on the model
     * (it depends on the model type)
     */
    ModelInfo getInfo();

    /**
     * Model type
     */
    String getType();

    /**
     * Creation/last update timestamp (this value is saved in the db)
     */
    long getTimestamp();

    /**
     * model configuration
     */
    ModelConfig getConfiguration();

    // ----------------------------------------------------------------------
    // Status handling
    // ----------------------------------------------------------------------

    /**
     * Get model status:
     *
     *  NOT_EXISTENT    the model doesn't exists
     *  TASK_RUNNING    a task is running
     *  VALID           the model exists and it is NOT valid
     *  INVALID         the model exists and it is valid
     *
     *  See @getReason() to have a message on the status
     *
     */
    ModelStatus getStatus();
    String getReason();

    /**
     * Set the new model status
     *
     * @param status new status
     * @param message a simple message related to the status change
     */
    void setStatus(ModelStatus status, String message);

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    /**
     * Check if the model exists: it exists IF
     * - exists the configuration file AND
     * - exists some specific object related to the model
     */
    boolean exists();

    /**
     * Check if the model can be create.
     * A model can be create IF:
     *
     * - it is NOT running (it doesn't exist or is VALID/NOT_VALID)
     * - has all dependencies resolved
     */
    boolean canCreate();

    /**
     * Create the model.
     *
     * Note: if the model already exists or a task is running the operation fails
     *       otherwise a task is created to create the model
     */
    ProjectTask create(ModelCreateParams params);


    /**
     * Check if it is possible to delete.
     * Note: not implemented yet
     */
    boolean canDelete();

    /**
     * Delete the model.
     * If the model doesn't exists, it does nothing
     * If a thread is running, it abort the thread BUT doesn't delete the model.
     * The model will be in state INVALID
     * If the model exists, deletes it
     */
    void delete();

    // ----------------------------------------------------------------------
    // Task handling
    // ----------------------------------------------------------------------
    // TODO: TO REMOVE!!!!

    ProjectTask getTask();

    /**
     * Same as 'getStatus() == ModelStatus.TASK_RUNNING
     */
    boolean isRunning();

    /**
     * Abort the running task if it exists
     *
     * == getTask().abort()
     */
    void abort();

    void create();

    /**
     * Wait for the completion of the running task, is it exists
     *
     * == getTask().waitForCompletion(...)
     */
    void waitForCompletion(long timeout, TimeUnit timeUnit);

}

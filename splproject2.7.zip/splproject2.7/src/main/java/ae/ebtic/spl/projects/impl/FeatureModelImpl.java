package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.features.FeatureGraph;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.tasks.AnalyzeFeaturesTask;
import ae.ebtic.spl.tasks.CreateManualFeatureTask;
import ae.ebtic.spl.tasks.ProjectTask;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class FeatureModelImpl extends ProjectModelImpl implements FeatureModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "feature-config.json";

    private FeatureGraph fg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FeatureModelImpl(SPLProject project) {
        super(project, FeatureModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl) super.getInfo();

        Map<String, Object> counts = new HashMap<>();
        counts.put("features", fg.getFeaturesCount());

        info.put("count", counts);

        return info;
    }

    @Override
    public long getTimestamp() {
        return fg.getTimestamp();
    }

    @Override
    public FeatureGraph getFeatureGraph() {
        return fg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public int getFeaturesCount() {
        return (int)fg.getFeaturesCount();
    }

    @Override
    public List<Feature> getFeatures() {
        return fg.getFeatures();
    }

    @Override
    public Feature getFeature(String featureId) {
        return fg.getFeature(featureId);
    }

    @Override
    public Feature findFeatureByName(String featureName) {
        return fg.findFeatureByName(featureName);
    }

    @Override
    public List<Component> getFeatureComponents(String featureId) {
        return fg.getFeatureComponents(featureId);
    }

    @Override
    public List<Component> getFeaturesComponents(List<String> ids) {
        Set<Component> components = new HashSet<>();

        for (String featureId : ids) {
            components.addAll(getFeatureComponents(featureId));
        }

        return new ArrayList<>(components);
    }

    @Override
    public List<Type> getFeatureTypes(String featureId) {
        return fg.getFeatureTypes(featureId);
    }

    @Override
    public List<Type> getFeaturesTypes(List<String> ids) {
        Set<Type> types = new HashSet<>();

        for(String featureId : ids) {
            types.addAll(getFeatureTypes(featureId));
        }

        return new ArrayList<>(types);
    }

    @Override
    public List<Type> addContext(List<Type> types, boolean interfaces, boolean links, boolean implementations) {
        return pga.getDependencyGraph().addContext(types, interfaces, links, implementations);
    }


    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public List<Feature> getFeaturesByComponents(List<Integer> componentIds) {return fg.getFeaturesByComponents(componentIds);}

    @Override
    public Feature newFeature(String fullname) {
        return fg.newFeature(fullname);
    }

    @Override
    public Map<String, Object> getModelGraph() {
        return fg.getModelGraph();
    }

    @Override
    public Map<String, Object> getSmallModelGraph() {
        return fg.getSmallModelGraph();
    }

    @Override
    public Map<String, Object> findIntegrationPoints(List<String> featureIds) {
        return fg.findIntegrationPoints(featureIds);
    }

    @Override
    public List<Map<String, Object>> getComponents(String featureId) {
        return fg.getComponentsGraph(featureId);
    }

    @Override
    public void setTypesCount() {
        fg.setTypesCount();
    }

    @Override
    public Map<String, Object> getTypesCount() {
        return fg.getTypesCount();
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    @Override
    public Map<String, Object> getTypes(String featureId) {
        return fg.listTypes(featureId);
    }

    @Override
    public Map<String, Object> getTypesWInterfaces(String featureId, boolean links, boolean implementation){
        return fg.listTypesWInterfaces(featureId,links,implementation);
    }

    @Override
    public Map<String, Object> exportFeatureToXLSX(String featureId, boolean implementation, double coreThreshold, boolean fullName){
        return fg.exportFeatureToXLSX(featureId, implementation, coreThreshold, fullName);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected boolean hasDependenciesResolved() {
        return getSPLProject().getComponentModel().getStatus() == ModelStatus.VALID;
    }

    @Override
    protected void checkStatus() {
        if (fg == null) {
            GraphConfig config = new GraphConfig()
                .setGraphDatabase(Managers.getGraphDatabase())
                .setProjectName(project.getName());
            //pg = fg = FeatureGraph.newFeatureGraph(config);
            fg = ProjectGraphAccess.newProjectGraphAccess(config).getFeatureGraph();
            setProjectGraphAccess(fg);
        }
    }

    // ----------------------------------------------------------------------

    @Override
    protected ProjectTask createThis() {
        fg.create();

        AnalyzeFeaturesTask task = new AnalyzeFeaturesTask(this);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());
        // Managers.getTaskManager().submit(task);
        return task;
    }

    @Override
    public CreateManualFeatureTask manualCreate(List<String> features, List< List<String> > components){
        fg.create();

        CreateManualFeatureTask task = new CreateManualFeatureTask(this,features,components);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());
        //Managers.getTaskManager().submit(task);
        return task;
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        fg.delete();
    }


    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkModelStatus() {

        // if (!fg.exists()) {
        //     setStatus(ModelStatus.NOT_EXISTENT, null);
        //     return;
        // }
        if (!STATUS_VALID.equals(fg.getStatus())) {
            setStatus(ModelStatus.valueOf(fg.getStatus()), String.format("Graph in status %s", fg.getStatus()));
            return;
        }

        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        ComponentModel componentModel = getSPLProject().getComponentModel();

        // check the status of the dependency model
        if (componentModel.getStatus() != ModelStatus.VALID) {
            setStatus(ModelStatus.INVALID, String.format("ComponentModel has status %s", componentModel.getStatus()));
            return;
        }

        // check the models timestamps
        if (componentModel.getTimestamp() > getTimestamp()) {
            setStatus(ModelStatus.INVALID, "ComponentModel is more recent");
            return;
        }
    }

}

package ae.ebtic.spl.server.controller.component;

import ae.ebtic.spl.analysis.diagrams.TypeDiagram;
import ae.ebtic.spl.analysis.diagrams.TypeDiagramConfig;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.DiagramsModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.diagram.WebTypeDiagram;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/component")
public class ComponentDiagramsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ComponentDiagramsController() {
        super(ComponentModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // typeDiagrams
    // ----------------------------------------------------------------------

    // DEBUG
    @GetMapping(value = "tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, config);
    }

    // DEBUG
    @GetMapping(value = "components/{componentId}/tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, componentId, config);
    }

    // --

    @PostMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig tdconfig) {
        return getTypeDiagram(repoName, projectName, tdconfig);
    }

    @GetMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig config) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }

    @PostMapping(value = "components/{componentId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId,
        @RequestBody TypeDiagramConfig config) {
        return getTypeDiagram(repoName, projectName, componentId, config);
    }

    @GetMapping(value = "components/{componentId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId,
        @RequestBody TypeDiagramConfig config) {

        config.addId(componentId);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // graph
    // sgraph
    // ----------------------------------------------------------------------

    /**
     * Retrieve the graph
     */
    @GetMapping(value = "graph")
    @ResponseBody
    public ResponseEntity<?> getModelGraph(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "depth", defaultValue = "0") int depth,
        @RequestParam(value = "small", defaultValue = "false") boolean small)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        Map<String, Object> graph;
        if (small)
            graph = cm.getSmallModelGraph(depth);
        else
            graph = cm.getModelGraph(depth);

        return new ResponseEntity<>(graph, HttpStatus.OK);
    }

    /**
     * (DEPRECATED)
     * Retrieve the graph
     */
    @GetMapping(value = "sgraph")
    @ResponseBody
    public ResponseEntity<?> getSmallModelGraph(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "depth", defaultValue = "0") int depth)
    {
        return getModelGraph(repoName, projectName, depth, true);
    }

}

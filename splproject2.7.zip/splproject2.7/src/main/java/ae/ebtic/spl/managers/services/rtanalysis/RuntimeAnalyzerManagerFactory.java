package ae.ebtic.spl.managers.services.rtanalysis;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class RuntimeAnalyzerManagerFactory {

    public static RTAnalysisManager createManager(Configuration config) throws ConfigurationException {
        RTAnalysisManager manager = new RuntimeAnalyzerManagerImpl();
        manager.configure(config);
        return manager;
    }
}

package ae.ebtic.spl.server.controller.uploads;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.managers.uploads.UploadsService;
import ae.ebtic.spl.server.controller.SPLRestController;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.IOException;
import java.util.List;

@CrossOrigin
@Controller
@RequestMapping("/spl/uploads")
public class FileUploadController extends SPLRestController {

    private static final String TYPE = "fileUpload";

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FileUploadController() {
        super(TYPE);
    }

    // ----------------------------------------------------------------------
    // Web services
    // ----------------------------------------------------------------------

    @GetMapping("stores")
    @ResponseBody
    public ResponseEntity<?> getUploadStores() {
        List<String> uploadStores = Managers.getUploadsService().getUploadStores();
        return ResponseEntity.ok(uploadStores);
    }


    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> listUploadedFiles(
        @RequestParam(value = "store", defaultValue = "") String store,
        @RequestParam(value = "directory", defaultValue = "") String directory) {
        List<String> uploadedFiles = Managers.getUploadsService().getUploadedFiles(store, directory);
        return ResponseEntity.ok(uploadedFiles);
    }

    @PostMapping("")
    public String handleFileUpload(
        @RequestParam(value = "store", defaultValue = "") String store,
        @RequestParam(value = "directory", defaultValue = "") String directory,
        @RequestParam(value = "file") MultipartFile file,
        RedirectAttributes redirectAttributes) throws IOException {

        UploadsService uploadsService = Managers.getUploadsService();

        uploadsService.store(store, directory, file);
        redirectAttributes.addFlashAttribute("message",
            "You successfully uploaded " + file.getOriginalFilename() + "!");

        return "redirect:/spl/uploads";
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

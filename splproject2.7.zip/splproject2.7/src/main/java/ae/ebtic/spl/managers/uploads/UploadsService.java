package ae.ebtic.spl.managers.uploads;

import jext.logging.Logger;
import jext.util.FileUtils;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class UploadsService {

    // ----------------------------------------------------------------------
    // Factory
    // ----------------------------------------------------------------------

    public static UploadsService createService(String path) {
        File uploadFolder = new File(path);
        if (!uploadFolder.exists() && !uploadFolder.mkdirs()) {
            logger.errorf("Unable to create the directory %s", uploadFolder.getAbsolutePath());
            uploadFolder = new File(".");
        }

        return new UploadsService(uploadFolder);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(UploadsService.class);

    private File uploadDir;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private UploadsService(File uf) {
        uploadDir = uf;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public List<String> getUploadStores() {
        return Collections.singletonList("uploads");
    }

    public String getUploadDir() {
        return FileUtils.getAbsolutePath(uploadDir);
    }



    public List<String> getUploadedFiles(String store, String directory) {
        File rootDir;
        if (StringUtils.isEmpty(directory))
            rootDir = uploadDir;
        else
            rootDir = new File(uploadDir, directory);
        return Arrays.asList(rootDir.list());
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void store(MultipartFile file) throws IOException {
        String filename = StringUtils.cleanPath(file.getOriginalFilename());
        if (file.isEmpty()) {
            throw new IOException("Failed to store empty file " + filename);
        }
        if (filename.contains("..")) {
            // This is a security check
            throw new IOException(
                "Cannot store file with relative path outside current directory "
                    + filename);
        }
        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, this.uploadDir.toPath().resolve(filename),
                StandardCopyOption.REPLACE_EXISTING);
        }
    }

    public void store(String store, String directory, MultipartFile file) throws IOException {
        String filename = StringUtils.cleanPath(file.getOriginalFilename());
        if (file.isEmpty()) {
            throw new IOException("Failed to store empty file " + filename);
        }
        if (filename.contains("..")) {
            // This is a security check
            throw new IOException(
                "Cannot store file with relative path outside current directory "
                    + filename);
        }

        File toFile;
        if (!StringUtils.isEmpty(directory)) {
            toFile = new File(uploadDir, directory + "/" + filename);
            toFile.getParentFile().mkdirs();
        }
        else
            toFile = new File(uploadDir, filename);

        try (InputStream inputStream = file.getInputStream()) {
            Files.copy(inputStream, toFile.toPath(),
                StandardCopyOption.REPLACE_EXISTING);
        }
    }
    public void destroy() {

    }
}

package ae.ebtic.spl.server.controller.feature;

import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/feature/features/{featureId}")
public class FeatureController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FeatureController() {
        super(FeatureModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getFeature(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        Feature feature = fm.getFeature(featureId);

        return new ResponseEntity<>((WebFeatureModel)new WebFeatureModel(feature, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping(value = "components")
    @ResponseBody
    public ResponseEntity<?> getFeatureComponentsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        List<WebComponentModel> components = fm.getFeatureComponents(featureId)
            .stream()
            .map(component -> new WebComponentModel(component, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(components, HttpStatus.OK);
    }

    @GetMapping(value = "types")
    @ResponseBody
    public ResponseEntity<?> getFeatureTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestParam(value = "itfcs",  defaultValue = "false") boolean itfcs,
        @RequestParam(value = "link",  defaultValue = "true") boolean links,
        @RequestParam(value = "imp", defaultValue = "true") boolean implementation)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        List<Type> featureTypes = fm.getFeatureTypes(featureId);

        featureTypes = fm.addContext(featureTypes, itfcs, links, implementation);

        List<WebTypeModel> types = featureTypes.stream()
            .map(type -> new WebTypeModel(type, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // export
    // ----------------------------------------------------------------------

    @GetMapping(value = "export")
    @ResponseBody
    public ResponseEntity<?> exportFeature(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestParam(value = "format", defaultValue = "xslx") String format,
        @RequestParam(value = "imp", defaultValue = "true") boolean implementation,
        @RequestParam(value = "core", defaultValue = "0.7") double coreThreshold,
        @RequestParam(value = "fullName", defaultValue = "false") boolean fullName)
    {
        return _exportToXLSX(repoName, projectName, featureId, implementation, coreThreshold, fullName);
    }

    /**
     * (DEPRECATED)
     */
    @GetMapping(value = "exportToCSV")
    @ResponseBody
    public ResponseEntity<?> exportToXLSXbyGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestParam(value = "imp", defaultValue = "true") boolean implementation,
        @RequestParam(value = "core", defaultValue = "0.7") double coreThreshold,
        @RequestParam(value = "fullName", defaultValue = "false") boolean fullName)
    {
        return _exportToXLSX(repoName, projectName, featureId, implementation, coreThreshold, fullName);
    }

    /**
     * (DEPRECATED)
     */
    @PostMapping(value = "exportToCSV")
    @ResponseBody
    public ResponseEntity<?> exportToXLSXbyPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestBody Map<String, Object> exportOptions)
    {
        boolean implementation = (Boolean) exportOptions.getOrDefault("imp",true);
        double coreThreshold = (Double) exportOptions.getOrDefault("core",0.7);
        boolean fullName =  (Boolean) exportOptions.getOrDefault("fullName",false);

        return _exportToXLSX(repoName, projectName, featureId, implementation, coreThreshold, fullName);
    }

    private ResponseEntity<?> _exportToXLSX(
        String repoName,
        String projectName,
        String featureId,
        boolean implementation,
        double coreThreshold,
        boolean fullName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        if (!fm.exists()) {
            logger.errorf("FeatureModel %s not existent", fm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        Map<String, Object> result = fm.exportFeatureToXLSX(featureId, implementation, coreThreshold, fullName);
        byte[] excelFile =  (byte[]) result.get("result");
//
//        // prepare response
        HttpHeaders header = new HttpHeaders();
        header.setContentType(new MediaType("application", "vnd.openxmlformats-officedocument.spreadsheetml.sheet"));
        header.setContentLength(excelFile.length);
        return new ResponseEntity<>(excelFile, HttpStatus.OK);
    }

}

package ae.ebtic.spl.managers;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public interface Manager {

    String getName();

    void configure(Configuration config) throws ConfigurationException;

    void destroy();

}

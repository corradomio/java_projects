package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.dependency.WebFieldModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency/fields")
public class FieldsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FieldsController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("{fieldId}")
    @ResponseBody
    public ResponseEntity<?> getTypeField(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String fieldId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Field field = dm.getDependencyGraph().getField(fieldId);

        return new ResponseEntity<>((WebFieldModel)new WebFieldModel(field, requestUrl).detailed(), HttpStatus.OK);
    }

}

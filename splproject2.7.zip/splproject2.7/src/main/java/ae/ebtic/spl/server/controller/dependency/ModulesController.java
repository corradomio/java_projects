package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.dependency.WebLibraryModel;
import ae.ebtic.spl.server.webmodels.dependency.WebModuleModel;
import ae.ebtic.spl.server.webmodels.dependency.WebSourceModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency/modules")
public class ModulesController extends SPLRestController  {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModulesController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public ResponseEntity<?> getModulesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        List<WebModuleModel> modules = dm.getModules()
            .stream()
            .map(module -> new WebModuleModel(module, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(modules, HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}")
    @ResponseBody
    public ResponseEntity<?> getModule(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Module module = dm.getModule(moduleId);

        return new ResponseEntity<>((WebModuleModel)new WebModuleModel(module, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}/sources")
    @ResponseBody
    public ResponseEntity<?> getModuleSourcesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Module module = dm.getModule(moduleId);

        List<WebSourceModel> sources = module.getSources()
            .stream()
            .map(source -> new WebSourceModel(source, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(sources, HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}/types")
    @ResponseBody
    public ResponseEntity<?> getModuleTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Module module = dm.getModule(moduleId);

        List<WebTypeModel> types = module.getTypes(false)
            .stream()
            .map(type -> new WebTypeModel(type, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }


    @GetMapping(value = "{moduleId}/libraries")
    @ResponseBody
    public ResponseEntity<?> getModuleLibrariesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Module module = dm.getModule(moduleId);

        List<WebLibraryModel> libraries = module.getLibraries()
            .stream()
            .map(library -> new WebLibraryModel(library, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(libraries, HttpStatus.OK);
    }

}

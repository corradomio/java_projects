package ae.ebtic.spl.server.controller.component;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.util.IdList;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebModelModel;
import ae.ebtic.spl.server.webmodels.WebModelsFactory;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import jext.graph.NodeDegree;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/component")
public class ModelComponentController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelComponentController() {
        super(ComponentModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    /**
     * List of components
     */
    @GetMapping("components")
    @ResponseBody
    public ResponseEntity<?> getComponentsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "depth", defaultValue = "0") int depth,
        @RequestParam(value = "indegree",  defaultValue = "") String indegree,
        @RequestParam(value = "outdegree", defaultValue = "") String outdegree) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        NodeDegree ndegree = NodeDegree.newNodeDegree(indegree, outdegree);

        List<WebComponentModel> components = cm.getComponents(depth, ndegree)
            .stream()
            .map(dt -> new WebComponentModel(dt, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(components, HttpStatus.OK);
    }

    /**
     * List of features
     */
    @GetMapping("features")
    @ResponseBody
    public ResponseEntity<?> getComponentsFeaturesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody IdList ids)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        List<WebFeatureModel> features = cm.getComponentsFeatures(ids.getIds())
            .stream()
            .map(feature -> new WebFeatureModel(feature, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(features, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // TypeCounts (DEPRECATED)
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     * Set the number of classes inside the features
     */
    @GetMapping(value = "setTypesCount")                // (DEPRECATED)
    @ResponseBody
    public ResponseEntity<?> setTypesCountDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getComponentModel();

        cm.setTypesCount();

        WebModelModel webmodel = WebModelsFactory.of(cm, requestUrl);
        return new ResponseEntity<>(webmodel, HttpStatus.OK);
    }

    /**
     * (DEPRECATED)
     *
     * Retrieve the number of classes inside the features
     */
    @GetMapping(value = "getTypesCount")
    @ResponseBody
    public ResponseEntity<?> getTypesCountDeprecated(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestParam(value = "depth", defaultValue = "-1") int depth)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        return new ResponseEntity<>(cm.getTypesCount(depth), HttpStatus.OK);
    }


    // ----------------------------------------------------------------------
    // DEPRECATED
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     */
    @GetMapping("{componentId}/types")
    @ResponseBody
    public ResponseEntity<?> getComponentTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        Component c = cm.getComponent(componentId);

        List<WebTypeModel> types = c.getTypes()
            .stream()
            .map(dt -> new WebTypeModel(dt, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }

    /**
     * (DEPRECATED)
     */
    @GetMapping("{componentId}/members")
    @ResponseBody
    public ResponseEntity<?> getComponentMembersList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String componentId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ComponentModel cm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getComponentModel();

        return new ResponseEntity<>(cm.getComponentMembers(componentId), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

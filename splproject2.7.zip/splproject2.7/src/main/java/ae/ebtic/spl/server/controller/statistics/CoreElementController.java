package ae.ebtic.spl.server.controller.statistics;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.CoreElementModel;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.StatisticsModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.statistics.CoreElement;
import ae.ebtic.spl.statistics.impl.CoreElementImpl;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/statistics/elements/core")
public class CoreElementController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public CoreElementController() {
        super(CoreElementModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     */
    @PostMapping(value="getValues")
    @ResponseBody
    public ResponseEntity<?> coreValuesByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody String alpha) {

        return this.coreValuesByGet(repoName, projectName, alpha);

    }

    @GetMapping(value="getValues")
    @ResponseBody
    public ResponseEntity<?> coreValuesByGet(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestParam(value = "alpha",  defaultValue = "0.75") String alpha)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        StatisticsModel statisticsModel = project
                .getStatisticsModel();

        CoreElementImpl cm = (CoreElementImpl) statisticsModel.newElement("core");

        List<Map<String, Object>> nodes = cm.getCoreScores(Double.parseDouble(alpha));

        return new ResponseEntity<>(nodes, HttpStatus.OK);
    }
}

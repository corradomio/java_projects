package ae.ebtic.spl.server.controller;

import jext.logging.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpServletRequest;

/**
 * Base class for all SPL controllers
 */
@CrossOrigin
@RestController
public abstract class SPLRestController {

    // ----------------------------------------------------------------------
    // Protected fields
    // ----------------------------------------------------------------------

    protected Logger logger = Logger.getLogger(this.getClass());

    @Autowired protected ServletContext context;
    @Autowired protected HttpServletRequest request;
    //@Autowired private HttpServletResponse response;

    protected String MODULE;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private SPLRestController() { }

    protected SPLRestController(String module) {
        MODULE = module;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

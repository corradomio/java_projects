package ae.ebtic.spl.managers.splrepos;

import ae.ebtic.spl.projects.SPLProject;
import jext.util.FileUtils;

import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.List;

public class SPLWorkspace implements SPLRepository {

    private static String WORKSPACE = "$workspace";

    private SPLReposManager manager;

    public SPLWorkspace(SPLReposManager manager) {
        this.manager = manager;
    }

    @Override
    public String getName() {
        return WORKSPACE;
    }

    @Override
    public SPLRepoConfig getConfiguration() {
        return new SPLRepoConfig()
            .setRepositoryRoot(FileUtils.getAbsolutePath(manager.getWorkspaceFolder()))
            .setDescription("");
    }

    @Override
    public File getRepositoryRoot() {
        return manager.getWorkspaceFolder();
    }

    @Override
    public boolean isLinkedRepository() {
        return true;
    }

    @Override
    public boolean exists() {
        return true;
    }

    @Override
    public boolean create(SPLRepoConfig config) {
        return false;
    }

    @Override
    public void delete() { }

    @Override
    public SPLProject newProject(String projectName) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<SPLProject> listProjects() {
        return Collections.emptyList();
    }

    public static boolean isWorkspace(String name) {
        return WORKSPACE.equals(name);
    }

    @Override
    public void dump() {

    }
}

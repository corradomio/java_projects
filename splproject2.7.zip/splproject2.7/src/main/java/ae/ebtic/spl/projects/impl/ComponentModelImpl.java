package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentGraph;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.common.ModelConstants;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.tasks.AnalyzeComponentsFilterTask;
import ae.ebtic.spl.tasks.AnalyzeComponentsTask;
import ae.ebtic.spl.tasks.AnalyzeTopDownComponentsTask;
import ae.ebtic.spl.tasks.ProjectTask;
import ae.ebtic.spl.tasks.SPLProjectTask;
import jext.graph.NodeDegree;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;


public class ComponentModelImpl extends ProjectModelImpl implements ComponentModel,
    ModelConstants, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "component-config.json";

    private ComponentGraph cg;
    // private String methodCreation = "";
    // private List<String> filterKeyword;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ComponentModelImpl(SPLProject project) {
        super(project, ComponentModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl) super.getInfo();

        Map<Object, Long> ccount = new HashMap<>();

        // -2: all
        // -1: DAGROOT
        for(long depth=-2; true; depth+=1) {
            long dcount = cg.getComponentsCount((int)depth, null);
            if (depth > 0 && dcount == 0)
                break;
            ccount.put(depth, dcount);
        }

        Map<String, Object> counts = new HashMap<>();
        counts.put("components", ccount);

        info.put("count", counts);

        return info;
    }

    @Override
    public long getTimestamp() {
        return cg.getTimestamp();
    }

    @Override
    public ComponentGraph getComponentGraph() {
        return cg;
    }

    // ----------------------------------------------------------------------

    @Override
    public int getComponentsCount() {
        return (int)cg.getComponentsCount();
    }

    @Override
    public List<Component> getComponents() {
        return cg.getComponents(0, null);
    }

    @Override
    public List<Component> getComponents(int depth, NodeDegree ndegree) {
        return cg.getComponents(depth, ndegree);
    }

    @Override
    public Component getComponent(String componentId) {
        return cg.getComponent(componentId);
    }

    @Override
    public Component findComponentByName(String componentName, int depth) {
        return cg.findComponentByName(componentName, depth);
    }

    // @Override
    // public List<Map<String, Object>> getMembers(String componentId) {
    //     return cg.listMembersGraph(componentId);
    // }

    // @Override
    // public List<Map<String, Object>> getTypes(String componentId) {
    //     return cg.listTypes(componentId);
    // }

    @Override
    public List<Component> getComponentMembers(String componentId) {
        return cg.getMembers(componentId);
    }

    @Override
    public List<Type> getComponentTypes(String componentId) {
        return cg.getComponentTypes(componentId);
    }

    @Override
    public List<Feature> getComponentFeatures(String componentId) {
        return cg.getComponentFeatures(componentId);
    }

    @Override
    public List<Feature> getComponentsFeatures(List<String> ids) {
        Set<Feature> features = new HashSet<>();

        for(String componentId : ids) {
            features.addAll(getComponentFeatures(componentId));
        }

        return new ArrayList<>(features);
    }


    // ----------------------------------------------------------------------
    // Diagrams
    // ----------------------------------------------------------------------

    @Override
    public Map<String, Object> getModelGraph(int depth) {
        return cg.getModelGraph(depth);
    }

    @Override
    public Map<String, Object> getSmallModelGraph(int depth) {
        return cg.getSmallModelGraph(depth);
    }

    // ----------------------------------------------------------------------
    // Utilities
    // ----------------------------------------------------------------------

    @Override
    public void setTypesCount() {
        cg.setTypesCount();
    }

    @Override
    public Map<String, Object> getTypesCount(int depth) {
        return cg.getTypesCount(depth);
    }


    // ----------------------------------------------------------------------
    // Model Implementation
    // ----------------------------------------------------------------------

    // @Override
    // protected boolean create(String methodCreation) {
    //     this.methodCreation = methodCreation;
    //     return createNoParams();
    // }

    // @Override
    // protected boolean create(String methodCreation, List<String> filter){
    //     this.methodCreation = methodCreation;
    //     this.filterKeyword = filter;
    //     return createNoParams();
    // }

    @Override
    protected boolean hasDependenciesResolved() {
        return getSPLProject().getDependencyModel().getStatus() == ModelStatus.VALID;
    }

    @Override
    protected ProjectTask createThis() {
        SPLProjectTask task;

        cg.create();

        switch( this.modelCreateParams.method()){
        case COMPONENT_TopDown_ANALYSIS:
            task = new AnalyzeTopDownComponentsTask(this);
            break;
        case COMPONENT_FILTER_ANALYSIS:
            task = new AnalyzeComponentsFilterTask(this, this.modelCreateParams.filter());
            break;
        default:
             task = new AnalyzeComponentsTask(this);
        }
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());
        //Managers.getTaskManager().submit(task);
        return task;
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        cg.delete();
    }
    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkStatus() {
        if (cg == null) {
            GraphConfig config = new GraphConfig()
                .setGraphDatabase(Managers.getGraphDatabase())
                .setProjectName(project.getName());
            //pg = cg = ComponentGraph.newComponentGraph(config);
            cg = ProjectGraphAccess.newProjectGraphAccess(config).getComponentGraph();
            setProjectGraphAccess(cg);
        }
    }

    @Override
    protected void checkModelStatus() {

        // if (!cg.exists()) {
        //     setStatus(ModelStatus.NOT_EXISTENT, null);
        //     return;
        // }
        if (!STATUS_VALID.equals(cg.getStatus())) {
            setStatus(ModelStatus.valueOf(cg.getStatus()), String.format("Graph in status %s", cg.getStatus()));
            return;
        }

        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        DependencyModel dependencyModel = getSPLProject().getDependencyModel();

        // check the status of the dependency model
        if (dependencyModel.getStatus() != ModelStatus.VALID) {
            setStatus(ModelStatus.INVALID, String.format("DependencyModel has status %s", dependencyModel.getStatus()));
            return;
        }

        // check the models timestamps
        if (dependencyModel.getTimestamp() > getTimestamp()) {
            setStatus(ModelStatus.INVALID, "DependencyModel is more recent");
            return;
        }
    }

}

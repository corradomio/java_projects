package ae.ebtic.spl.server.controller.statistics;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.StatisticsModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.statistics.WebStatisticsElementModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/statistics/elements/{elementType}")
public class StatisticsElementController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public StatisticsElementController() {
        super("statisticsElement");
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------
    @GetMapping(value="")
    @ResponseBody
    public ResponseEntity<?> getStatisticsElement(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String elementType)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        StatisticsModel statisticsModel = project
                .getStatisticsModel();

        WebStatisticsElementModel element = WebStatisticsElementModel.newWebStatisticsElementModel(statisticsModel.newElement(elementType), requestUrl).detailed();

        return new ResponseEntity<>(element, HttpStatus.OK);

    }

    @GetMapping(value="create")
    @ResponseBody
    public ResponseEntity<?> createStatisticsElement(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String elementType) {

        return this._createStatisticsElement(repoName, projectName, elementType);
    }
    private ResponseEntity<?> _createStatisticsElement(String repoName, String projectName, String elementType) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        StatisticsModel statisticsModel = project
                .getStatisticsModel();

        WebStatisticsElementModel element = WebStatisticsElementModel.newWebStatisticsElementModel(statisticsModel.newElement(elementType), requestUrl).detailed();

        if(statisticsModel.createElement(elementType))
            return new ResponseEntity<>(element, HttpStatus.OK);
        else
            return new ResponseEntity<>(element, HttpStatus.NOT_FOUND);
    }


    @GetMapping(value="delete")
    @ResponseBody
    public ResponseEntity<?> deleteStatisticsElement(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String elementType) {

        return this._deleteStatisticsElement(repoName, projectName, elementType);
    }
    private ResponseEntity<?> _deleteStatisticsElement(String repoName, String projectName, String elementType) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        StatisticsModel statisticsModel = project
                .getStatisticsModel();

        WebStatisticsElementModel element = WebStatisticsElementModel.newWebStatisticsElementModel(statisticsModel.newElement(elementType), requestUrl).detailed();

        if(statisticsModel.deleteElement(elementType))
            return new ResponseEntity<>(element, HttpStatus.OK);
        else
            return new ResponseEntity<>(element, HttpStatus.NOT_FOUND);
    }



}

package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class VersioningModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public VersioningModelConfig() {
        super();
    }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    public static VersioningModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(VersioningModelConfig.class);

        if (configFile.exists())
        try {
            return (VersioningModelConfig) JSONUtils.load(configFile, VersioningModelConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
        }

        return (VersioningModelConfig) new VersioningModelConfig().configIn(configFile);
    }
}

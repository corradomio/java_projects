package ae.ebtic.spl.server.controller.wsocket;

public interface WSMessage {

    String destination();
}

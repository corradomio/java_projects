package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.diagrams.TypeDiagram;
import ae.ebtic.spl.analysis.diagrams.TypeDiagramConfig;

public interface DiagramsModel extends ProjectModel {

    String TYPE = "diagrams";

    TypeDiagram getTypeDiagram(TypeDiagramConfig config);
}

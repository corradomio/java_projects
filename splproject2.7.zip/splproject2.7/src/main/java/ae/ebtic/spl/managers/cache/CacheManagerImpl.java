package ae.ebtic.spl.managers.cache;

import jext.cache.CacheConfiguration;
import jext.logging.Logger;
import java.util.Properties;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.HierarchicalConfiguration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class CacheManagerImpl implements CacheManager {

    private static Logger logger = Logger.getLogger(CacheManager.class);
    private Configuration config;

    // ----------------------------------------------------------------------
    // Configuration
    // ----------------------------------------------------------------------
    /*
        <cacheManager>
            <cache name="">
                <capacity value="1024"/>
                <expireAfterWrite value="5:00"/>
                <expireAfterAccess value="5:00"/>
            </cache>

        </cacheManager>

     */

    @Override
    public String getName() { return CacheManager.MANAGER; }

    @Override
    public void configure(Configuration config) throws ConfigurationException {

        this.config = config;

        logger.info("configure");

        CacheConfiguration cacheConfig = new CacheConfiguration();

        for (Object lconfig : ((HierarchicalConfiguration)config).configurationsAt("cache")) {
            HierarchicalConfiguration cconfig = (HierarchicalConfiguration) lconfig;

            String cname = cconfig.getString("[@name]");

            logger.infof("    cache configuration for '%s'", cname);

            String capacity = cconfig.getString("capacity[@value]", "");
            String expireAfterWrite = cconfig.getString("expireAfterWrite[@value]", "");
            String expireAfterAccess = cconfig.getString("expireAfterAccess[@value]", "");

            Properties cprops = new Properties();
            if (!capacity.isEmpty())
                cprops.put(jext.cache.CacheManager.CAPACITY, capacity);
            if (!expireAfterWrite.isEmpty())
                cprops.put(jext.cache.CacheManager.EXPIRE_AFTER_WRITE, expireAfterWrite);
            if (!expireAfterAccess.isEmpty())
                cprops.put(jext.cache.CacheManager.EXPIRE_AFTER_ACCESS, expireAfterAccess);

            cacheConfig.add(cname, cprops);
        }

        // Configure the global cache manager
        jext.cache.CacheManager.configure(cacheConfig);

        logger.info("done");
    }

    @Override
    public void destroy() {
        jext.cache.CacheManager.clear();
    }
}

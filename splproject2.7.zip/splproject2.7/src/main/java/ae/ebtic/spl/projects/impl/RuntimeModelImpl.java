package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.runtime.RuntimeGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.RuntimeModel;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.server.controller.runtime.EntryPointsConfig;
import ae.ebtic.spl.tasks.ProjectTask;
import ae.ebtic.spl.tasks.EntryPointsAnalysisTask;

import java.util.List;
import java.util.Map;

public class RuntimeModelImpl extends ProjectModelImpl implements RuntimeModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private RuntimeGraph rtg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected RuntimeModelImpl(SPLProject project) {
        super(project, RuntimeModel.TYPE);
    }

    @Override
    public RuntimeGraph getRuntimeGraph() {
        return rtg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public long getTimestamp() {
        return rtg.getTimestamp();
    }

    @Override
    protected boolean hasDependenciesResolved() {
        return  project.getFeatureModel().getStatus() == ModelStatus.VALID;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public Map<String, Long> getEntryPointsCount() {
        return rtg.getEntryPointsCounts();
    }

    // ----------------------------------------------------------------------
    // Overrides
    // ----------------------------------------------------------------------

    @Override
    public void resetEntryPoints() {
        rtg.resetEntryPoints();
    }

    // ----------------------------------------------------------------------

    @Override
    protected ProjectTask createThis() {
        rtg.create();

        EntryPointsConfig config = (EntryPointsConfig) this.modelCreateParams.parameters().get("config");

        EntryPointsAnalysisTask task = new EntryPointsAnalysisTask(project).setConfig(config);

        return task;
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        rtg.delete();
    }

    // ----------------------------------------------------------------------
    // EntryPoints
    // ----------------------------------------------------------------------

    @Override
    public void updateEntryPoints() {
        rtg.updateEntryPoints();
    }

    // ----------------------------------------------------------------------
    // Queries

    public List<Type> getEntryPointTypes() {
        return rtg.getEntryPointTypes();
    }

    public List<Component> getEntryPointComponents() {
        return rtg.getEntryPointComponents();
    }

    public List<Feature> getEntryPointFeatures() {
        return rtg.getEntryPointFeatures();
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkStatus() {
        if (rtg == null) {
            GraphConfig config = new GraphConfig()
                .setGraphDatabase(Managers.getGraphDatabase())
                .setProjectName(project.getName());
            //pg = dg = DependencyGraph.newDependencyGraph(config);
            rtg = ProjectGraphAccess.newProjectGraphAccess(config).getRuntimeGraph();
            setProjectGraphAccess(rtg);
        }
    }

    @Override
    protected void checkModelStatus() {

        // check if the model is created
        // if (!rtg.exists()) {
        //     setStatus(ModelStatus.NOT_EXISTENT, null);
        //     return;
        // }
        if (!STATUS_VALID.equals(rtg.getStatus())) {
            setStatus(ModelStatus.valueOf(rtg.getStatus()), String.format("Graph in status %s", rtg.getStatus()));
            return;
        }


        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        // NOT_EXISTENT: if the node "runtime" is not present in the database
        // INVALID: if is present BUT some model is not existent or invalid OR
        //     the timestamp of the analysis is BEFORE the timestamp of some model
        // VALID: if all models are valid

        // check if the graph is valid
        if (!rtg.getStatus().equals(GraphConstants.STATUS_VALID)) {
            setStatus(ModelStatus.NOT_EXISTENT, rtg.getReason());
            return;
        }

        // check if the dependency model is valid
        FeatureModel fm = project.getFeatureModel();

        // feature model not valid
        if (fm.getStatus() != ModelStatus.VALID) {
            setStatus(ModelStatus.INVALID, String.format("Feature model in status %s", fm.getStatus()));
            return;
        }

        // featue model more recent
        if (fm.getTimestamp() > getTimestamp()) {
            setStatus(ModelStatus.INVALID, String.format("Feature model more recent"));
            return;
        }
    }

}

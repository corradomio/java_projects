package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.tasks.ProjectTask;
import jext.tasks.Progress;
import jext.tasks.Task;

public class TaskProgressChangeMessage extends TaskStatusMessage {

    public TaskProgressChangeMessage(ProjectTask task) {
        super(task);
    }

    public String getMessage() { return task.getMessage(); }

    public Progress getProgress() {
        return task.getProgress();
    }

    @Override
    public String destination() {
        String destination = super.destination();
        return destination + ".progress";
    }
}

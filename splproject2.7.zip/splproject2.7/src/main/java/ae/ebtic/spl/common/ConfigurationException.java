package ae.ebtic.spl.common;

public class ConfigurationException extends RuntimeException {

    public ConfigurationException(String what, String who) {
        super(what + " " + who);
    }

}

package ae.ebtic.spl.managers.system;

import ae.ebtic.spl.managers.Manager;
import ae.ebtic.spl.managers.uploads.UploadsService;
import jext.graph.GraphDatabase;
import jext.tasks.TaskManagerService;

import java.util.concurrent.ExecutorService;

public interface SystemManager extends Manager {

    String MANAGER = "system";

    GraphDatabase getGraphDatabase();

    ExecutorService getExecutorService();

    TaskManagerService getTaskManager();

    UploadsService getUploadsService();
}

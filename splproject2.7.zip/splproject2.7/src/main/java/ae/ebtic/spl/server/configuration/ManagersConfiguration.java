package ae.ebtic.spl.server.configuration;

import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.managers.cache.CacheManager;
import ae.ebtic.spl.managers.confidential.ConfidentialManager;
import ae.ebtic.spl.managers.extlibs.ExtLibsManager;
import ae.ebtic.spl.managers.services.rtanalysis.RTAnalysisManager;
import ae.ebtic.spl.managers.splrepos.SPLReposManager;
import ae.ebtic.spl.managers.system.SystemManager;
import ae.ebtic.spl.managers.uploads.UploadsService;
import jext.graph.GraphDatabase;
import jext.tasks.TaskManagerService;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

import java.util.concurrent.ExecutorService;

@Configuration
public class ManagersConfiguration {

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public SPLReposManager reposManager() {
        return Managers.getSPLReposManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public SystemManager systemManager() {
        return Managers.getSystemManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public ExtLibsManager extLibsManager() {
        return Managers.getExtLibsManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public TaskManagerService taskManagerService() {
        return Managers.getTaskManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public GraphDatabase graphDatabase() {
        return Managers.getGraphDatabase();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public LibraryFinder libraryFinder() {
        return Managers.getLibraryFinder();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public ExecutorService executorService() {
        return Managers.getExecutorService();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public UploadsService uploadsService() {
        return Managers.getUploadsService();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public ConfidentialManager confidentialManager() {
        return Managers.getConfidentialManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public CacheManager cacheManager() {
        return Managers.getCacheManager();
    }

    @Bean
    @Scope(value = ConfigurableBeanFactory.SCOPE_SINGLETON)
    public RTAnalysisManager runtimeAnalyzer() {
        return Managers.getRuntimeAnalyzerManager();
    }

}

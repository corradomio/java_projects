package ae.ebtic.spl.server.controller;

import ae.ebtic.spl.server.Version;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebLink;
import jext.util.MapUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Arrays;
import java.util.Date;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/spl")
public class SPLAppController extends SPLRestController{

    private static final String TYPE = "SPL";

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    public SPLAppController() {
        super(TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public Map<String, Object> getSPLRoot() {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        return MapUtils.map(
            "version", Version.VERSION,
                "date", new Date().toString(),
                "href", requestUrl,
                "links", Arrays.asList(
                WebLink.of(requestUrl, "repositories"),
                WebLink.of(requestUrl, "version"),
                new WebLink(requestUrl)
        ));
    }

    @GetMapping("version")
    @ResponseBody
    public Map<String,String> getVersion() {
        return MapUtils.map("version", Version.VERSION);
    }

}

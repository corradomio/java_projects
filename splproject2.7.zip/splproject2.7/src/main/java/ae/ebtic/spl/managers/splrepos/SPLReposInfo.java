package ae.ebtic.spl.managers.splrepos;

public class SPLReposInfo {
}

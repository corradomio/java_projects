package ae.ebtic.spl.managers.splrepos;

import ae.ebtic.spl.managers.Manager;

import java.io.File;
import java.util.List;

public interface SPLReposManager extends Manager {

    String MANAGER = "splreposManager";

    File getWorkspaceFolder();

    List<SPLRepository> listRepositories();

    SPLRepository newRepository(String name);

}

package ae.ebtic.spl.managers.splrepos;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.logging.Logger;
import jext.util.JSONUtils;
import jext.util.Parameters;

import java.io.File;
import java.io.IOException;

public class SPLRepoConfig {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(SPLRepoConfig.class);

    private String repositoryRoot;
    private String description = "";
    private File configFile;
    private Parameters parameters = new Parameters();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLRepoConfig() { }

    // DEBUG
    public SPLRepoConfig(String repositoryHome) {
        this.repositoryRoot = repositoryHome;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public SPLRepoConfig setRepositoryHome(String repositoryHome) {
        // DON'T REMOVE! It is necessary to JSON serialization
        this.repositoryRoot = repositoryHome;
        return this;
    }

    public String getRepositoryHome() {
        return repositoryRoot;
    }

    public SPLRepoConfig setDescription(String desc) {
        // DON'T REMOVE! It is necessary to JSON serialization
        this.description = desc;
        return this;
    }

    public String getDescription() { return description; }


    public SPLRepoConfig setRepositoryRoot(String repositoryHome) {
        // DON'T REMOVE! It is necessary to JSON serialization
        this.repositoryRoot = repositoryHome;
        return this;
    }

    public SPLRepoConfig setHomeFolder(String homeFolder) {
        // DON'T REMOVE! It is necessary to JSON serialization
        this.repositoryRoot = homeFolder;
        return this;
    }

    public SPLRepoConfig setParameters(Parameters params) {
        this.parameters.putAll(params);
        return this;
    }

    public Parameters getParameters() {
        return parameters;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @JsonIgnore
    public boolean isLinkedRepository() {
        return repositoryRoot != null && repositoryRoot.length() > 0;
    }

    SPLRepoConfig configIn(File configFile) {
        this.configFile = configFile;
        return this;
    }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    public boolean exists() {
        return configFile != null && configFile.exists();
    }

    public void delete() {
        configFile.delete();
    }

    public SPLRepoConfig save() {
        try {
            JSONUtils.save(configFile, this);
        }
        catch (IOException e) {
            logger.error(e, e);
        }

        return this;
    }

    public static SPLRepoConfig loadOrDefault(File configFile) {

        if (configFile.exists())
        try {
            return JSONUtils.load(configFile, SPLRepoConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
        }

        return new SPLRepoConfig().configIn(configFile);
    }
}

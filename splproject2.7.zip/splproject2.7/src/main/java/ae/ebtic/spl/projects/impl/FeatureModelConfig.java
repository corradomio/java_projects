package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class FeatureModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FeatureModelConfig() {
        super();
    }

    public static FeatureModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(FeatureModelConfig.class);

        if (configFile.exists())
        try {
            return (FeatureModelConfig) JSONUtils.load(configFile, FeatureModelConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
            return (FeatureModelConfig) new FeatureModelConfig().configIn(configFile);
        }

        return (FeatureModelConfig) new FeatureModelConfig().configIn(configFile);
    }

}

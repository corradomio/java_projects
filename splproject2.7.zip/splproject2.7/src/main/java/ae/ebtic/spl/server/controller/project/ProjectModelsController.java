package ae.ebtic.spl.server.controller.project;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.ProjectModel;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebModelConfig;
import ae.ebtic.spl.server.webmodels.WebModelModel;
import ae.ebtic.spl.server.webmodels.WebModelsFactory;
import ae.ebtic.spl.tasks.ProjectTask;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static ae.ebtic.spl.common.ModelConstants.COMPONENT_FILTER_ANALYSIS;


@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models")
public class ProjectModelsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectModelsController() {
        super("models");
    }

    // ----------------------------------------------------------------------
    // Project Models
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getProjectModelsList(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);
        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        List<WebModelModel> models = project.getModels()
            .stream()
            .map(model -> WebModelsFactory.of(model, requestUrl))
            .collect(Collectors.toList());

        if (!project.exists()) {
            logger.errorf("Project %s not existent", project.getName());
            return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
        }

        return new ResponseEntity<>(models, HttpStatus.OK);
    }

    /**
     * Retrieve a model
     */
    @GetMapping("{modelType}")
    @ResponseBody
    public WebModelModel getProjectModel(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType) {

        return _getProjectModel(repoName, projectName, modelType).detailed();
    }

    @GetMapping("{modelType}/status")
    @ResponseBody
    public WebModelModel getProjectModelStatus(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType) {

        return _getProjectModel(repoName, projectName, modelType);
    }

    private WebModelModel _getProjectModel(
        String repoName,
        String projectName,
        String modelType) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectModel model = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getModel(modelType);

        return WebModelsFactory.of(model, requestUrl);
    }

    /**
     * Create a model
     */
    @PutMapping(value = "{modelType}", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProjectModel(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType,
        @RequestParam(value = "method", defaultValue = "", required = false) String method,
        @RequestBody WebModelConfig config) throws Exception {

        config.setRepository(repoName)
            .setProject(projectName)
            .setModelType(modelType)
            .setMethod(method);

        return this._createProjectModel(config);
    }

    @PostMapping(consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProjectModel(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody WebModelConfig config) throws Exception {

        config.setRepository(repoName)
            .setProject(projectName);

        return this._createProjectModel(config);
    }

    @PostMapping(value = "{modelType}/createFilter")
    @ResponseBody
    public ResponseEntity<?> createComponentWithFilter(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String modelType,
            @RequestBody List<String> filterKeywords)
    {
        // String requestUrl = WebHrefMapper.getRequestUrl(request);
        //
        // ProjectModel model = Managers.getSPLReposManager()
        //         .newRepository(repoName)
        //         .newProject(projectName)
        //         .newModel(modelType);
        //
        // ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance)
        //     .method(COMPONENT_FILTER_ANALYSIS)
        //     .properties(cprops)
        //     .filter(filterKeywords);
        //
        // if (model.create(params)) {
        //     WebModelModel webmodel = WebModelModel.newWebModelModel(model, requestUrl).detailed();
        //     return new ResponseEntity<>(webmodel, HttpStatus.OK);
        // }
        // else {
        //     WebModelModel webmodel = WebModelModel.newWebModelModel(model, requestUrl);
        //     return new ResponseEntity<>(webmodel, HttpStatus.FORBIDDEN);
        // }

        WebModelConfig config = (WebModelConfig) new WebModelConfig()
            .setRepository(repoName)
            .setProject(projectName)
            .setModelType(modelType)
            .setMethod(COMPONENT_FILTER_ANALYSIS)
            .addParameter("filter", filterKeywords);

        return this._createProjectModel(config);
    }

    //
    // DEBUG
    //
    @GetMapping(value = "{modelType}/create")
    @ResponseBody
    public ResponseEntity<?> createProjectModelByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType/*,
        @RequestParam(value = "method", defaultValue = "") String method*/) {

        WebModelConfig config = (WebModelConfig) new WebModelConfig()
            .setRepository(repoName)
            .setProject(projectName)
            .setModelType(modelType)
            .addParameters(request.getQueryString());

        return this._createProjectModel(config);
    }

    private ResponseEntity<?> _createProjectModel(WebModelConfig config) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectModel model = Managers.getSPLReposManager()
            .newRepository(config.getRepository())
            .newProject(config.getProject())
            .getModel(config.getModelType());

        ModelCreateParams params = new ModelCreateParams(WSTaskStatusListener.instance)
            .method(config.getMethod())
            .parameters(config.getParameters());

        ProjectTask task = model.create(params);

        WebModelModel webmodel = WebModelsFactory.of(model, requestUrl);
        if (task == null)
            return new ResponseEntity<>(webmodel, HttpStatus.FORBIDDEN);

        Managers.getTaskManager().submit(task);
        return new ResponseEntity<>(webmodel, HttpStatus.OK);

        // if (model.create(params)) {
        //     WebModelModel webmodel = WebModelsFactory.of(model, requestUrl).detailed();
        //     return new ResponseEntity<>(webmodel, HttpStatus.OK);
        // }
        // else {
        //     WebModelModel webmodel = WebModelsFactory.of(model, requestUrl);
        //     return new ResponseEntity<>(webmodel, HttpStatus.FORBIDDEN);
        // }
    }

    /**
     * Delete a model
     */
    @DeleteMapping(value = "{modelType}")
    @ResponseBody
    public ResponseEntity<?> deleteProjectModel(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType) throws Exception {

        return this._deleteProjectModel(repoName, projectName, modelType);
    }

    //
    // DEBUG
    //
    @GetMapping(value = "{modelType}/delete")
    @ResponseBody
    public ResponseEntity<?> deleteProjectModelByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType) {

        return this._deleteProjectModel(repoName, projectName, modelType);
    }

    private ResponseEntity<?> _deleteProjectModel(String repoName, String projectName, String modelType) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectModel model = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getModel(modelType);

        Managers.getExecutorService().submit(() -> {
            model.delete();
        });

        WebModelModel webmodel = WebModelsFactory.of(model, requestUrl);
        return new ResponseEntity<>(webmodel, HttpStatus.OK);
    }

    @GetMapping(value = "{modelType}/abort")
    @ResponseBody
    public ResponseEntity<?> abortProjectModelByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String modelType)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        ProjectModel model = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getModel(modelType);

        WebModelModel webmodel = WebModelsFactory.of(model, requestUrl);
        if (model.isRunning()) {
            model.abort();
            return new ResponseEntity<>(webmodel, HttpStatus.OK);
        }
        else {
            return new ResponseEntity<>(webmodel, HttpStatus.FORBIDDEN);
        }
    }


    /**
     * Create a feature model manually
     */
    @PostMapping(value = "createFeatureModel", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createFeatureModel(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestBody Map<String, Object> features) throws Exception {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        FeatureModel fm = project.getFeatureModel();

        if(fm.exists()){
            fm.delete();
        }

        ProjectTask task = fm.manualCreate((List<String>)features.get("features"),(List<List<String>>)features.get("components"));
        Managers.getTaskManager().submit(task);

        WebModelModel webmodel = WebModelsFactory.of(fm, requestUrl).detailed();
        return new ResponseEntity<>(webmodel, HttpStatus.ACCEPTED);
    }

}

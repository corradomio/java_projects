package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.diagrams.TypeDiagram;
import ae.ebtic.spl.analysis.diagrams.TypeDiagramConfig;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.projects.DiagramsModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.diagram.WebTypeDiagram;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency")
public class TypeDiagramsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public TypeDiagramsController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Graph
    // ----------------------------------------------------------------------

    // DEBUG
    @GetMapping(value = "tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, config);
    }

    // DEBUG
    @GetMapping(value = "types/{typeId}/tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, typeId, config);
    }

    // --

    @PostMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig config) {
        return getTypeDiagram(repoName, projectName, config);
    }

    @GetMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig config) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }

    // --

    @PostMapping(value = "types/{typeId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestBody TypeDiagramConfig config) {
        return getTypeDiagram(repoName, projectName, typeId, config);
    }

    @GetMapping(value = "types/{typeId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestBody TypeDiagramConfig config) {

        config.addId(typeId);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }


    // ----------------------------------------------------------------------
    // typesWInterfaces
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     */
    @GetMapping(value = "types/{typeId}/typesWInterfaces")
    @ResponseBody
    public ResponseEntity<?> getTypesWihInterfacesDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestParam(value = "link", defaultValue = "true") boolean links,
        @RequestParam(value = "imp", defaultValue = "true") boolean implementation)
    {
        TypeDiagramConfig config = new TypeDiagramConfig();
        config.setLink(links);
        config.setImp(implementation);

        return getTypeDiagram(repoName, projectName, typeId, config);
    }

}

package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentGraph;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.NodeDegree;

import java.util.List;
import java.util.Map;

public interface ComponentModel extends ProjectModel {

    String TYPE = "component";

    ComponentGraph getComponentGraph();

    // ----------------------------------------------------------------------

    int getComponentsCount();

    /**
     * List of components at depth 0
     */
    List<Component> getComponents();

    /**
     * List of components as pecified depth.
     *
     * Uses '-1' to specify the TOP (DAG) level
     *
     * Pass null to ndegree if the degree of the component is not important
     *
     * @param depth
     * @param ndegree
     * @return
     */
    List<Component> getComponents(int depth, NodeDegree ndegree);

    Component getComponent(String componentId);

    Component findComponentByName(String componentName, int depth);

    List<Component> getComponentMembers(String componentId);

    List<Type> getComponentTypes(String componentId);

    List<Feature> getComponentFeatures(String componentId);

    List<Feature> getComponentsFeatures(List<String> ids);

    // --

    Map<String, Object> getModelGraph(int depth);

    Map<String, Object> getSmallModelGraph(int depth);

    void setTypesCount();

    Map<String, Object> getTypesCount(int depth);
}

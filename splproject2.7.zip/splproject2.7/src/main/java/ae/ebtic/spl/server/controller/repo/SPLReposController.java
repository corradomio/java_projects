package ae.ebtic.spl.server.controller.repo;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.managers.splrepos.SPLRepoConfig;
import ae.ebtic.spl.managers.splrepos.SPLRepository;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.repo.WebRepoConfig;
import ae.ebtic.spl.server.webmodels.repo.WebRepoModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories")
public class SPLReposController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLReposController() {
        super("repositories");
    }

    // ----------------------------------------------------------------------
    // Repositories
    // ----------------------------------------------------------------------

    /**
     * List of repositories
     */
    @GetMapping("")
    @ResponseBody
    public List<WebRepoModel> getRepositoriesList() {

        logger.infof("listRepositories");

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        List<WebRepoModel> rmList = Managers.getSPLReposManager()
            .listRepositories()
            .stream()
            .map(repo -> new WebRepoModel(repo, requestUrl))
            .collect(Collectors.toList());

        return rmList;
    }

    // ----------------------------------------------------------------------

    /**
     * Retrieve a repository
     */
    @GetMapping("{repoName}")
    @ResponseBody
    public ResponseEntity<?> getRepository(@PathVariable String repoName) {

        logger.infof("getRepository(%s)", repoName);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLRepository repo = Managers.getSPLReposManager().newRepository(repoName);

        if (!repo.exists())
            return new ResponseEntity<>(new WebRepoModel(repo, requestUrl), HttpStatus.NOT_FOUND);

        return new ResponseEntity<>((WebRepoModel)new WebRepoModel(repo, requestUrl).detailed(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Create a repository
    // ----------------------------------------------------------------------

    /**
     * Create a new repository (DEBUG)
     */
    @GetMapping(value="{repoName}/create")
    @ResponseBody
    public ResponseEntity<?> createRepositoryByGet(@PathVariable String repoName) throws Exception {

        WebRepoConfig config = (WebRepoConfig) new WebRepoConfig()
            .setDescription("Test Repository")
            .setName(repoName)
            .addParameter("isTest", true);

        return createRepository(config);
    }

    /**
     * Create a new repository  (DEPRECATED)
     */
    @PutMapping(value="{repoName}", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createRepository(
        @PathVariable String repoName,
        @RequestBody WebRepoConfig config) throws Exception {

        config.setRepository(repoName);

        return createRepository(config);
    }

    /**
     * Create a new repository
     */
    @PostMapping(value="", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createRepository(
        @RequestBody WebRepoConfig config) throws Exception {

        String repoName = config.getRepository();

        logger.infof("%s.create()", repoName);

        String requestUrl = WebHrefMapper.getRequestUrl(request);
        String repositoryRoot = config.getDirectory();

        SPLRepository repo = Managers.getSPLReposManager().newRepository(repoName);

        SPLRepoConfig splconfig = new SPLRepoConfig()
            .setRepositoryRoot(repositoryRoot)
            .setDescription(config.getDescription())
            .setParameters(config.getParameters());

        if (repo.create(splconfig))
            return new ResponseEntity<>(new WebRepoModel(repo, requestUrl), HttpStatus.OK);
        else
            return new ResponseEntity<>(new WebRepoModel(repo, requestUrl), HttpStatus.FORBIDDEN);
    }

    // ----------------------------------------------------------------------
    // Delete a repository
    // ----------------------------------------------------------------------

    /**
     * Delete a repository (DEBUG)
     */
    @GetMapping(value="{repoName}/delete")
    @ResponseBody
    public ResponseEntity<?> deleteRepositoryByGet(
        @PathVariable String repoName,
        @RequestParam(name = "content", defaultValue = "false") boolean content) {

        return this.deleteRepository(repoName, content);
    }

    /**
     * Delete a repository
     */
    @DeleteMapping(value="{repoName}")
    @ResponseBody
    public ResponseEntity<?> deleteRepository(
        @PathVariable String repoName,
        @RequestParam(name = "content", defaultValue = "false") boolean content) {

        logger.infof("%s.delete()", repoName);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLRepository repo = Managers.getSPLReposManager()
            .newRepository(repoName);

        Managers.getExecutorService().submit(() -> {
            repo.delete();
        });

        return new ResponseEntity<>(new WebRepoModel(repo, requestUrl), HttpStatus.OK);
    }

}

package ae.ebtic.spl.managers.confidential;

import ae.ebtic.spl.managers.Manager;

public interface ConfidentialManager extends Manager {

    String MANAGER = "confidentialManager";

    String getSystemPassword();

}

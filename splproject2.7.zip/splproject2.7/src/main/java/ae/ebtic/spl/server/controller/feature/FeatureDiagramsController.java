package ae.ebtic.spl.server.controller.feature;

import ae.ebtic.spl.analysis.diagrams.TypeDiagram;
import ae.ebtic.spl.analysis.diagrams.TypeDiagramConfig;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DiagramsModel;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.diagram.WebTypeDiagram;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.Collections;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/feature")
public class FeatureDiagramsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected FeatureDiagramsController() {
        super(FeatureModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // typeDiagrams
    // ----------------------------------------------------------------------

    // DEBUG
    @GetMapping(value = "tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, config);
    }

    // DEBUG
    @GetMapping(value = "features/{featureId}/tdiag")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByGet(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        // @RequestParam(value = "ref", defaultValue = "false") boolean ref,
        // @RequestParam(value = "rec", defaultValue = "false") boolean rec,
        // @RequestParam(value = "ext", defaultValue = "false") boolean ext,
        // @RequestParam(value = "imp", defaultValue = "true")  boolean imp,
        // @RequestParam(value = "dep", defaultValue = "true")  boolean dep,
        // @RequestParam(value = "op",  defaultValue = "false") boolean op,
        // @RequestParam(value = "opc", defaultValue = "false") boolean opc,
        // @RequestParam(value = "att", defaultValue = "false") boolean att,
        // @RequestParam(value = "atyp",defaultValue = "false") boolean atyp,
        // @RequestParam(value = "orph",defaultValue = "true") boolean orph
        TypeDiagramConfig config
        ) {

        // TypeDiagramConfig config = new TypeDiagramConfig();
        // config.setRef(ref);
        // config.setRec(rec);
        // config.setExt(ext);
        // config.setImp(imp);
        // config.setDep(dep);
        // config.setOp(op);
        // config.setOpc(opc);
        // config.setAtt(att);
        // config.setAtyp(atyp);
        // config.setOrph(orph);

        return getTypeDiagram(repoName, projectName, featureId, config);
    }

    // --

    @PostMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig config) {
        return getTypeDiagram(repoName, projectName, config);
    }

    @GetMapping(value = "typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody TypeDiagramConfig config) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }

    // --

    @PostMapping(value = "features/{featureId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagramByPost(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestBody TypeDiagramConfig config) {
        return getTypeDiagram(repoName, projectName, featureId, config);
    }

    @GetMapping(value = "features/{featureId}/typeDiagram")
    @ResponseBody
    public ResponseEntity<?> getTypeDiagram(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestBody TypeDiagramConfig config) {

        config.addId(featureId);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DiagramsModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDiagramsModel();

        TypeDiagram td = dm.getTypeDiagram(config);

        return new ResponseEntity<>(new WebTypeDiagram(td, config, requestUrl), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // graph
    // sgraph
    // ----------------------------------------------------------------------

    /**
     * Retrieve the graph
     */
    @GetMapping(value = "graph")
    @ResponseBody
    public ResponseEntity<?> getModelGraph(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "small", defaultValue = "false") boolean small)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        if (!fm.exists()) {
            logger.errorf("FeatureModel %s not existent", fm.getName());
            return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
        }

        if (small)
            return new ResponseEntity<>(fm.getSmallModelGraph(), HttpStatus.OK);
        else
            return new ResponseEntity<>(fm.getModelGraph(), HttpStatus.OK);
    }

    @GetMapping(value = "sgraph")
    @ResponseBody
    public ResponseEntity<?> getSmallModelGraphDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        return getModelGraph(repoName, projectName, true);
    }

    // ----------------------------------------------------------------------
    // typesWInterfaces
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     */
    @GetMapping(value = "{featureId}/typesWInterfaces")
    @ResponseBody
    public ResponseEntity<?> getTypesWihInterfacesWrongDeprecated(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String featureId,
        @RequestParam(value = "link", defaultValue = "true") boolean links,
        @RequestParam(value = "imp", defaultValue = "true") boolean implementation)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        FeatureModel fm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getFeatureModel();

        return new ResponseEntity<>(fm.getTypesWInterfaces(featureId, links, implementation), HttpStatus.OK);
    }


}

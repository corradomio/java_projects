package ae.ebtic.spl.projects;

public interface CoreElementModel {

    String TYPE = "coreelement";

}

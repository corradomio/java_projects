package ae.ebtic.spl.server.controller.task;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.task.WebTaskManagerModel;
import ae.ebtic.spl.server.webmodels.task.WebTaskModel;
import ae.ebtic.spl.tasks.CheckTask;
import jext.tasks.Task;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/tasks")
public class TasksController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public TasksController() {
        super("tasks");
    }

    // ----------------------------------------------------------------------
    // DEBUG: Special task
    // ----------------------------------------------------------------------

    @GetMapping("check")
    @ResponseBody
    public List<WebTaskModel> insertCheckTask(
        @RequestParam(value = "w", defaultValue = "1") String stotalworks,
        @RequestParam(value = "s", defaultValue = "30") String stotalsteps,
        @RequestParam(value = "ss", defaultValue = "1") String ssleepseconds)
    {
        int totalWorks = Integer.parseInt(stotalworks);
        int totalSteps = Integer.parseInt(stotalsteps);
        int sleepSeconds = Integer.parseInt(ssleepseconds);
        Task task = new CheckTask(totalWorks, totalSteps, sleepSeconds);
        task.addListener( WSTaskStatusListener.instance);
        Managers.getTaskManager().submit(task);
        return getTasksList();
    }

    // ----------------------------------------------------------------------
    // Manager
    // ----------------------------------------------------------------------

    @GetMapping("manager")
    @ResponseBody
    public WebTaskManagerModel getTaskManager() {
        String prefixUrl = WebHrefMapper.getRequestUrl(request);
        return new WebTaskManagerModel(Managers.getTaskManager(), prefixUrl);
    }

    // ----------------------------------------------------------------------
    // All tasks
    // ----------------------------------------------------------------------

    /**
     * Retrieve the list of all tasks
     */
    @GetMapping("")
    @ResponseBody
    public List<WebTaskModel> getTasksList() {
        String prefixUrl = WebHrefMapper.getRequestUrl(request);

        return Managers.getTaskManager()
            .listTasks()
            .stream()
            .map(task -> new WebTaskModel(task, prefixUrl))
            .collect(Collectors.toList());
    }


    /**
     * Abort all tasks
     */
    @DeleteMapping("")
    @ResponseBody
    public void abortAllTasks() {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Managers.getTaskManager().abortAll();
    }

    //
    // DEBUG
    //
    @GetMapping("abort")
    @ResponseBody
    public void abortAllTasksByGet() {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Managers.getTaskManager().abortAll();
    }


    // ----------------------------------------------------------------------
    // Task by id
    // ----------------------------------------------------------------------

    @GetMapping("{taskId:[0-9_]+}")
    @ResponseBody
    public ResponseEntity<?> getTask(@PathVariable String taskId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Task task = Managers.getTaskManager().getTask(taskId);
        if (task == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        return new ResponseEntity<>((WebTaskModel)new WebTaskModel(task, requestUrl).detailed(), HttpStatus.OK);
    }


    @DeleteMapping("{taskId:[0-9_]+}")
    @ResponseBody
    public ResponseEntity<?> abortTask(@PathVariable String taskId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Task task = Managers.getTaskManager().getTask(taskId);
        if (task == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        task.abort();
        return new ResponseEntity<WebTaskModel>((WebTaskModel)new WebTaskModel(task, requestUrl).detailed(), HttpStatus.OK);
    }

    //
    // DEBUG
    //
    @GetMapping("{taskId:[0-9_]+}/abort")
    @ResponseBody
    public ResponseEntity<?> abortTaskByGet(@PathVariable String taskId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Task task = Managers.getTaskManager().getTask(taskId);
        if (task == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        task.abort();
        return new ResponseEntity<>((WebTaskModel)new WebTaskModel(task, requestUrl).detailed(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Tasks by type
    // ----------------------------------------------------------------------

    @GetMapping("{taskType:[a-z]+}")
    @ResponseBody
    public List<WebTaskModel> getTasksByType(@PathVariable String taskType) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        return Managers.getTaskManager()
            .listTasks(taskType)
            .stream()
            .map(task -> new WebTaskModel(task, requestUrl))
            .collect(Collectors.toList());
    }

    @DeleteMapping("{taskType:[a-z]+}")
    @ResponseBody
    public void abortTypedTasks(@PathVariable String taskType) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Managers.getTaskManager().abortAll(taskType);
    }

    //
    // DEBUG
    //
    @GetMapping("{taskType:[a-z]+}/abort")
    @ResponseBody
    public void abortTypedTasksByger(@PathVariable String taskType) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        Managers.getTaskManager().abortAll(taskType);
    }

}

package ae.ebtic.spl.managers.splrepos;

import ae.ebtic.spl.projects.SPLProject;

import java.io.File;
import java.io.IOException;
import java.util.List;

public interface SPLRepository {

    // ----------------------------------------------------------------------
    // SPL Repository Properties
    // ----------------------------------------------------------------------

    /**
     * Name of the repository
     */
    String getName();

    /**
     * Configuration of the repository
     */
    SPLRepoConfig getConfiguration();

    /**
     * Repository root
     */
    File getRepositoryRoot();

    /**
     * If the repository is not owner of the home directory
     */
    boolean isLinkedRepository();

    /**
     * Check if the repository exists:
     *  check if exists the configuration file AND the home folder
     */
    boolean exists();

    /**
     * Create the repository with the specified properties
     */
    boolean create(SPLRepoConfig config) throws Exception;

    /**
     * Delete the repository
     *
     * Note: it doesn't delete the content of the repository
     */
    void delete();

    // ----------------------------------------------------------------------
    // SPL Project Properties
    // ----------------------------------------------------------------------

    /**
     * Create the proxy for the project with the specified name
     *
     * @param projectName name of the project
     */
    SPLProject newProject(String projectName);

    /**
     * List of the projects available inside the repository
     *
     * @return list of SPL projects
     */
    List<SPLProject> listProjects();

    // ----------------------------------------------------------------------
    // Debug
    // ----------------------------------------------------------------------

    void dump() throws IOException ;
}

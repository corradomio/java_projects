package ae.ebtic.spl.server.controller.util;

import ae.ebtic.spl.server.webmodels.WebLink;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.util.concurrent.LazyList;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Page<T> {
    private List<T> elements;
    private Pageable pageable;
    private List<T> content = new ArrayList<>();
    private String href;

    public Page(List<T> elements, Pageable pageable, String href) {
        this.elements = elements;
        this.pageable = pageable;
        this.href = href;

        int offset = pageable.getPageOffset();
        int end = Math.min(offset + pageable.getPageSize(), elements.size());

        for(int index=offset; index<end; ++index)
            content.add(elements.get(index));
    }

    public List<T> getContent() {
        return content;
    }

    public Map<String, Object> getMetadata() {
        Map<String, Object> pageInfo = new HashMap<>();
        pageInfo.put("pageNumber", pageable.getPageNumber());
        pageInfo.put("pageSize", pageable.getPageSize());
        pageInfo.put("totalPages", getTotalPages());
        pageInfo.put("pageOffset", pageable.getPageOffset());
        pageInfo.put("currentElements", getNumberOfElements());
        pageInfo.put("totalElements", getTotalElements());

        if (elements instanceof LazyList) {
            pageInfo.put("loading", Boolean.valueOf(((LazyList)elements).isLoading()));
        }

        return pageInfo;
    }

    @JsonIgnore
    public boolean hasContent() {
        return !content.isEmpty();
    }

    @JsonIgnore
    public boolean isFirst() {
        return pageable.getPageNumber() == 1;
    }

    @JsonIgnore
    public boolean isLast() {
        return pageable.getPageNumber() == getTotalPages();
    }

    @JsonIgnore
    public boolean hasNext() {
        return pageable.getPageNumber() < getTotalPages();
    }

    @JsonIgnore
    public boolean hasPrevious() {
        return pageable.getPageNumber() > 1 && pageable.getPageNumber() <= getTotalPages();
    }

    @JsonIgnore
    public int getNumber() {
        return pageable.getPageNumber();
    }

    @JsonIgnore
    public int getSize() {
        return pageable.getPageSize();
    }

    @JsonIgnore
    public int getNumberOfElements() {
        return content.size();
    }

    @JsonIgnore
    public int getTotalPages() {
        return (elements.size() + pageable.getPageSize()-1)/pageable.getPageSize();
    }

    @JsonIgnore
    public int getTotalElements() {
        return elements.size();
    }

    public List<WebLink> getLinks() {
        List<WebLink> links = new ArrayList<>();

        int currentPage = pageable.getPageNumber();
        int totalPages = getTotalPages();

        links.add(new WebLink(pageable.toRequestParams(href, currentPage)));

        if (getTotalPages() <= 1)
            return links;

        if (getTotalPages() > 2) {
            // if (!isFirst())
            links.add(new WebLink("first", pageable.toRequestParams(href, 1)));
            // if (!isLast())
            links.add(new WebLink("last", pageable.toRequestParams(href, totalPages)));
        }

        if (hasPrevious())
            links.add(new WebLink("previous", pageable.toRequestParams(href, currentPage-1)));
        if (hasNext())
            links.add(new WebLink("next", pageable.toRequestParams(href, currentPage+1)));

        return links;
    }

}

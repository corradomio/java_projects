package ae.ebtic.spl.projects;

import ae.ebtic.spl.server.controller.wsocket.WSTaskStatusListener;
import jext.tasks.TaskStatusListener;
import jext.util.Parameters;
import jext.util.StringUtils;

import java.util.*;

public class ModelCreateParams {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    // private boolean sync = false;
    private String method = "";
    private Parameters parameters = new Parameters();
    private List<TaskStatusListener> listeners = new ArrayList<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelCreateParams() {

    }

    public ModelCreateParams(WSTaskStatusListener l) {
        this.listener(l);
    }

    // ----------------------------------------------------------------------
    // Set the parameters
    // ----------------------------------------------------------------------

    // public ModelCreateParams sync() {
    //     sync = true;
    //     return this;
    // }

    public ModelCreateParams method(String method) {
        this.method = method;
        return this;
    }

    public ModelCreateParams filter(List<String> filter) {
        parameters.put("filter", filter);
        return this;
    }

    public ModelCreateParams listener(TaskStatusListener l) {
        listeners.add(l);
        return this;
    }

    public ModelCreateParams parameters(Parameters params) {
        parameters.putAll(params);
        return this;
    }

    // ----------------------------------------------------------------------
    // Get the parameters
    // ----------------------------------------------------------------------

    // public boolean isSync() { return sync; }

    public String method() { return method; }

    public List<String> filter() { return (List<String>) parameters.getOrDefault("filter", Collections.emptyList()); }

    public List<TaskStatusListener> listeners() { return listeners; }

    // ----------------------------------------------------------------------
    // Get the parameters
    // ----------------------------------------------------------------------

    public ModelCreateParams addParameter(String name, Object value) {
        parameters.put(name, value);
        return this;
    }

    public Parameters parameters() { return parameters; }

    // ----------------------------------------------------------------------
    // Check the parameters
    // ----------------------------------------------------------------------

    public boolean isDefault() {
        return StringUtils.isEmpty(this.method)
            && ((List) parameters.getOrDefault("filter", Collections.emptyList())).isEmpty()
            ;
    }

    public boolean hasMethodAndFilter() {
        return !StringUtils.isEmpty(this.method)
            && !((List) parameters.getOrDefault("filter", Collections.emptyList())).isEmpty()
            ;
    }

    public boolean hasMethod() {
        return !StringUtils.isEmpty(this.method);
    }
}

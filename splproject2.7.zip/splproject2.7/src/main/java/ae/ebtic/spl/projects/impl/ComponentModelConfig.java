package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelConfig;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;

public class ComponentModelConfig extends ModelConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ComponentModelConfig() {
        super();
    }

    public static ComponentModelConfig loadOrDefault(File configFile) {

        Logger logger = Logger.getLogger(ComponentModelConfig.class);

        if (configFile.exists())
        try {
            return (ComponentModelConfig) JSONUtils.load(configFile, ComponentModelConfig.class).configIn(configFile);
        }
        catch (Exception e) {
            logger.error(e, e);
        }

        return (ComponentModelConfig) new ComponentModelConfig().configIn(configFile);
    }

}

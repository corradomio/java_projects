package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.projects.ModelInfo;
import jext.util.HashMap;

public class ModelInfoImpl extends HashMap<String, Object> implements ModelInfo {

}

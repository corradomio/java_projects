package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.dependency.WebLibraryModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency/libraries")
public class LibrariesController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public LibrariesController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public ResponseEntity<?> getLibrariesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        List<WebLibraryModel> libraries = dm.getLibraries()
            .stream()
            .map(library -> new WebLibraryModel(library, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(libraries, HttpStatus.OK);
    }

    @GetMapping(value = "{libraryId}")
    @ResponseBody
    public ResponseEntity<?> getLibrary(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String libraryId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Library library = dm.getLibrary(libraryId);

        return new ResponseEntity<>((WebLibraryModel)new WebLibraryModel(library, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping(value = "{libraryId}/types")
    @ResponseBody
    public ResponseEntity<?> getLibraryTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String libraryId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        //Library library = dm.getLibrary(libraryId);

        List<WebTypeModel> types = dm.getLibraryTypes(libraryId)//library.getTypes()
            .stream()
            .map(type -> new WebTypeModel(type, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(types, HttpStatus.OK);
    }
}

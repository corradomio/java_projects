package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.diagrams.TypeDiagram;
import ae.ebtic.spl.analysis.diagrams.TypeDiagramConfig;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.GraphEdge;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DiagramsModel;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import jext.graph.Direction;
import jext.logging.Logger;

import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class DiagramsModelImpl extends ProjectModelImpl implements DiagramsModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(DiagramsModel.class);

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected DiagramsModelImpl(SPLProject project) {
        super(project, DiagramsModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public TypeDiagram getTypeDiagram(TypeDiagramConfig config) {
        TypeDiagram td = new TypeDiagram(config);

        List<GraphNode> nodes = this.pga.getGraphAccess().getNodes(config.ids);
        addTypes(td, nodes);

        if (config.extend && config.implement)
            addHierarchy(td);
        else if (config.extend)
            addExtends(td);
        else if (config.implement)
            addImplements(td);

        if (config.dependsOn)
            addDependsOn(td);

        if (config.extend || config.implement || config.dependsOn)
            addEdges(td);

        if (config.attributes)
            addFields(td);

        if (config.operations)
            addOperations(td);

        if (config.operationCalls)
            addMethodCalls(td);

        return td;
    }

    private void addTypes(TypeDiagram td, List<GraphNode> nodes) {

        for(GraphNode node : nodes) {
            if (node.isFeature()) {
                td.addTypes(node.asFeature().getTypes());
            }
            else if (node.isComponent()) {
                td.addTypes(node.asComponent().getTypes());
            }
            else if (node.isType()) {
                td.addType(node.asType());
            }
        }
    }

    private void addHierarchy(TypeDiagram td) {
        TypeDiagramConfig config = td.getConfig();
        Set<Type> extendTypes = new HashSet<>();
        for(Type typeNode : td.getTypeNodes()) {
            List<Type> types = typeNode.getUseTypes(TypeUse.HIERARCHY, Direction.Input, config.recursive, config.refTypes);
            extendTypes.addAll(types);
        }
        td.addTypes(extendTypes);
    }

    private void addExtends(TypeDiagram td) {
        TypeDiagramConfig config = td.getConfig();
        Set<Type> extendTypes = new HashSet<>();
        for(Type typeNode : td.getTypeNodes()) {
            List<Type> types = typeNode.getUseTypes(TypeUse.EXTENDS, Direction.Input, config.recursive, config.refTypes);
            extendTypes.addAll(types);
        }
        td.addTypes(extendTypes);
    }

    private void addImplements(TypeDiagram td) {
        TypeDiagramConfig config = td.getConfig();
        Set<Type> implementTypes = new HashSet<>();
        List<Type> types;
        for(Type typeNode : td.getTypeNodes()) {
            if (typeNode.getRole().equals(TypeRole.INTERFACE)) {
                types = typeNode.getUseTypes(TypeUse.IMPLEMENTS, Direction.Input, config.recursive, config.refTypes);
                implementTypes.addAll(types);
            }
        }
        td.addTypes(implementTypes);
    }

    private void addDependsOn(TypeDiagram td) {
        TypeDiagramConfig config = td.getConfig();
        Set<Type> dependTypes = new HashSet<>();
        for(Type typeNode : td.getTypeNodes()) {
            List<Type> types = typeNode.getUseTypes(TypeUse.DEPENDS_ON, Direction.Output, config.recursive, config.refTypes);
            dependTypes.addAll(types);
        }
        td.addTypes(dependTypes);
    }

    private void addEdges(TypeDiagram td) {
        td.addTypeDeps(this.pga.getGraphAccess().getEdges(USES, td.getTypeIds()));
    }

    private void addFields(TypeDiagram td) {
        for (Type typeNode : td.getTypeNodes()) {
            td.addFields(typeNode.getFields());
        }
    }

    private void addOperations(TypeDiagram td) {
        for (Type typeNode : td.getTypeNodes()) {
            td.addMethods(typeNode.getMethods());
        }
    }

    private void addMethodCalls(TypeDiagram td) {
        List<GraphEdge> edges = this.pga.getGraphAccess().getEdges(METHOD_CALL, td.getMethodIds());
        td.addMethodCalls(edges);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkStatus() {
        if (pga == null) {
            GraphConfig config = new GraphConfig()
                .setGraphDatabase(Managers.getGraphDatabase())
                .setProjectName(project.getName());
            pga = ProjectGraphAccess.newProjectGraphAccess(config);
            setProjectGraphAccess(pga);
        }
    }

    @Override
    protected void checkModelStatus() {
        setStatus(ModelStatus.VALID, null);
    }

}

package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.managers.Managers;
import jext.util.DelayedTimer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.messaging.simp.SimpMessageSendingOperations;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;

import java.text.SimpleDateFormat;
import java.util.Date;

@Controller
@CrossOrigin
public class WebSocketController /*extends SPLRestController*/ {

    // ----------------------------------------------------------------------
    // Static methods
    // ----------------------------------------------------------------------

    private static WebSocketController instance;

    public static void send(WSMessage message) {
        if (instance == null)
            return;

        instance.sendMessage(message);
    }

    // ----------------------------------------------------------------------
    // KeepAlive
    // ----------------------------------------------------------------------

    private static final SimpleDateFormat FORMATTER = new SimpleDateFormat("HH:mm:ss");

    public static class KeepAliveMessage implements WSMessage {
        private String timestamp;

        private KeepAliveMessage() {
            this.timestamp = FORMATTER.format(new Date());
        }

        public String getTimestamp() { return timestamp; }

        @Override
        public String destination() {
            return WebSocketController.TOPIC_KEEP_ALIVE;
        }
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static final String TOPIC_KEEP_ALIVE = "/topic/keepalive";
    private static final String PROGRESS_MESSAGE = ".progress";

    @Autowired private SimpMessageSendingOperations messagingTemplate;

    private static long progressTimeout = 100;
    private static long progressTimestamp = System.currentTimeMillis();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public WebSocketController() {

        instance = this;

        long keepAliveTimeout = Managers.getConfiguration().getLong("system.messages.keepalive[@timeout]", 5000);
        progressTimeout = Managers.getConfiguration().getInt("system.messages.progress[@timeout]", 100);

        DelayedTimer.register(keepAliveTimeout, (previous, now) -> WebSocketController.this.sendKeepAlive());
    }


    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private void sendKeepAlive() {
        sendMessage(new KeepAliveMessage());
    }

    private void sendMessage(WSMessage message) {
        if (messagingTemplate == null)
            return;

        String destination = message.destination();

        if (destination.endsWith(PROGRESS_MESSAGE)) {
            long now = System.currentTimeMillis();
            if ((now - progressTimestamp) < progressTimeout)
                return;
            else
                progressTimestamp = now;
        }

        messagingTemplate.convertAndSend(destination, message);
    }

}

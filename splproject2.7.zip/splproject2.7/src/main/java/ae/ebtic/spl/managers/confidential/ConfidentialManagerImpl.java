package ae.ebtic.spl.managers.confidential;

import jext.logging.Logger;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class ConfidentialManagerImpl implements ConfidentialManager {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(ConfidentialManagerImpl.class);

    private String systemPassword;
    private Configuration config;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ConfidentialManagerImpl() {

    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getSystemPassword() {
        return systemPassword;
    }

    @Override
    public String getName() {
        return MANAGER;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public void configure(Configuration config) throws ConfigurationException {
        this.config = config;

        logger.info("configure");

        systemPassword = config.getString("password[@value]");
        logger.infof("  system.password: %s", "***");

        logger.info("configure");

    }

    @Override
    public void destroy() {

    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.tasks.AnalyzeDependencyFilterTask;
import ae.ebtic.spl.tasks.AnalyzeDependencyTask;
import ae.ebtic.spl.tasks.ProjectTask;
import ae.ebtic.spl.tasks.SPLProjectTask;
import jext.graph.NodeDegree;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ae.ebtic.spl.common.ModelConstants.COMPONENT_FILTER_ANALYSIS;


public class DependencyModelImpl extends ProjectModelImpl implements DependencyModel,
    GraphConstants{

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    // private static final String MODEL_CONFIG = "dependency-config.json";

    private DependencyGraph dg;
    // private String methodCreation;
    // private List<String> filterKeyword;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public DependencyModelImpl(SPLProject project) {
        super(project, DependencyModel.TYPE);
        // methodCreation = "";
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl)super.getInfo();

        Map<String, Object> counts = new HashMap<>();
        counts.put("sources", dg.getSourcesCount());
        counts.put("modules", dg.getModulesCount());
        counts.put("types", dg.getTypesCount(false));
        counts.put("refTypes", dg.getTypesCount(true));

        info.put("count", counts);

        return info;
    }

    @Override
    public long getTimestamp() {
        return dg.getTimestamp();
    }

    @Override
    public DependencyGraph getDependencyGraph() {
        return dg;
    }

    // ----------------------------------------------------------------------
    // Navigate Source Object Model
    // ----------------------------------------------------------------------

    @Override
    public Project getProject() {
        return dg.getProject();
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    // -- Modules

    @Override
    public List<Module> getModules() {
        return dg.getModules();
    }

    @Override
    public Module getModule(String moduleId) {
        return dg.getModule(moduleId);
    }

    @Override
    public List<Type> getModuleTypes(String moduleId) {
        return dg.getModuleTypes(moduleId);
    }

    @Override
    public List<Library> getModuleLibraries(String moduleId) {
        return dg.getModuleLibraries(moduleId);
    }

    // -- Sources

    @Override
    public List<Source> getSources() {
        return dg.getSources();
    }

    @Override
    public List<Source> getSources(String moduleId) {
        return dg.getSources(moduleId);
    }

    @Override
    public Source getSource(String sourceId) {
        return dg.getSource(sourceId);
    }

    // -- Types

    @Override
    public int getTypesCount() {
        return (int)dg.getTypesCount(false);
    }

    @Override
    public List<Type> getTypes() {
        return dg.getTypes();
    }

    @Override
    public List<Type> getTypes(String moduleId) {
        return dg.getTypes(moduleId);
    }

    @Override
    public List<Type> getTypes(NodeDegree ndegree, String role) {
        return dg.getTypes(ndegree, role);
    }

    @Override
    public Type getType(String typeId) {
        return dg.getType(typeId);
    }

    @Override
    public Method getMethod(String methodId) {
        return dg.getMethod(methodId);
    }

    @Override
    public Field getField(String fielId) {
        return dg.getField(fielId);
    }

    @Override
    public double getComplexity(double threshold) {
        return dg.getComplexity(threshold);
    }

    // -- Libraries

    @Override
    public List<Library> getLibraries() {
        return dg.getLibraries();
    }

    @Override
    public List<Library> getLibraries(String moduleId) {
        return dg.getLibraries(moduleId);
    }

    @Override
    public Library getLibrary(String libraryId) {
        return dg.getLibrary(libraryId);
    }

    @Override
    public List<RefType> getLibraryTypes(String libraryId) {
        return dg.getLibraryTypes(libraryId);
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public Map<String, Object> getModelGraph() {
        return dg.getModelGraph();
    }

    @Override
    public Map<String, Object> getFeatures(String typeId) {return  dg.getFeaturesOld(typeId);}

    // -- Closures

    @Override
    public Map<String, Object> getClosure(String typeId, boolean refTypes, boolean implementation, boolean links) {
        return dg.getClosure(typeId, refTypes, implementation, links);
    }

    @Override
    public Map<String, Object> getClosures(List<String> typeIds, boolean refTypes, boolean implementation, boolean links) {
        return dg.getClosures(typeIds, refTypes, implementation, links);
    }

    @Override
    public List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, String typeId){
        return dg.getInterfaceImplementations(interfaces, typeId);
    }

    @Override
    public List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, List<String> typeIds){
        return dg.getInterfaceImplementations(interfaces, typeIds);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected boolean hasDependenciesResolved() {
        return getSPLProject().getSourceModel().getStatus() == ModelStatus.VALID;
    }

    // @Override
    // protected boolean create(String methodCreation, List<String> filter){
    //     this.methodCreation = methodCreation;
    //     this.filterKeyword = filter;
    //     return createNoParams();
    // }

    @Override
    protected ProjectTask createThis() {
        SPLProjectTask task;

        dg.create();
        dg.setStatus(STATUS_TASK_RUNNING, REASON_CREATE);

        switch( this.modelCreateParams.method()){
            case COMPONENT_FILTER_ANALYSIS:
                task = new AnalyzeDependencyFilterTask(this, this.modelCreateParams.filter());
                break;
            default:
                task = new AnalyzeDependencyTask(this);
        }
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());

        return task;

        // if (sync)
        //     task.run();
        // else
        //     Managers.getTaskManager().submit(task);
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        dg.delete();
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkStatus() {
        if (dg == null) {
            GraphConfig config = new GraphConfig()
                .setGraphDatabase(Managers.getGraphDatabase())
                .setProjectName(project.getName());
            //pg = dg = DependencyGraph.newDependencyGraph(config);
            dg = ProjectGraphAccess.newProjectGraphAccess(config).getDependencyGraph();
            setProjectGraphAccess(dg);
        }
    }

    @Override
    protected void checkModelStatus() {

        // if (!dg.exists()) {
        //     setStatus(ModelStatus.NOT_EXISTENT, null);
        //     return;
        // }
        if (!STATUS_VALID.equals(dg.getStatus())) {
            setStatus(ModelStatus.valueOf(dg.getStatus()), String.format("Graph in status %s", dg.getStatus()));
            return;
        }

        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        SourceModel sm = getSPLProject().getSourceModel();

        // check the status of the source model
        if (sm.getStatus() != ModelStatus.VALID) {
            setStatus( ModelStatus.INVALID, String.format("SourceModel has status %s", sm.getStatus()));
            return;
        }

        // chekc the models timestamps
        if (sm.getTimestamp() > getTimestamp()) {
            setStatus(ModelStatus.INVALID, "SourceModel is more recent");
            return;
        }
    }

}

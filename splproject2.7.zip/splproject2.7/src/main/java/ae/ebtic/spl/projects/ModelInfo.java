package ae.ebtic.spl.projects;

public interface ModelInfo {
}

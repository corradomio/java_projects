package ae.ebtic.spl.projects;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.logging.Logger;
import jext.util.JSONUtils;

import java.io.File;
import java.io.IOException;

public class ModelConfig {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    protected Logger logger = Logger.getLogger(getClass());

    protected File configFile;
    protected ModelStatus status = ModelStatus.VALID;
    protected String message = "";
    protected long timestamp = 0;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelConfig() { }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    @JsonIgnore
    public File configIn() {
        return this.configFile;
    }

    @JsonIgnore
    public ModelConfig configIn(File configFile) {
        this.configFile = configFile;
        return this;
    }

    public void delete() {
        configFile.delete();
        status = ModelStatus.NOT_EXISTENT;
    }

    public ModelConfig save() {
        try {
            configFile.getParentFile().mkdirs();
            JSONUtils.save(configFile, this);
        }
        catch (IOException e) {
            logger.error(e, e);
        }

        return this;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    /**
     * Check if the configuration is a VALID configuration.
     * It is valid IF the parent directory exists
     */
    public boolean isValid() {
        return configFile.getParentFile().exists();
    }

    /**
     * Check if the configuration file exists
     */
    public boolean exists() {
        return configFile.exists();
    }

    // -- timestamp

    /**
     * Set the timestamp of the model
     */
    public ModelConfig setTimestamp(long ts) {
        timestamp = ts;
        return this;
    }

    public long getTimestamp() {
        if (timestamp == 0 && configFile.exists())
            timestamp = configFile.lastModified();
        return timestamp;
    }

    public ModelConfig updateTimestamp() {
        timestamp = System.currentTimeMillis();
        return this;
    }

    // -- Status

    @JsonIgnore
    public ModelConfig setStatus(ModelStatus status, String message) {
        this.message = message;
        setStatus(status);
        if (status != ModelStatus.NOT_EXISTENT)
            save();
        return this;
    }

    /**
     * Set the new status of the model
     * @param status new status
     * @return this
     */
    public ModelConfig setStatus(ModelStatus status) {
        this.status = status;
        return this;
    }

    /**
     * retrieve the status of the model
     *
     * @return current status
     */
    public ModelStatus getStatus() {
        if (!configFile.exists())
            return ModelStatus.NOT_EXISTENT;
        else
            return this.status;
    }

    // -- Message

    public ModelConfig setMessage(String message) {
        // DON'T REMOVE! It is necessary to JSON serialization
        if (message == null) message = "";
        this.message = message;
        return this;
    }

    public String getMessage() {
        return this.message;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public String toString() {
        return String.format("%s[%s]", getClass().getName(), configFile);
    }
}

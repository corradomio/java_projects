package ae.ebtic.spl.managers.cache;

import ae.ebtic.spl.managers.Manager;

public interface CacheManager extends Manager {

    String MANAGER = "cacheManager";

}

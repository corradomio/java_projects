package ae.ebtic.spl.server.controller.project;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.SPLProjectConfig;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebDetailedModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.project.WebProjectConfig;
import ae.ebtic.spl.server.webmodels.project.WebProjectModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects")
public class SPLProjectsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLProjectsController() {
        super("projects");
    }

    // ----------------------------------------------------------------------
    // Projects
    // ----------------------------------------------------------------------

    /**
     * List of projects
     */
    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getProjectsList(
        @PathVariable String repoName,
        @RequestParam(value = "select", defaultValue = "") String select) {
        // logger.infof("%s.listProjects()", repoName);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        List<WebProjectModel> projects = Managers.getSPLReposManager().newRepository(repoName)
            .listProjects()
            .stream()
            .map(project -> (WebProjectModel)(new WebProjectModel(project, requestUrl).detailed(select)))
            .collect(Collectors.toList());

        return new ResponseEntity<>(projects, HttpStatus.OK);
    }

    /**
     * Retrieve a project
     */
    @GetMapping("{projectName}")
    @ResponseBody
    public ResponseEntity<?> getProject(
        @PathVariable String repoName,
        @PathVariable String projectName) {
        logger.infof("%s.getProject(%s)", repoName, projectName);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager().newRepository(repoName).newProject(projectName);

        if (!project.exists())
            return new ResponseEntity<>(new WebProjectModel(project, requestUrl), HttpStatus.NOT_FOUND);

        return new ResponseEntity<>((WebProjectModel)new WebProjectModel(project, requestUrl).detailed(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // Create a project
    // ----------------------------------------------------------------------

    /**
     * Create a project (DEPRECATED)
     */
    @PutMapping(value="{projectName}", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProject(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody WebProjectConfig config) throws Exception {

        config.setRepository(repoName).setProject(projectName);

        return createProject(repoName, config);
    }

    /**
     * Create a project
     */
    @PostMapping(value="", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> createProject(
        @PathVariable String repoName,
        @RequestBody WebProjectConfig config) throws Exception {

        config.setRepository(repoName);

        String projectName = config.getProject();

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        SPLProjectConfig splconfig = new SPLProjectConfig()
            .setURL(config.getUrl())
            .setParameters(config.getParameters())
            .setDescription(config.getDescription());

        if (project.create(splconfig))
            return new ResponseEntity<>(new WebProjectModel(project, requestUrl), HttpStatus.OK);
        else
            return new ResponseEntity<>(new WebProjectModel(project, requestUrl), HttpStatus.FORBIDDEN);
    }

    // ----------------------------------------------------------------------
    // Delete a project
    // ----------------------------------------------------------------------

    /**
     * Delete a project (DEBUG)
     */
    @GetMapping(value="{projectName}/delete")
    @ResponseBody
    public ResponseEntity<?> deleteProjectByGet(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        return this.deleteProject(repoName, projectName);
    }

    /**
     * Delete a project
     */
    @DeleteMapping(value="{projectName}", consumes="application/json", produces="application/json")
    @ResponseBody
    public ResponseEntity<?> deleteProject(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        Managers.getExecutorService().submit(() -> {
            project.delete();
        });

        return new ResponseEntity<>(new WebProjectModel(project, requestUrl), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    /**
     * (TO_REPLACE)
     * Move it under "feature model"
     * Check for missing model
     */
    @GetMapping(value="{projectName}/modulesWithTypes")
    @ResponseBody
    public ResponseEntity<?> getModulesWithTypesList(
            @PathVariable String repoName,
            @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getModulesWithTypes(), HttpStatus.OK);
    }

    /**
     * (TO_REPLACE)
     * Move it under "feature model"
     * Check for missing model
     * CRUD rules: url & POST->GET
     */
    @PostMapping(value="{projectName}/findModulesIP")
    @ResponseBody
    public ResponseEntity<?> findModulesIP(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestBody Map<String, Integer> ids)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().findModulesIP(ids), HttpStatus.OK);
    }

    /**
     * (TO_REPLACE)
     * Move it under "feature model"
     * Check for missing model
     * CRUD rules: url
     */
    @GetMapping(value="{projectName}/getModelsSize")
    @ResponseBody
    public ResponseEntity<?> getModelsSize(
            @PathVariable String repoName,
            @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getModelsSize(), HttpStatus.OK);
    }

    /**
     * (TO_REPLACE)
     * Move it under "feature model"
     * Check for missing model
     * CRUD rules: url
     */
    @GetMapping(value="{projectName}/getTypesCount")
    @ResponseBody
    public ResponseEntity<?> getTypesCount(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @RequestParam(value = "depth", defaultValue = "1") int depth)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName);

        project.getFeatureModel().setTypesCount();

        Map<String, Object> featureCount = project.getFeatureModel().getTypesCount();

        List<Map<String, Object>> featureList = (ArrayList<Map<String, Object>>)featureCount.get("graph");

        project.getComponentModel().setTypesCount();

        Map<String, Object> componentCount = project.getComponentModel().getTypesCount(depth);

        List<Map<String, Object>> componentList = (ArrayList<Map<String, Object>>)componentCount.get("graph");

        componentList = componentList
            .stream()
            .filter(c -> featureList.stream().noneMatch(f -> f.get("fullName").equals(c.get("fullName"))))
            .collect(Collectors.toList());

        componentCount.put("graph",componentList);

        Map<String, Object> finalCount = new HashMap<>();

        finalCount.put("feature", featureCount);
        finalCount.put("component", componentCount);

        return new ResponseEntity<>(finalCount, HttpStatus.OK);
    }

}

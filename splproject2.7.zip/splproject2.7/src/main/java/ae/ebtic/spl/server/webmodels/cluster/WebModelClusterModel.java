package ae.ebtic.spl.server.webmodels.cluster;

import ae.ebtic.spl.projects.ClusterModel;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.ProjectModel;
import ae.ebtic.spl.server.webmodels.WebModelModel;

public class WebModelClusterModel extends WebModelModel {

    public WebModelClusterModel(ProjectModel pmodel, String prefixUrl) {
        super(pmodel, prefixUrl);
    }

    private ClusterModel getModel() {
        return (ClusterModel) model;
    }

}

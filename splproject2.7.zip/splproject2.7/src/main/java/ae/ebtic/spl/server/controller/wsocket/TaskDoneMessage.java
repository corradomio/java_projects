package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.tasks.ProjectTask;
import jext.tasks.Task;

public class TaskDoneMessage extends TaskStatusMessage {

    public TaskDoneMessage(ProjectTask task) {
        super(task);
    }

}

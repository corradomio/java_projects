package ae.ebtic.spl.server.webmodels.component;

import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.ProjectModel;
import ae.ebtic.spl.server.webmodels.WebLink;
import ae.ebtic.spl.server.webmodels.WebModelModel;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class WebModelComponentModel extends WebModelModel {

    public WebModelComponentModel(ProjectModel model, String prefixUrl) {
        super(model, prefixUrl);
    }

    // public List<WebComponentModel> getComponents() {
    //     if (!detailed)
    //         return Collections.emptyList();
    //
    //     return getModel().getComponents()
    //         .stream()
    //         .map(c -> new WebComponentModel(c, href))
    //         .collect(Collectors.toList());
    // }

    @Override
    protected List<WebLink> getLinks() {
        if (!detailed)
            return Collections.emptyList();

        return Arrays.asList(
            WebLink.of(href, "components"),
            new WebLink(href)
        );
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.managers.services.rtanalysis;

import ae.ebtic.spl.managers.Manager;
import ae.ebtic.spl.server.controller.runtime.EntryPointsConfig;
import ae.ebtic.spl.tasks.EntryPointsAnalysisTask;

public interface RTAnalysisManager extends Manager {

    String MANAGER = "runtime";

    EntryPointsAnalysisTask analyzeProject(EntryPointsConfig config);
}

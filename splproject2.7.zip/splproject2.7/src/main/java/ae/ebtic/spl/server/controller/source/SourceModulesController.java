package ae.ebtic.spl.server.controller.source;

import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.source.WebLibraryModel;
import ae.ebtic.spl.server.webmodels.source.WebModuleModel;
import ae.ebtic.spl.server.webmodels.source.WebSourceModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/source/modules")
public class SourceModulesController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourceModulesController() {
        super(SourceModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web navigation
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public ResponseEntity<?> getModulesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        List<WebModuleModel> wmodules = sm.getModules()
            .stream()
            .map(module -> new WebModuleModel(module, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(wmodules, HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}")
    @ResponseBody
    public  ResponseEntity<?> getModule(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Module module = sm.getModule(moduleId);

        WebModuleModel wm = new WebModuleModel(module, requestUrl).detailed();
        return new ResponseEntity<>(wm, HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}/sources")
    @ResponseBody
    public  ResponseEntity<?> getModuleSourcesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Module module = sm.getModule(moduleId);

        List<WebSourceModel> wsources = module.getSources()
            .stream()
            .map(source -> new WebSourceModel(source, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(wsources, HttpStatus.OK);
    }

    @GetMapping(value = "{moduleId}/libraries")
    @ResponseBody
    public  ResponseEntity<?> getModuleLibrariesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String moduleId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Module module = sm.getModule(moduleId);

        List<WebLibraryModel> mlibraries = module.getLibraries()
            .stream()
            .map(library -> new WebLibraryModel(library, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(mlibraries, HttpStatus.OK);
    }

}

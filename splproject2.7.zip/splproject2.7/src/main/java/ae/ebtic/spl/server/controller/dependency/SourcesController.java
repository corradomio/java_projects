package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.dependency.WebModuleModel;
import ae.ebtic.spl.server.webmodels.dependency.WebSourceModel;
import jext.util.FileUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency/sources")
public class SourcesController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourcesController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Wen methods
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public ResponseEntity<?> getSourcesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        List<WebSourceModel> sources = dm.getSources()
            .stream()
            .map(source -> new WebSourceModel(source, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(sources, HttpStatus.OK);
    }

    @GetMapping(value = "{sourceId}")
    @ResponseBody
    public ResponseEntity<?> getSource(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String sourceId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Source source = dm.getSource(sourceId);

        return new ResponseEntity<>((WebSourceModel)new WebSourceModel(source, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping(value = "{sourceId}/content", produces = "text/plain")
    @ResponseBody
    public ResponseEntity<?> getSourceContent(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String sourceId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Source source = dm.getSource(sourceId);

        File sourceFile = new File(source.getPath());

        String content = FileUtils.toString(sourceFile);

        return new ResponseEntity<>(content, HttpStatus.OK);
    }
}

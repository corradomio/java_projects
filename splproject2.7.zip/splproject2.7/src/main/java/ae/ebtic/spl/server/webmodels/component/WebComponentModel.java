package ae.ebtic.spl.server.webmodels.component;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.server.webmodels.WebDetailedModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebLink;
import jext.util.SetUtils;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class WebComponentModel extends WebDetailedModel implements GraphConstants {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private Component component;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public WebComponentModel(Component c, String prefixUrl) {
        super(prefixUrl);
        this.component = c;
        this.href = WebHrefMapper.of(prefixUrl).getComponentHref(c.getId());
        populate();
    }

    // ----------------------------------------------------------------------
    // Populate
    // ----------------------------------------------------------------------

    @Override
    protected void populate() {
        super.populate();

        put(ID, component.getId());
        put(NAME, component.getName().getName());
        if (isSelected(FULL_NAME))
            put(FULL_NAME, component.getName().getFullName());
        put(COUNT, component.getCount());
        put(TYPES_COUNT, component.getTypesCount());
        put(DEPTH, component.getDepth());
        put(TYPE_ID, component.getTypeId());

        // if (isSelected(ENTRY_POINT))
            put(ENTRY_POINT, component.isEntryPoint());
        // if (isSelected(COUNT_ENTRY_POINTS)
            put(COUNT_ENTRY_POINTS, component.getCountEntryPoints());
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // public String getHref() { return href; }

    // public String getId() { return component.getId(); }

    // public String getName() { return component.getName().getName(); }

    // public String getFullName() { return component.getName().getFullName(); }

    // public long getCount() {return component.getCount(); }

    // public long getTypesCount() { return component.getTypesCount(); }

    // public long getDepth() { return component.getDepth(); }

    // public String getTypeId() { return component.getTypeId(); }

    // public List<WebComponentModel> getMembers() {
    //     if (!detailed)
    //         return Collections.emptyList();
    //
    //     return component.listMembers()
    //         .stream()
    //         .map(c -> new WebComponentModel(c, href))
    //         .collect(Collectors.toList());
    // }

    // public List<WebTypeModel> getTypes() {
    //     if (!detailed)
    //         return Collections.emptyList();
    //
    //     return component.listTypes()
    //         .stream()
    //         .map(dt -> new WebTypeModel(dt, href))
    //         .collect(Collectors.toList());
    // }

    // public List<WebFeatureModel> getFeatures() {
    //     if (!detailed)
    //         return Collections.emptyList();
    //
    //     return component.listFeatures()
    //         .stream()
    //         .map(dt -> new WebFeatureModel(dt, href))
    //         .collect(Collectors.toList());
    // }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected List<WebLink> getLinks() {
        if (!detailed)
            return Collections.emptyList();

        String typeId = component.getTypeId();

        return Arrays.asList(
            new WebLink("type", WebHrefMapper.of(href).getTypeHref(typeId)),
            WebLink.of(href, "members"),
            WebLink.of(href, "types"),
            WebLink.of(href, "features"),
            new WebLink(href)
        );
    }

    @Override
    protected  Map<String, Object> readValues() {
        return component.getValues();
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

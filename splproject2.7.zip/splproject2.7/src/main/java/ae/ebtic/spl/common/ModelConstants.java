package ae.ebtic.spl.common;

public interface ModelConstants {

    // ----------------------------------------------------------------------
    // Analysis Methods
    // ----------------------------------------------------------------------

    String COMPONENT_TopDown_ANALYSIS = "topdown";

    String COMPONENT_FILTER_ANALYSIS = "filter";

}

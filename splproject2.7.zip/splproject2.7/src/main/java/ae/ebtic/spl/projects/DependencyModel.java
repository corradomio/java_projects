package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.NodeDegree;

import java.util.List;
import java.util.Map;

public interface DependencyModel extends ProjectModel {

    String TYPE = "dependency";

    DependencyGraph getDependencyGraph();

    Project getProject();

    // ----------------------------------------------------------------------

    // -- Modules

    List<Module> getModules();

    Module getModule(String moduleId);

    List<Type> getModuleTypes(String moduleId);

    List<Library> getModuleLibraries(String moduleId);

    // -- Sources

    List<Source> getSources();

    List<Source> getSources(String moduleId);

    Source getSource(String sourceId);

    // -- Types

    int getTypesCount();

    List<Type> getTypes();

    List<Type> getTypes(String moduleId);

    List<Type> getTypes(NodeDegree ndegree, String role);

    /** retrieve the type by id or 'fullname' */
    Type getType(String typeId);

    Method getMethod(String methodId);

    Field getField(String fieldId);

    // -- Libraries

    List<Library> getLibraries();

    List<Library> getLibraries(String moduleId);

    Library getLibrary(String libraryId);

    List<RefType> getLibraryTypes(String libraryId);

    // ----------------------------------------------------------------------

    double getComplexity(double threshold);

    // ----------------------------------------------------------------------

    Map<String, Object> getModelGraph();

    Map<String, Object> getFeatures(String typeId);

    Map<String, Object> getClosure(String typeId, boolean refTypes, boolean implementation, boolean links);

    Map<String, Object> getClosures(List<String> typeIds, boolean refTypes, boolean implementation, boolean links);

    List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, String typeId);

    List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, List<String> typeIds);
}

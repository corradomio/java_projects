package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import ae.ebtic.spl.managers.splrepos.SPLRepository;
import ae.ebtic.spl.projects.ClusterModel;
import ae.ebtic.spl.projects.ComponentModel;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.projects.DiagramsModel;
import ae.ebtic.spl.projects.FeatureModel;
import ae.ebtic.spl.projects.ProjectModel;
import ae.ebtic.spl.projects.RuntimeModel;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.SPLProjectConfig;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.projects.StatisticsModel;
import ae.ebtic.spl.projects.VersioningModel;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.StringUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/*
    It is necessary to have TWO different directories:

    - <projectName>         for the source codes
    - <projectName>.spl     for the SPL service

    This because the versioning systems, when they need to download a project, they NEED

    - a not existent directory OR
    - an empty directory

    Another consideration is to convert a project in a SPL project with minimum modifications
    of the original project: it can be a not good idea to change the ORIGINAL directory, for
    example because the directory is in a READONLY folder, or in a REMOTE repository.

    This permit also another nice trick:

    - to chec if the SourceModel is available, it is enough to check if the project home exists
    - also, it is possible to DELETE the source model

 */
public class SPLProjectImpl extends NamedObject implements SPLProject {

    // ----------------------------------------------------------------------
    // Private Properties
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(SPLProjectImpl.class);

    private static final String PROJECT_CONFIG = "project-config.json";

    private SPLRepository repo;
    private SPLProjectConfig configuration;

    private File projectRoot;   // home directory used for OTHER operations
    private File projectSpl;

    private Map<String, ProjectModel> modelsByType = new HashMap<>();
    // private Map<Class<?>, ProjectModel> modelsByClass = new HashMap<>();

    // private ProjectTask task;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLProjectImpl(SPLRepository repo, String name) {
        super(new PathName(repo.getName(), name));
        this.repo = repo;

        checkConfig();
        createModels();
    }

    public void registerModel(ProjectModel model) {
        modelsByType.put(model.getType(), model);
        // modelsByClass.put(model.getClass(), model);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public SPLRepository getRepository() {
        return repo;
    }

    @Override
    public String getId() {
        return StringUtils.digest(getName().getFullName());
        // String id = ProjectModelConfig.loadForProject(getSPLDirectory()).getId();
        // if (id.isEmpty())
        //     return StringUtils.digest(getName().getFullName());
        // else
        //     return id;
    }

    @Override
    public File getProjectRoot() {
        return projectRoot;
    }

    @Override
    public File getSPLDirectory() {
        return projectSpl;
    }

    @Override
    public boolean isLinkedProject() {
        return getConfiguration().isLinkedProject();
    }

    @Override
    public SPLProjectConfig getConfiguration() {
        checkConfig();
        return this.configuration;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public boolean exists() {
        return projectRoot.exists() || configuration.exists();
    }

    @Override
    public boolean create(SPLProjectConfig config) {
        configuration = config;

        File configFile = getConfigFile();
        config.configIn(configFile);

        // it is not possible to create a project already existent
        if (configFile.exists())
            return false;

        config.save();
        createModels();

        return true;
    }

    @Override
    public void delete() {

        // task = new DeleteProjectTask(this);
        //
        // Managers.getTaskManager().submit(task);
        //
        // task.waitForCompletion(60, TimeUnit.SECONDS);

        for (ProjectModel model : getModels())
            model.delete();

        deleteThis();
    }

    private void deleteThis() {
        FileUtils.deleteAll(getSPLDirectory());
        getConfiguration().delete();
    }

    // ----------------------------------------------------------------------
    // Async support
    // ----------------------------------------------------------------------

    // @Override
    // public void waitForCompletion(long timeout, TimeUnit timeUnit) {
    //     Task runningTask = Managers.getTaskManager().getTask(task);
    //     task = null;
    //
    //     if (runningTask != null)
    //         runningTask.waitForCompletion(timeout, timeUnit);
    // }

    // ----------------------------------------------------------------------
    // Model Properties
    // ----------------------------------------------------------------------

    private void createModels() {
        if (exists()) {
            new SourceModelImpl(this);
            new DependencyModelImpl(this);
            new ComponentModelImpl(this);
            new FeatureModelImpl(this);
            new VersioningModelImpl(this);
            new StatisticsModelImpl(this);
            new ClusterModelImpl(this);
            new DiagramsModelImpl(this);
            new RuntimeModelImpl(this);
        }
    }

    @Override
    public List<ProjectModel> getModels() {
        if (!exists())
            return Collections.emptyList();
        else
            return new ArrayList<>(this.modelsByType.values());
    }

    @Override
    public ProjectModel getModel(String modelType) {

        if (modelsByType.containsKey(modelType))
            return modelsByType.get(modelType);
        else
            throw new RuntimeException(String.format("Unknown model type '%s'", modelType));
    }

    // ----------------------------------------------------------------------

    @Override
    public SourceModel getSourceModel() {
        return (SourceModel) getModel(SourceModel.TYPE);
    }

    @Override
    public DependencyModel getDependencyModel() {
        return (DependencyModel) getModel(DependencyModel.TYPE);
    }

    @Override
    public ComponentModel getComponentModel() {
        return (ComponentModel)getModel(ComponentModel.TYPE);
    }

    @Override
    public FeatureModel getFeatureModel() {
        return (FeatureModel)getModel(FeatureModel.TYPE);
    }

    @Override
    public VersioningModel getVersioningModel() {
        return (VersioningModel) getModel(VersioningModel.TYPE);
    }

    @Override
    public StatisticsModel getStatisticsModel() {
        return (StatisticsModel) getModel(StatisticsModel.TYPE);
    }

    @Override
    public ClusterModel getClusterModel() {
        return (ClusterModel) getModel(ClusterModel.TYPE);
    }

    @Override
    public DiagramsModel getDiagramsModel() {
        return (DiagramsModel) getModel(DiagramsModel.TYPE);
    }

    @Override
    public RuntimeModel getRuntimeModel() {
        return (RuntimeModel) getModel(RuntimeModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private void checkConfig() {
        if (configuration != null)
            return;

        File configFile = getConfigFile();
        configuration = SPLProjectConfig.loadOrDefault(configFile);

        if (configuration.isLinkedProject())
            projectRoot = configuration.getProjectRoot();
        else
            projectRoot = new File(repo.getRepositoryRoot(), getName().getName());

        projectSpl = new File(projectRoot, SPL);
    }

    private File getConfigFile() {
        File configFile = new File(repo.getRepositoryRoot(), getName().getName() + SPL);

        //
        // JUST FOR COMPATIBILITY with the v2.2
        //
        if (configFile.isDirectory()) {
            SPLProjectConfig config = null;

            // loadOrDefault the project configuration
            File projectConfigFile = new File(configFile, PROJECT_CONFIG);
            if (projectConfigFile.exists()) {
                config = SPLProjectConfig.loadOrDefault(projectConfigFile);
            }

            // delete the directory
            FileUtils.deleteAll(configFile);

            // save the configuration
            if (config != null)
                config.configIn(configFile).save();
        }

        return configFile;
    }

}

package ae.ebtic.spl.managers.system;

import ae.ebtic.spl.common.ConfigurationUtils;
import ae.ebtic.spl.managers.uploads.UploadsService;
import jext.graph.GraphDatabase;
import jext.graph.GraphDatabases;
import jext.logging.Logger;
import jext.tasks.TaskManagerService;
import jext.util.FileUtils;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

import java.io.File;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SystemManagerImpl implements SystemManager {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(SystemManager.class);

    private Configuration config;
    private GraphDatabase graphdb;
    private ExecutorService executorService;
    private TaskManagerService taskManager;
    private UploadsService uploadsService;

    // ----------------------------------------------------------------------
    // Configuration
    // ----------------------------------------------------------------------

    @Override
    public String getName() { return SystemManager.MANAGER; }

    /*
    <systemManager>

        <graphdb class="ae.ebtic.spl.graph.neo4j.Neo4JOnlineGraphBuilder">
            <url value="bolt://10.10.103.110:7687"/>
            <login name="neo4j" password="neo4j"/>
            <property name='...' value='...'/>
            ...
        </graphdb>

    </systemManager>
     */
    @Override
    public void configure(Configuration config) throws ConfigurationException {
        this.config = config;

        logger.info("configure");

        configureGraphDatabase();
        configureExecutorService();
        configureTaskManager();
        configureUploadsManager();

        logger.info("done");
    }

    private void configureGraphDatabase() throws ConfigurationException {
        try {
            Properties props;

            props = ConfigurationUtils.loadPropertiesFromFile(config, "graphdb[@path]");
            if (props == null)
                props = ConfigurationUtils.loadProperties(config, "graphdb.properties");
            graphdb = GraphDatabases.newGraphDatabase(props);

            // register the list of named queries
            Map<String, String> nqueries = ConfigurationUtils.loadDictionary(config,"graphdb.namedqueries.query");
            graphdb.registerQueries(nqueries);

            logger.infof("    graphdb: %s", props.toString());
        }
        catch (Exception e){
            throw new ConfigurationException(e);
        }

        logger.info("    configured graphdb");
    }

    private void configureExecutorService() throws ConfigurationException {
        int nthreads = config.getInt("threadpool[@threads]", 2);
        if (nthreads > 0)
            executorService = Executors.newFixedThreadPool(nthreads);
        else
            executorService = Executors.newFixedThreadPool(java.lang.Thread.activeCount() + nthreads);

        logger.infof("    executorService: %d threads", nthreads);
    }

    private void configureTaskManager() throws ConfigurationException {

        int nthreads = config.getInt("taskpool[@threads]", 2);
        this.taskManager = TaskManagerService.createTaskManager(nthreads);

        logger.infof("    taskManager: %d threads", nthreads);
    }

    private void configureUploadsManager() {
        File uploadDir = new File(config.getString("uploads[@path]", "."));

        String uploadPath = FileUtils.getAbsolutePath(uploadDir);

        this.uploadsService = UploadsService.createService(uploadPath);

        logger.infof("    uploadsService: root folder %s", uploadPath);
    }

    @Override
    public void destroy() {

        if (executorService != null)
            executorService.shutdown();

        if (taskManager != null)
            taskManager.shutdown();

        if (graphdb != null)
            graphdb.destroy();

        if (uploadsService != null)
            uploadsService.destroy();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public GraphDatabase getGraphDatabase() { return graphdb; }

    @Override
    public ExecutorService getExecutorService() { return executorService; }

    @Override
    public TaskManagerService getTaskManager() { return taskManager; }

    @Override
    public UploadsService getUploadsService() { return uploadsService; }
}

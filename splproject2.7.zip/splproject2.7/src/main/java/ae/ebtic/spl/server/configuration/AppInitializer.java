package ae.ebtic.spl.server.configuration;


import ae.ebtic.spl.managers.Managers;
import jext.logging.Logger;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.springframework.web.WebApplicationInitializer;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import java.io.File;


public class AppInitializer implements WebApplicationInitializer {

    private String homePath;

    @Override
    public void onStartup(ServletContext context) throws ServletException {
        homePath = context.getRealPath("/");

        try {
            configureLogging();
            configureManagers();
        }
        catch (Throwable t) {
            throw new ServletException("Unable to initialize SPL Server", t);
        }
    }

    private void configureLogging() {
        File log4jConfig = new File(homePath, "WEB-INF/log4j.xml");
        Logger.configure(log4jConfig);
        Logger.getLogger("SPLServer").warn("Initialized");
    }

    private void configureManagers() throws ConfigurationException {
        File configFile = new File(homePath, "WEB-INF/splserver.xml");

        // Configurations configurations = new Configurations();
        // Configuration config = configurations.xml(splserverConfig);
        //
        // // put_ the HOME directory
        // config.addProperty(ConfigurationUtils.HOME_PATH, homePath);

        Managers.configure(configFile, homePath);
    }
}
package ae.ebtic.spl.managers.extlibs;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class ExtLibsManagerFactory {

    /**
     * Create the manager based on the configuration
     *
     * @param config configuration
     * @return
     * @throws ConfigurationException
     */
    public static ExtLibsManager createManager(Configuration config) throws ConfigurationException {
        ExtLibsManager manager = new ExtLibsManagerImpl();
        manager.configure(config);
        return manager;
    }
}

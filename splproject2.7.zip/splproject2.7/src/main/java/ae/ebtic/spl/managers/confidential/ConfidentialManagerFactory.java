package ae.ebtic.spl.managers.confidential;

import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class ConfidentialManagerFactory {

    /**
     * Create the manager based on the configuration
     *
     * @param config configuration
     * @return
     * @throws ConfigurationException
     */
    public static ConfidentialManager createManager(Configuration config) throws ConfigurationException {
        ConfidentialManager manager = new ConfidentialManagerImpl();
        manager.configure(config);
        return manager;
    }
}

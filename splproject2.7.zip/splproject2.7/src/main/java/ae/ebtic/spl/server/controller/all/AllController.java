package ae.ebtic.spl.server.controller.all;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.controller.util.Page;
import ae.ebtic.spl.server.controller.util.Pageable;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import ae.ebtic.spl.server.webmodels.project.WebProjectModel;
import jext.cache.Cache;
import jext.cache.CacheManager;
import jext.logging.Logger;
import jext.util.concurrent.LazyList;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/all")
public class AllController extends SPLRestController {

    private static final String TYPE = "all";

    private static Logger logger = Logger.getLogger(AllController.class);

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public AllController() {
        super(TYPE);
    }

    // ----------------------------------------------------------------------
    // All projects
    // ----------------------------------------------------------------------
    /*
        http://localhost:8080/check3?
            select=a1,a2,a3&
            where=w1,w2,w3&
            page=10&
            size=33&
            sort=name,desc&     <==
            sort=name2,asc      <==
     */

    @GetMapping(value = "projects")
    @ResponseBody
    public ResponseEntity<?> getAllProjects(Pageable pageable)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);
        String href = WebHrefMapper.of(requestUrl).noQueryParams();

        logger.warn(pageable.toString());

        Cache<String, List<WebProjectModel>> webListCache = CacheManager.getCache("web.lists");

        LazyList<WebProjectModel> allProjects = (LazyList<WebProjectModel>) webListCache.get(pageable.toKey("allProjects"),
            () -> getAllProjects(requestUrl, pageable.getSelect()));

        if (pageable.isUnpaged())
            return ResponseEntity.ok(allProjects.waitForCompletion());
        else
            return ResponseEntity.ok(new Page<>(allProjects.waitForContent(pageable.getNeededContent()), pageable, href));
    }

    private List<WebProjectModel> getAllProjects(String requestUrl, String select) {
        return new LazyList<>(
            Managers.getExecutorService(),
            (self) -> {
                Managers.getSPLReposManager().listRepositories()
                    .forEach(repo -> {
                        repo.listProjects()
                            .forEach(project -> {
                                self.add(new WebProjectModel(project, requestUrl).detailed(select));
                            });
                    });
            });

        // List<SPLProject> allp = new ArrayList<>();
        // Managers.getSPLReposManager().listRepositories()
        //     .forEach(repo -> {
        //         allp.addAll(repo.listProjects());
        //     });
        // return allp.stream()
        //     .map(project -> (WebProjectModel)(new WebProjectModel(project, requestUrl).detailed(select)))
        //     .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // All features
    // ----------------------------------------------------------------------

    @GetMapping(value = "features")
    @ResponseBody
    public ResponseEntity<?> getAllFeatures(Pageable pageable)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);
        String href = WebHrefMapper.of(requestUrl).noQueryParams();

        Cache<String, List<WebFeatureModel>> webListCache = CacheManager.getCache("web.lists");

        LazyList<WebFeatureModel> allFeatures = (LazyList<WebFeatureModel>) webListCache.get(pageable.toKey("allFeatures"),
            () -> getAllFeatures(requestUrl, pageable.getSelect()));

        if (pageable.isUnpaged())
            return ResponseEntity.ok(allFeatures.waitForCompletion());
        else
            return ResponseEntity.ok(new Page<>(allFeatures.waitForContent(pageable.getNeededContent()), pageable, href));
    }

    private List<WebFeatureModel> getAllFeatures(String requestUrl, String select) {

        return new LazyList<>(
            Managers.getExecutorService(),
            (self) -> {
                WebHrefMapper requestHref = WebHrefMapper.of(requestUrl);

                Managers.getSPLReposManager().listRepositories()
                    .forEach(repo -> {
                        repo.listProjects().forEach(project -> {
                            String pname = project.getName().getFullName();
                            String projectHref = requestHref.getProjectHref(pname);
                            self.addAll(project.getFeatureModel().getFeatures().stream()
                                .map(feature -> (WebFeatureModel) (new WebFeatureModel(feature, projectHref).detailed(select)))
                                .collect(Collectors.toList()));
                        });
                    });
            });

        // List<WebFeatureModel> allf = new ArrayList<>();
        // Managers.getSPLReposManager().listRepositories()
        //     .forEach(repo -> {
        //         repo.listProjects().forEach(project -> {
        //             String pname = project.getName().getFullName();
        //             String projectHref = requestHref.getProjectHref(pname);
        //             allf.addAll(project.getFeatureModel().getFeatures().stream()
        //                 .map(feature -> (WebFeatureModel)(new WebFeatureModel(feature, projectHref).detailed(select)))
        //                 .collect(Collectors.toList())
        //             );
        //         });
        //     });
        // return allf;
    }

}

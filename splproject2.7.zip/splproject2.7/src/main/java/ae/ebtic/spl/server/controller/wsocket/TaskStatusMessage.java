package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.tasks.ProjectTask;
import jext.util.Parameters;

import java.util.Properties;

public class TaskStatusMessage implements WSMessage {

    protected ProjectTask task;

    public TaskStatusMessage(ProjectTask task) {
        this.task = task;
    }

    public String getId() {
        return task.getId();
    }

    public String getTaskType() {
        return task.getType().toLowerCase();
    }

    public String getStatus() {
        return task.getStatus().toString();
    }

    public String getModelType() { return task.getModelType(); }

    public String getProject() { return task.getProjectName().getName(); }

    public String getRepository() { return task.getProjectName().getParentName(); }

    public Parameters getParameters() { return task.getParameters(); }

    @Override
    public String destination() {
        String destination;
        String modelType = getModelType();

        if (modelType != null)
            destination = String.format("/topic/taskstatus.%s.%s.%s",
                getRepository(),
                getProject(),
                modelType);
        else
            destination = String.format("/topic/taskstatus.%s.%s.%s",
                getRepository(),
                getProject(),
                getTaskType());
        return destination;
    }
}

package ae.ebtic.spl.server.webmodels.dependency;

import ae.ebtic.spl.analysis.dependencies.FieldNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.server.webmodels.WebDetailedModel;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebLink;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Map;

public class WebFieldModel extends WebDetailedModel implements GraphConstants {

    private Field field;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public WebFieldModel(Field field, String prefixUrl) {
        super(prefixUrl);
        this.field = field;
        this.href = WebHrefMapper.of(prefixUrl).getFieldHref(field.getId());
        populate();
    }

    // ----------------------------------------------------------------------
    // Populate
    // ----------------------------------------------------------------------

    @Override
    protected void populate() {
        super.populate();

        put(ID, field.getId());
        put(NAME, field.getName().getName());
        put(TYPE_ID, field.getTypeId());
        put(OWNER_TYPE_ID, field.getOwnerTypeId());
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // public String getHref() {
    //     return href;
    // }

    // public String getId() { return field.getId(); }

    // public String getName() { return field.getName().getName(); }

    // public WebRefTypeModel getType() {
    //     return new WebRefTypeModel(field.getType(), prefixUrl);
    // }

    // public String getTypeId() { return field.getTypeId(); }

    // public String getOwnerTypeId() { return field.getOwnerTypeId(); }

    // public Map<String, Object> getValues() {
    //     if (!detailed)
    //         return Collections.emptyMap();
    //     else
    //         return ((FieldNode) field).getValues();
    // }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected List<WebLink> getLinks() {
        if (!detailed)
            return Collections.emptyList();

        String typeId = field.getTypeId();
        String ownerTypeId = field.getOwnerTypeId();

        return Arrays.asList(
            new WebLink("type", WebHrefMapper.of(href).getTypeHref(typeId)),
            new WebLink("ownerType", WebHrefMapper.of(href).getTypeHref(ownerTypeId)),
            new WebLink(href)
        );
    }

    @Override
    protected  Map<String, Object> readValues() {
        return ((FieldNode) field).getValues();
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

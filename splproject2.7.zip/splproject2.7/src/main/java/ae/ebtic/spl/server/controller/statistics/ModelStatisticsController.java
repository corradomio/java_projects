package ae.ebtic.spl.server.controller.statistics;


import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.StatisticsModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.statistics.WebStatisticsElementModel;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/statistics")
public class ModelStatisticsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelStatisticsController() {
        super(StatisticsModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    /**
     * List of components
     */
    @GetMapping("elements")
    @ResponseBody
    public ResponseEntity<?> getStatisticalElementsList(
            @PathVariable String repoName,
            @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        StatisticsModel sm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getStatisticsModel();

        List<WebStatisticsElementModel> elements = sm.getElements()
                .stream()
                .map(e -> WebStatisticsElementModel.newWebStatisticsElementModel(e, requestUrl))
                .collect(Collectors.toList());

        return new ResponseEntity<>(elements, HttpStatus.OK);
    }

}

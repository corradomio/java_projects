package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.component.WebComponentModel;
import ae.ebtic.spl.server.webmodels.dependency.WebFieldModel;
import ae.ebtic.spl.server.webmodels.dependency.WebMethodModel;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import ae.ebtic.spl.server.webmodels.feature.WebFeatureModel;
import jext.graph.Direction;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency/types/{typeId}")
public class TypeController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public TypeController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    @GetMapping("")
    @ResponseBody
    public ResponseEntity<?> getType(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type dt = dm.getDependencyGraph().getType(typeId);

        return new ResponseEntity<>((WebTypeModel)new WebTypeModel(dt, requestUrl).detailed(), HttpStatus.OK);
    }

    @GetMapping("methods")
    @ResponseBody
    public ResponseEntity<?> getMethodsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getDependencyGraph().getType(typeId);

        List<WebMethodModel> methods = type.getMethods()
            .stream()
            .map(method -> new WebMethodModel(method, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(methods, HttpStatus.OK);
    }

    @GetMapping("fields")
    @ResponseBody
    public ResponseEntity<?> getTypeFieldsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getDependencyGraph().getType(typeId);

        List<WebFieldModel> fields = type.getFields()
            .stream()
            .map(field -> new WebFieldModel(field, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(fields, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // components
    // features
    // ----------------------------------------------------------------------

    @GetMapping(value = "components")
    @ResponseBody
    public ResponseEntity<?> getTypeComponentsList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        List<WebComponentModel> components = dm.getType(typeId).getComponents()
            .stream()
            .map(component -> new WebComponentModel(component, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(components, HttpStatus.OK);
    }

    @GetMapping(value = "features")
    @ResponseBody
    public ResponseEntity<?> getTypeFeaturesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        List<WebFeatureModel> features = dm.getType(typeId).getFeatures()
            .stream()
            .map(feature -> new WebFeatureModel(feature, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(features, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    //  uses
    //      extends
    //      implements
    //      dependsOn
    // ----------------------------------------------------------------------

    @GetMapping("uses")
    @ResponseBody
    public ResponseEntity<?> getUseTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestParam(value = "rec", defaultValue = "false") boolean recursive,
        @RequestParam(value = "ref", defaultValue = "false") boolean refTypes)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getType(typeId);

        List<WebTypeModel> useTypes = type.getUseTypes(TypeUse.ALL, Direction.Output, recursive, refTypes)
            .stream()
            .map(etype -> new WebTypeModel(etype, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(useTypes, HttpStatus.OK);
    }

    @GetMapping("extends")
    @ResponseBody
    public ResponseEntity<?> getExtendTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestParam(value = "rec", defaultValue = "false") boolean recursive,
        @RequestParam(value = "ref", defaultValue = "false") boolean refTypes)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getType(typeId);

        List<WebTypeModel> extendTypes = type.getUseTypes(TypeUse.EXTENDS, Direction.Output, recursive, refTypes)
            .stream()
            .map(etype -> new WebTypeModel(etype, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(extendTypes, HttpStatus.OK);
    }

    @GetMapping("implements")
    @ResponseBody
    public ResponseEntity<?> getImplementTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestParam(value = "rec", defaultValue = "false") boolean recursive,
        @RequestParam(value = "ref", defaultValue = "false") boolean refTypes)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getType(typeId);

        List<WebTypeModel> implementTypes = type.getUseTypes(TypeUse.IMPLEMENTS, Direction.Output, recursive, refTypes)
            .stream()
            .map(etype -> new WebTypeModel(etype, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(implementTypes, HttpStatus.OK);
    }

    @GetMapping("dependsOn")
    @ResponseBody
    public ResponseEntity<?> getDependsOnTypesList(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String typeId,
        @RequestParam(value = "rec", defaultValue = "false") boolean recursive,
        @RequestParam(value = "ref", defaultValue = "false") boolean refTypes)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        Type type = dm.getType(typeId);

        List<WebTypeModel> dependOnTypes = type.getUseTypes(TypeUse.DEPENDS_ON, Direction.Output, recursive, refTypes)
            .stream()
            .map(etype -> new WebTypeModel(etype, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(dependOnTypes, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // closure
    // ----------------------------------------------------------------------

    @GetMapping("closure")
    @ResponseBody
    public ResponseEntity<?> getClosure(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String typeId,
            @RequestParam(value = "ref", defaultValue = "true") boolean refTypes,
            @RequestParam(value = "imp", defaultValue = "true") boolean implementation,
            @RequestParam(value = "links", defaultValue = "true") boolean links)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getDependencyModel();

        return new ResponseEntity<>( dm.getClosure(typeId,refTypes,implementation,links), HttpStatus.OK);
    }

    @PostMapping("implementations")
    @ResponseBody
    public ResponseEntity<?> getImplementationsByPost(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String typeId,
            @RequestBody Map<String, Object> options)
    {

        List<Map<String, Object>> interfaces = (ArrayList<Map<String, Object>>) options.getOrDefault("interfaces", new ArrayList<>());


        return getImplementations(repoName, projectName, typeId, interfaces);
    }

    @GetMapping("implementations")
    @ResponseBody
    public ResponseEntity<?> getImplementationsByGet(
            @PathVariable String repoName,
            @PathVariable String projectName,
            @PathVariable String typeId)
    {
        return getImplementations(repoName, projectName, typeId, new ArrayList<>());
    }

    private  ResponseEntity<?> getImplementations(String repoName,
                                                  String projectName,
                                                  String typeId,
                                                  List<Map<String,Object>> interfaces){

        logger.infof("%s.%s.dependency.types.getImplementations(%s)", repoName, projectName, typeId);

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
                .newRepository(repoName)
                .newProject(projectName)
                .getDependencyModel();

        if (!dm.exists()) {
            logger.errorf("DependencyModel not existent");
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }


        return new ResponseEntity<>( dm.getInterfaceImplementations(interfaces, typeId), HttpStatus.OK);

    }

}

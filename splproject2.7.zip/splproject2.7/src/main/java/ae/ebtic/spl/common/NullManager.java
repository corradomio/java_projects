package ae.ebtic.spl.common;

import ae.ebtic.spl.managers.Manager;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;

public class NullManager implements Manager {

    private static Manager INSTANCE = new NullManager();

    public static Manager getInstance() {
        return INSTANCE;
    }

    @Override
    public String getName() { return "Null"; }

    @Override
    public void configure(Configuration config) throws ConfigurationException {

    }

    @Override
    public void destroy() {

    }
}

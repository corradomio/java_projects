package ae.ebtic.spl.managers.splrepos;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.SPLProjectConfig;
import ae.ebtic.spl.projects.impl.SPLProjectImpl;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.HashSet;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class SPLRepositoryImpl implements SPLRepository {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(SPLRepositoryImpl.class);

    private SPLReposManager manager;
    private String name;
    private SPLRepoConfig configuration;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLRepositoryImpl(SPLReposManager manager, String name) {
        this.manager = manager;
        this.name = name;

        checkStatus();
    }

    public SPLRepositoryImpl(SPLReposManager manager, File configFile) {
        this.manager = manager;
        this.name = FileUtils.getNameWithoutExt(configFile);

        checkStatus();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getName() {
        return name;
    }

    @Override
    public SPLRepoConfig getConfiguration() {
        return configuration;
    }

    @Override
    public File getRepositoryRoot() {
        if (getConfiguration().isLinkedRepository())
            return new File(getConfiguration().getRepositoryHome());
        else
            return new File(manager.getWorkspaceFolder(), name);
    }

    @Override
    public boolean isLinkedRepository() {
        return getConfiguration().isLinkedRepository();
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public boolean exists() {
        return configuration.exists() && getRepositoryRoot().exists();
    }

    @Override
    public boolean create(SPLRepoConfig config) {
        this.configuration = config;

        File configFile = new File(manager.getWorkspaceFolder(), name + ".json");
        config.configIn(configFile);

        if (!createRepository())
            return false;

        importProjects();

        return true;
    }

    @Override
    public void delete() {
        File repositoryRoot = getRepositoryRoot();
        if (!repositoryRoot.exists() && !configuration.exists())
            return;

        if (isLinkedRepository()) {
            configuration.delete();
            return;
        }

        Managers.getExecutorService().submit(() -> {
            FileUtils.deleteAll(repositoryRoot);
            configuration.delete();
        });
    }

    // ----------------------------------------------------------------------
    // Project Operations
    // ----------------------------------------------------------------------
    /*
        There are 2 versions of 'Project' to handle:

        - v1: it is based on a directory with name '<project>.spl'
        - v2: it is based on a file with name '<project>.spl'

        Version 1
        ---------

        The directory has name:  '<project>.spl'. It contains

        - project-config.json:
            url:            url where to download the source code
            description:    a description of the project
            properties:     a list of extra properties

        - source-config.json:   status of the "Source" module
            status:         status of the module
            taskId:         id of the running/last task, if present. It id necessary to check if
                            a task with this is id is running
            message:        last message generated from the task
            taskType:       type of the running/last task

        - dependency-config.json:   status of the "Dependency" module
            ... same as 'source-config.json'

        - component-config.json:   status of the "Components" module
            ... same as 'source-config.json'

        - feature-config.json:   status of the "Features" module
            ... same as 'source-config.json'


        Version 2
        ---------
        The idea is to keep ONLY one configuration file: '<project>.spl'.
        The status of dependency/component/feature modules is saved inside the database
     */

    public SPLProject newProject(String projectName) {
        return new SPLProjectImpl(this, projectName);
    }

    public List<SPLProject> listProjects() {

        // if the repository doesn't exists, return the empty list of projects
        if (!exists())
            return Collections.emptyList();

        Set<String> pnames = new HashSet<>();
        List<SPLProject> projects = new ArrayList<>();

        // repository home
        File homeFolder = getRepositoryRoot();

        // list the FILES/DIRECTORIES with name '<project>.spl'
        FileUtils.listFiles(homeFolder, ".spl")
            .forEach(json -> {
                String name = FileUtils.getNameWithoutExt(json);
                SPLProject project = new SPLProjectImpl(this, name);
                projects.add(project);
                pnames.add(name);
            });

        // list the DIRECTORIES with a name not already retrieved
        // NO!
        // FileUtils.asList(homeFolder.listFiles(File::isDirectory))
        //     .stream()
        //     .filter(folder ->
        //         ! folder.getName().endsWith(".spl"))
        //     .filter(folder ->
        //         !pnames.contains(folder.getName()))
        //     .forEach(folder -> {
        //         String name = folder.getName();
        //         SPLProject project = new SPLProjectImpl(this, name);
        //         projects.add(project);
        //         pnames.add(name);
        //     });

        return projects;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private void checkStatus() {
        if (configuration != null)
            return;

        File configFile = new File(manager.getWorkspaceFolder(), name + ".json");
        configuration = SPLRepoConfig.loadOrDefault(configFile);
    }

    private boolean createRepository() {
        File repositoryRoot = getRepositoryRoot();

        if (repositoryRoot.exists() && configuration.exists())
            return false;

        if (!repositoryRoot.exists() && !repositoryRoot.mkdirs()) {
            logger.errorf("Unable to create the repository root for %s: %s", name, repositoryRoot.getAbsolutePath());
            return false;
        }

        configuration.save();
        return true;
    }

    private void importProjects() {
        File repositoryRoot = getRepositoryRoot();

        // 1) search the files/directories with extension ".spl"

        Set<String> names = FileUtils.listFiles(repositoryRoot, ".spl")
            .stream()
            .map(FileUtils::getNameWithoutExt)
            .collect(Collectors.toSet());

        // 2) search the directories not in 'names'

        List<String> projects = FileUtils.asList(repositoryRoot.listFiles(File::isDirectory))
            .stream()
            .map(File::getName)
            .filter(name -> !names.contains(name))
            .collect(Collectors.toList());

        // 3) create 'linked projects':

        projects.forEach(projectName -> {
            File projectRoot = new File(getRepositoryRoot(), projectName);
            String linkUrl = String.format("link:///%s", projectRoot.getAbsolutePath());
            try {
                newProject(projectName).create(new SPLProjectConfig().setURL(linkUrl));
            }
            catch (IOException e) {
                logger.errorf("Unable to create the project %s/%s", getName(), projectName);
            }
        });
    }

    public void dump() {
        SPLRepoConfig config = getConfiguration();

        System.out.printf("Repository: %s\n", getName());
        System.out.printf("    config:\n");
        System.out.printf("        home folder: '%s'\n", config.getRepositoryHome());
        System.out.printf("        description: '%s'\n", config.getDescription());
    }

}

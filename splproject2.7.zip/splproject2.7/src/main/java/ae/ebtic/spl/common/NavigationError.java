package ae.ebtic.spl.common;

public class NavigationError extends Error {

    public NavigationError(String msg) {
        super(msg);
    }
}

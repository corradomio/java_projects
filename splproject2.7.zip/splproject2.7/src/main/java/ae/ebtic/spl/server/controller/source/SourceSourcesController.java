package ae.ebtic.spl.server.controller.source;

import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.source.WebSourceModel;
import jext.util.FileUtils;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/source/sources")
public class SourceSourcesController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourceSourcesController() {
        super(SourceModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web navigation
    // ----------------------------------------------------------------------

    @GetMapping(value = "")
    @ResponseBody
    public ResponseEntity<?> getModuleSourcesList(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        List<WebSourceModel> wsources = sm.getSources()
            .stream()
            .map(source -> new WebSourceModel(source, requestUrl))
            .collect(Collectors.toList());

        return new ResponseEntity<>(wsources, HttpStatus.OK);
    }

    @GetMapping(value = "{sourceId}")
    @ResponseBody
    public  ResponseEntity<?> getSource(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String sourceId) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Source source = sm.getSource(sourceId);
        if (source == null)
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);

        WebSourceModel wm = new WebSourceModel(source, requestUrl);
        return new ResponseEntity<>((WebSourceModel)wm.detailed(), HttpStatus.OK);
    }

    @GetMapping(value = "{sourceId}/content", produces = "text/plain")
    @ResponseBody
    public ResponseEntity<?> getSourceContent(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @PathVariable String sourceId) {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        Source source = sm.getSource(sourceId);

        File sourceFile = new File(source.getPath());

        String content = FileUtils.toString(sourceFile);

        return new ResponseEntity<>(content, HttpStatus.OK);
    }

}

package ae.ebtic.spl.common;

import jext.util.HashMap;
import jext.util.Properties;
import jext.util.StringUtils;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.HierarchicalConfiguration;

import java.io.File;
import java.util.List;
import java.util.Map;

public class ConfigurationUtils {

    public static final String HOME_PATH = "homePath";

    public static File getPath(Configuration config, String entry) {
        String homePath = config.getString(HOME_PATH);
        String localPath = config.getString(entry);
        if (localPath == null)
            return null;
        return new File(homePath, localPath);
    }

    public static Properties loadPropertiesFromFile(Configuration config, String entry) {
        File propsFile = getPath(config, entry);
        if (propsFile == null)
            return null;
        return Properties.load(propsFile);
    }

    public static Properties loadProperties(Configuration config, String entry) {
        Configuration subConfig = ((HierarchicalConfiguration)config).configurationAt(entry);
        List pnames = subConfig.getList("property[@name]");
        List values = subConfig.getList("property[@value]");

        Properties props = new Properties();
        for (int i=0; i<pnames.size(); ++i) {
            String pname = pnames.get(i).toString();
            String value = values.get(i).toString();

            props.setProperty(pname, value);
        }

        return props;
    }

    public static Map<String,String> loadDictionary(Configuration config, String entry) {
        String ekey = "[@name]";
        String evalue = "";
        String prefix = StringUtils.prefixOf(entry, ".");
        String dkey = StringUtils.lastOf(entry, ".");

        Configuration subConfig = ((HierarchicalConfiguration)config).configurationAt(prefix);
        List pnames = subConfig.getList(dkey + ekey);
        List values = subConfig.getList(dkey + evalue);

        Map<String,String> props = new HashMap<>();
        for (int i=0; i<pnames.size(); ++i) {
            String pname = pnames.get(i).toString();
            String value = values.get(i).toString();

            props.put(pname, value);
        }

        return props;
    }

    public static List<String> loadUrls(Configuration config, String entry) {
        String ekey = "[@url]";
        String prefix = StringUtils.prefixOf(entry, ".");
        String dkey = StringUtils.lastOf(entry, ".");

        Configuration subConfig = ((HierarchicalConfiguration)config).configurationAt(prefix);
        List values = subConfig.getList(dkey + ekey);

        return values;
    }
}

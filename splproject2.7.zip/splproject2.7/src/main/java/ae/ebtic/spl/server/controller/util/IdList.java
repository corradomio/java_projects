package ae.ebtic.spl.server.controller.util;

import java.util.ArrayList;
import java.util.List;

public class IdList {
    private List<String> ids = new ArrayList<>();

    public List<String> getIds() {
        return ids;
    }

    public void setIds(List<String> ids) {
        this.ids = ids;
    }
}

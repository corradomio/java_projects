package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.tasks.ProjectTask;
import jext.tasks.TaskStatus;

public class TaskStatusChangeMessage extends TaskStatusMessage {

    private TaskStatus prevStatus;

    public TaskStatusChangeMessage(TaskStatus prevStatus, ProjectTask task) {
        super(task);
        this.prevStatus = prevStatus;
    }

    @Override
    public String destination() {
        String destination = super.destination();
        return destination + ".status";
    }

    public String getPrevStatus() {
        return prevStatus.toString();
    }
}

package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.runtime.RuntimeGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.tasks.ProjectTask;

import java.util.List;
import java.util.Map;

public interface RuntimeModel extends ProjectModel {

    String TYPE = "runtime";

    RuntimeGraph getRuntimeGraph();

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    void resetEntryPoints();

    void updateEntryPoints();

    Map<String, Long> getEntryPointsCount();

    // ----------------------------------------------------------------------
    // Queries
    // ----------------------------------------------------------------------

    List<Type> getEntryPointTypes();

    List<Component> getEntryPointComponents();

    List<Feature> getEntryPointFeatures();

}

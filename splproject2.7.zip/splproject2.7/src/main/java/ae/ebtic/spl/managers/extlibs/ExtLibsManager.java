package ae.ebtic.spl.managers.extlibs;

import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.managers.Manager;

public interface ExtLibsManager extends Manager {

    String MANAGER = "extlibsManager";

    /**
     * Retrieve the GLOBAL library finder
     */
    LibraryFinder getLibraryFinder();

}

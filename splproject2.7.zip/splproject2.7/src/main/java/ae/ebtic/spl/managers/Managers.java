package ae.ebtic.spl.managers;

import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.common.ConfigurationUtils;
import ae.ebtic.spl.managers.cache.CacheManager;
import ae.ebtic.spl.managers.cache.CacheManagerFactory;
import ae.ebtic.spl.managers.confidential.ConfidentialManager;
import ae.ebtic.spl.managers.confidential.ConfidentialManagerFactory;
import ae.ebtic.spl.managers.extlibs.ExtLibsManager;
import ae.ebtic.spl.managers.extlibs.ExtLibsManagerFactory;
import ae.ebtic.spl.managers.services.rtanalysis.RTAnalysisManager;
import ae.ebtic.spl.managers.services.rtanalysis.RuntimeAnalyzerManagerFactory;
import ae.ebtic.spl.managers.splrepos.SPLReposManager;
import ae.ebtic.spl.managers.splrepos.SPLReposManagerFactory;
import ae.ebtic.spl.managers.system.SystemManager;
import ae.ebtic.spl.managers.system.SystemManagerFactory;
import ae.ebtic.spl.managers.uploads.UploadsService;
import jext.graph.GraphDatabase;
import jext.logging.Logger;
import jext.tasks.TaskManagerService;
import jext.util.concurrent.Parallel;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.XMLConfiguration;
import org.apache.commons.configuration2.builder.fluent.Configurations;

import java.io.File;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.TimeUnit;

public class Managers {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static File configFile;
    private static String homePath;
    private static long lastModified = 0;
    private static Configuration configuration;

    private static Map<String, Manager> managers = new HashMap<>();

    // ----------------------------------------------------------------------
    // Configuration
    // ----------------------------------------------------------------------

    public static void configure(File configFile, String homePath) {

        Managers.configFile = configFile;
        Managers.homePath = homePath;

        checkConfiguration();
    }

    private static void checkConfiguration() {
        if (Managers.lastModified == Managers.configFile.lastModified())
            return;

        try {
            Configurations configurations = new Configurations();
            Managers.lastModified = configFile.lastModified();
            Managers.configuration = configurations.xml(configFile);

            // put_ the HOME directory
            configuration.addProperty(ConfigurationUtils.HOME_PATH, homePath);

            Managers.destroy();
        }
        catch (Exception e) {
            Logger.getLogger(Managers.class).fatal(e, e);
            throw new RuntimeException(e);
        }
    }

    private static void register(Manager manager) {
        managers.put(manager.getName(), manager);
    }

    public static void destroy() {

        for(String name : managers.keySet())
            managers.get(name).destroy();
        managers.clear();
        Parallel.shutdown();
    }

    public static void waitForCompletion(int timeout, TimeUnit timeUnit) throws InterruptedException {
        getTaskManager()
            .shutdown()
            .waitForCompletion(timeout, timeUnit);
    }

    // ----------------------------------------------------------------------
    // Managers
    // ----------------------------------------------------------------------

    public static Manager getManager(String manager) {
        checkConfiguration();

        if (!managers.containsKey(manager))
            createManager(manager);

        return managers.get(manager);
    }

    public static SPLReposManager getSPLReposManager() { return (SPLReposManager) getManager(SPLReposManager.MANAGER); }

    public static SystemManager getSystemManager() { return (SystemManager) getManager(SystemManager.MANAGER); }

    public static ExtLibsManager getExtLibsManager() { return (ExtLibsManager) getManager(ExtLibsManager.MANAGER); }

    public static TaskManagerService getTaskManager() { return getSystemManager().getTaskManager(); }

    public static GraphDatabase getGraphDatabase() { return getSystemManager().getGraphDatabase(); }

    public static LibraryFinder getLibraryFinder() { return getExtLibsManager().getLibraryFinder(); }

    public static ExecutorService getExecutorService() { return getSystemManager().getExecutorService(); }

    public static UploadsService getUploadsService() { return getSystemManager().getUploadsService(); }

    public static ConfidentialManager getConfidentialManager() { return (ConfidentialManager) getManager(ConfidentialManager.MANAGER); }

    public static RTAnalysisManager getRuntimeAnalyzerManager() { return (RTAnalysisManager) getManager(RTAnalysisManager.MANAGER); }

    public static CacheManager getCacheManager() { return (CacheManager) getManager(CacheManager.MANAGER); }

    // ----------------------------------------------------------------------
    // Extras
    // ----------------------------------------------------------------------

    private static void createManager(String manager)  {
        try {
            if (SystemManager.MANAGER.equals(manager))
                register(SystemManagerFactory
                    .createManager(getConfiguration(configuration, SystemManager.MANAGER)));

            if (SPLReposManager.MANAGER.equals(manager))
                register(SPLReposManagerFactory
                    .createManager(getConfiguration(configuration, SPLReposManager.MANAGER)));

            if (ExtLibsManager.MANAGER.equals(manager))
                register(ExtLibsManagerFactory
                    .createManager(getConfiguration(configuration, ExtLibsManager.MANAGER)));

            if (ConfidentialManager.MANAGER.equals(manager))
                register(ConfidentialManagerFactory
                    .createManager(getConfiguration(configuration, ConfidentialManager.MANAGER)));

            if (CacheManager.MANAGER.equals(manager))
                register(CacheManagerFactory
                    .createManager(getConfiguration(configuration, CacheManager.MANAGER)));

            if (RTAnalysisManager.MANAGER.equals(manager))
                register(RuntimeAnalyzerManagerFactory
                    .createManager(getConfiguration(configuration, RTAnalysisManager.MANAGER)));
        }
        catch (Exception e) {
            Logger.getLogger(Managers.class).fatal(e);
            throw new RuntimeException(e);
        }
    }

    private static Configuration getConfiguration(Configuration parentConfig, String key) {
        Configuration config = ((XMLConfiguration) parentConfig).configurationAt(key);
        String homePath = parentConfig.getString(ConfigurationUtils.HOME_PATH);
        config.addProperty(ConfigurationUtils.HOME_PATH, homePath);
        return config;
    }

    public static Configuration getConfiguration() {
        return configuration;
    }

}

package ae.ebtic.spl.server.controller.runtime;

import ae.ebtic.spl.server.webmodels.WebConfig;
import com.fasterxml.jackson.annotation.JsonIgnore;
import jext.util.PathUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Configuration for RTAnalysis
 *
 *  [common]
 *      - repository:   string      repository OR repository/project
 *      - project:      string      project    OR repository/project
 *      - parameters
 *          -- name: value
 *
 *  [RTAnalysisConfig]
 *      - uploaded: bool            if the files are saved in the uploaded area
 *      - files: list[string]       list of files.
 *          If 'uploaded' is 'true' a file is specified as a 'relative path'
 *          to the 'upload directory'.
 *          Otherwise, for now, it must be an 'absolute path'.
 *          Note: other possibilities can be possible
 *
 */
public class EntryPointsConfig extends WebConfig {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private boolean uploaded = true;
    // files to analyze
    private List<String> files = new ArrayList<>();
    // selected namespaces. All if empty
    private List<String> select = new ArrayList<>();
    // excluded namespaces. None if empty
    private List<String> exclude = new ArrayList<>();

    // DEBUG: if to process the analysis in the same thread
    // private boolean sync;
    private double test;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- uploaded
    // If the files ar in the uploaded area

    public boolean isUploaded() {
        return uploaded;
    }

    public EntryPointsConfig setUploaded(boolean uploaded) {
        this.uploaded = uploaded;
        return this;
    }

    // -- files
    // Files do analyze

    public List<String> getFiles() {
        return files;
    }

    public EntryPointsConfig setFiles(List<String> files) {
        this.files.addAll(files);
        return this;
    }

    // -- selected/excluded
    // selected: list of namespaces to select. All if not specified
    // excluded: list of namespaces to exclud. None if not specified

    public EntryPointsConfig setSelect(List<String> select) {
        this.select.addAll(select);
        return this;
    }

    public List<String> getSelect() {
        return select;
    }

    public EntryPointsConfig setExclude(List<String> exclude) {
        this.exclude.addAll(exclude);
        return this;
    }

    public List<String> getExclude() {
        return exclude;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public EntryPointsConfig addFiles(String files) {
        if (files.contains("|"))
            setFiles(Arrays.asList(files.split("\\|")));
        else if (files.contains(","))
            setFiles(Arrays.asList(files.split(",")));
        else
            setFiles(Collections.singletonList(files));
        return this;
    }

    /** convert paths relative to the 'uploads' folder to 'absolute file paths' */
    @JsonIgnore
    public void setParentDir(String parentDir) {
        files = files.stream()
            .map(file -> PathUtils.concat(parentDir, file))
            .collect(Collectors.toList());
    }

    @JsonIgnore
    public EntryPointsConfig setTest(double test) {
        this.test = test;
        return this;
    }

    @JsonIgnore
    public double getTest() {
        return this.test;
    }

}

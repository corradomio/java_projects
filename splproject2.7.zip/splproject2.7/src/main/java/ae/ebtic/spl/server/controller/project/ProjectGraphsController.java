package ae.ebtic.spl.server.controller.project;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}")
public class ProjectGraphsController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectGraphsController() {
        super("project.graph");
    }

    // ----------------------------------------------------------------------
    // Project graph
    // ----------------------------------------------------------------------

    /**
     * Retrieve the project graph
     */
    @GetMapping(value="graph")
    @ResponseBody
    public ResponseEntity<?> getProjectGraph(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "limit",  defaultValue = "true") String limit)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        if(limit.equals("false"))
            return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraph(false), HttpStatus.OK);
        else
            return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraph(true), HttpStatus.OK);
    }

    /**
     * (TO_REPLACE)
     * @param repoName
     * @param projectName
     * @param features
     * @return
     */
    @PostMapping(value="graph")
    @ResponseBody
    public ResponseEntity<?> getProjectGraphWithIDs(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody List<Map<String,Object>> features)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        List<Integer> featureIds = features.stream().mapToInt(r -> Integer.parseInt(r.get("id").toString())).boxed().collect(Collectors.toList());
        return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraph(featureIds), HttpStatus.OK);
    }

    @GetMapping(value="graphTypes")
    @ResponseBody
    public ResponseEntity<?> getProjectGraphTypes(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestParam(value = "limit",  defaultValue = "true") String limit)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        if(limit.equals("false"))
            return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraphTypes(false), HttpStatus.OK);
        else
            return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraphTypes(true), HttpStatus.OK);
    }

    @PostMapping(value="graphTypes")
    @ResponseBody
    public ResponseEntity<?> getProjectGraphTypesWithIDs(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody List<Map<String,Object>> features)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SPLProject project = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName);

        List<Integer> featureIds = features.stream().mapToInt(r -> Integer.parseInt(r.get("id").toString())).boxed().collect(Collectors.toList());
        return new ResponseEntity<>(project.getFeatureModel().getFeatureGraph().getProjectGraphTypes(featureIds), HttpStatus.OK);
    }

}

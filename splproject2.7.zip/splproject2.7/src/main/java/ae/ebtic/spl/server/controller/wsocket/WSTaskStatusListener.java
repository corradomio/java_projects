package ae.ebtic.spl.server.controller.wsocket;

import ae.ebtic.spl.tasks.ProjectTask;
import jext.tasks.Task;
import jext.tasks.TaskStatus;
import jext.tasks.TaskStatusListener;

public class WSTaskStatusListener implements TaskStatusListener {

    public static WSTaskStatusListener instance = new WSTaskStatusListener();

    private WSTaskStatusListener() { }

    @Override
    public void onStatusChanged(TaskStatus prevStatus, Task task) {
        WebSocketController.send(new TaskStatusChangeMessage(prevStatus, (ProjectTask) task));
    }

    @Override
    public void onDone(Task task) {
        WebSocketController.send(new TaskDoneMessage((ProjectTask) task));
    }

    @Override
    public void onProgressChanged(Task task) {
        WebSocketController.send(new TaskProgressChangeMessage((ProjectTask) task));
    }

}

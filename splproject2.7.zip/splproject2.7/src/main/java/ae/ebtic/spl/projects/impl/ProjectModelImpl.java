package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import ae.ebtic.spl.common.ProjectTaskManager;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ModelConfig;
import ae.ebtic.spl.projects.ModelCreateParams;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.ProjectModel;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.tasks.ProjectTask;
import jext.logging.Logger;

import java.util.List;
import java.util.concurrent.TimeUnit;


public class ProjectModelImpl extends NamedObject implements ProjectModel {

    public static class ModelStatusInfo {

        private ModelStatus status = ModelStatus.NOT_EXISTENT;
        private String reason = ModelStatus.NOT_EXISTENT.toString();

        public void setStatus(ModelStatus status, String reason) {
            this.status = status;
            if (reason == null)
                this.reason = status.toString();
            else
                this.reason = reason;
        }

        public ModelStatus getStatus() {
            return status;
        }

        public String getReason() {
            return reason;
        }
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // logger
    protected Logger logger;

    // model type
    protected String type;

    // model status
    protected ModelStatusInfo modelStatus = new ModelStatusInfo();

    // parent project
    protected SPLProject project;

    // model create parameters
    protected ModelCreateParams modelCreateParams;

    // model configuration
    protected ModelConfig configuration;

    // graphdb access
    protected ProjectGraphAccess pga;
    protected ProjectModelGraph pmg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ProjectModelImpl(SPLProject project, String type) {
        super(new PathName(project.getName(), type));
        this. logger = Logger.getLogger(getClass());

        this.type = type;
        this.project = project;

        project.registerModel(this);

        checkStatus();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getType(){ return type; }

    @Override
    public long getTimestamp() { return 0; }

    @Override
    public SPLProject getSPLProject() { return project; }

    @Override
    public ModelConfig getConfiguration() {
        return configuration;
    }

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = new ModelInfoImpl();

        // info.put("name", getName().getName());
        // info.put("type", getType());
        info.put("name", getType());
        info.put("timestamp", Long.toString(getTimestamp()));
        info.put("status", getStatus().toString());

        return info;
    }

    // ----------------------------------------------------------------------

    // public ProjectGraphAccess getProjectGraphAccess() {
    //     return pga;
    // }

    @Override
    public boolean isRunning() {
        return ProjectTaskManager.getTaskManager().findTasks(this).size() > 0;
    }

    /**
     * A model exists IF exists the reference node in the database.
     * It exists ALSO if the status is TASK_RUNNING.
     */
    @Override
    public boolean exists() {
        ModelStatus status = getStatus();
        return status != ModelStatus.NOT_EXISTENT;
    }

    /**
     * Check if the model dependencies are resolved.
     * For example the DependencyModel can be created ONLY if the SourceModel exists.
     */
    protected boolean hasDependenciesResolved() {
        return true;
    }

    // ----------------------------------------------------------------------
    // Status handling
    // ----------------------------------------------------------------------

    @Override
    public final ModelStatus getStatus() {
        checkModelStatus();
        return modelStatus.getStatus();
    }

    @Override
    public String getReason() {
        return this.modelStatus.getReason();
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    protected void checkStatus() {

    }

    protected void checkModelStatus()  {
        setStatus(ModelStatus.VALID, null);

        if (ProjectTaskManager.getTaskManager().hasRunning(this)) {
            setStatus(ModelStatus.TASK_RUNNING, null);
            return;
        }

        if (pmg == null)
            return;

        ModelStatus status = ModelStatus.valueOf(pmg.getStatus());
        if (status == ModelStatus.TASK_RUNNING) {
            setStatus(ModelStatus.INVALID, "It has status TASK_RUNNING but no task is running");
            return;
        }
    }

    @Override
    public final void setStatus(ModelStatus status, String message) {
        this.modelStatus.setStatus(status, message);
    }

    // ----------------------------------------------------------------------
    // Operations: create
    // ----------------------------------------------------------------------

    @Override
    public ProjectTask create(ModelCreateParams params) {
        if (params == null)
            params = new ModelCreateParams();

        this.modelCreateParams = params;

        if (!canCreate())
            return null;

        try {
            return this.createThis();
        }
        catch (Exception e) {
            setStatus(ModelStatus.INVALID, e.toString());
            logger.error(e, e);
            return null;
        }
    }

    // @Override
    // public final boolean create(ModelCreateParams params) {
    //     if (params == null)
    //         params = new ModelCreateParams();
    //
    //     boolean ret;
    //     this.modelCreateParams = params;
    //     // if (params.isDefault())
    //     //     ret = this.create(params.method());
    //     // else if (params.hasMethodAndFilter())
    //     //     ret =  this.create(params.method(), params.filter());
    //     // else if (params.hasMethod())
    //     //     ret =  this.create(params.method());
    //     // else
    //     //     ret = this.create(params.isSync());
    //
    //     if (!canCreate())
    //         return false;
    //
    //     try {
    //         this.createThis(modelCreateParams.isSync());
    //         return true;
    //     }
    //     catch (Exception e) {
    //         setStatus(ModelStatus.INVALID, e.toString());
    //         logger.error(e, e);
    //         return false;
    //     }
    // }

    /**
     * Check if it is possible to create the model.
     *
     * The model can be create IF:
     *
     * 1) there is not a already task running creating the model
     * 2) the dependencies are resolved
     * 3) the model doesn't exist
     *
     * @return true if it is possible to create the model
     */
    @Override
    public boolean canCreate() {
        // if a task is running, it is not possible to create it
        if (isRunning()) {
            logger.warnf("canCreate: FALSE -> A task is running");
            return false;
        }

        // if the dependencies are not resolved
        if (!hasDependenciesResolved()) {
            logger.warnf("canCreate: FALSE -> Dependencies are not resolved");
            return false;
        }

        if (exists()) {
            logger.warnf("canCreate: FALSE -> Model already present");
            return false;
        }

        return true;
    }

    /**
     * Create the model, model specific
     */
    protected ProjectTask createThis() { return null; }


    // ----------------------------------------------------------------------

    @Override
    public boolean canDelete() {
        // It is ALWAYS possible to delete something
        return true;
    }

    /**
     * Delete the model
     *
     * If a task is running, it is aborted and the model is NOT delete.
     * Otherwise the model is deleted from the filesystem/database
     */
    @Override
    public final void delete() {

        // it is not possible to delete the model if a task is running.
        // ABORT the task
        if (isRunning()) {
            abort();
            return;
        }

        try {
            this.deleteThis();
        }
        catch (Exception e) {
            logger.error(e, e);
        }
    }

    /**
     * Delete the model, model-specific
     */
    protected void deleteThis() { }

    // ----------------------------------------------------------------------
    // Task handling
    // ----------------------------------------------------------------------

    @Override
    public ProjectTask getTask() {
        List<ProjectTask> tasks = ProjectTaskManager.getTaskManager().findTasks(this);
        if (tasks.size() == 0)
            return null;

        if (tasks.size() == 1)
            return tasks.get(0);

        logger.errorf("More of ONE (1) task found for this model. Selected the FIRST");
        return tasks.get(0);
    }

    @Override
    public void abort() {
        ProjectTaskManager.getTaskManager().abort(this);
    }

    @Override
    public void create() {
        ProjectTask task = create(modelCreateParams);
        if (task != null)
            Managers.getTaskManager().submit(task);
    }

    @Override
    public void waitForCompletion(long timeout, TimeUnit timeUnit) {
        for(ProjectTask task : ProjectTaskManager.getTaskManager().findTasks(this))
            task.waitForCompletion(timeout, timeUnit);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    protected void setProjectGraphAccess(ProjectModelGraph pmg) {
        this.pmg = pmg;
        this.pga = pmg.getProjectGraphAccess();
    }

    protected void setProjectGraphAccess(ProjectGraphAccess pga) {
        this.pga = pga;
        this.pmg = pga.getGraphAccess();
    }

}

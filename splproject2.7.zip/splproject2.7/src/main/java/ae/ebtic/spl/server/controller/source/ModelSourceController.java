package ae.ebtic.spl.server.controller.source;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebConfig;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.WebModelModel;
import ae.ebtic.spl.server.webmodels.WebModelsFactory;
import ae.ebtic.spl.tasks.ProjectTask;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.io.File;
import java.io.FilenameFilter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/source")
public class ModelSourceController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelSourceController() {
        super(SourceModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web navigation: modules
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Libraries
    // ----------------------------------------------------------------------


    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    /**
     * Checkout/Update: copy the remote changes into the local
     */
    @GetMapping(value="update")
    @ResponseBody
    public ResponseEntity<?> updateSources(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        ProjectTask task = sm.update();
        Managers.getTaskManager().submit(task);

        // WebModelModel wm = WebModelsFactory.of(sm, requestUrl).detailed();
        // if (sm.update(false))
        //     return new ResponseEntity<>(wm, HttpStatus.OK);
        // else
        //     return new ResponseEntity<>(wm, HttpStatus.BAD_REQUEST);

        WebModelModel wm = WebModelsFactory.of(sm, requestUrl).detailed();
        return new ResponseEntity<>(wm, HttpStatus.OK);
    }


    /**
     * Checkin/Commit: copy the local changes into the remote
     */
    @PutMapping(value="commit")
    @ResponseBody
    public ResponseEntity<?> commitSources(
        @PathVariable String repoName,
        @PathVariable String projectName,
        @RequestBody WebConfig config) {

        config.setRepository(repoName).setProject(projectName);
        return _commitSources(config);
    }

    /**
     * Checkin/Commit: copy the local changes into the remote  (DEBUG)
     */
    @GetMapping(value="commit")
    @ResponseBody
    public ResponseEntity<?> commitSourcesByGet(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        WebConfig config = new WebConfig()
            .setRepository(repoName)
            .setProject(projectName);
        return _commitSources(config);
    }

    private ResponseEntity<?> _commitSources(WebConfig config) {

        String repoName = config.getRepository();
        String projectName = config.getProject();

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        ProjectTask task = sm.commit();
        Managers.getTaskManager().submit(task);

        // if (!sm.exists()) {
        //     logger.errorf("SourceModel %s not existent", sm.getName());
        //     return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        // }
        // else {
        //     WebModelModel wm = WebModelsFactory.of(sm, requestUrl).detailed();
        //     if (sm.commit(false))
        //         return new ResponseEntity<>(wm, HttpStatus.OK);
        //     else
        //         return new ResponseEntity<>(wm, HttpStatus.BAD_REQUEST);
        // }

        WebModelModel webmodel = WebModelsFactory.of(sm, requestUrl).detailed();
        return new ResponseEntity<>(webmodel, HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // (DEPRECATED)
    // ----------------------------------------------------------------------

    /**
     * (DEPRECATED)
     */
    @GetMapping(value="getDirectory")       // DEPRECATED
    @ResponseBody
    public ResponseEntity<?> getSourceHomeDeprecated(
            @PathVariable String repoName,
            @PathVariable String projectName) {
        return this.getSourceHome(repoName, projectName);
    }

    @GetMapping(value="directory")
    @ResponseBody
    public ResponseEntity<?> getSourceHome(
        @PathVariable String repoName,
        @PathVariable String projectName) {

        String requestUrl = WebHrefMapper.getRequestUrl(request);

        SourceModel sm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getSourceModel();

        if (!sm.exists()) {
            logger.errorf("SourceModel %s not existent", sm.getName());
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
        else {
            return new ResponseEntity<>(buildDirectory(sm.getSourceHome()), HttpStatus.OK);
        }
    }

    private Map<String, Object> buildDirectory(File file){

        Map<String, Object> fObj = new HashMap<>();
        fObj.put("name", file.getName());
        fObj.put("path", file.getAbsolutePath());

        List<Map<String,Object>> children = new ArrayList<>();
        File[] childFiles = file.listFiles(new FilenameFilter() {

            //apply a filter
            @Override
            public boolean accept(File dir, String name) {
                return new File(dir, name).isDirectory() && !name.startsWith(".");
            }
        });

        for(File childFile: childFiles){
            children.add(buildDirectory(childFile));
        }

        if(children.size() > 0)
            fObj.put("children", children);
        return fObj;
    }

}

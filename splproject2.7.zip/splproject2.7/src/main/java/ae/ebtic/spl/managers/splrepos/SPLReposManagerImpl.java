package ae.ebtic.spl.managers.splrepos;

import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.PathUtils;
import org.apache.commons.configuration2.Configuration;
import org.apache.commons.configuration2.ex.ConfigurationException;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.SystemUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/*
    A SPLRepository in the SPL workspace can be:

    1) a directory
    2) a file JSON with the informations about where is the repository

 */

public class SPLReposManagerImpl implements SPLReposManager {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(SPLReposManager.class);

    private Configuration config;

    /**
     * Directory with the configuration files (.properties) of the
     * remote repositories
     */
    private File workspaceFolder;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SPLReposManagerImpl() { }

    // ----------------------------------------------------------------------
    // System Operations
    // ----------------------------------------------------------------------

    @Override
    public String getName() { return SPLReposManager.MANAGER; }

    @Override
    public File getWorkspaceFolder() {
        if (!workspaceFolder.exists() && workspaceFolder.mkdirs())
            logger.errorf("Created SPLRepoManager home folder %s", workspaceFolder.getAbsolutePath());
        return workspaceFolder;
    }

    @Override
    public void configure(Configuration config) throws ConfigurationException {

        this.config = config;

        logger.info("configure");

        String homePath = config.getString("homePath");
        // String rootPath = config.getString("root[@path]");

        // retrieve the SPL workspace configuration
        String workspacePath = PathUtils.normalize(config.getString("workspace[@path]"));

        if(SystemUtils.IS_OS_UNIX && config.getString("workspace[@path]").startsWith("/"))
            workspacePath = "/" + workspacePath;

        if (StringUtils.isEmpty(workspacePath))
            // backward compatibility
            workspacePath = config.getString("root[@path]");
        if (StringUtils.isEmpty(workspacePath))
            throw new ConfigurationException("configuration workspace[@path] not defined");

        // create the directory if is doesn't exists
        workspaceFolder = FileUtils.toFile(homePath, workspacePath);
        if (!workspaceFolder.exists() && workspaceFolder.mkdirs())
            logger.warnf("Created SPLRepoManager workspace folder %s", workspaceFolder.getAbsolutePath());

        if (!workspaceFolder.exists() || !workspaceFolder.isDirectory())
            throw new ConfigurationException(String.format("'%s' is not existent", workspaceFolder.getAbsolutePath()));

        logger.infof("    home path: %s", homePath);
        logger.infof("    workspace folder: %s", workspaceFolder.getAbsolutePath());

        logger.info("done");
    }

    @Override
    public void destroy() {

    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public SPLRepository newRepository(String name) {
        if (SPLWorkspace.isWorkspace(name))
            return new SPLWorkspace(this);
        else
            return new SPLRepositoryImpl(this, name);
    }

    public List<SPLRepository> listRepositories() {

        List<SPLRepository> repos = FileUtils.listFiles(workspaceFolder, ".json")
            .stream()
            .map(repoCfg -> new SPLRepositoryImpl(this, repoCfg))
            .collect(Collectors.toList());

        List<SPLRepository> splrepos = new ArrayList<>();
        splrepos.add(new SPLWorkspace(this));
        splrepos.addAll(repos);
        return splrepos;
    }

}

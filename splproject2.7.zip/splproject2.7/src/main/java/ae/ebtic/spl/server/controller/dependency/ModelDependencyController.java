package ae.ebtic.spl.server.controller.dependency;

import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.DependencyModel;
import ae.ebtic.spl.server.controller.SPLRestController;
import ae.ebtic.spl.server.webmodels.WebHrefMapper;
import ae.ebtic.spl.server.webmodels.dependency.WebTypeModel;
import jext.graph.NodeDegree;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@CrossOrigin
@RestController
@RequestMapping("/spl/repositories/{repoName}/projects/{projectName}/models/dependency")
public class ModelDependencyController extends SPLRestController {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ModelDependencyController() {
        super(DependencyModel.TYPE);
    }

    // ----------------------------------------------------------------------
    // Web methods
    // ----------------------------------------------------------------------

    // /**
    //  * List of types
    //  *
    //  * It is possible to specify degree of the nodes:
    //  *
    //  *      indegree:   input degree
    //  *      outdegree:  output degree
    //  *
    //  *  The degree can be specified as:
    //  *
    //  *      n       exactly the specified degree
    //  *      n-m     n <= degree <= m
    //  *      n-      n <= degree
    //  *       -m          degree <= m
    //  *
    //  */
    // @GetMapping(value = "types")
    // @ResponseBody
    // public ResponseEntity<?> listDependencyTypes(
    //     @PathVariable String repoName,
    //     @PathVariable String projectName,
    //     @RequestParam(value = "indegree",  defaultValue = "") String indegree,
    //     @RequestParam(value = "outdegree", defaultValue = "") String outdegree,
    //     @RequestParam(value = "role", defaultValue = "") String role)
    // {
    //     String requestUrl = WebHrefMapper.getRequestUrl(request);
    //
    //     DependencyModel dm = Managers.getSPLReposManager()
    //         .newRepository(repoName)
    //         .newProject(projectName)
    //         .getDependencyModel();
    //
    //     if (!dm.exists()) {
    //         logger.errorf("DependencyModel %s not existent", dm.getName());
    //         return new ResponseEntity<>(Collections.emptyList(), HttpStatus.NOT_FOUND);
    //     }
    //
    //     NodeDegree ndegree = NodeDegree.newNodeDegree(indegree, outdegree);
    //
    //     List<WebTypeModel> types;
    //     if (ndegree.isEmpty() && role.isEmpty())
    //         types = dm.listTypes()
    //             .stream()
    //             .map(dt -> new WebTypeModel(dt, requestUrl))
    //             .collect(Collectors.toList());
    //     else
    //         types = dm.listTypes(ndegree, role)
    //             .stream()
    //             .map(dt -> new WebTypeModel(dt, requestUrl))
    //             .collect(Collectors.toList());
    //
    //     return new ResponseEntity<>(types, HttpStatus.OK);
    // }
    //
    // // ----------------------------------------------------------------------
    // // Closures/implementation
    // // ----------------------------------------------------------------------
    //
    // @PostMapping(value = "types/closures")
    // @ResponseBody
    // public ResponseEntity<?> getTypeClosures(
    //     @PathVariable String repoName,
    //     @PathVariable String projectName,
    //     @RequestBody Map<String, Object> closureOptions)
    // {
    //     boolean implementation = (Boolean) closureOptions.getOrDefault("imp",true);
    //     boolean links = (Boolean) closureOptions.getOrDefault("links",true);
    //     boolean refTypes =  (Boolean) closureOptions.getOrDefault("ref",true);
    //     List<String> typeIds = ((List<Object>) closureOptions.getOrDefault("ids", new ArrayList<>())).stream().map(t -> t.toString()).collect(Collectors.toList());
    //
    //     String requestUrl = WebHrefMapper.getRequestUrl(request);
    //
    //     DependencyModel dm = Managers.getSPLReposManager()
    //         .newRepository(repoName)
    //         .newProject(projectName)
    //         .getDependencyModel();
    //
    //     if (!dm.exists()) {
    //         logger.errorf("DependencyModel %s not existent", dm.getName());
    //         return new ResponseEntity<>(Collections.emptyMap(), HttpStatus.NOT_FOUND);
    //     }
    //
    //     return new ResponseEntity<>(dm.getClosures(typeIds,refTypes, implementation, links), HttpStatus.OK);
    // }

    // ----------------------------------------------------------------------
    // Graph
    // ----------------------------------------------------------------------

    /**
     * Retrieve the model graph
     */
    @GetMapping(value = "graph")
    @ResponseBody
    public ResponseEntity<?> getDependencyGraph(
        @PathVariable String repoName,
        @PathVariable String projectName)
    {
        String requestUrl = WebHrefMapper.getRequestUrl(request);

        DependencyModel dm = Managers.getSPLReposManager()
            .newRepository(repoName)
            .newProject(projectName)
            .getDependencyModel();

        return new ResponseEntity<>(dm.getModelGraph(), HttpStatus.OK);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

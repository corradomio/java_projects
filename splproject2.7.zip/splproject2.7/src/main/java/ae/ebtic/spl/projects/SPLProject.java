package ae.ebtic.spl.projects;

import ae.ebtic.spl.analysis.sourcecode.model.IdNamed;
import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.managers.splrepos.SPLRepository;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

public interface SPLProject extends IdNamed {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    String SPL = ".spl";

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    /**
     * Retrieve the repository owner of this project
     */
    SPLRepository getRepository();

    /**
     * Directory where the code is saved
     */
    File getProjectRoot();

    /**
     * Directory '.spl' used to save
     */
    File getSPLDirectory();

    /**
     * It is not possible to delete the source code of the
     * specifla 'linked project'
     */
    boolean isLinkedProject();

    /**
     * Configuration used to create the project
     */
    SPLProjectConfig getConfiguration();

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    /**
     * Create the project.
     * A project can be created ONLY if  it is not already created
     *
     * @param config project configuration
     * @return true if the project is created, false otherwise
     */
    boolean create(SPLProjectConfig config) throws IOException;

    /**
     * Check if exists project exists.
     * A project exists if exists the project home AND the configuration file
     */
    boolean exists();

    /**
     * Delete the project: delete all modules, the configuration file and the project home
     */
    void delete();

    // ----------------------------------------------------------------------
    // Project Models
    // ----------------------------------------------------------------------

    /**
     * Add the model to the list of project models
     */
    void registerModel(ProjectModel model);

    /**
     * Retrieve the list of defined models in the project
     *
     * Note: if the project doesn't exist, return the empty list
     *
     * @return list of models
     */
    List<ProjectModel> getModels();

    /**
     * Retrieve a project model.
     * Available models are: "source", "dependency", "feature", "component",
     * but other models can exists
     *
     * @param modeType name of the model
     * @return a ProjectModel
     */
    ProjectModel getModel(String modeType);

    // ----------------------------------------------------------------------
    // Predefined models
    // ----------------------------------------------------------------------

    SourceModel getSourceModel();

    DependencyModel getDependencyModel();

    ComponentModel getComponentModel();

    FeatureModel getFeatureModel();

    VersioningModel getVersioningModel();

    StatisticsModel getStatisticsModel();

    ClusterModel getClusterModel();

    DiagramsModel getDiagramsModel();

    RuntimeModel getRuntimeModel();

    // ----------------------------------------------------------------------
    // Project Models
    // ----------------------------------------------------------------------

    // void waitForCompletion(long timeout, TimeUnit timeUnit);
}

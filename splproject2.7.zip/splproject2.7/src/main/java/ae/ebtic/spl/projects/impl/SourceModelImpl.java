package ae.ebtic.spl.projects.impl;

import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.Projects;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.SourceInfo;
import ae.ebtic.spl.common.ProjectTaskManager;
import ae.ebtic.spl.managers.Managers;
import ae.ebtic.spl.projects.ModelConfig;
import ae.ebtic.spl.projects.ModelInfo;
import ae.ebtic.spl.projects.ModelStatus;
import ae.ebtic.spl.projects.SPLProject;
import ae.ebtic.spl.projects.SourceModel;
import ae.ebtic.spl.tasks.CommitSourcesTask;
import ae.ebtic.spl.tasks.DownloadSourcesTask;
import ae.ebtic.spl.tasks.ProjectTask;
import ae.ebtic.spl.tasks.UpdateSourcesTask;
import jext.util.FileUtils;
import jext.util.JSONUtils;
import jext.util.Parameters;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

/*
    Supported protocols:

        git://....

        svn://...

        svn+file://
        svn+http://
        svn+https://

        ftp://....
        file://...
        local://...

        link://...
            is used to specify a project already in the local filesystem
 */


public class SourceModelImpl extends ProjectModelImpl implements SourceModel, GraphConstants {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String MODEL_CONFIG = "source-config.json";

    private File projectRoot;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SourceModelImpl(SPLProject project) {
        super(project, SourceModel.TYPE);

        projectRoot = project.getProjectRoot();
        configuration = project.getConfiguration();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public ModelInfo getInfo() {
        ModelInfoImpl info = (ModelInfoImpl) super.getInfo();

        Map<String, Object> counts = new HashMap<>();
        counts.put("modules", getModules().size());
        counts.put("sources", getSourceInfo());

        info.put("count", counts);

        return info;
    }

    @Override
    public long getTimestamp() {
        return getConfiguration().getTimestamp();
    }

    @Override
    public File getSourceHome() {
        return project.getProjectRoot();
    }

    // ----------------------------------------------------------------------
    // Navigation
    // ----------------------------------------------------------------------

    @Override
    public Project getSourceProject() {
        Parameters params = project.getConfiguration().getParameters();
        return Projects
            .newProject(getSourceHome(), params.toProperties())
            .setLibraryFinder(Managers.getLibraryFinder());
    }

    @Override
    public ModelConfig getConfiguration() {
        return configuration;
    }

    // ----------------------------------------------------------------------
    // Sources
    // ----------------------------------------------------------------------

    @Override
    public List<Source> getSources() {
        List<Source> sources = new ArrayList<>();
        for(Module module : getModules()) {
            sources.addAll(module.getSources());
        }
        return sources;
    }

    @Override
    public Source getSource(String sourceId) {
        for(Module module : getModules()) {
            Source source = module.getSource(sourceId);
            if (source != null)
                return source;
        }
        return null;
    }

    // ----------------------------------------------------------------------
    // Libraries
    // ----------------------------------------------------------------------

    @Override
    public List<Library> getLibraries() {
        Set<Library> libraries = new HashSet<>();
        for(Module module : getModules()) {
            libraries.addAll(module.getLibraries());
        }
        return new ArrayList<>(libraries);
    }

    @Override
    public Library getLibrary(String libraryId) {
        for(Module module : getModules()) {
            Library library = module.getLibrary(libraryId);
            if (library != null)
                return library;
        }
        return null;
    }

    // ----------------------------------------------------------------------
    // Modules
    // ----------------------------------------------------------------------

    @Override
    public List<Module> getModules() {
        return getSourceProject().getModules();
    }

    @Override
    public Module getModule(String moduleName) {
        return getSourceProject().getModule(moduleName);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    public boolean hasDependenciesResolved() {
        return true;
    }

    @Override
    protected ProjectTask createThis() {
        DownloadSourcesTask task = new DownloadSourcesTask(this);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());

        return task;

        // if (sync)
        //     task.run();
        // else
        //     Managers.getTaskManager().submit(task);

        // WARNING:
        // the configuration file of the model MUST be saved AFTER
        // the source code is downloaded, NOT before.
        // This because, for example, Git NEED to have a FREE directory where to
        // download the project.
        // IF the directory already contains something, Git is not able to fill
        // it.
    }

    @Override
    protected void deleteThis() {
        setStatus(ModelStatus.INVALID, REASON_DELETE);

        if (!project.isLinkedProject())
            FileUtils.deleteAll(project.getProjectRoot());
        else
            Managers.getExecutorService().submit(() -> {
                FileUtils.deleteAll(project.getSPLDirectory());
            });
    }

    // ----------------------------------------------------------------------
    // Source statistics
    // ----------------------------------------------------------------------

    private SourceInfo getSourceInfo() {
        File sourceInfo = new File(project.getSPLDirectory(), MODEL_CONFIG);
        if (sourceInfo.exists()) {
            try {
                return JSONUtils.load(sourceInfo, SourceInfo.class);
            } catch (IOException e) {
                logger.error(e, e);
            }
        }

        SourceInfo ginfo = new SourceInfo();
        sourceInfo.getParentFile().mkdirs();

        getSources().forEach(source -> {
            SourceInfo sinfo = source.getSourceInfo();
            ginfo.count += sinfo.count;
            ginfo.bytes += sinfo.bytes;
            ginfo.blankLines += sinfo.blankLines;
            ginfo.codeLines += sinfo.codeLines;
            ginfo.totalLines += sinfo.totalLines;
        });

        try {
            JSONUtils.save(sourceInfo, ginfo);
        } catch (IOException e) {
            logger.error(e, e);
        }

        return ginfo;
    }

    // ----------------------------------------------------------------------
    // Versioning support
    // ----------------------------------------------------------------------

    @Override
    public UpdateSourcesTask update() {
        UpdateSourcesTask task = new UpdateSourcesTask(this);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());

        return task;

        // if (sync)
        //     task.run();
        // else
        //     Managers.getTaskManager().submit(task);
        //
        // return true;
    }

    @Override
    public CommitSourcesTask commit() {
        CommitSourcesTask task = new CommitSourcesTask(this);
        task.addListeners(modelCreateParams.listeners());
        task.setParameters(modelCreateParams.parameters());

        return task;

        // if (sync)
        //     task.run();
        // else
        //     Managers.getTaskManager().submit(task);
        //
        // return true;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    @Override
    protected void checkModelStatus(){

        if (!projectRoot.exists()) {
            setStatus(ModelStatus.NOT_EXISTENT, "Project root doesn't exist");
            return;
        }

        super.checkModelStatus();
        ModelStatus thisStatus = modelStatus.getStatus();
        if (thisStatus != ModelStatus.VALID)
            return;

        setStatus(configuration.getStatus(), null);
    }

}

package ae.ebtic.spl.data;

import jext.logging.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.neo4j.repository.config.EnableNeo4jRepositories;

import javax.annotation.PostConstruct;

@Configuration
@EnableNeo4jRepositories
public class SPLDataConfig {

    private static Logger logger = Logger.getLogger(SPLDataConfig.class);

    @Value("${spring.data.neo4j.uri}")
    private String neo4jUri;

    public SPLDataConfig() {
        // logger.info("new");
    }

    @PostConstruct
    public void init() {
        logger.info("init");
    }
}

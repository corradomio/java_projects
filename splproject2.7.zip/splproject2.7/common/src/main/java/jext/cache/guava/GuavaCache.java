package jext.cache.guava;

import jext.cache.Cache;

import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

public class GuavaCache<K, V> implements Cache<K, V> {

    private com.google.common.cache.Cache<K, V> innerCache;

    public GuavaCache(com.google.common.cache.Cache<K, V> innerCache) {
        this.innerCache = innerCache;
    }

    @Override
    public Optional<V> getIfPresent(K key) {
        V value = innerCache.getIfPresent(key);
        if (value == null)
            return Optional.empty();
        else
            return Optional.of(value);
    }

    @Override
    public V getChecked(K key, Callable<? extends V> loader) throws ExecutionException {
        return innerCache.get(key, loader);
    }

    @Override
    public V get(K key, Function<K, ? extends V> loader) {
        try {
            return innerCache.get(key, () -> loader.apply(key));
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public V get(K key, Callable<? extends V> loader) {
        try {
            return innerCache.get(key, loader);
        } catch (ExecutionException e) {
            throw new RuntimeException(e);
        }
    }
}

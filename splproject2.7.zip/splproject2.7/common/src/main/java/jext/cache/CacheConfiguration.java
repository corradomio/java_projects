package jext.cache;

import jext.util.HashMap;

import java.util.Map;
import java.util.Properties;

public class CacheConfiguration {

    private Map<String, Properties> cacheProps = new HashMap<>();

    public CacheConfiguration() {
        // default configuration
        cacheProps.put("", new Properties());
    }

    public void add(String name, Properties properties) {
        this.cacheProps.put(name, properties);
    }

    public Properties get(String name) {
        // there is a specific configuration for the cache, retrieve it
        if (cacheProps.containsKey(name))
            return cacheProps.get(name);

        // retrieve the most specific cache configuration

        Properties selProps = cacheProps.getOrDefault("", jext.util.Properties.empty());
        String selName = "";
        for (String cname : cacheProps.keySet()) {
            String prefix = cname + ".";

            if (name.startsWith(prefix) && cname.length() > selName.length()) {
                selProps = cacheProps.get(cname);
                selName = cname;
            }
        }

        return selProps;
    }
}

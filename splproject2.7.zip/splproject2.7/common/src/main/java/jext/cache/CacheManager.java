package jext.cache;

import com.google.common.cache.CacheBuilder;
import jext.cache.guava.GuavaCache;
import jext.logging.Logger;
import jext.util.PropertiesUtils;
import jext.util.TimeUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.concurrent.TimeUnit;

public class CacheManager {

    /** Maximum capacity (number of entries) */
    public static String CAPACITY = "capacity";

    /** Expiry policy based on the first 'put': after the specified timeout */
    public static String EXPIRE_AFTER_WRITE = "expireAfterWrite";

    /** Expiry policy based on the last 'put'/'get': after the specified timeout */
    public static String EXPIRE_AFTER_ACCESS = "expireAfterAccess";

    /** If a value is wrapped by a WeakReference (boolean) */
    public static String WEAK_VALUES = "weakValues";

    // --

    private static Logger logger = Logger.getLogger(CacheManager.class);

    private static CacheConfiguration config = new CacheConfiguration();

    private static Map<String, Cache> caches = new HashMap<>();

    public static void configure(CacheConfiguration config) {
        CacheManager.config = config;
    }

    public static synchronized  <K, V> Cache<K, V> getCache(String fmt, Object... args) {
        String name = String.format(fmt, args);;
        if (caches.containsKey(name))
            return caches.get(name);

        Properties cacheProps = config.get(name);
        Cache cache = createCache(name, cacheProps);

        caches.put(name, cache);
        return cache;
    }

    private static Cache createCache(String name, Properties properties) {
        CacheBuilder<Object, Object> builder = CacheBuilder.newBuilder();

        if(properties.containsKey(CAPACITY)) {
            long capacity = PropertiesUtils.getInt(properties, CAPACITY, 128);
            builder.maximumSize(capacity);
        }
        if (properties.containsKey(EXPIRE_AFTER_ACCESS)) {
            long duration = TimeUtils.toMillis(PropertiesUtils.getString(properties, EXPIRE_AFTER_ACCESS));
            builder.expireAfterAccess(duration, TimeUnit.MILLISECONDS);
        }
        if (properties.containsKey(EXPIRE_AFTER_WRITE)) {
            long duration = TimeUtils.toMillis(PropertiesUtils.getString(properties, EXPIRE_AFTER_WRITE));
            builder.expireAfterWrite(duration, TimeUnit.MILLISECONDS);
        }
        if (properties.containsKey(WEAK_VALUES)) {
            boolean weakValues = Boolean.parseBoolean(properties.getProperty(WEAK_VALUES));
            if (weakValues)
                builder.weakValues();
        }

        com.google.common.cache.Cache guavaCache = builder.build();

        logger.infof("Created cache %s", name);

        return new GuavaCache(guavaCache);
    }

    public static synchronized void removeCaches(String fmt, Object... args) {
        String name = String.format(fmt, args);
        String nameDot = name + ".";
        List<String> cacheNames = new ArrayList<>(caches.keySet());
        for (String cname : cacheNames) {
            if (cname.equals(name) || cname.startsWith(nameDot))
                caches.remove(cname);
        }
    }

    public static void clear() {
        caches.clear();
    }

}

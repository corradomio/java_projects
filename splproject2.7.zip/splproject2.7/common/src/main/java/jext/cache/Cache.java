package jext.cache;

import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutionException;
import java.util.function.Function;

public interface Cache<K, V> {

    Optional<V> getIfPresent(K key);

    V get(K key, Callable<? extends V> loader);
    V get(K key, Function<K, ? extends V> loader);

    V getChecked(K key, Callable<? extends V> loader) throws ExecutionException;
}

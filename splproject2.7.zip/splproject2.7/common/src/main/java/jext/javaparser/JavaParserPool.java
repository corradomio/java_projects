package jext.javaparser;

import com.github.javaparser.JavaParser;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ParserConfiguration;
import com.github.javaparser.Problem;
import com.github.javaparser.TokenRange;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.comments.CommentsCollection;
import com.github.javaparser.symbolsolver.javaparser.Navigator;
import com.google.common.cache.Cache;
import com.google.common.cache.CacheBuilder;
import jext.logging.Logger;

import java.io.File;
import java.io.FileNotFoundException;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import static com.github.javaparser.ParseStart.COMPILATION_UNIT;
import static com.github.javaparser.ParserConfiguration.LanguageLevel.BLEEDING_EDGE;
import static com.github.javaparser.Providers.provider;

/*
    This class is Copy & Paste plus some updates of the class:

        com.github.javaparser.symbolsolver.resolution.typesolvers.JavaParserTypeSolver

 */
public class JavaParserPool {

    // ----------------------------------------------------------------------
    // Pool
    // ----------------------------------------------------------------------

    private static JavaParserPool pool = new JavaParserPool();

    public static JavaParserPool getPool() {
        return pool;
    }

    public static JavaParserPool newPool(String name) {
        return new JavaParserPool(name);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static final String GLOBAL = "global";

    private Logger logger;

    private String name;

    // source directories of the parsed files
    private Set<Path> sourceRoots;

    // parser configuration used for the parser
    private ParserConfiguration parserConfiguration;

    // maximum cache size
    private long cacheSizeLimit = -1;

    // caches
    private Cache<Path, ParseResult<CompilationUnit>> parsedFiles;
    private Cache<Path, List<CompilationUnit>> parsedDirectories;
    private Cache<String, Optional<TypeDeclaration<?>>> foundTypes;
    private static final int CACHE_SIZE_UNSET = -1;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public JavaParserPool() {
        this(GLOBAL, new ParserConfiguration().setLanguageLevel(BLEEDING_EDGE), CACHE_SIZE_UNSET);
    }

    public JavaParserPool(String name) {
        this(name, new ParserConfiguration().setLanguageLevel(BLEEDING_EDGE), CACHE_SIZE_UNSET);
    }

    /**
     * @param parserConfiguration is the configuration the solver should use when inspecting source code files.
     * @param cacheSizeLimit is an optional size limit to the internal caches used by this solver.
     *        Be advised that setting the size too low might lead to noticeable performance degradation.
     *        However, using a size limit is advised when solving symbols in large code sources. In such cases, internal
     *        caches might consume large amounts of heap space.
     */
    public JavaParserPool(String name, ParserConfiguration parserConfiguration, long cacheSizeLimit) {
        this.name = name;
        this.sourceRoots = new HashSet<>();
        this.parserConfiguration = parserConfiguration;
        this.cacheSizeLimit = cacheSizeLimit;

        this.logger = Logger.getLogger(getClass(), name);

        this.parsedFiles = BuildCache(cacheSizeLimit);
        this.parsedDirectories = BuildCache(cacheSizeLimit);
        this.foundTypes = BuildCache(cacheSizeLimit);
    }

    // ----------------------------------------------------------------------
    // Cache
    // ----------------------------------------------------------------------

    private <TKey, TValue> Cache<TKey, TValue> BuildCache(long cacheSizeLimit) {
        CacheBuilder<Object, Object> cacheBuilder = CacheBuilder.newBuilder().softValues();
        if (cacheSizeLimit != CACHE_SIZE_UNSET) {
            cacheBuilder.maximumSize(cacheSizeLimit);
        }
        return cacheBuilder.build();
    }

    public JavaParserPool resetCache() {
        parsedFiles = BuildCache(cacheSizeLimit);
        parsedDirectories = BuildCache(cacheSizeLimit);
        foundTypes = BuildCache(cacheSizeLimit);
        return this;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public JavaParserPool setParserConfiguration(ParserConfiguration parserConfiguration) {
        Objects.requireNonNull(parserConfiguration, "parserConfiguration can be not null");
        this.parserConfiguration = parserConfiguration;
        return this;
    }

    public JavaParserPool setCacheSizeLimit(long cacheSizeLimit) {
        this.cacheSizeLimit = cacheSizeLimit;
        return this;
    }

    public JavaParserPool addSourceRoot(File sourceRoot) {
        sourceRoots.add(sourceRoot.toPath());
        return this;
    }

    // ----------------------------------------------------------------------
    // Parsing
    // ----------------------------------------------------------------------

    public ParseResult<CompilationUnit> parse(File srcFile) {
        synchronized (this/*getPool()*/) {
            return parsePath(srcFile.toPath());
        }
    }

    private ParseResult<CompilationUnit> parsePath(Path srcFile) {
        try {
            return parsedFiles.get(srcFile.toAbsolutePath(), () -> {
                ParseResult<CompilationUnit> result =
                    new JavaParser(parserConfiguration)
                        .parse(COMPILATION_UNIT, provider(srcFile));
                result.ifSuccessful(cu -> {
                    cu.setStorage(srcFile);
                    cu.getPackageDeclaration().ifPresent(pdecl -> {
                        addSourceRoot(srcFile, pdecl.getNameAsString());
                    });
                });
                return result;
            });
        }
        catch (Throwable e) {
            return new ParseResult<>(
                null,
                new ArrayList<Problem>(){{
                    add(new Problem(e.getMessage(), TokenRange.INVALID, e));
                }},
                new CommentsCollection());
        }
    }

    private ParseResult<CompilationUnit> parse(Path srcFile) {
        try {
            return parsedFiles.get(srcFile.toAbsolutePath(), () -> {
                try {
                    if (!Files.exists(srcFile) || !Files.isRegularFile(srcFile)) {
                        return new ParseResult<>(
                            null,
                            new ArrayList<Problem>(){{
                                add(new Problem("FileNotFoundException", TokenRange.INVALID,
                                    new FileNotFoundException(srcFile.toString())));
                            }},
                            new CommentsCollection());
                    }
                    return new JavaParser(parserConfiguration).parse(COMPILATION_UNIT, provider(srcFile));
                }
                catch (FileNotFoundException e) {
                    throw new RuntimeException("Issue while parsing while type solving: " + srcFile.toAbsolutePath(), e);
                }
            });
        }
        catch (ExecutionException e) {
            return new ParseResult<>(
                null,
                new ArrayList<Problem>(){{
                    add(new Problem("ExecutionException", TokenRange.INVALID, e));
                }},
                new CommentsCollection());
        }
    }

    private void addSourceRoot(Path srcFile, String packageName) {
        String subDir = packageName.replace('.', '/');
        String srcHome = srcFile.getParent().toAbsolutePath().toString().replace('\\', '/');

        // check that the java file is the correct directory
        if (!srcHome.endsWith(subDir))
            return;

        Path srcDir = Paths.get(srcHome.substring(0, srcHome.length() - subDir.length()-1));
        sourceRoots.add(srcDir);
    }

    /**
     * Note: that this parse only files directly contained in this directory.
     *       It does not traverse recursively all children directory.
     */
    private List<CompilationUnit> parseDirectory(Path srcDirectory) {
        return parseDirectory(srcDirectory, false);
    }

    private List<CompilationUnit> parseDirectoryRecursively(Path srcDirectory) {
        return parseDirectory(srcDirectory, true);
    }

    private List<CompilationUnit> parseDirectory(Path srcDirectory, boolean recursively) {
        try {
            return parsedDirectories.get(srcDirectory.toAbsolutePath(), () -> {
                List<CompilationUnit> units = new ArrayList<>();
                if (Files.exists(srcDirectory)) {
                    try (DirectoryStream<Path> srcDirectoryStream = Files.newDirectoryStream(srcDirectory)) {
                        srcDirectoryStream
                            .forEach(file -> {
                                if (file.getFileName().toString().toLowerCase().endsWith(".java")) {
                                    parse(file).getResult().ifPresent(units::add);
                                } else if (recursively && file.toFile().isDirectory()) {
                                    units.addAll(parseDirectoryRecursively(file));
                                }
                            });
                    }
                }
                return units;
            });
        }
        catch (ExecutionException e) {
            throw new RuntimeException(e);
        }

    }

    // ----------------------------------------------------------------------
    // Resolve
    // ----------------------------------------------------------------------

    // @Override
    // public SymbolReference<ResolvedReferenceTypeDeclaration> tryToSolveType(String name) {
    //     try {
    //         return foundTypes.get(name, () -> {
    //             SymbolReference<ResolvedReferenceTypeDeclaration> result = tryToSolveTypeUncached(name);
    //             if (result.isSolved()) {
    //                 return SymbolReference.solved(result.getCorrespondingDeclaration());
    //             }
    //             return result;
    //         });
    //     }
    //     catch (ExecutionException e) {
    //         throw new RuntimeException(e);
    //     }
    // }
    //
    // private SymbolReference<ResolvedReferenceTypeDeclaration> tryToSolveTypeUncached(String name) {
    //     String[] nameElements = name.split("\\.");
    //
    //     for(Path srcDir : sourceRoots)
    //     for (int i = nameElements.length; i > 0; i--) {
    //         StringBuilder filePath = new StringBuilder(srcDir.toAbsolutePath().toString());
    //         for (int j = 0; j < i; j++) {
    //             filePath.append("/")
    //                 .append(nameElements[j]);
    //         }
    //         filePath.append(".java");
    //
    //         StringBuilder typeName = new StringBuilder();
    //         for (int j = i - 1; j < nameElements.length; j++) {
    //             if (j != i - 1) {
    //                 typeName.append(".");
    //             }
    //             typeName.append(nameElements[j]);
    //         }
    //
    //         // As an optimization we first try to look in the canonical position where we expect to find the file
    //         Path srcFile = Paths.get(filePath.toString());
    //         {
    //             Optional<CompilationUnit> compilationUnit = parse(srcFile);
    //             if (compilationUnit.isPresent()) {
    //                 Optional<com.github.javaparser.ast.body.TypeDeclaration<?>> astTypeDeclaration
    //                     = Navigator.findType(compilationUnit.get(), typeName.toString());
    //                 if (astTypeDeclaration.isPresent()) {
    //                     return SymbolReference.solved(JavaParserFacade.get(this).getTypeDeclaration(astTypeDeclaration.get()));
    //                 }
    //             }
    //         }
    //
    //         // If this is not possible we parse all files
    //         // We try just in the same package, for classes defined in a file not named as the class itself
    //         {
    //             List<CompilationUnit> compilationUnits = parseDirectory(srcFile.getParent());
    //             for (CompilationUnit compilationUnit : compilationUnits) {
    //                 Optional<com.github.javaparser.ast.body.TypeDeclaration<?>> astTypeDeclaration
    //                     = Navigator.findType(compilationUnit, typeName.toString());
    //                 if (astTypeDeclaration.isPresent()) {
    //                     return SymbolReference.solved(JavaParserFacade.get(this).getTypeDeclaration(astTypeDeclaration.get()));
    //                 }
    //             }
    //         }
    //     }
    //
    //     return SymbolReference.unsolved(ResolvedReferenceTypeDeclaration.class);
    // }

    public Optional<TypeDeclaration<?>> tryToSolveType(String name) {
        synchronized (this/*getPool()*/) {
            try {
                return foundTypes.get(name, () -> tryToSolveTypeUncached(name));
            }
            catch (ExecutionException e) {
                throw new RuntimeException(e);
            }
        }
    }

    private Optional<TypeDeclaration<?>> tryToSolveTypeUncached(String name) {
        String[] nameElements = name.split("\\.");

        for(Path srcDir : sourceRoots)
            for (int i = nameElements.length; i > 0; i--) {
                StringBuilder filePath = new StringBuilder(srcDir.toAbsolutePath().toString());
                for (int j = 0; j < i; j++) {
                    filePath.append("/")
                        .append(nameElements[j]);
                }
                filePath.append(".java");

                StringBuilder typeName = new StringBuilder();
                for (int j = i - 1; j < nameElements.length; j++) {
                    if (j != i - 1) {
                        typeName.append(".");
                    }
                    typeName.append(nameElements[j]);
                }

                // As an optimization we first try to look in the canonical position where we expect to find the file
                Path srcFile = Paths.get(filePath.toString());
                {
                    Optional<CompilationUnit> compilationUnit = parse(srcFile).getResult();
                    if (compilationUnit.isPresent()) {
                        Optional<com.github.javaparser.ast.body.TypeDeclaration<?>> astTypeDeclaration
                            = Navigator.findType(compilationUnit.get(), typeName.toString());
                        if (astTypeDeclaration.isPresent()) {
                            //return SymbolReference.solved(JavaParserFacade.get(this).getTypeDeclaration(astTypeDeclaration.get()));
                            return astTypeDeclaration;
                        }
                    }
                }

                // If this is not possible we parse all files
                // We try just in the same package, for classes defined in a file not named as the class itself
                {
                    List<CompilationUnit> compilationUnits = parseDirectory(srcFile.getParent());
                    for (CompilationUnit compilationUnit : compilationUnits) {
                        Optional<com.github.javaparser.ast.body.TypeDeclaration<?>> astTypeDeclaration
                            = Navigator.findType(compilationUnit, typeName.toString());
                        if (astTypeDeclaration.isPresent()) {
                            //return SymbolReference.solved(JavaParserFacade.get(this).getTypeDeclaration(astTypeDeclaration.get()));
                            return astTypeDeclaration;
                        }
                    }
                }
            }

        return Optional.empty();
    }

    // ----------------------------------------------------------------------
    // Overrides
    // ----------------------------------------------------------------------

    @Override
    public String toString() {
        return String.format("JavaParserPool[%s]", name);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

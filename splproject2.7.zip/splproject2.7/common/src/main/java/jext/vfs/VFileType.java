package jext.vfs;

public enum VFileType {
    UNKNOWN,
    FILE,
    FOLDER,
}

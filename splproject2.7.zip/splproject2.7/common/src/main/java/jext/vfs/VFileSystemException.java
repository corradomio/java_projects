package jext.vfs;

public class VFileSystemException extends Error {

    public VFileSystemException(String msg) {
        super(msg);
    }
}

package jext.vfs;

public interface VFileSelector {

    boolean accept(VFile file);
}

package jext.graph;

public class GraphDatabaseException extends Error {

    public GraphDatabaseException(String msg) {
        super(msg);
    }
}

package jext.graph;

public enum Direction {
    Any,
    Input,
    Output
}

package jext.io.file;

public class FileSet extends ItemSet {

    public FileSet() {
        super();
        this.selectDirs = false;
    }
}

package jext.io.file;

public class DirSet extends ItemSet {

    public DirSet() {
        super();
        this.selectFiles = false;
    }
}

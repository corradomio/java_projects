package jext.jfr;

import jext.logging.Logger;
import jext.util.FileUtils;
import org.openjdk.jmc.common.item.IItemCollection;
import org.openjdk.jmc.common.item.IItemIterable;
import org.openjdk.jmc.flightrecorder.CouldNotLoadRecordingException;
import org.openjdk.jmc.flightrecorder.JfrLoaderToolkit;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/**
 * Note: the library IN THEORY is able to read zipped/gzipped/bzipped files.
 *       BUT this is not true. There is an internal error that trows an exception ('format not supported)
 *       To resolve this problem, the solution is to extract the content of the compressed file,
 *       and work on the uncompressed version.
 */
public class JfrEvents {

    private static final String DOT_JFR = ".jfr";
    private static final String DOT_ZIP = ".zip";

    private static Logger logger = Logger.getLogger(JfrEvents.class);

    // ----------------------------------------------------------------------
    // Static methods
    // ----------------------------------------------------------------------

    /**
     * Read the content of the JFR events file
     */
    public static JfrEvents loadEvents(File eventsFile) throws IOException, CouldNotLoadRecordingException {
        return loadEvents(Collections.singletonList(eventsFile));
    }
    /**
     * Read the content of a list of JFR event files
     * It is possible to use ".jfr" files or ".zip" files containing ".jfr" files
     */
    public static JfrEvents loadEvents(List<File> eventsFiles) throws IOException, CouldNotLoadRecordingException {

        JfrEvents parsedEvents = new JfrEvents();

        // process different type of files
        if (isAllJfrFiles(eventsFiles)) {
            parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(eventsFiles));
            return parsedEvents;
        }

        for (File eventsFile : eventsFiles)
            if (eventsFile.getName().endsWith(DOT_JFR))
                parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(eventsFile));
            else if (eventsFile.getName().endsWith(DOT_ZIP))
                analyzeZippedEventsFile(parsedEvents, eventsFile);
            else
                logger.errorf("Unsupported file %s", FileUtils.getAbsolutePath(eventsFile));

        return parsedEvents;
    }

    /**
     * Check if all files are ".jfr".
     * Necessary to use the library's internal services to read multiple files
     */
    private static boolean isAllJfrFiles(List<File> eventsFiles) {
        for (File file : eventsFiles) {
            if (!file.getName().endsWith(DOT_JFR))
                return false;
        }
        return true;
    }

    /**
     *
     * @param parsedEvents
     * @param zippedFile
     */
    private static void analyzeZippedEventsFile(JfrEvents parsedEvents, File zippedFile) {

        try {
            ZipFile zipFile = new ZipFile(zippedFile);
            Enumeration<? extends ZipEntry> entries = zipFile.entries();
            while (entries.hasMoreElements()) {
                ZipEntry entry = entries.nextElement();
                String ename = entry.getName();
                if (ename.endsWith(DOT_JFR)) {
                    Path tempFile = Files.createTempFile(zippedFile.getName(), DOT_JFR);
                    Files.delete(tempFile);
                    InputStream events = zipFile.getInputStream(entry);
                    Files.copy(events, tempFile);

                    parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(tempFile.toFile()));
                }
            }
        }
        catch (Exception e) {
            logger.errorf("Unable to parse %s: %s", zippedFile, e);
        }


        //
        // DOESN'T WORK
        //
        // try(ZipInputStream zis = new ZipInputStream(new FileInputStream(zippedFile))) {
        //     for (ZipEntry ze = zis.getNextEntry(); ze != null; ze = zis.getNextEntry()) {
        //         String name = ze.getName();
        //         if (!name.endsWith(DOT_JFR))
        //             continue;
        //
        //         InputStream events = zis;
        //         parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(events));
        //     }
        // }
        // catch (Exception e) {
        //     logger.errorf("Unable to parse %s: %s", zippedFile, e);
        // }

        //
        // DOESN'T WORK
        //
        // try {
        //     ZipFile zipFile = new ZipFile(zippedFile);
        //     Enumeration<? extends ZipEntry> entries = zipFile.entries();
        //     while (entries.hasMoreElements()) {
        //         ZipEntry entry = entries.nextElement();
        //         String ename = entry.getName();
        //         if (ename.endsWith(DOT_JFR)) {
        //             InputStream events = zipFile.getInputStream(entry);
        //             parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(events));
        //         }
        //
        //     }
        // }
        // catch (Exception e) {
        //     logger.errorf("Unable to parse %s: %s", zippedFile, e);
        // }

        //
        // DOESN'T WORK
        //
        // try (InputStream events = new BufferedInputStream(new FileInputStream(zippedFile))) {
        //     parsedEvents.addEvents(JfrLoaderToolkit.loadEvents(events));
        // }
        // catch (Exception e) {
        //     logger.errorf("Unable to parse %s: %s", zippedFile, e);
        // }
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private List<IItemCollection> eventsList = new ArrayList<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private JfrEvents() {

    }

    private JfrEvents addEvents(IItemCollection events) {
        this.eventsList.add(events);
        return this;
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    private static final String THREAD_DUMP = "jdk.ThreadDump";

    /** Extract the "jdk.ThreadDump" events from the file */
    public ThreadDumps getThreadDumps() {

        List<IItemIterable> threadDumps = new ArrayList<>();

        for (IItemCollection events : eventsList) {
            for (IItemIterable iterableEvent : events) {
                // id of the 'iterable event'
                String id = iterableEvent.getType().getIdentifier();
                if (THREAD_DUMP.equals(id))
                    threadDumps.add(iterableEvent);
            }
        }

        return new ThreadDumps(threadDumps);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

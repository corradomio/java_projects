package jext.util;

public interface Set<E> extends java.util.Set<E> {

    Set<E> add_(E e);

    Set<E> addAll_(java.util.Collection<? extends E> c);
}

package jext.util.concurrent;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.function.Consumer;
import java.util.function.IntConsumer;
import java.util.stream.Collectors;
import java.util.stream.IntStream;
import java.util.stream.Stream;

import static jext.util.concurrent.Parallel.*;

/**
 * Split a long queue in chunks of the specified size
 * and pass each chunk to a different thread
 */
public class Parallelize {

    private int chunkSize = 0;

    public Parallelize(int chunkSize) {
        this.chunkSize = chunkSize;
    }

    public void forEach(int first, int last, IntConsumer body) {
        List<Callable<Boolean>> tasks = new ArrayList<>();
        for(int t=first; t<last; ++t) tasks.add(new IntTask(t, body));
        invokeAll(tasks);
    }

    public <T> void forEach(Iterable<T> it, Consumer<T> body) {
        List<Callable<Boolean>> tasks = new ArrayList<>();
        for(T t : it) tasks.add(new Task<>(t, body));
        invokeAll(tasks);
    }

    public <T> void forEach(Stream<T> s, Consumer<T> body) {
        List<Callable<Boolean>> tasks = s.map(t -> new Task<>(t, body)).collect(Collectors.toList());
        invokeAll(tasks);
    }

    public void forEach(IntStream s, IntConsumer body) {
        List<Callable<Boolean>> tasks = s.mapToObj(t -> new IntTask(t, body)).collect(Collectors.toList());
        invokeAll(tasks);
    }

    private void invokeAll(List<Callable<Boolean>> tasks) {
        int fromIndex = 0;
        int toIndex, endIndex = tasks.size();

        while (fromIndex < endIndex) {
            toIndex = Math.min(fromIndex + chunkSize, endIndex);
            List<Callable<Boolean>> tasksChunk = tasks.subList(fromIndex, toIndex);

            beginChunk();

            Parallel.invokeAll(tasksChunk);

            endChunk();

            fromIndex = toIndex;
        }
    }

    protected void beginChunk() {

    }

    protected void endChunk() {

    }
}

package jext.util;

public class HashCode {

    private long hashCode;
    private long multiplier = 17;

    public HashCode() {
        this.hashCode = 0;
    }

    public HashCode add(boolean value) {
        hashCode = hashCode << 4 ^ Boolean.hashCode(value);
        return this;
    }

    public HashCode add(int value) {
        hashCode = (hashCode*multiplier) ^ Integer.hashCode(value);
        return this;
    }

    public HashCode add(long value) {
        hashCode = (hashCode*multiplier) ^ Long.hashCode(value);
        return this;
    }

    public HashCode add(double value) {
        hashCode = (hashCode*multiplier) ^ Double.hashCode(value);
        return this;
    }

    public HashCode add(String value) {
        if (value != null)
            hashCode = (hashCode*multiplier) ^ value.hashCode();
        return this;
    }

    public int toHashCode() {
        return (int)hashCode;
    }

    public long toHashCode64() { return hashCode; }

    public String toHashCodeString64() {
        return Long.toHexString(toHashCode64());
    }
}

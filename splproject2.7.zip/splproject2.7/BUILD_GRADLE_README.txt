'build.gradle' it is NOT the only file name
-------------------------------------------
Some projects use a Gradle file with name '<project>.gradle' as build Gradle script.
Sometimes there are also other '.gradle' files 


Structure of the file 'build.gradle'
------------------------------------

https://docs.gradle.org/current/userguide/declaring_dependencies.html
https://docs.gradle.org/current/userguide/java_library_plugin.html


simplyfied
----------

Is a dependency ANY line that contains a string like:

    group: 'org.nd4j', name: 'nd4j-native', version: '1.0.0-beta2'
    'org.nd4j:nd4j-native:1.0.0-beta2'

    'org.tensorflow:tensorflow-android:+'       ??

a line like

    project(':identityManagement')

is a dependency with another project

Problem:

    "antlr:antlr:$antlrVersion"

contains a 'placeholder'. At the moment, the resolution of the placeholders is not possible
because doesn't exist a single rule.


Old
---

The file 'build.gradle' is written in 'Groovy'
It is necessary to support, at minimum, the 'line comments'

For the analysis, the important part of the file are the rows that start with

        compile ...

        api ...
        implementation ...
        testImplementation ...
        compileOnly ...
        runtimeOnly ...
        testCompileOnly ...
        testRuntimeOnly ...

Some examples:

        compile localGroovy()
        compile.extendsFrom gradleApi

        compile 'commons-collections:commons-collections:3.2.2'
        compile (group: 'org.deeplearning4j', name: 'deeplearning4j-core', version: '1.0.0-beta2')
        compile group: 'org.nd4j', name: 'nd4j-native', version: '1.0.0-beta2'

        compile 'com.google.code.findbugs:annotations:3.0.1', { ... }
        compile 'junit:junit:4.12', project(':project2')

        compile project(':identityManagement')


Note: skip

        'compile', "compile"


Gradle Daemon
-------------

https://docs.gradle.org/current/userguide/gradle_daemon.html#gradle_daemon

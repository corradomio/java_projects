package ae.ebtic.spl.analysis.dependencyv2.util;

import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import jext.util.concurrent.Parallelize;

public class ParallelizeAnalysis extends Parallelize {

    public ParallelizeAnalysis() {
        super(512);
    }

    public ParallelizeAnalysis(int chunkSize) {
        super(chunkSize);
    }

    @Override
    protected void beginChunk() {
        JavaParserFacade.clearInstances();
    }

    @Override
    protected void endChunk() {
        JavaParserFacade.clearInstances();
    }
}

package ae.ebtic.spl.analysis.components;

import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;

import java.util.List;
import java.util.Map;

public class TopDownComponentAnalyzer extends AbstractComponentAnalyzer implements ComponentAnalysis {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ComponentAnalysis newAnalyzer(AnalyzerConfig config){
        TopDownComponentAnalyzer analyzer = new TopDownComponentAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public TopDownComponentAnalyzer (AnalyzerConfig config){
        super(config);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public void analyze() {
        if (aborted) return;

        try (ComponentGraph cg = (ComponentGraph) this.cg.connect()) {
            createComponentNode();

            int depth = 0;
            List<Map<String, Object>> typesValues = cg.findTypesWithoutInEdge();//.findTypeValues();
            createComponentGraph(typesValues, depth);

            analysisDone(false);
        }
        catch (Exception e){
            this.logger.error(e, e);
            analysisDone(true);
        }
    }

    @Override
    public void createComponentGraph(List<Map<String, Object>> memberValues, int depth) {
        createComponents(memberValues, depth);
    }

    @Override
    public void createComponents(List<Map<String, Object>> membersValues, int depth) {

        listeners.fireCreateComponents(setTotalComponents(membersValues.size()));

        lcg = new SimpleDirectedGraph<>(DefaultEdge.class);
        for (Map<String, Object> memberValue : membersValues) {
            // create a component for each type
           String componentId= super.createComponent(memberValue, depth);
            cg.updateComponentProperty(componentId, CROLE_DAGROOT);
        }
    }

}

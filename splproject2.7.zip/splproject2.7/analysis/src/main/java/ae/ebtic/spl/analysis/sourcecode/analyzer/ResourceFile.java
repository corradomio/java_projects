package ae.ebtic.spl.analysis.sourcecode.analyzer;

import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.MimeTypes;
import jext.util.PathUtils;

import java.io.File;

public class ResourceFile extends NamedObject implements Resource {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    protected final Module module;
    protected final File file;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ResourceFile(File file, Module module) {
        super(ObjectName.empty());

        this.module = module;
        this.file = file;

        String rpath = FileUtils.relativePathNoExt(module.getDirectory(), getFile());
        setName(new PathName(rpath));
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getPath() {
        return FileUtils.getAbsolutePath(file);
    }

    @Override
    public File getFile() {
        return file;
    }

    @Override
    public String getDigest() {
        return FileUtils.digest(file);
    }

    @Override
    public String getMimeType() {
        return MimeTypes.guessMimeType(PathUtils.getName(getPath()));
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public Module getModule() {
        return module;
    }

    @Override
    public String getModuleId() {
        return module.getId();
    }

}

package ae.ebtic.spl.analysis.sourcecode.analyzerv2.simple;

import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseProject;
import ae.ebtic.spl.analysis.sourcecode.model.Module;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

public class SimpleProject extends BaseProject {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    public static final String TYPE = "simple";

    // ----------------------------------------------------------------------
    // Static methods
    // ----------------------------------------------------------------------

    public static boolean isProject(File projectDir) {
        return true;
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private SimpleModule rootModule;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SimpleProject(String projectName, File projectDir, Properties properties) {
        super(projectName, projectDir, properties, TYPE);
        if (!properties.containsKey(PROJECT_MODULE))
            this.properties.setProperty(PROJECT_MODULE, MODULE_FILE);

        this.rootModule = new SimpleModule(projectDir, this);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public List<Module> getModules() {
        return Collections.singletonList(rootModule);
    }

    @Override
    protected Module newModule(File moduleDir) {
        return new SimpleModule(moduleDir, this);
    }

}

package ae.ebtic.spl.analysis.sourcecode.analyzer.util;

import ae.ebtic.spl.analysis.sourcecode.analyzer.configuration.ConfigurationFactory;
import ae.ebtic.spl.analysis.sourcecode.analyzer.configuration.ModuleConfiguration;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.PropertiesUtils;
import jext.util.StringUtils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * A module is a directory containing
 * - one (or more) configuration files or
 * - one (or more) source directories
 * - one (or more) resource directories
 *
 * A 'configuration file' is one of the following files:
 *
 *      build.gradle
 *      pom.xml
 *      build.pom
 *      .classpath
 *      ${directoryName}.gradle
 *      ${directoryName}.pom
 *      ${directoryName}.xml
 *
 *  (other configuration files are possible)
 *
 *  A 'source directory' is a directory with name
 *
 *      src
 *      source
 *      sources
 *      java
 *      scala
 *
 *  A 'source file' is a file with extension
 *
 *      *.java
 *      *.scala
 *
 *  A 'resource directory' is a directory with name
 *
 *      lib
 *      libs
 *      build
 *
 *  Some 'names' are 'invalid':
 *
 *      .*   (each name starting with a dot '.')
 *      *.class
 *      *.bak
 */

public class ProjectConfigurator {

    // ----------------------------------------------------------------------
    // Project Configuration
    // ----------------------------------------------------------------------

    public static class Configuration {

        public List<String> configurationFiles = new ArrayList<String>(){{
            add("build.gradle");
            add("pom.xml");
            add(".classpath");
            add("${directoryName}.gradle");
            add("${directoryName}.pom");
            add("${directoryName}.xml");
            add("${directoryName}.iml");
        }};

        public List<String> sourceDirectories = new ArrayList<String>() {{
            add("src");
            add("source");
            add("sources");
            add("java");
            add("scala");
        }};

        public List<String> resourceDirectories = new ArrayList<String>() {{
            add("build");
            add("lib");
            add("libs");
        }};

        public List<String> sourceFiles = new ArrayList<String>() {{
            add("*.java");
            add("*.scala");
        }};

        public List<String> libraryFiles = new ArrayList<String>() {{
            add("*.jar");
            add("*.aar");
        }};

        public List<String> invalidNames = new ArrayList<String>() {{
            // add(".idea");
            // add(".git");
            // add(".gitignore");
            // add(".gradle");
            // add(".spl");
            // add(".metadata");
            add("out");
            add("build");
            add("target");

            add(".*");
            add("*.class");
            add("*.bak");
        }};

    }

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    public static final String PROJECT_SPL = "project.spl";

    private static final Logger logger = Logger.getLogger(ProjectConfigurator.class);

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private Project project;

    // ----------------------------------------------------------------------
    // Default configuration
    // ----------------------------------------------------------------------

    public static ProjectConfigurator instance() {
        //return instance_;
        return new ProjectConfigurator();
    }

    // ----------------------------------------------------------------------
    // IO
    // ----------------------------------------------------------------------

    public static ProjectConfigurator load(File jsonFile, Project project) {
        if (jsonFile.isDirectory())
            jsonFile = new File(jsonFile, PROJECT_SPL);
        if (!jsonFile.exists())
            return instance().setProject(project);

        try {
            ObjectMapper mapper = new ObjectMapper()
                .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
            ProjectConfigurator configurator
                = mapper.readValue(jsonFile, ProjectConfigurator.class);
            configurator.loadDefaults();
            return configurator.setProject(project);
        }
        catch (IOException e) {
            logger.error(e, e);
            return instance().setProject(project);
        }
    }

    public ProjectConfigurator setProject(Project project) {
        this.project = project;
        return this;
    }

    public void save(File jsonFile) throws IOException {
        try (OutputStream stream = new FileOutputStream(jsonFile)) {
            save(stream);
        }
    }

    public void save(OutputStream stream) throws IOException {
        ObjectMapper mapper = new ObjectMapper()
            .enable(SerializationFeature.INDENT_OUTPUT)
            .disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        mapper.writeValue(stream, this);
    }

    private void loadDefaults() {
        if (isInvalid(configuration.configurationFiles))
            configuration.configurationFiles = instance().configuration.configurationFiles;

        if (isInvalid(configuration.sourceDirectories))
            configuration.sourceDirectories = instance().configuration.sourceDirectories;

        if (isInvalid(configuration.resourceDirectories))
            configuration.resourceDirectories = instance().configuration.resourceDirectories;

        if (isInvalid(configuration.sourceFiles))
            configuration.sourceFiles = instance().configuration.sourceFiles;

        if (isInvalid(configuration.libraryFiles))
            configuration.libraryFiles = instance().configuration.libraryFiles;

        if (isInvalid(configuration.invalidNames))
            configuration.invalidNames = instance().configuration.invalidNames;
    }

    private static boolean isInvalid(List<String> list) {
        return list == null || list.size() == 0;
    }

    public Configuration configuration = new Configuration();

    public List<String> modules = new ArrayList<>();

    public Map<String, List<String>> moduleDependencies = new HashMap<>();

    // ----------------------------------------------------------------------
    // Module dependencies
    // ----------------------------------------------------------------------

    public List<String> getModuleDependencies(Name moduleName) {
        String fullname = moduleName.getFullName();
        String name = moduleName.getName();
        for(String mname : moduleDependencies.keySet()) {
            if (mname.equals("*"))
                return moduleDependencies.get(mname);
            if (mname.equals(fullname) || mname.equals(name))
                return moduleDependencies.get(mname);
        }
        return Collections.emptyList();
    }

    // ----------------------------------------------------------------------
    // Get file/directory list
    // ----------------------------------------------------------------------

    public List<File> getModuleDirectories(File projectDir) {
        List<File> moduleDirs = new ArrayList<>();
        try {
            Files.walkFileTree(projectDir.toPath(), new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                    File directory = dir.toFile();
                    if (hasInvalidName(directory))
                        return FileVisitResult.SKIP_SUBTREE;

                    if (isSourceDirectory(directory))
                        return FileVisitResult.SKIP_SUBTREE;

                    if (isResourceDirectory(directory))
                        return FileVisitResult.SKIP_SUBTREE;

                    if (directory.equals(projectDir))
                        return FileVisitResult.CONTINUE;

                    if (isModule(directory))
                        moduleDirs.add(directory);

                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path file, IOException exc) throws IOException {
                    logger.errorf("Unable to visit file %s", file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        catch (IOException e) {
            logger.error(e);
        }
        return moduleDirs;
    }

    public List<ModuleConfiguration> getConfigurationFiles(File moduleDir, Properties properties) {
        return FileUtils.asList(moduleDir.listFiles(File::isFile))
            .stream()
            .filter(this::hasValidName)
            .filter(this::isConfigurationFile)
            .map(configurationFile -> ConfigurationFactory.newConfiguration(configurationFile, properties))
            .filter(Objects::nonNull)
            .filter(ModuleConfiguration::isValid)
            .collect(Collectors.toList());
    }

    public List<File> getSourceDirectories(File moduleDir, Set<File> modulePaths) {
        return FileUtils.asList(moduleDir.listFiles(File::isDirectory))
            .stream()
            .filter(this::hasValidName)
            .filter(this::isSourceDirectory)
            .collect(Collectors.toList());
    }

    public List<File> getResourceDirectories(File moduleDir, Set<File> modulePaths) {
        return FileUtils.asList(moduleDir.listFiles(File::isDirectory))
            .stream()
            .filter(dir -> !hasInvalidName(dir))
            .filter(dir -> !isModule(dir))
            .filter(dir -> !isSourceDirectory(dir))
            .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Predicates
    // ----------------------------------------------------------------------

    /**
     * A 'module' is a directory containing one (or more) of:
     *
     *  - configuration file
     *
     * WARN: The presence of these directories IS NOT ENOUGH!!
     *
     *  - source directory
     *  - resource directory
     *
     *  Files and directories must have a "valid" name
     *
     * @param directory root directory of the module
     * @return if the directory is a 'module'
     */
    public boolean isModule(File directory) {

        //it  must have a valid name AND to be a directory
        if (!directory.isDirectory() || hasInvalidName(directory))
            return false;

        // check if it contains some configuration file
        if(FileUtils.asList(directory.listFiles(File::isFile))
            .stream()
            .anyMatch(this::isConfigurationFile))
            return true;

        //
        // NO!
        // A 'moduleDir' is a directory containing some configuration file
        // and NOT if it contains a source or resource directory!
        //

        // check if it contains some source directory
        // if(FileUtils.asList(directory.listFiles(File::isDirectory))
        //     .stream()
        //     .anyMatch(this::isSourceDirectory))
        //     return true;

        // check if it contains some resource directory
        // if(FileUtils.asList(directory.listFiles(File::isDirectory))
        //     .stream()
        //     .anyMatch(this::isResourceDirectory))
        //     return true;

        return false;
    }

    /**
     * A 'building system configuration file' is a file with a name in the list of predefined names or
     * it has a name that matches a name template
     * @param file file to analyze
     * @return if it is a configuration file
     */
    public boolean isConfigurationFile(File file) {
        if (hasInvalidName(file) || !file.isFile())
            return false;
        if (matchPattern(configuration.configurationFiles, file)) {
            ModuleConfiguration configuratiorn = ConfigurationFactory.newConfiguration(file, PropertiesUtils.empty());
            return configuratiorn != null && configuratiorn.isValid();
        }
        return false;
    }

    /**
     * A library is a ".jar" (or '.aar' for Android) or a ".zip" file
     * @param file file to analyze
     * @return if it is a library file
     */
    public boolean isLibraryFile(File file) {
        if (hasInvalidName(file) || !file.isFile())
            return false;
        if (matchPattern(configuration.libraryFiles, file))
            return true;
        return false;
    }

    /**
     * A source file is a file with ".java",... extension
     * @param file file to analyze
     * @return if it is a source file
     */
    public boolean isSourceFile(File file) {
        if (hasInvalidName(file) || !file.isFile())
            return false;
        if (matchPattern(configuration.sourceFiles, file))
            return true;
        return false;
    }

    /**
     * A 'resource file' is each file that is not
     * - a configuration file
     * - a source file
     * - a library file
     * @param file file to analyze
     * @return if it is a resource file
     */
    public boolean isResourceFile(File file) {
        if (hasInvalidName(file) || !file.isFile())
            return false;
        if (isSourceFile(file))
            return false;
        if (isConfigurationFile(file))
            return false;
        if (isLibraryFile(file))
            return false;
        return true;
    }

    // ----------------------------------------------------------------------

    /**
     * A 'source directory' is a directory containing source files.
     * For now we check only the directory name
     * @param directory directory to analyze
     * @return if it is a source directory
     */
    public boolean isSourceDirectory(File directory) {
        if (hasInvalidName(directory) || !directory.isDirectory())
            return false;
        if (matchPattern(configuration.sourceDirectories, directory))
            return true;
        return false;
    }

    /**
     * A 'resource directory' is a directory containing resource files.
     * For now we check only the directory name
     * @param directory directory to analyze
     * @return if it is a resource directory
     */
    public boolean isResourceDirectory(File directory) {
        if (hasInvalidName(directory) || !directory.isDirectory())
            return false;
        if (matchPattern(configuration.resourceDirectories, directory))
            return true;
        return false;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private boolean hasValidName(File file) {
        return !hasInvalidName(file);
    }

    private boolean hasInvalidName(File file) {
        return matchPattern(configuration.invalidNames, file);
    }

    private static boolean matchPattern(List<String> patterns, File file) {
        Map<String, Object> params = new HashMap<String, Object>() {{
            put("directoryName", file.getParentFile().getName());
        }};
        String name = file.getName();
        for(String pattern : patterns) {
            if (pattern.endsWith("*")) {
                String prefix = pattern.substring(pattern.length()-1);
                if (name.startsWith(prefix))
                    return true;
            }
            if (pattern.startsWith("*")) {
                String suffix = pattern.substring(1);
                if (name.endsWith(suffix))
                    return true;
            }
            if (pattern.contains("${directoryName}"))
                pattern = StringUtils.format(pattern, params);
            if (name.equals(pattern))
                return true;
        }
        return false;
    }

}

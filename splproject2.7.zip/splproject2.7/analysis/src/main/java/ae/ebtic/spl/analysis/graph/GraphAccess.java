package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.dependencies.CommentNode;
import ae.ebtic.spl.analysis.dependencies.FieldNode;
import ae.ebtic.spl.analysis.dependencies.LibraryNode;
import ae.ebtic.spl.analysis.dependencies.MethodNode;
import ae.ebtic.spl.analysis.dependencies.ModuleNode;
import ae.ebtic.spl.analysis.dependencies.ParameterNode;
import ae.ebtic.spl.analysis.dependencies.ProjectNode;
import ae.ebtic.spl.analysis.dependencies.ResourceNode;
import ae.ebtic.spl.analysis.dependencies.SourceNode;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.features.FeatureNode;
import jext.graph.GraphSession;
import jext.util.Parameters;

import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

public class GraphAccess extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private Map<String, Function<Map<String, Object>, GraphNode>> makers = new HashMap<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public GraphAccess(ProjectGraphAccess pga) {
        super(pga, PROJECT);

        makers.put(COMPONENT, nv -> ComponentNode.of(pga.getComponentGraph(), nv));
        makers.put(FEATURE, nv -> FeatureNode.of(pga.getFeatureGraph(), nv));
        makers.put(COMMENT, nv -> CommentNode.of(pga.getDependencyGraph(), nv));
        makers.put(FIELD, nv -> FieldNode.of(pga.getDependencyGraph(), nv));
        makers.put(LIBRARY, nv -> LibraryNode.of(pga.getDependencyGraph(), nv));
        makers.put(METHOD, nv -> MethodNode.of(pga.getDependencyGraph(), nv));
        makers.put(MODULE, nv -> ModuleNode.of(pga.getDependencyGraph(), nv));
        makers.put(PARAMETER, nv -> ParameterNode.of(pga.getDependencyGraph(), nv));
        makers.put(PROJECT, nv -> ProjectNode.of(pga.getDependencyGraph(), nv));
        makers.put(RESOURCE, nv -> ResourceNode.of(pga.getDependencyGraph(), nv));
        makers.put(SOURCE, nv -> SourceNode.of(pga.getDependencyGraph(), nv));
        makers.put(TYPE, nv -> TypeNode.of(pga.getDependencyGraph(), nv));
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public GraphNode getNode(String nodeId) {
        Map<String, Object> nv;
        try(GraphSession session = graphdb.connect()) {
            nv = session.getNodeValues(nodeId);
        }
        return toNode(nv);
    }

    private GraphNode toNode(Map<String, Object> nv) {
        if (nv == null)
            return null;

        String type = nv.get(GRAPH_NODE_TYPE).toString();
        if (!makers.containsKey(type)) {
            logger.errorf("Unsupported graph node type %s", type);
            return null;
        }

        return makers.get(type).apply(nv);
    }

    public List<GraphNode> getNodes(List<String> nodeIds) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.getNodesValues(nodeIds);
        }

        return nvlist.stream()
            .map(this::toNode)
            .filter(Objects::nonNull)
            .collect(Collectors.toList());
    }

    public List<GraphEdge> getEdges(String edgeType, Collection<String> nodeIds) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryEdges(edgeType, nodeIds, Parameters.empty()).result().toList();
            // fromid, toid
        }

        return nvlist.stream().map(nv -> {
            GraphEdge ge = new GraphEdge();
            ge.nv = (Map<String, Object>) nv.get("edge");
            ge.edgeType = ge.nv.get(GRAPH_EDGE_TYPE).toString();
            if (ge.nv.containsKey("type"))
                ge.subType = ge.nv.get("type").toString();
            else if (ge.nv.containsKey("uses"))
                ge.subType = ge.nv.get("uses").toString();
            else
                ge.subType = ge.edgeType;
            ge.sourceId = nv.get("idfrom").toString();
            ge.targetId = nv.get("idto").toString();
            ge.index = (List<Long>) ge.nv.getOrDefault("index", Collections.emptyList());

            return ge;
        })
        .collect(Collectors.toList());
    }
}

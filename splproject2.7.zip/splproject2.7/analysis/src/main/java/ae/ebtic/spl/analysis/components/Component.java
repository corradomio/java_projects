package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.sourcecode.model.IdNamed;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.Direction;

import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface Component extends IdNamed {

    /**
     * Reference type id
     * It is the type used to create the component
     */
    String getTypeId();

    // -- Properties

    /**
     * Level of the component model.
     * The level 0 is created from the dependency model
     */

    long getDepth();

    /**
     * Number of members inside the component.
     * If the depth is 0, it is the number of contained types
     * otherwise it is the number of member components at lebel
     * depth-1
     */
    long getCount();

    /**
     * Number of types inside the component.
     * If the component is at level greater than 0, it is the union of the
     * types at level depth-1
     */
    long getTypesCount();

    /**
     * List of types member of this component or union
     * of the component's member types
     */
    List<Type> getTypes();

    /**
     * Member components.
     * At level 0 it is the empty set
     */
    List<Component> getMembers();

    /** List of features containing this component */
    List<Feature> getFeatures();

    /**
     * Dependencies between components (forward & backward)
     */
    List<Component> getUsesComponents(Direction direction);

    // -- EntryPoint

    /** A component is 'entryPoint' if it contains one or more 'entryPoint' types */
    boolean isEntryPoint();
    long[] getCountEntryPoints();

    // -- Neo4j

    /** Neo4j node values */
    Map<String, Object> getValues();

}

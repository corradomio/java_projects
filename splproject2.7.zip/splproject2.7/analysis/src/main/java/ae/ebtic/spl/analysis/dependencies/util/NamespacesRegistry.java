package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;

public class NamespacesRegistry extends NameRegistry {

    public String getNamespaceIdOrLock(Name namespace) {
        return super.getIdOrLock(namespace);
    }

    public void registerNamespaceAndRelease(String namespaceId, Name namespace) {
        super.registerAndRelease(namespaceId, namespace);
    }

    public String getNamespaceId(Name namespace) {
        return super.getId(namespace);
    }

    public void registerNamespace(String namespaceId, Name namespace) {
        super.register(namespaceId, namespace);
    }
}

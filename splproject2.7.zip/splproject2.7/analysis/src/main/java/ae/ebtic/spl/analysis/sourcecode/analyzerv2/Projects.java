package ae.ebtic.spl.analysis.sourcecode.analyzerv2;

public class Projects extends ProjectFactory {

}

package ae.ebtic.spl.analysis.util;

import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import com.fasterxml.jackson.annotation.JsonIgnore;

import java.util.Map;

/*
    There are a limited number of 'Name' objects:

    'PathName':     the name contains '/'
    'ObjectName':   the name contains '.'
    'MavenName':    the name contains ':'
 */

public class NodeName implements GraphConstants, Name {

    private enum NameType {
        PATH_NAME,
        OBJECT_NAME,
        MAVEN_NAME
    }

    // ----------------------------------------------------------------------
    // Fields
    // ----------------------------------------------------------------------

    private Map<String, Object> nv;
    private NameType nameType;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public NodeName(Map<String, Object> nv) {
        this.nv = nv;
        String fullname = nv.get(FULLNAME).toString();
        if (fullname.contains("/"))
            nameType = NameType.PATH_NAME;
        else if (fullname.contains("."))
            nameType = NameType.OBJECT_NAME;
        else if (fullname.contains(":"))
            nameType = NameType.MAVEN_NAME;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @JsonIgnore
    @Override
    public boolean isRoot() {
        return getName().length() == 0;
    }

    @Override
    public String getName() {
        return (String) nv.get(NAME);
    }

    @JsonIgnore
    @Override
    public Name getParent() {
        throw new UnsupportedOperationException();
    }

    @JsonIgnore
    public String getParentName() {
        if (isRoot())
            return null;
        else
            return (String) nv.get(NAMESPACE);
    }

    @Override
    public String getFullName() {
        return (String) nv.get(FULLNAME);
    }

    @Override
    public String[] getParts() {
        String fullName = getFullName();
        if (fullName.contains("/"))
            return fullName.split("/");
        else
            return fullName.split("\\.");
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    // @Override
    // public Name compose(String name) {
    //     throw new UnsupportedOperationException();
    // }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private String getId() {
        return (String) nv.get(GRAPH_NODE_ID);
    }

    private String getType() {
        return (String) nv.get(GRAPH_NODE_TYPE);
    }

    // ----------------------------------------------------------------------
    // Overrides
    // ----------------------------------------------------------------------

    @Override
    public int compareTo(Name that) {
        return getFullName().compareTo(that.getFullName());
    }

    @Override
    public boolean equals(Object obj) {
        Name that = (Name) obj;
        return getFullName().equals(that.getFullName());
    }

    @Override
    public int hashCode() {
        return getFullName().hashCode();
    }

    @Override
    public String toString() {
        return String.format("%s[%s: %s]", getType(), getId(), getFullName());
    }

}

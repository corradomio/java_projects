package ae.ebtic.spl.analysis.sourcecode.util;

import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.TypeName;
import jext.lang.JavaUtils;

public class MethodObjectName extends ObjectName implements MethodName {

    private int nParams;
    private String signature;

    public MethodObjectName(String methodName, int nParams, String signature) {
        super(methodName);

        this.nParams = nParams;
        this.signature = signature;
    }

    public MethodObjectName(String typeName, String methodName, int nParams, String signature) {
        super(typeName, methodName);

        this.nParams = nParams;
        this.signature = signature;
    }

    // public MethodObjectName(Name typeName, String methodName, int nParams, String signature) {
    //     super(typeName, methodName);
    //
    //     this.nParams = nParams;
    //     this.signature = signature;
    // }

    public TypeName getParent() {
        return new TypeObjectName(JavaUtils.namespaceOf(name));
    }

    @Override
    public String getSignature() {
        return signature;
    }

    @Override
    public int getNumParameters() {
        return nParams;
    }

    // ----------------------------------------------------------------------

    @Override
    public String toString() {
        return getSignature();
    }

}

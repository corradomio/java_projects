package ae.ebtic.spl.analysis.sourcecode.analyzer.configuration;

import java.io.File;

public class NullConfigurationFile extends CommonConfiguration {

    private static NullConfigurationFile instance = new NullConfigurationFile();

    public NullConfigurationFile() {
        super(new File("."));
    }

    public static ModuleConfiguration getInstance() { return instance; }

}

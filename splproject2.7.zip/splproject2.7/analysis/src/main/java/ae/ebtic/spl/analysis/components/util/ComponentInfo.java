package ae.ebtic.spl.analysis.components.util;

import java.util.Set;

public class ComponentInfo {
    public String componentId;
    //public String memberId;
    public Set<String> closureIds;
    public String name;

    // public ComponentInfo(String componentId, String name, String memberId, Set<String> closureIds) {
    //     this.componentId = componentId;
    //     this.memberId = memberId;
    //     this.closureIds = closureIds;
    //     this.name = name;
    // }
    public ComponentInfo(String componentId, String name, Set<String> closureIds) {
        this.componentId = componentId;
        this.closureIds = closureIds;
        this.name = name;
    }
}

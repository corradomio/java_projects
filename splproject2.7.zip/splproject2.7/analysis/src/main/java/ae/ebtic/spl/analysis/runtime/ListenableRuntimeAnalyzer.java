package ae.ebtic.spl.analysis.runtime;

import jext.jfr.ThreadDumps;
import org.openjdk.jmc.flightrecorder.CouldNotLoadRecordingException;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ListenableRuntimeAnalyzer extends RuntimeAnalyzer {

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    protected Listeners listeners = new Listeners();

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ListenableRuntimeAnalyzer newAnalyzer(AnalyzerConfig config) throws Exception {
        ListenableRuntimeAnalyzer analyzer = new ListenableRuntimeAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ListenableRuntimeAnalyzer(AnalyzerConfig config) {
        super(config);
    }

    // ----------------------------------------------------------------------
    // Overrides methods
    // ----------------------------------------------------------------------

    @Override
    public void analyze() {
        if (aborted)
            return;

        listeners.fireStartAnalysis();
        super.analyze();
    }

    @Override
    protected ThreadDumps getThreadDumps(List<File> jfrFiles) throws IOException, CouldNotLoadRecordingException {
        if (aborted)
            return new ThreadDumps();

        listeners.fireThreadDumps();
        return super.getThreadDumps(jfrFiles);
    }

    @Override
    protected Set<String> getDefinedTypes() {
        if (aborted)
            return Collections.emptySet();

        listeners.fireDefinedTypes();
        return super.getDefinedTypes();
    }

    @Override
    protected Map<String, Set<String>> getEntryPointInfos(ThreadDumps tdumps, Set<String> definedTypes) {
        if (aborted)
            return Collections.emptyMap();

        listeners.fireEntryPoints();
        return super.getEntryPointInfos(tdumps, definedTypes);
    }

    @Override
    protected void setEntryPointTypes(Map<String, Set<String>> entryPoints) {
        if (aborted)
            return;

        super.setEntryPointTypes(entryPoints);
    }

    @Override
    protected void propagateEntryPoints() {
        if (aborted)
            return;

        listeners.firePropagateEntryPoints();
        super.propagateEntryPoints();
    }

    @Override
    protected void done(String status, String reason) {
        if (aborted)
            return;

        listeners.fireDone();
        super.done(status, reason);
    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    @Override
    public RuntimeAnalysis addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }

    private static class Listeners {
        protected List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireStartAnalysis() {
            listeners.forEach(l -> l.onStartAnalysis());
        }

        void fireCheckFiles() {
            listeners.forEach(l -> l.onCheckFiles());
        }

        void fireThreadDumps() {
            listeners.forEach(l -> l.onThreadDumps());
        }

        void fireDefinedTypes() {
            listeners.forEach(l -> l.onDefinedTypes());
        }

        void fireEntryPoints() {
            listeners.forEach(l -> l.onEntryPoints());
        }

        void firePropagateEntryPoints() {
            listeners.forEach(l -> l.onPropagateEntryPoints());
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone());
        }

    }
}

package ae.ebtic.spl.analysis.dependencyv2.util;

import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryType;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import jext.util.StringUtils;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class UnresolvedSymbolsLibrary extends NamedObject implements Library {

    public static final String UNRESOLVED = "$Unresolved";

    private Module module;
    private Map<Name, RefType> symbolMap = new HashMap<>();

    public UnresolvedSymbolsLibrary(Module module) {
        super(new ObjectName(UNRESOLVED));
        this.module = module;
    }

    @Override
    public String getId() {
        return UNRESOLVED;
    }

    @Override
    public Project getProject() {
        return module.getProject();
    }

    @Override
    public LibraryType getLibraryType() {
        return LibraryType.INVALID;
    }

    @Override
    public boolean isLocal() {
        return false;
    }

    @Override
    public String getPath() {
        return "";
    }

    @Override
    public List<File> getFiles() {
        return Collections.emptyList();
    }

    @Override
    public String getDigest() {
        return "0";
    }

    @Override
    public String getModuleId() {
        if (module != null)
            return module.getId();
        else
            return null;
    }

    @Override
    public Module getModule() {
        return module;
    }

    @Override
    public List<Library> getDependencies() {
        return Collections.emptyList();
    }

    @Override
    public boolean contains(Name typeName) {
        return contains(typeName.getFullName());
    }

    @Override
    public Set<RefType> getTypes() {
        return new HashSet<>(symbolMap.values());
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    @Override
    public String getVersion() { return StringUtils.empty(); }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    public synchronized boolean contains(String symbol) {
        return symbolMap.containsKey(new ObjectName(symbol));
    }

    public synchronized boolean containsOrAdd(Name typeName) {
        if (symbolMap.containsKey(typeName))
            return true;

        symbolMap.put(typeName, new ReferencedType(typeName, this));
        return false;
    }

}

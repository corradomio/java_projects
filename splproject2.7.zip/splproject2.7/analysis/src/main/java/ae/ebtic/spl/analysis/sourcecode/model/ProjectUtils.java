package ae.ebtic.spl.analysis.sourcecode.model;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;

public class ProjectUtils {

    public static List<Type> getTypes(Project project) {
        List<Type> definedTypes = new ArrayList<>();
        project.getModules().forEach(module -> {
            module.getTypes(false).forEach(refType -> {
                definedTypes.add(refType.asType());
            });
        });

        return definedTypes;
    }

    /**
     * Collect all module's defined types
     *
     * @param project
     * @param includeLibraries if to include the types defined in external libraries
     * @return
     */
    public static Set<RefType> getDefinedTypes(Project project, boolean includeLibraries) {
        Set<RefType> definedTypes = new HashSet<>();

        project.getModules().forEach(module -> {
            definedTypes.addAll(module.getTypes(includeLibraries));
        });

        return definedTypes;
    }

    /**
     * Collect all module's used types
     *
     * @param project
     * @return
     */
    public static Set<RefType> getUsedTypes(Project project) {
        Set<RefType> usedTypes = new HashSet<>();

        project.getModules().forEach(module -> {
            usedTypes.addAll(module.getUsedTypes());
        });

        return usedTypes;
    }

    /**
     * Scann all modules for a defined type with the specified name
     * @param project
     * @param typeName
     * @return
     */
    public static Optional<RefType> findType(Project project, String typeName) {
        for (Module module : project.getModules()) {
            for (RefType refType : module.getTypes(false))
                if (refType.getName().getFullName().equals(typeName) ||
                    refType.getName().getName().equals(typeName) ||
                    refType.getId().equals(typeName))
                    return Optional.of(refType);
        }
        return Optional.empty();
    }


    public static Set<Component> getComponents(Project project) {
        Set<Component> components = new HashSet<>();

        project.getModules().forEach(module -> {
            module.getTypes(false).forEach(refType -> {
                components.addAll(refType.asType().getComponents());
            });
        });
        return components;
    }


    public static Set<Feature> getFeatures(Project project) {
        Set<Feature> features = new HashSet<>();

        project.getModules().forEach(module -> {
            module.getTypes(false).forEach(refType -> {
                features.addAll(refType.asType().getFeatures());
            });
        });
        return features;
    }

    // /**
    //  * Project complexity (in range [0,1])
    //  * @param project
    //  * @param threshold
    //  * @return
    //  */
    // public static double getComplexity(Project project, double threshold) {
    //     List<Type> types = getTypes(project);
    //     int nTypes = types.size();
    //     double aboveThreshold = types.stream()
    //         .map(Type::getScore)
    //         .filter(Objects::nonNull)
    //         .filter(score -> score.size() >= 2)
    //         .filter(score -> score.get(1) > threshold)
    //         .count();
    //
    //     return nTypes > 0 ? aboveThreshold/nTypes : 0.;
    // }
}

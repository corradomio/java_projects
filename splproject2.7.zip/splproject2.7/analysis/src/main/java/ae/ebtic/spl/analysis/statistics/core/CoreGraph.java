package ae.ebtic.spl.analysis.statistics.core;

import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import jext.graph.GraphSession;
import jext.util.Parameters;

import java.util.List;
import java.util.Map;

public class CoreGraph extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public CoreGraph(ProjectGraphAccess pga) {
        super(pga, CORE);
    }

    // private CoreGraph(GraphConfig config){
    //     super(config, CORE);
    // }

    // ----------------------------------------------------------------------
    // Utilities
    // ----------------------------------------------------------------------

    public List<Map<String,Object>> getTypeGraph(){

        List<Map<String, Object>> nodes = null;

        try (GraphSession session = graphdb.connect()) {

//            vlist = session.queryNodes(TYPE, Parameters.params(
//                    PROJECT_ID, projectId
//            )).allValues().toList();
//
//            elist = session.queryEdges(USES,
//                    TYPE, Parameters.params(PROJECT_ID, projectId),
//                    TYPE, Parameters.params(PROJECT_ID, projectId),
//                    Parameters.empty()).result().toList();
            nodes = session.queryUsing("getNodeNeighborsType",Parameters.params(
                    PROJECT_ID, projectId
            )).result().toList();
        }

        return nodes;
    }

    public List<Map<String,Object>> getTypeFeaturesCount(){

        List<Map<String, Object>> nodes = null;

        try (GraphSession session = graphdb.connect()) {
            nodes = session.queryUsing("getNodeFeatureCount",Parameters.params(
                    PROJECT_ID, projectId
            )).result().toList();
        }

        return nodes;
    }

    public void writeScores(List<Map<String,Object>> nodes){
        try (GraphSession session = graphdb.connect()) {
            session.queryUsing("setCoreScores",Parameters.params(
                    NODES, nodes
            )).result();
        }
    }

    public List<Map<String, Object>> getCoreScores(double alpha){

        List<Map<String, Object>> nodes = null;

        try (GraphSession session = graphdb.connect()) {
            nodes = session.queryUsing("getCoreScoresType",Parameters.params(
                    PROJECT_ID, projectId,
                    ALPHA,alpha
            )).result().toList();
        }

        return nodes;
    }

    // public void delete() {
    //     try (GraphSession session = graphdb.connect()) {
    //         session.queryUsing("DeleteCoreScores",Parameters.params(
    //                 PROJECT_ID, projectId
    //         )).result();
    //     }
    //     super.delete();
    // }

    @Override
    protected void deleteModelElements(String projectId) {
        try (GraphSession session = graphdb.connect()) {
            session.queryUsing("DeleteCoreScores",Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }


}

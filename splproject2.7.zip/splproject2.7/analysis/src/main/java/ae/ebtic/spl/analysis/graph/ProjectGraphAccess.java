package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.clustering.ClusteringGraph;
import ae.ebtic.spl.analysis.components.ComponentGraph;
import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.features.FeatureGraph;
import ae.ebtic.spl.analysis.runtime.RuntimeGraph;
import ae.ebtic.spl.analysis.statistics.core.CoreGraph;

public class ProjectGraphAccess {

    // ----------------------------------------------------------------------
    // Static methods
    // ----------------------------------------------------------------------

    public static ProjectGraphAccess newProjectGraphAccess(GraphConfig config) {
        ProjectGraphAccess pga = new ProjectGraphAccess(config);
        return pga;
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private GraphConfig config;

    private GraphAccess ga;
    private DependencyGraph dg;
    private ComponentGraph cg;
    private FeatureGraph fg;

    private CoreGraph cog;
    private ClusteringGraph cug;
    private RuntimeGraph rtg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectGraphAccess(GraphConfig config) {
        this.config = config;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public GraphConfig getConfig() {
        return this.config;
    }

    public GraphAccess getGraphAccess() {
        synchronized (config) {
            if (ga == null) {
                ga = new GraphAccess(this);
                ga.initialize();
            }
            return ga;
        }
    }

    public DependencyGraph getDependencyGraph() {
        synchronized (config) {
            if (dg == null) {
                dg = new DependencyGraph(this);
                dg.initialize();
            }
            return dg;
        }
    }

    public ComponentGraph getComponentGraph() {
        synchronized (config) {
            if (cg == null) {
                cg = new ComponentGraph(this);
                cg.initialize();
            }
            return cg;
        }
    }

    public FeatureGraph getFeatureGraph() {
        synchronized (config) {
            if (fg == null) {
                fg = new FeatureGraph(this);
                fg.initialize();
            }
            return fg;
        }
    }

    public CoreGraph getCoreGraph() {
        synchronized (config) {
            if (cog == null) {
                cog = new CoreGraph(this);
                cog.initialize();
            }
            return cog;
        }
    }

    public ClusteringGraph getClusteringGraph() {
        synchronized (config) {
            if (cug == null) {
                cug = new ClusteringGraph(this);
                cug.initialize();
            }
            return cug;
        }
    }

    public RuntimeGraph getRuntimeGraph() {
        synchronized (config) {
            if (rtg == null) {
                rtg = new RuntimeGraph(this);
                rtg.initialize();
            }
            return rtg;
        }
    }
}

package ae.ebtic.spl.analysis.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import jext.graph.GraphDatabase;
import jext.util.Parameters;

import java.util.Properties;

public class AnalysisConfig {

    // ----------------------------------------------------------------------
    // Protected fields
    // ----------------------------------------------------------------------

    protected GraphDatabase graphdb;

    protected Parameters parameters = new Parameters();

    protected Name projectName;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public AnalysisConfig() {

    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- projectName

    public Name getProjectName() { return projectName; }

    // -- properties

    public Parameters getParameters() { return parameters; }

    // -- graphdatabase

    public GraphDatabase getGraphDatabase() { return graphdb; }

}

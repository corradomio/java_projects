package ae.ebtic.spl.analysis.sourcecode.model;

public interface TypeName extends Name {

    @Override
    TypeName getParent();
}

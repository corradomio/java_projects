package ae.ebtic.spl.analysis.sourcecode.model;

public interface IdNamed extends Named {

    String getId();

}

package ae.ebtic.spl.analysis.clustering;

public interface AnalyzerListener {
    void onClusteringDesignPatterns(int types);

    void onClusteringTokens(int clusters);

    void onDone();
}

package ae.ebtic.spl.analysis.components;

public interface AnalyzerListener {

    void onCreateComponents(int totalComponents);

    void onAggregateComponents(int totalComponents);

    void onComponentsDependencies(int totalComponents);

    void onCreateDependencies(int totalComponents);

    void onComponentsProcessed(int componentsProcessed, int totalComponents);

    void onDone();
}

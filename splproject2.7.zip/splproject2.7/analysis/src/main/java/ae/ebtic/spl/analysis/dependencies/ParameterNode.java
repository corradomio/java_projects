package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Parameter;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ParameterNode extends GraphNode implements Parameter {

    public static List<Parameter> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> ParameterNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static ParameterNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new ParameterNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ParameterNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getOwnerMethodId() {
        return nv.get(OWNER_METHOD_ID).toString();
    }

    @Override
    public String getOwnerTypeId() {
        return nv.get(OWNER_TYPE_ID).toString();
    }

    @Override
    public String getTypeId() {
        return nv.get(TYPE_ID).toString();
    }

    @Override
    public Method getOwnerMethod() {
        return dg.getMethod(getOwnerMethodId());
    }

    @Override
    public RefType getType() {
        return dg.getType(getTypeId());
    }
}

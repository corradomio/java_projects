package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.components.util.ComponentInfo;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.features.FeatureGraph;
import ae.ebtic.spl.analysis.features.FeatureNode;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.*;
import jext.util.*;
import jext.util.HashMap;
import jext.util.HashSet;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class ComponentGraph extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ComponentGraph(ProjectGraphAccess pga) {
        super(pga, COMPONENT);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public boolean isDAG(int depth) {
        try(GraphSession session = graphdb.connect()) {
            return session.isDAG(COMPONENT, Parameters.params(
                PROJECT_ID, projectId,
                DEPTH, depth),
                USES, Parameters.empty());
        }
    }

    public boolean isEntryPoint(String componentId) {
        try(GraphSession session = graphdb.connect()) {
            return session.queryAdjacentNodes(componentId, CONTAINS,
                Direction.Output, true,
                TYPE, Parameters.params(ENTRY_POINT, true),
                Parameters.empty()).count() > 0;
        }
    }

    // ----------------------------------------------------------------------
    // Operations (create session)
    // ----------------------------------------------------------------------

    public Component getComponent(String componentId) {
        return pga.getGraphAccess().getNode(componentId).asComponent();
    }

    public Component findComponentByName(String componentName, int depth){
        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            nv = session.queryNodes(COMPONENT, Parameters.params(
                    PROJECT_ID, projectId,
                    FULLNAME, componentName,
                    DEPTH, depth
            )).values();
        }
        return ComponentNode.of(this, nv);
    }


    public long getComponentsCount() {
        return getComponentsCount(-2, null);
    }

    /**
     *
     * @param depth
     *          -2: ALL components
     *          -1: DAG roots
     *          0+: specific level
     * @param ndegree
     * @return
     */
    public long getComponentsCount(int depth, NodeDegree ndegree) {
        if (ndegree == null)
            ndegree = new NodeDegree();

        // ALL components
        if(depth == -2){
            try (GraphSession session = graphdb.connect()) {
                return session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId
                    )).count();
            }
        }
        // DAG roots
        else if (depth == -1) {
            try (GraphSession session = graphdb.connect()) {
                return session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        ROLE, CROLE_DAGROOT
                    )).count();
            }
        }
        // SPECIFIC level
        else if (ndegree.isEmpty()) {
            try (GraphSession session = graphdb.connect()) {
                return session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        DEPTH, depth
                    )).count();
            }

        }
        else {
            try (GraphSession session = graphdb.connect()) {
                return session.queryNodesWithDegree(COMPONENT,
                    USES, ndegree,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        DEPTH, depth
                    ),
                    Parameters.empty()).count();
            }
        }
    }

    /**
     * Retrieve the components at the specified level (depth) and node degree
     * @param depth  -2: all components
     *               -1: DAGROOT
     *               0, ...: specified level
     *
     * @param ndegree
     * @return
     */
    public List<Component> getComponents(int depth, NodeDegree ndegree) {

        List<Map<String, Object>> nvlist;
        if (ndegree == null)
            ndegree = new NodeDegree();

        if(depth == -2){
            try (GraphSession session = graphdb.connect()) {
                nvlist = session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId
                    ))
                    .allValues().toList();
            }
        }
        else if (depth == -1) {
            try (GraphSession session = graphdb.connect()) {
                nvlist = session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        ROLE, CROLE_DAGROOT
                    ))
                    .allValues().toList();
            }
        }
        else if (ndegree.isEmpty()) {
            try (GraphSession session = graphdb.connect()) {
                nvlist = session.queryNodes(COMPONENT,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        DEPTH, depth
                    ))
                    .allValues().toList();
            }

        }
        else {
            try (GraphSession session = graphdb.connect()) {
                nvlist = session.queryNodesWithDegree(COMPONENT,
                    USES, ndegree,
                    Parameters.params(
                        PROJECT_ID, projectId,
                        DEPTH, depth
                    ),
                    Parameters.empty())
                    .allValues().toList();
            }
        }

        return ComponentNode.of(this, nvlist);
    }

    public List<Component> getUsesComponents(String componentId, Direction direction) {
        // String componentId = c.getId();
        List<Map<String, Object>> nvlist;

        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(componentId,
                USES, direction, false,
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId
                ),
                Parameters.empty())
                .allValues().toList();
        }

        return ComponentNode.of(this, nvlist);
    }

    public List<Component> getMembers(String componentId) {
        // String componentId = c.getId();
        List<Map<String, Object>> nvlist;

        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(componentId,
                CONTAINS, Direction.Output, false,
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId
                ),
                Parameters.empty())
                .allValues().toList();
        }

        return ComponentNode.of(this, nvlist);
    }

    // ----------------------------------------------------------------------
    // Types
    // ----------------------------------------------------------------------

    public List<Type> getComponentTypes(String componentId) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(
                componentId, CONTAINS, Direction.Output, true,
                TYPE, Parameters.params(PROJECT_ID, projectId),
                Parameters.empty())
                .distinct().allValues().toList();
        }

        DependencyGraph dg = pga.getDependencyGraph();

        return TypeNode.of(dg, nvlist);
    }

    public List<Type> getComponentTypes(String componentId, long depth) {
        List<Map<String, Object>> nvlist;
        // String componentId = c.getId();
        // long depth = c.getDepth();

        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                DEPTH, depth,
                COMPONENT_ID, Long.parseLong(componentId));

            if (depth == 0)
                nvlist = session.queryUsing("findComponentTypesByID", params)
                    .distinct().allValues().toList();
            else
                nvlist = session.queryUsing("findRecursiveComponentTypesByID", params)
                    .distinct().allValues().toList();
        }

        if (nvlist == null || nvlist.size() == 0)
            return Collections.emptyList();

        DependencyGraph dg = pga.getDependencyGraph();

        return TypeNode.of(dg, nvlist);
    }

    // ----------------------------------------------------------------------
    // Features
    // ----------------------------------------------------------------------

    public List<Feature> getComponentFeatures(String componentId) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(
                componentId, CONTAINS, Direction.Input, true,
                FEATURE, Parameters.params(PROJECT_ID, projectId),
                Parameters.empty())
                .distinct().allValues().toList();
        }

        FeatureGraph fg = pga.getFeatureGraph();

        return FeatureNode.of(fg, nvlist);
    }

    public List<Feature> getFeatures(String componentId) {
        // String componentId = c.getId();
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(componentId,
                CONTAINS, Direction.Input, false,
                FEATURE, Parameters.params(
                    PROJECT_ID, projectId
                ),
                Parameters.empty())
                .allValues().toList();
        }

        FeatureGraph fg = this.getProjectGraphAccess().getFeatureGraph();

        return FeatureNode.of(fg, nvlist);
    }

    // ----------------------------------------------------------------------
    // Operations (create session)
    // ----------------------------------------------------------------------

    @Deprecated
    public List<Map<String, Object>> listMembersGraph(String componentId) {

        return getMembers(componentId)
                .stream()
                .map(r -> {
                    return new jext.util.HashMap<String, Object>()
                            .put_(ID, r.getId())
                            .put_(LABEL, r.getName().getName())
                            .put_(ROLE, "COMPONENT"+r.getDepth())
                            .put_("expanded",false);
                })
                .collect(Collectors.toList());
    }

    @Deprecated
    public List<Map<String, Object>> listTypes(String componentId) {

        return getComponent(componentId).getTypes()
                .stream()
                .map(r -> {
                    return new jext.util.HashMap<String, Object>()
                            .put_(ID, r.getId())
                            .put_(LABEL, r.getName().getName())
                            .put_(NAME,r.getName().getName())
                            .put_(FULLNAME,r.getName().getFullName())
                            .put_("kCore",((List<Double>) ((TypeNode)r).getValues().get("score")).get(1))
                            .put_(ROLE, "Type")
                            .put_("expanded", false);
                })
                .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Operations (use current session)
    // ----------------------------------------------------------------------

    public List<String> findDAGRootComponents(int depth) {
        try(GraphSession session = graphdb.connect()) {
            return session.queryNodesWithDegree(COMPONENT, USES,
                new NodeDegree(0, 0, 0, NodeDegree.MAX_DEGREE),
                Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth
                ),
                Parameters.empty())
                .ids().toList();
        }
    }

    /**
     * Find all nodes in the 'dependency graph' of type 'type'
     * (interface, classes, enumerations)
     * Note: ALL types NOT only-top level types
     * @return
     */
    public List<Map<String, Object>> findTypeValues() {
        try(GraphSession session = graphdb.connect()) {
            return session.queryNodes(TYPE, Parameters.params(
                PROJECT_ID, projectId,
                TYPE, TYPE
            )).allValues().toList();

            // return session.queryUsing("findValidTypes", Parameters.params(
            //     PROJECT_ID, projectId
            // )).allValues().toList();
        }
    }

    public List<Map<String, Object>> findTypeRelations() {
        try(GraphSession session = graphdb.connect()) {
            return session.queryEdges(USES,
                TYPE, Parameters.params(PROJECT_ID, projectId, TYPE, TYPE),
                TYPE, Parameters.params(PROJECT_ID, projectId, TYPE, TYPE),
                Parameters.empty()).result().toList();
        }
    }

    // /**
    //  * Retrieve the list of types that have no
    //  * edges in input and no edges in output, OR the output edges are only
    //  * towards types in libraries (with 'role' = 'UNKNOWN')
    //  */
    // public Set<String> findStandAloneTypes() {
    //     Parameters params = Parameters.params(PROJECT_ID, projectId);
    //
    //     try (GraphSession session = graphdb.connect()) {
    //         Set<String> selectedTypes = session.queryUsing("findValidTypes", params).distinct().ids().toSet();
    //         Set<String> withInpEdges = session.queryUsing("findValidTypesWithInEdges", params).distinct().ids().toSet();
    //         Set<String> withOutEdges = session.queryUsing("findTypesWithValidOutEdges", params).distinct().ids().toSet();
    //
    //         selectedTypes.removeAll(withInpEdges);
    //         selectedTypes.removeAll(withOutEdges);
    //
    //         return selectedTypes;
    //     }
    // }

    // ----------------------------------------------------------------------
    // Graph handling

    /**
     * Export the dependency graph from the graphdb into a SimpleDirectedGraph
     * of JGrapht library
     *
     * @nodeNames map (id,fullname). Can be null
     */
    public Graph<String, DefaultEdge> getTypeDependencyGraph(
        BidiMap<String/*typeId*/, String/*fullname*/> nodeNames, boolean useNames) {

        // create a simple directed graph
        Graph<String, DefaultEdge> g = new SimpleDirectedGraph<>(DefaultEdge.class);

        findTypeValues().forEach(values -> {
            String typeId = values.get(GRAPH_NODE_ID).toString();
            String fullname = values.get(FULLNAME).toString();
            nodeNames.put(typeId, fullname);

            if (useNames)
                g.addVertex(fullname);
            else
                g.addVertex(typeId);
        });

        // add the vertices
        // nodeNames.forEach((typeId, fullname) -> {
        //     if (useNames)
        //         g.addVertex(fullname);
        //     else
        //         g.addVertex(typeId);
        // });

        // 2) retrieve edges between 'type' nodes (NOT "reftype" nodes)
        // session.queryEdges(USES,
        //     TYPE, Parameters.params(PROJECT_ID, projectId, TYPE, TYPE),
        //     TYPE, Parameters.params(PROJECT_ID, projectId, TYPE, TYPE),
        //     Parameters.empty()).result().forEach(map -> {
        //         // {idfrom=112786, idto=125908}
        //         String from = map.get("idfrom").toString();
        //         String to = map.get("idto").toString();
        //
        //         if (!nodeNames.containsKey(from) || !nodeNames.containsKey(to))
        //             return;
        //
        //         if (useNames) {
        //             from = nodeNames.get(from);
        //             to = nodeNames.get(to);
        //         }
        //
        //         g.addEdge(from, to);
        // });

        findTypeRelations().forEach(values -> {
            // {idfrom=112786, idto=125908}
            String from = values.get("idfrom").toString();
            String to = values.get("idto").toString();

            if (!nodeNames.containsKey(from) || !nodeNames.containsKey(to))
                return;

            if (useNames) {
                from = nodeNames.get(from);
                to = nodeNames.get(to);
            }

            g.addEdge(from, to);
        });

        return g;
    }

    // ----------------------------------------------------------------------
    // Create Nodes

    /**
     * Create the 'project' component (role: PROJECT)
     *
     * Note/1: this component is used to check if the 'Component Model' exists in
     * the database.
     *
     * Note/2: the component MUST be the first component to create because in this
     * way, it is possible to delete the model if it is created partially
     *
     * @return
     */
    public ComponentInfo createComponent(Map<String, Object> memberValues, int depth) {

        String fullname = memberValues.get(FULLNAME).toString();
        String typeId = memberValues.get(TYPE_ID).toString();
        String memberId = memberValues.get(GRAPH_NODE_ID).toString();
        String memberType = depth == 0 ? TYPE : COMPONENT;
        String subType = depth <= 1 ? TYPE : COMPONENT;
        Set<String> closureIds;

        try(GraphSession session = graphdb.connect()) {
            //
            // ERROR: there is some problem that generated an exception ArrayOutOfBoundException: -1
            //
            closureIds = session.queryAdjacentNodesAlgorithm(memberId,
                USES, Direction.Output, true,
                memberType, Parameters.params(
                    USES, subType
                ),
                Parameters.empty()
            ).distinct().result().toList().stream().map(r -> r.get("n").toString()).collect(Collectors.toSet());
        }

        return createComponent(fullname, typeId, closureIds, depth);
    }

    /**
     * Create a component
     *
     * @param fullname fullname of the type
     * @param closureIds type ids of the closure
     * @param depth component layer's level
     * @return
     */
    public ComponentInfo createComponent(String fullname, String referenceId, Set<String> closureIds, int depth) {
        String memberType = depth == 0 ? TYPE : COMPONENT;
        String typeId = referenceId;

        if (referenceId != null) {
            GraphNode gnode = pga.getGraphAccess().getNode(referenceId);
            if (gnode != null && gnode.isComponent()) {
                Object rid = gnode.getValues().getOrDefault(TYPE_ID, null);
                typeId = rid != null ? rid.toString() : null;
            }
        }

        Parameters nparams = Parameters.params(
            NAME, StringUtils.lastOf(fullname, "."),
            FULLNAME, fullname,
            DEPTH, depth,
            COUNT, (long)closureIds.size(),
            ROLE, depth == 0 ? CROLE_TYPE : CROLE_COMPONENT,
            TYPE, depth == 0 ? TYPE : COMPONENT,
            PROJECT_ID, projectId);

        if (typeId != null)
            nparams.put(TYPE_ID, typeId);

        String componentId;
        try(GraphSession session = graphdb.connect()) {
            // create the node COMPONENT
            componentId = session.createNode(COMPONENT, nparams);

            // create the relation 'contains' between the 'component' and its members (of type 'type')
            session.createEdges(CONTAINS, componentId, closureIds, Parameters.params(EDGE_TYPE, memberType));
        }

        setTypesCount(componentId);

        return new ComponentInfo(componentId, fullname, closureIds);
    }

    private void setTypesCount(String componentId) {
        try(GraphSession session = graphdb.connect()) {
            // set component.countTypes (==.classes)
            long nTypes = session.queryAdjacentNodes(componentId,
                CONTAINS, Direction.Output, true,
                TYPE, Parameters.params(PROJECT_ID, projectId), Parameters.empty())
                .distinct().count();

            session.setNodeProperties(componentId, Parameters.params(
                CLASSES, nTypes,        // COMPATIBILITY
                COUNT_TYPES, nTypes
            ));
        }
    }

    public void deleteComponent(String componentId) {
        try(GraphSession session = graphdb.connect()) {
            session.deleteNode(componentId);
        }
    }

    public void deleteComponents(Set<String> componentIds) {
        try(GraphSession session = graphdb.connect()) {
            session.deleteNodes(componentIds);
        }
    }

    public void connectComponents(String supersetId, String subsetId) {
        try(GraphSession session = graphdb.connect()) {
            session.createEdge(USES, supersetId, subsetId, Parameters.params(EDGE_TYPE, COMPONENT));
        }
        catch (Throwable t) {
            logger.error(t, t);
        }
    }

    public Set<String> mergeChains(int depth) {
        Set<String> deletedNodes = new HashSet<>();
        Parameters params = Parameters.params(DEPTH, depth, PROJECT_ID, projectId);

        try(GraphSession session = graphdb.connect()) {
            Query query = session.queryUsing("findOneInOneOutComponents", params);

            // keys in the result:
            //
            //      "pid" id of the "previous node" (component)
            //      "nid" id of the "next node"     (component)
            //
            //      (p) -[:uses]-> (n) -[:uses]->(...)
            for (Iterator<Map<String, Object>> it = query.result(); it.hasNext(); ) {
                Map<String, Object> r = it.next();
                String pid = r.get("pid").toString();
                String nid = r.get("nid").toString();

                // 0) if nid or pid is already deleted, skip
                if (deletedNodes.contains(pid) || deletedNodes.contains(nid))
                    continue;

                // 1) find the adjacent nodes of (n) by edge ":uses":
                Set<String> adjacentIds = session.queryAdjacentNodes(nid,
                    USES, Direction.Output, false,
                    COMPONENT, params,
                    Parameters.empty()).ids().toSet();

                // 2) connect (p) to the adjacent nodes of (n)
                for (String toId : adjacentIds) {
                    // create the edge ONLY if is doesn't exist
                    session.findEdge(USES, pid, toId,
                        Parameters.empty(),
                        Parameters.params(USES, COMPONENT));
                }

                // 3) find the "content" of the node (n) by edge ":contains":
                Set<String> contentIds = session.queryAdjacentNodes(nid,
                    CONTAINS, Direction.Output, false,
                    COMPONENT, params,
                    Parameters.empty()).ids().toSet();

                // 4) merge the content of the node (p) with the content of the node (n)
                for (String cid : contentIds) {
                    // create the edge ONLY if is doesn't exist
                    session.findEdge(CONTAINS, pid, cid,
                        Parameters.empty(),
                        Parameters.params(EDGE_TYPE, COMPONENT));
                }

                // 5) delete the node (n)
                deletedNodes.add(nid);

                session.deleteNode(nid);
            }
        }

        return deletedNodes;
    }

    public void collapseCyclesWithComponent(int depth, String componentId, Set<String> cycleIds) {
        // 0) remove componentId from the cycle
        cycleIds.remove(componentId);

        // 1) create a list of nodes where componentId is the first node
        List<String> nodeIds = new ArrayList<>();
        nodeIds.add(componentId);
        nodeIds.addAll(cycleIds);

        // 2) merge all nodes on the first node in the list
        Parameters params = Parameters.params(
            "id", componentId,
            "ids", nodeIds);

        try(GraphSession session = graphdb.connect()) {
            session.queryUsing("collapseCycleIntoOneComponent", params).result();

            session.queryUsing("deleteComponents", params).result();
        }
    }

    public String collapseDAGRootComponent(int depth, String rootId) {
//        Set<String> memberIds = session.queryAdjacentNodes(rootId,
//            USES, Direction.Output, true,
//            COMPONENT, Parameters.params(
//                PROJECT_ID, projectId,
//                DEPTH, depth
//            ),
//            Parameters.empty()).ids().toSet();
//
//        // ADD the root node to the members!
//        memberIds.add(rootId);

        String componentId;

        try(GraphSession session = graphdb.connect()) {
            Set<String> memberIds = session.queryAdjacentNodesAlgorithm(rootId,
                USES, Direction.Output, true,
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth
                ),
                Parameters.empty()
            ).distinct().result().toList().stream().map(r -> r.get("n").toString()).collect(Collectors.toSet());

            Map<String, Object> nv = session.getNodeValues(rootId);

            Parameters nparams = Parameters.params();
            for (String key : nv.keySet())
                if (!key.startsWith("$"))           // skip keys starting with '$'
                    nparams.put(key, nv.get(key));

            nparams
                .put_(DEPTH, depth + 1)
                .put_(ROLE, CROLE_DAGROOT)
                .put_(COUNT, (long) memberIds.size())
                .put_(TYPE, COMPONENT);

            // Parameters nparams = Parameters.params(
            //     PROJECT_ID, projectId,
            //     DEPTH, depth+1,
            //     NAME, nv.get(NAME),
            //     FULLNAME, nv.get(FULLNAME),
            //     ROLE, CROLE_DAGROOT,
            //     TYPE, COMPONENT,
            //     TYPE_ID, nv.get(TYPE_ID)
            //     COUNT, (long)memberIds.size()
            // ));

            componentId = session.createNode(COMPONENT, nparams);

            session.createEdges(CONTAINS, componentId, memberIds, Parameters.params(EDGE_TYPE, COMPONENT));
        }

        setTypesCount(componentId);

        return componentId;
    }

    /**
     * Find all nodes with no ingoing edge in the 'dependency graph' of type 'type'
     * (classes)
     * @return
     */
    public List<Map<String, Object>> findTypesWithoutInEdge() {

        Parameters params = Parameters.params( PROJECT_ID, projectId );

        try(GraphSession session = graphdb.connect()) {
            return session.queryUsing("findTypesWithoutInEdge", params).distinct().allValues().toList();
        }
    }

    /**
     * this method to update the role property of all created top-down components to CROLE_DAGROOT
     */
    public void updateComponentProperty(String id, String role){
        Parameters params = Parameters.params( ROLE, CROLE_DAGROOT );

        try(GraphSession session = graphdb.connect()) {
            session.setNodeProperties(id, params);
        }
    }

    // ----------------------------------------------------------------------
    // Copy Graph in memory
    // ----------------------------------------------------------------------

    public SimpleDirectedGraph<String, DefaultEdge> getComponentGraph(int depth) {

        SimpleDirectedGraph<String, DefaultEdge> lcg = new SimpleDirectedGraph<String, DefaultEdge>(DefaultEdge.class);

        try(GraphSession session = graphdb.connect()) {
            session.queryNodes(COMPONENT,
                Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth
                )).ids()
                .toList().forEach(componentId -> lcg.addVertex(componentId));

            session.queryEdges(USES,
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth
                ),
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth),
                Parameters.empty())
                .result().toList().forEach(r -> {
                String fromId = r.get("idfrom").toString();
                String toId = r.get("idto").toString();

                lcg.addEdge(fromId, toId);
            });
        }

        return lcg;
    }

    // ----------------------------------------------------------------------
    // Model Graph
    // ----------------------------------------------------------------------

    public Map<String, Object> getModelGraph(int depth) {
        List<Map<String, Object>> vlist;
        List<Map<String, Object>> elist;

        try (GraphSession session = graphdb.connect()) {

            vlist = session.queryNodes(COMPONENT, Parameters.params(
                PROJECT_ID, projectId,
                DEPTH, depth
            )).allValues().toList();

            elist = session.queryEdges(USES,
                COMPONENT, Parameters.params(PROJECT_ID, projectId),
                COMPONENT, Parameters.params(PROJECT_ID, projectId),
                Parameters.empty()).result().toList();
        }

        // compose the nodeList
        List<Map<String, Object>> nodes =
            vlist.stream()
                .map(r -> {
                    return new HashMap<String, Object>()
                        .put_(ID, r.get(GRAPH_NODE_ID).toString())
                        .put_(LABEL, r.get(NAME))
                        .put_(METADATA, r);
                })
                .collect(Collectors.toList());

        // compose the edge list
        List<Map<String, Object>> edges =
            elist.stream()
                .map(r -> {
                    String fromId = r.get("idfrom").toString();
                    String toId = r.get("idto").toString();

                    return new HashMap<String, Object>()
                        .put_(EDGE_SOURCE, fromId)
                        .put_(EDGE_TARGET, toId)
                        .put_(EDGE_DIRECTED, true)
                        .put_(EDGE_RELATION, USES)
                        .put_(METADATA, Collections.emptyMap());
                })
                .collect(Collectors.toList());

        // compose the graph descriptor
        HashMap<String, Object> graph = new HashMap<>();
        graph
            .put_(GRAPH_DIRECTED, true)
            .put_(GRAPH_TYPE, String.format("ComponentModel graph (level %d)", depth))
            .put_(LABEL, config.getProjectName().getFullName())
            .put_(GRAPH_NODES, nodes)
            .put_(GRAPH_EDGES, edges);

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getSmallModelGraph(int depth) {
        List<Map<String, Object>> vlist;
        List<Map<String, Object>> elist;

        try (GraphSession session = graphdb.connect()) {

            vlist = session.queryNodes(COMPONENT, Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth
            )).allValues().toList();

            elist = session.queryEdges(USES,
                    COMPONENT, Parameters.params(PROJECT_ID, projectId),
                    COMPONENT, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).result().toList();
        }

        // compose the nodeList
        List<Map<String, Object>> nodes =
                vlist.stream()
                        .map(r -> {
                            return new HashMap<String, Object>()
                                    .put_(ID, r.get(GRAPH_NODE_ID).toString())
                                    .put_(LABEL, r.get(NAME))
                                    .put_(METADATA, r);
                        })
                        .collect(Collectors.toList());

        // compose the edge list
        List<Map<String, Object>> edges =
                elist.stream()
                        .map(r -> {
                            String fromId = r.get("idfrom").toString();
                            String toId = r.get("idto").toString();

                            return new HashMap<String, Object>()
                                    .put_(EDGE_SOURCE, fromId)
                                    .put_(EDGE_TARGET, toId)
                                    .put_(EDGE_DIRECTED, true)
                                    .put_(EDGE_RELATION, USES)
                                    .put_(METADATA, Collections.emptyMap());
                        })
                        .collect(Collectors.toList());

        // compose the graph descriptor
        HashMap<String, Object> graph = new HashMap<>();
        graph
                .put_(GRAPH_DIRECTED, true)
                .put_(GRAPH_TYPE, String.format("ComponentModel graph (level %d)", depth))
                .put_(LABEL, config.getProjectName().getFullName())
                .put_(GRAPH_NODES, nodes)
                .put_(GRAPH_EDGES, edges);

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    // ----------------------------------------------------------------------

    public void setTypesCount(){

        if(checkSetTypeCount())
            return;
        try (GraphSession session = graphdb.connect()) {
            session.queryUsing("setComponentTypesCount",Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }

    public Map<String, Object> getTypesCount(int depth){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            boolean all = false;
            if(depth == -1){
                all = true;
            }
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH, depth,
                    ALL, all);
            graph = session.queryUsing("getComponentTypesCount", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public boolean checkSetTypeCount(){
        List<Map<String, Object>> graph = null;

        try (GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);
            graph = session.queryUsing("checkSetComponentTypesCount", params).distinct().allValues().toList();
        }

        return (graph != null && graph.size() == 0);
    }

}

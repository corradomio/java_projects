package ae.ebtic.spl.analysis.sourcecode.analyzerv2.maven;

import ae.ebtic.spl.analysis.sourcecode.analyzer.maven.MavenLibrary;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseModule;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.maven.MavenPom;
import jext.util.OrderedHashSet;

import java.io.File;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class MavenModule extends BaseModule {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private MavenPom pom;
    private int maxDepth = 3;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public MavenModule(File moduleDir, Project project) {
        super(moduleDir, project);
        this.pom = new MavenPom(moduleDir);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getId() {
        // Override 'BaseModule::getId()' to use the 'module Maven coords'

        if (pom.exists())
            return pom.getCoords().toString();
        else
            return super.getId();
    }

    // ----------------------------------------------------------------------

    @Override
    protected List<Module> getDependencies() {
        //
        // Override 'BaseModule::getDependencies()' to reorder the
        // dependencies based on the 'building system configuration file'
        //

        Set<Module> dependencies = new OrderedHashSet<>();
        List<MavenCoords> dcoords = pom.getDependencyCoords();

        // speedup: dcoords is empty
        if (dcoords.isEmpty())
            return super.getDependencies();

        // retrieve the list of module dependencies based on
        // the Maven configuration file ('pom.xml')
        dcoords.forEach(coords -> {
            Module dmodule = project.getModule(coords.toString());
            if (dmodule != null) {
                dependencies.add(dmodule);
            }
        });

        // speedup: Maven dependencies is empty
        if (dependencies.isEmpty())
            return super.getDependencies();

        // add the missing dependencies based on the module types intersection
        dependencies.addAll(super.getDependencies());

        // return a list
        return new ArrayList<>(dependencies);
    }

    @Override
    protected List<String> getMavenRepositories() {
        return pom.getRepositories();
    }

    @Override
    protected List<Library> getMavenLibraries() {

        MavenDownloader md = project.getLibraryDownloader();

        List<MavenCoords> dependencies = getDirectCoordsDependencies();
        Set<MavenCoords> setCoords = new HashSet<>(dependencies);

        dependencies.forEach(dcoords -> {
            List<MavenCoords> ddcoords = md.getDependencies(dcoords, maxDepth);
            setCoords.addAll(ddcoords);
        });

        return setCoords.stream()
            .map(coords -> new MavenLibrary(coords, md, project))
            .collect(Collectors.toList());
    }

    private List<MavenCoords> getDirectCoordsDependencies() {

        MavenDownloader md = project.getLibraryDownloader();

        return pom.getDependencyCoords()
            .stream()
            .filter(this::isLibrary)
            .map(md::getVersioned)
            .collect(Collectors.toList());
    }

    private boolean isLibrary(MavenCoords coords) {
        return project.getModule(coords.toString()) == null;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.analysis.sourcecode.analyzer.maven;

import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
import ae.ebtic.spl.analysis.sourcecode.analyzer.java.BaseLibrary;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryType;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.util.MavenName;
import jext.cache.Cache;
import jext.cache.CacheManager;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.maven.MavenPom;
import jext.util.FileUtils;
import jext.util.JarUtils;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;


public class MavenLibrary extends BaseLibrary {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    protected MavenCoords coords;
    protected MavenDownloader downloader;

    protected List<Library> dependencies;
    private List<File> jarFiles;

    private static final int MAX_DEPTH = 3;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public MavenLibrary(MavenCoords coords, MavenDownloader downloader, Project project) {
        super(new MavenName(coords), project);

        this.coords = coords;
        this.downloader = downloader;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public synchronized boolean contains(Name typeName) {
        if (definedTypes.contains(typeName))
            return true;
        if (undefinedTypes.contains(typeName))
            return false;

        checkFilesNoSync();
        for (File jarFile : jarFiles) {
            if (JarUtils.containsClass(jarFile, typeName.toString())) {
                definedTypes.add(typeName);
                return true;
            }
        }
        {
            undefinedTypes.add(typeName);
            return false;
        }
    }

    @Override
    public LibraryType getLibraryType() {
        return LibraryType.MAVEN;
        // if (downloader.isPomPackaging(coords))
        //     return LibraryType.MAVEN_COLLECTION;
        // else
        //     return LibraryType.MAVEN;
    }

    @Override
    public String getDigest() {
        File digestFile;
        MavenPom pom = downloader.getPom(coords);
        if (pom != null && pom.isPomPackaging())
            digestFile = downloader.getPomFile(coords);
        else
            digestFile = downloader.getArtifact(coords);
        return FileUtils.digest(digestFile);
    }

    @Override
    public String getPath() {
        return coords.toString();
    }

    // ----------------------------------------------------------------------
    // Dependencies
    // ----------------------------------------------------------------------

    @Override
    public List<Library> getDependencies() {
        if (dependencies != null)
            return dependencies;

        dependencies = getDependencies(coords).stream()
            .map(dcoords -> new MavenLibrary(dcoords, downloader, project))
            .collect(Collectors.toList());

        return dependencies;
    }

    private List<MavenCoords> getDependencies(MavenCoords coords) {
        return downloader.getDependencies(coords, MAX_DEPTH);
    }

    // ----------------------------------------------------------------------
    // Types
    // ----------------------------------------------------------------------

    @Override
    public Set<RefType> getTypes() {
        Cache<String, Set<RefType>> cache = CacheManager.getCache("dependency.%s.library.types", project.getId());

        return cache.get(getId(), () -> {
            Set<RefType> types = new HashSet<>();

            getFiles().forEach(libraryFile -> {
                JarUtils.listClassNames(libraryFile).forEach(typeName -> {
                    types.add(new ReferencedType(typeName));
                });
            });

            return types;
        });

        // Set<RefType> types = new HashSet<>();
        //
        // getFiles().forEach(libraryFile -> {
        //     JarUtils.listClassNames(libraryFile).forEach(typeName -> {
        //         types.add(new ReferencedType(typeName));
        //     });
        // });
        //
        // return types;
    }

    // ----------------------------------------------------------------------
    // Specific Properties
    // ----------------------------------------------------------------------

    @Override
    public synchronized List<File> getFiles() {
        checkFilesNoSync();
        return jarFiles;
    }

    // ----------------------------------------------------------------------
    // Version
    // ----------------------------------------------------------------------

    @Override
    public String getVersion() {
        return coords.version;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private void checkFilesNoSync() {
        if (jarFiles != null)
            return;

        jarFiles = downloader.getArtifacts(coords);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

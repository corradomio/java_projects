package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.components.util.ComponentAggregator;
import ae.ebtic.spl.analysis.components.util.ComponentInfo;
import ae.ebtic.spl.analysis.components.util.LogAnalyzerListener;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.jgrapht.Graphs;
import jext.logging.Logger;
import jext.util.BidiMap;
import jext.util.ConcurrentHashMultimap;
import jext.util.DurationUtils;
import jext.util.HashBidiMap;
import jext.util.HashSet;
import jext.util.Multimap;
import jext.util.Pair;
import jext.util.SetUtils;
import org.jgrapht.Graph;
import org.jgrapht.alg.TransitiveReduction;
import org.jgrapht.alg.cycle.CycleDetector;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Collectors;

public class ComponentAnalyzer /*extends AbstractComponentAnalyzer*/ implements ComponentAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ComponentAnalysis newAnalyzer(AnalyzerConfig config) {
        ComponentAnalyzer analyzer = new ComponentAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    private static final String STANDALONE_COMPONENT = "$StandAloneTypes";
    private static final int COLLAPSE_CYCLES = 1;
    private static final int MERGE_CHAINS = 1;

    private static final String COMPONENT_SAMPLES = "componentSamples";
    private static final String COMPONENT_TIMEOUT = "componentTimeout";

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // logger
    protected Logger logger;

    // if aborted
    protected boolean aborted;

    // listeners
    protected Listeners listeners = new Listeners();

    // component project id
    protected String componentProjectId;

    // Configuration
    protected AnalyzerConfig config;

    // Handle the component graph
    protected ComponentGraph cg;

    // Local Component Graph
    protected SimpleDirectedGraph<String, DefaultEdge> lcg;

    // Component Aggregator
    protected ComponentAggregator ca;

    // counters used in the status of the analyzer
    protected int processedComponents, totalComponents;

    // n of samples to use
    protected long componentSamples;

    // sample timeout
    protected long componentTimeout;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ComponentAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    protected ComponentAnalyzer initialize() {
        logger = Logger.getLogger("%s.%s.%s",
            getClass(), config.getProjectName().getParentName(), config.getProjectName().getName());

        GraphConfig config = new GraphConfig()
                .setGraphDatabase(this.config.getGraphDatabase())
                .setProjectName(this.config.getProjectName())
                .setParameters(this.config.getParameters());

        //cg = ComponentGraph.newComponentGraph(config);
        cg = ProjectGraphAccess.newProjectGraphAccess(config).getComponentGraph();

        componentSamples = this.config.getParameters().getLong(COMPONENT_SAMPLES, 0);
        componentTimeout = DurationUtils.parse(this.config.getParameters().getString(COMPONENT_TIMEOUT, "0"));

        return this;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    /**
     * Abort the analysis
     */
    public void abort() {
        this.aborted = true;
    }

    /**
     * Delete the component model
     */
    public void delete() {
        cg.delete();
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void analyze() {
        if (aborted) return;

        addListener(new LogAnalyzerListener(this.logger));

        analyzeNew();
        // analyzeOld();
    }

    private void analyzeNew() {
        /*
            Create the dependency model:

            1) analyze the dependency graph (the relations between the types)
                a) for each type with degree greater that 0
                    creates the component that contains the closure of the type
                b) for each component, cheh the relation between the other component
                   (a component is a set of types)

                   ci == cj -> remove ci
                   ci >  cj -> create "ci -[uses]-> cj"
                   ci != cj -> che components has empty intersection
                   sij = ci*cj -> (not empty intersection) search the component that has sij as subset, then
                        "ci -[uses]-> cij <-[uses]- cj"

            2) start from the component graph at level 0, creates the component graphs at component 1, 2, ...
         */
        try (ComponentGraph cg = (ComponentGraph) this.cg.connect()) {
            int depth = 0;
            boolean isDAG = false;

            // create the node used to check if the component model exists
            createProjectNode();

            // -----------------------------------------------------------
            // depth 0

            BidiMap<String/*typeId*/, String/*fullname*/> typeNames = new HashBidiMap<>();
            Graph<String, DefaultEdge> dgraph = getDependencyGraph(typeNames);
            Map<String, Set<String>> closures = computeClosures(dgraph);

            initComponentGraph();
            createStandAloneComponent(dgraph);
            createComponentGraph(closures, typeNames, depth);
            composeDependenciesNew(depth);
            createDependencies(depth);
            deleteComponents(depth);

            while (!isDAG && depth < 5) {
                if (aborted) break;

                Graph<String, DefaultEdge> cgraph = lcg;
                BidiMap<String/*typeId*/, String/*fullname*/> componentNames = ca.getComponentNames();
                closures = computeClosures(cgraph);
                ++depth;

                initComponentGraph();
                createComponentGraph(closures, componentNames, depth);
                composeDependenciesNew(depth);
                createDependencies(depth);
                deleteComponents(depth);

                isDAG = simplifyGraph(depth);
                checkComponentGraph(depth);
            }

            collapseDAGRoots(depth);
            checkComponentGraph(depth+1);

            analysisDone(false);
        }
        catch (Throwable t) {
            logger.error(t, t);

            analysisDone(true);
        }

        logger.infof("Component analysis complete");
    }

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------

    private void initComponentGraph() {
        ca = new ComponentAggregator();
        lcg = new SimpleDirectedGraph<>(DefaultEdge.class);
    }

    private Graph<String, DefaultEdge> getDependencyGraph(BidiMap<String/*typeId*/, String/*fullname*/> typeNames) {

        // note: the name of the component is based on the name of the typeName!

        // retrieve the dependency graph (:type)-[:uses]->(:type) between VALID types (NO 'reftype's)

        Graph<String, DefaultEdge> g = cg.getTypeDependencyGraph(typeNames, false);

        logger.debugf("    ... retrieved dependency graph (v: %d, e: %d)", g.vertexSet().size(), g.edgeSet().size());

        return g;
    }

    private Map<String, Set<String>> computeClosures(Graph<String, DefaultEdge> g) {

        logger.debugf("    ... compute %d closures", g.vertexSet().size());

        Map<String, Set<String>> closures = g.vertexSet().parallelStream()
            .filter(v -> !aborted)
            // skip the isolated vertices
            .filter(v -> !Graphs.isIsolated(g, v))
            // compute the closure for each NOT isolated vertex
            .map(v -> {
                Set<String> closure = Graphs.closureOf(g, v);
                return new Pair<>(v, closure);
            })
            .collect(Collectors.toMap(Pair::getKey, Pair::getValue));

        return closures;
    }

    private void createStandAloneComponent(Graph<String, DefaultEdge> g) {

        Set<String> standAloneTypeIds = Graphs.isolatedVertices(g);

        if (standAloneTypeIds.isEmpty())
            return;

        ComponentInfo ci = cg.createComponent(STANDALONE_COMPONENT, null, standAloneTypeIds, 0);
        registerComponent(ci);

        logger.debugf("    ... created component $StandAloneTypes (%s: %d types)", ci.componentId, ci.closureIds.size());

        processedComponents += standAloneTypeIds.size();
        listeners.fireComponentsProcessed(processedComponents, totalComponents);
        ca.addToAlreadyInComponents(standAloneTypeIds);
    }

    private void createComponentGraph(Map<String, Set<String>> closures, BidiMap<String, String> nodeNames, int depth) {

        logger.infof("    [%d] createComponentGraph", depth);

        listeners.fireCreateComponents(setTotalComponents(closures.size()));

        // create the components
        closures.forEach((referenceId, closureIds) -> {
            String fullname = nodeNames.get(referenceId);

            if (ca.isAlreadyInComponents(referenceId) || aborted)
                return;

            logger.debugft("    ... create component %s", fullname);

            ComponentInfo ci = cg.createComponent(fullname, referenceId, closureIds, depth);
            registerComponent(ci);

            listeners.fireComponentsProcessed(++processedComponents, totalComponents);
        });
    }

    // ----------------------------------------------------------------------

    private boolean simplifyGraph(int depth) {
        boolean simplified = false;

        logger.infof("    [%d] simplifyGraph", depth);

        simplified |= mergeChains(depth);
        simplified |= collapseCycles(depth);

        return simplified;
    }

    private boolean mergeChains(int depth) {
        if (depth < MERGE_CHAINS)
            return false;

        boolean merged = false;

        // loop to simplify the graph
        Set<String> mergedNodes;
        while((mergedNodes = cg.mergeChains(depth)).size() > 0) {
            logger.warnf("       merged chains %s", mergedNodes.toString());
            merged = true;
        }

        return merged;
    }

    private boolean collapseCycles(int depth) {
        if (depth < COLLAPSE_CYCLES) return false;

        if (cg.isDAG(depth)) return true;

        lcg = cg.getComponentGraph(depth);

        CycleDetector<String, DefaultEdge> cycleDetector = new CycleDetector<>(lcg);

        if (!cycleDetector.detectCycles()) {
            logger.warnf("The Component Model at depth %d is a DAG", depth);
            return true;
        }

        Set<String> componentIds = lcg.vertexSet();
        Set<String> deletedComponents = new HashSet<>();

        componentIds.forEach(componentId -> {

            // 0) if the component is deleted, skip it
            if (deletedComponents.contains(componentId) || aborted)
                return;

            // 1) check if the component is inside a cycle
            Set<String> cycleIds = cycleDetector.findCyclesContainingVertex(componentId);
            if (cycleIds.isEmpty())
                return;

            // 2) the component is inside a cycle, collapse the cycle
            deletedComponents.add(componentId);
            deletedComponents.addAll(cycleIds);

            collapseCyclesWithComponent(depth, componentId, cycleIds);

            logger.warnf("       collapsed cycle %s", cycleIds.toString());
        });

        return false;
    }

    private List<String> collapseDAGRoots(int depth) {

        List<String> dagRoots = cg.findDAGRootComponents(depth).stream()
            .filter(componentid -> !aborted)
            .map(componentId -> cg.collapseDAGRootComponent(depth, componentId))
            .collect(Collectors.toList());

        return dagRoots;
    }

    private void collapseCyclesWithComponent(int depth, String componentId, Set<String> cycleIds) {
        logger.infof("      collapsed cycle ");
        cg.collapseCyclesWithComponent(depth, componentId, cycleIds);
    }

    private void checkComponentGraph(int depth) {

        logger.infof("    [%d] checkComponentGraph", depth);

        List<Component> components = cg.getComponents(depth, null);
        for(Component c: components) {
            if (aborted) return;

            List<Component> members = c.getMembers();
            if (members.size() == 0) {
                logger.warnf("Component %s (%s) is empty", c.getId(), c.getValues().toString());
                cg.deleteComponent(c.getId());
            }
        }

        // logger.infof("    [%d] checkComponentGraph.done", depth);
    }

    // ----------------------------------------------------------------------
    // Graph Operations
    // ----------------------------------------------------------------------

    /**
     * Create the 'project component': this node is used ONLY to check if in the database
     * is present the 'component model' for the current project
     */
    private void createProjectNode() {
        componentProjectId = cg.create();
    }

    private void analysisDone(boolean failed) {
        cg.setStatus((failed || aborted) ? STATUS_INVALID : STATUS_VALID, null);

        listeners.fireDone();
    }

    private void registerComponent(ComponentInfo ci) {
        // add the component to the "ComponentAggregator"
        ca.addComponent(ci);

        // add the componentId in the local component graph
        lcg.addVertex(ci.componentId);
    }

    // ----------------------------------------------------------------------

    /**
     * Consolidate the components:  let Ci, Cj two components
     * (remembre that the components are sets of types)
     *
     *  1) if Ci == Cj, they are the same component, removes a component
     *  2) if Ci  > Cj, creates the relation Ci -[uses]-> Cj
     *  3) if intersection(Ci, Cj) != {}
     *      let Iij = intersection(Ci, Cj)
     *      let Cij the smallest component containing Iij (if there are more than 1 ??? Select the first)
     *      creates the relations
     *
     *      Ci -[uses]-> Cij <-[uses]- Cj
     *
     *  3') if Cij == Ci == Cj, do nothing
     *      if Cij == Ci,       creates    Cj -[uses]-> Ci
     *      if Cij == Cj,       creates    Ci -[uses]-> Cj
     *
     *
     */
    private void composeDependenciesNew(int depth) {
        if (aborted) return;

        // counter
        final AtomicInteger nComparisons = new AtomicInteger();

        // ci is superset of the list of cj
        Multimap<String, String> isSupersetOf = new ConcurrentHashMultimap<>();

        // ci and cj have not empty intersection
        Multimap<String, String> hasIntersectionWith = new ConcurrentHashMultimap<>();

        logger.infof("    [%d] composeDependencies", depth);

        listeners.fireComponeDependencies(setTotalComponents(totalComponents));

        nComparisons.set(0);
        asList(ca.getComponentSizes()).parallelStream()
            .forEach(csize -> {
                if (aborted) return;

                Set<String> componentIds = ca.getComponentsBySize(csize);

                // retrieve the list of components with the same size or smaller
                List<String> smallerIds = ca.getSmallerComponents(csize);

                // compare the components with the smaller ones
                loop: for(String ci : componentIds) {
                    nComparisons.incrementAndGet();

                    // skip the components already marked to remove
                    if (ca.isToRemove(ci) || aborted)
                        continue;

                    long nOfSamples = 0;
                    long startTime = System.currentTimeMillis();

                    listeners.fireComponentsProcessed(++processedComponents, totalComponents);

                    for(String cj : smallerIds) {

                        nComparisons.incrementAndGet();
                        ++nOfSamples;

                        if (componentSamples != 0 && nOfSamples >= this.componentSamples) {
                            logger.warnf("    ... analysis skipped for component sizes %d for stopping criteria 'componentSamples'", csize);
                            break loop;
                        }
                        //
                        if (componentTimeout != 0 && (System.currentTimeMillis() - startTime) >= this.componentTimeout) {
                            logger.warnf("    ... analysis skipped for component sizes %d for stopping criteria 'componentTimeout'", csize);
                            break loop;
                        }

                        // skip the components already marked to remove
                        if (ca.isToRemove(cj) || aborted)
                            continue;

                        // skip if they are the same component
                        if (ci.equals(cj))
                            continue;;

                        Set<String> si = ca.getComponentClosure(ci);
                        Set<String> sj = ca.getComponentClosure(cj);

                        // check if si and sj are the same set: keep only one
                        if (SetUtils.isSameset(si, sj))
                            ca.addToRemove(cj);

                            // check if si is a superset of sj
                        else if (SetUtils.isSuperset(si, sj))
                            isSupersetOf.put(ci, cj);

                            // check is si and sj have a not empty intersection
                        else if (SetUtils.hasIntersection(si, sj))
                            hasIntersectionWith.put(ci, cj);
                    }
                }
            });

        logger.debugf("    ... compared %d component pairs", nComparisons.get());

        nComparisons.set(0);
        isSupersetOf.keySet().parallelStream()
            .forEach(ci -> {
                nComparisons.incrementAndGet();

                if (ca.isToRemove(ci) || aborted)
                    return;

                Set<String> subsetIds = isSupersetOf.get(ci);
                for(String cj : subsetIds) {
                    if (aborted) return;

                    nComparisons.incrementAndGet();
                    if (ca.isToRemove(cj))
                        continue;

                    this.connectComponents(ci, cj);
                }
            });

        logger.debugf("    ... compared %d superset relations", nComparisons.get());

        //
        // Resolve the components with intersection
        //
        //  1) compute the intersection
        //  2) compute the closure of the intersection
        //  3) check if already exists a component equals to the closure
        //      if it exists, uses it
        //  4) create a new component 'component3'
        //  5) create the relations:
        //
        //      component1 -[uses]-> component3 <-[uses]- component2
        //  NO!
        //
        // New solution:
        //
        //  1) compute the intersection
        //  2) for each element in the intersection, find the component
        //     that contain it (this component exists for construction)
        //  3) create a link between the current component and the component
        //     found
        //
        // NOTE: the component "$UtilityTypes" is a SPECIAL component, it
        //      must be excluded from the analysis
        // NOTE: the component "StandAloneTypes" is a SPECIAL component, but,
        //      because it contains classes without other dependencies, it is
        //      not a big problem if it is considered during the analysis
        //
        nComparisons.set(0);
        hasIntersectionWith.keySet().parallelStream()
            .forEach(ci -> {
                nComparisons.incrementAndGet();

                if (ca.isToRemove(ci) || aborted)
                    return;

                long nOfSamples = 0;
                long startTime = System.currentTimeMillis();

                Set<String> intersectedIds = hasIntersectionWith.get(ci);
                loop: for (String cj : intersectedIds) {
                    nComparisons.incrementAndGet();

                    if (ca.isToRemove(cj) || aborted)
                        continue;

                    if (componentSamples != 0 && nOfSamples >= this.componentSamples) {
                        logger.warnf("    ... analysis skipper for component %s for stopping criteria (componentSamples)", ci);
                        break loop;
                    }
                    //
                    if (componentTimeout != 0 && (System.currentTimeMillis() - startTime) >= this.componentTimeout) {
                        logger.warnf("    ... analysis skipper for component %s for stopping criteria (componentTimeout)", ci);
                        break loop;
                    }

                    Set<String> si = ca.getComponentClosure(ci);
                    Set<String> sj = ca.getComponentClosure(cj);
                    Set<String> sij = SetUtils.intersection(si, sj);
                    String cij;

                    //
                    // find the smallest component that contains the closure
                    //
                    // int nij = si.size() < sj.size() ? si.size() : sj.size();
                    // cij = ca.findComponent(sij, nij-1);
                    // if (cij != null)
                    // {
                    //     // the component exists
                    //
                    //     if (cij.equals(ci) && cij.equals(cj))
                    //         continue;
                    //     else if(cij.equals(ci))
                    //         continue;
                    //     else if(cij.equals(cj))
                    //         continue;
                    //     else {
                    //         this.connectComponents(ci, cij);
                    //         this.connectComponents(cj, cij);
                    //     }
                    // }
                    // else
                    {
                        // the component doesn't exist
                        // for each element in the set, find the smallest component
                        // that contains is and create a relation

                        for (String memberId : sij) {
                            if (aborted) return;

                            nComparisons.incrementAndGet();

                            cij = ca.getOwnerComponent(memberId);

                            if (cij != null) {
                                this.connectComponents(ci, cij);
                                this.connectComponents(cj, cij);
                            }
                            else {
                                logger.errorf("The type/component with id %s is not member of some component", memberId);
                            }
                        }
                    }
                }
            });

        logger.debugf("    ... compared %d intersect relations", nComparisons.get());
        logger.infof( "    [%d] composeDependencies.done", depth);
    }

    private static List<Integer> asList(int[] a) {
        List<Integer> list = new ArrayList<>(a.length);
        for (int i=0; i<a.length; ++i)
            list.add(a[i]);
        return list;
    }

    // ----------------------------------------------------------------------

    private synchronized void connectComponents(String ci, String cj) {
        if (ci.equals(cj))
            return;

        logger.debugft("    ... connecting %s -> %s", ci, cj);

        try {
            lcg.addEdge(ci, cj);
        }
        catch (IllegalArgumentException | NullPointerException e) {
            logger.error(e, e);
        }
    }

    private void createDependencies(int depth) {
        AtomicInteger nConnections = new AtomicInteger();
        if (aborted) return;

        logger.infof("    [%d] createDependencies", depth);

        listeners.fireCreateDependencies(setTotalComponents(lcg.edgeSet().size()));

        if (config.getReduceGraph()) {
            logger.warnf("    ... transitive reduction of the graph");
            TransitiveReduction.INSTANCE.reduce(lcg);
        }

        // update the total number of edges to process because some edges are removed
        // by the Transitive Reduction
        setTotalComponents(lcg.edgeSet().size());

        lcg.edgeSet()
                .forEach(edge -> {
                    if (aborted) return;

                    String ci = lcg.getEdgeSource(edge);
                    String cj = lcg.getEdgeTarget(edge);

                    listeners.fireComponentsProcessed(++processedComponents, totalComponents);

                    cg.connectComponents(ci, cj);
                    nConnections.getAndIncrement();
                });

        logger.debugf("    ... created %d component dependencies", nConnections.get());
        // logger.infof( "    [%d] createDependencies.done", depth);
    }

    protected void deleteComponents(int depth) {
        // for(String componentId : toRemove)
        //     cg.deleteComponent(componentId);
        Set<String> toRemove = ca.deleteComponents();
        cg.deleteComponents(toRemove);
        Graphs.removeVertices(lcg, toRemove);
        logger.infof( "    [%d] deleted %d components", depth, toRemove.size());
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private int setTotalComponents(int totalComponents) {
        this.totalComponents = totalComponents;
        this.processedComponents = 0;
        return totalComponents;
    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    private static class Listeners {

        private List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireCreateComponents(int totalComponents) {
            listeners.forEach(l -> l.onCreateComponents(totalComponents) );
        }

        void fireAggregateComponents(int totalComponents) {
            listeners.forEach(l -> l.onAggregateComponents(totalComponents) );
        }

        void fireComponeDependencies(int totalComponents) {
            listeners.forEach(l -> l.onComponentsDependencies(totalComponents) );
        }

        void fireComponentsProcessed(int componentsProcessed, int totalComponents) {
            listeners.forEach(l -> l.onComponentsProcessed(componentsProcessed, totalComponents) );
        }

        void fireCreateDependencies(int totalDependencies) {
            listeners.forEach(l -> l.onCreateDependencies(totalDependencies) );
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone() );
        }

    }

    public ComponentAnalyzer addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }

}

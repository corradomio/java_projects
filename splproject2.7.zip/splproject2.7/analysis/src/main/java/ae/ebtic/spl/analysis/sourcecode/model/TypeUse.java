package ae.ebtic.spl.analysis.sourcecode.model;

public enum TypeUse {
    ALL,        // EXTENDS or IMPLEMENTS or DEPENDS_ON
    HIERARCHY,  // EXTENDS or IMPLEMENTS
    EXTENDS,
    IMPLEMENTS,
    DEPENDS_ON
}

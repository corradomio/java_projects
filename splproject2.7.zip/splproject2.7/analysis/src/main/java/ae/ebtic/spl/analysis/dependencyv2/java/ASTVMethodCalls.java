package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.util.MethodObjectName;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.MethodReferenceExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.resolution.declarations.ResolvedConstructorDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import jext.javaparser.util.JPUtils;
import jext.util.Parameters;

import java.util.Optional;

/**
 * This class is used to
 */
public class ASTVMethodCalls extends ASTVisitor {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private MethodObjectName methodName;
    private long callIndex;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ASTVMethodCalls(DependencyAnalyzer da) {
        super(da);
    }

    // ----------------------------------------------------------------------
    // Analyze
    // ----------------------------------------------------------------------

    public void analyze(Source source, Parameters params) {
        super.analyze(source, params);
    }

    public ASTVMethodCalls analyze(CompilationUnit cu) {
        try {
            ts = composeTypeSolver();

            super.analyze(cu);
        }
        finally {
            if (ts != null)
                ts.detach();
        }

        return this;
    }

    // ----------------------------------------------------------------------
    // Visit // method declaration
    // ----------------------------------------------------------------------

    @Override
    public void visit(ConstructorDeclaration n, Void arg) {
        analyze(n);
        // System.out.printf("[[ Constructor %s\n", n.getNameAsString());
        super.visit(n, arg);
        // System.out.printf("]] Constructor %s\n", n.getNameAsString());

        methodName = null;
    }

    @Override
    public void visit(MethodDeclaration n, Void arg) {
        analyze(n);
        // System.out.printf("[[ Method %s\n", n.getNameAsString());
        super.visit(n, arg);
        // System.out.printf("]] Method %s\n", n.getNameAsString());

        methodName = null;
    }

    // ----------------------------------------------------------------------
    // Visit // method calls
    // ----------------------------------------------------------------------

    @Override
    public void visit(MethodCallExpr n, Void arg) {
        // System.out.printf("    call %s\n", n.toString());
        analyze(methodName, n);
        super.visit(n, arg);
    }

    @Override
    public void visit(ObjectCreationExpr n, Void arg) {
        // System.out.printf("    call %s\n", n.toString());
        analyze(methodName, n);
        super.visit(n, arg);
    }

    @Override
    public void visit(MethodReferenceExpr n, Void arg) {
        // System.out.printf("    call %s\n", n.toString());
        analyze(methodName, n);
        super.visit(n, arg);
    }

    // ----------------------------------------------------------------------
    // Analyze
    // ----------------------------------------------------------------------

    private void analyze(ConstructorDeclaration n) {
        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent())
            return;

        // get the full qualified class name
        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent())
            return;

        int nParameters = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) compose the method name
        this.methodName = new MethodObjectName(qname.get(), n.getName().getIdentifier(), nParameters, signature);
        this.callIndex = 0;

        //analyze(methodName, n.getBody());
    }

    private void analyze(MethodDeclaration n) {
        // getNameAsString() == getName().getIdentifier()
        String mname = n.getNameAsString();

        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent())
            return;

        // get the full qualified class name
        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent())
            return;

        // body not present ("abstract")
        if (!n.getBody().isPresent())
            return;

        int nParams = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) compose the method name
        this.methodName = new MethodObjectName(qname.get(), mname, nParams, signature);
        this.callIndex = 0;

        //analyze(methodName, n.getBody().get());
    }

    // -- method call

    private void analyze(MethodName callingMethod, MethodCallExpr mce) {
        // 'method call' called outside a constructor/method declaration
        if (callingMethod == null) {
            logger.warnc("Method call outside","Method call outside constructor/method declaration: %s", mce.toString());
            return;
        }

        try {
            ResolvedMethodDeclaration rmd = ts.resolve(mce);
            if (rmd == null)
                return;

            int nArgs = mce.getArguments().size();
            String signature = JPUtils.getSignature(rmd);

            MethodName calledMethod = new MethodObjectName(rmd.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod, this.callIndex);
            this.callIndex += 1;

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }

    private void analyze(MethodName callingMethod, ObjectCreationExpr oce) {
        // 'method call' called outside a constructor/method declaration
        if (callingMethod == null) {
            logger.warnc("Method call outside", "Method call outside constructor/method declaration: %s", oce.toString());
            return;
        }

        try {
            ResolvedConstructorDeclaration rcm = ts.resolve(oce);
            if (rcm == null)
                return;

            int nArgs = oce.getArguments().size();
            String signature = JPUtils.getSignature(rcm);

            MethodName calledMethod = new MethodObjectName(rcm.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod, this.callIndex);
            this.callIndex += 1;

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }

    private void analyze(MethodName callingMethod, MethodReferenceExpr mre) {

        try {
            ResolvedMethodDeclaration rmd = ts.resolve(mre);
            if (rmd == null)
                return;

            int nArgs = rmd.getNumberOfParams();
            String signature = JPUtils.getSignature(rmd);

            MethodName calledMethod = new MethodObjectName(rmd.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod, this.callIndex);
            this.callIndex += 1;

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }
}

package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Type;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class FieldNode extends GraphNode implements Field {

    public static List<Field> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> FieldNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static FieldNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new FieldNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private FieldNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    @Override
    public String getTypeId() {
        return nv.get(TYPE_ID).toString();
    }

    @Override
    public String getOwnerTypeId(){
        return nv.get(OWNER_TYPE_ID).toString();
    }

    @Override
    public Type getOwnerType() {
        return dg.getType(getOwnerTypeId());
    }

    @Override
    public Type getType() {
        return dg.getType(getTypeId());
    }

}

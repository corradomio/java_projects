package ae.ebtic.spl.analysis.sourcecode.analyzer.java;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryType;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.HashSet;
import jext.util.StringUtils;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Set;


public abstract class BaseLibrary extends NamedObject implements Library {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    protected Logger logger;

    protected Project project;

    protected File libraryFile;
    protected LibraryType libraryType;
    protected Module module;

    protected Set<Name> definedTypes = new HashSet<>();
    protected Set<Name> undefinedTypes = new HashSet<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected BaseLibrary(Name libraryName, Project project) {
        super(libraryName);

        this.project = project;

        this.logger = Logger.getLogger("ae.ebtic.spl.analysis.sourcecode.model.Library.%s", libraryName);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public Project getProject() {
        return project;
    }

    @Override
    public String getPath() {
        return FileUtils.getAbsolutePath(libraryFile);
    }

    @Override
    public String getModuleId() {
        return null;
    }

    @Override
    public Module getModule() {
        return null;
    }

    @Override
    public LibraryType getLibraryType() {
        return libraryType;
    }

    @Override
    public String getDigest() {
        return FileUtils.digest(libraryFile);
    }

    @Override
    public List<Library> getDependencies() {
        return Collections.emptyList();
    }

    @Override
    public boolean isLocal() {
        LibraryType ltype = getLibraryType();
        return !(ltype == LibraryType.MAVEN
            // || ltype == LibraryType.MAVEN_COLLECTION
            // || ltype == LibraryType.LOCAL_COLLECTION
            || ltype == LibraryType.RUNTIME
        );
    }

    // ----------------------------------------------------------------------
    // Version
    // ----------------------------------------------------------------------

    @Override
    public String getVersion() { return StringUtils.empty(); }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.analysis.sourcecode.model;

import java.util.Map;

public interface Field extends IdNamed {

    // Name getName();

    // String getId();

    RefType getType();

    Type getOwnerType();

    String getOwnerTypeId();

    String getTypeId();

    Map<String, Object> getValues();
}

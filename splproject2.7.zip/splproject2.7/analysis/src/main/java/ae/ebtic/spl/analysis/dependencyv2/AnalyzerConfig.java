package ae.ebtic.spl.analysis.dependencyv2;

import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import ae.ebtic.spl.analysis.util.AnalysisConfig;
import jext.graph.GraphDatabase;
import jext.util.Parameters;

import java.io.File;
import java.util.List;

public class AnalyzerConfig extends AnalysisConfig {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private LibraryFinder lfinder;
    private File projectRoot;
    private List<String> pathFilters;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public AnalyzerConfig() {

    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- Parameters

    public AnalyzerConfig setParameter(String name, Object value) {
        parameters.setValue(name, value);
        return this;
    }

    // -- projectName

    public AnalyzerConfig setProjectName(Name projectName) {
        this.projectName = projectName;
        return this;
    }

    public AnalyzerConfig setProjectName(String repository, String projectName) {
        return setProjectName(new PathName(repository, projectName));
    }

    // -- properties

    public AnalyzerConfig setParameters(Parameters params) {
        if (params != null)
            this.parameters.putAll(params);
        return this;
    }

    // -- graphdatabase

    public AnalyzerConfig setGraphDatabase(GraphDatabase graphdb) {
        this.graphdb = graphdb;
        return this;
    }

    // -- extlibfinder

    public AnalyzerConfig setLibraryFinder(LibraryFinder lfinder) {
        this.lfinder = lfinder;
        return this;
    }

    public LibraryFinder getLibraryFinder() { return lfinder; }

    // -- projectRoot

    public AnalyzerConfig setProjectRoot(File projectRoot) {
        this.projectRoot = projectRoot;
        assert this.projectName != null;
        return this;
    }

    public File getProjectRoot() { return projectRoot; }

    // -- pathFilters

    public AnalyzerConfig setPathFilters(List<String> pathFilters) {
        this.pathFilters = pathFilters;
        return this;
    }

    public List<String> getPathFilters() {
        return pathFilters;
    }

}

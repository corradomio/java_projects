package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Parameter;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import jext.graph.Direction;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MethodNode extends GraphNode implements Method {

    public static List<Method> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> MethodNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static MethodNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new MethodNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private MethodNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public String getTypeId() {
        return (String) this.nv.get(TYPE_ID);
    }


    public String getOwnerTypeId() {
        return (String) this.nv.get(OWNER_TYPE_ID);
    }

    @Override
    public Type getOwnerType() {
        return dg.getType(getOwnerTypeId());
    }

    @Override
    public Type getType() {
        return dg.getType(getTypeId());
    }

    @Override
    public String getSignature() {
        return (String) this.nv.get(SIGNATURE);
    }

    @Override
    public List<Parameter> getParameters() {
        return dg.getParameters(getId());
    }

    @Override
    public List<Type> getReferencedTypes() {
        return dg.getUseTypes(getId(), TypeUse.ALL, Direction.Output, false, false);
    }

    @Override
    public List<Method> getMethodCalls() {
        return dg.getMethodCalls(getId());
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public boolean isEntryPoint() {
        return (Boolean)nv.getOrDefault(ENTRY_POINT, Boolean.FALSE);
    }

}

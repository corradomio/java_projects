package ae.ebtic.spl.analysis.dependencyv2;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.dependencies.util.LibrariesRegistry;
import ae.ebtic.spl.analysis.dependencies.util.ModulesRegistry;
import ae.ebtic.spl.analysis.dependencies.util.NamespacesRegistry;
import ae.ebtic.spl.analysis.dependencies.util.TypeRegistry;
import ae.ebtic.spl.analysis.dependencyv2.util.UnresolvedSymbolsLibrary;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import jext.logging.Logger;
import jext.util.Parameters;

import java.util.Collections;
import java.util.Map;

/**
 * This class is used to collect the method used to create nodes inside the database.
 * Each
 */
public class DAtoDG implements AutoCloseable, GraphConstants {
    private Logger logger;
    private DependencyAnalyzer da;
    private DependencyGraph dg;

    private String projectId;
    private Parameters params;

    private Project project;
    private Module module;
    private Source source;

    private String moduleId;
    private String sourceId;

    private final ModulesRegistry modulesRegistry;
    private final LibrariesRegistry librariesRegistry;
    private final NamespacesRegistry namespacesRegistry;
    private final Library runtimeLibrary;
    private final UnresolvedSymbolsLibrary unresolvedSymbolsLibrary;

    public DAtoDG(DependencyAnalyzer da, DependencyGraph dg) {
        this(da, dg, null, Parameters.empty());
    }

    public DAtoDG(DependencyAnalyzer da, DependencyGraph dg, Source source, Parameters params) {
        this.da = da;
        this.dg = dg;

        this.modulesRegistry = da.modulesRegistry;
        this.librariesRegistry = da.librariesRegistry;
        this.namespacesRegistry = da.namespacesRegistry;

        if (source != null) {
            this.source = source;
            this.module = source.getModule();
            this.project = source.getModule().getProject();

            this.sourceId = this.modulesRegistry.getSourceId(source);
            this.moduleId = this.modulesRegistry.getModuleId(module);

            this.params = Parameters.params(
                SOURCE_ID, this.sourceId,
                MODULE_ID, this.moduleId
            ).add(params);

            this.logger = Logger.getLogger("%s.%s.%s",
                this.project.getName().getName(),
                this.module.getName().getName(),
                this.source.getName().getName());
        }
        else {
            this.logger = da.logger;
        }

        this.runtimeLibrary = da.runtimeLibrary;
        this.unresolvedSymbolsLibrary = da.unresolvedLibrary;
    }

    public DAtoDG connect() {
        dg.connect();
        return this;
    }

    public void close() {
        dg.close();
    }

    // ----------------------------------------------------------------------
    // createProjectStructure
    // createModuleNode
    // ----------------------------------------------------------------------

    protected Parameters createProjectNode(Project project, Parameters params) {

        Parameters nparams = Parameters.params(
            // NAME, project.getName().getName(),
            // REPOSITORY, project.getName().getParentName(),
            // FULLNAME, project.getName().getFullName(),
            // PROJECT_TYPE, project.getProjectType(),
            PATH, project.getPath()
        ).add(params);
        //
        // projectId = dg.createProjectNode(nparams);

        projectId = dg.create(nparams);

        return Parameters.params(PROJECT_ID, projectId).add(params);
    }

    protected String createModuleNode(Module module, Parameters params) {
        // Note: 'this.params' IS NOT FILLED

        Parameters nparams = Parameters.params(
            NAME, module.getName().getName(),
            FULLNAME, module.getName().getFullName(),
            PATH, module.getPath()
        ).add(params);

        // (module)
        String moduleId = dg.createNode(MODULE, nparams);

        // (module) -[memberOf]-> (project)
        dg.createEdge(MEMBER_OF, moduleId, projectId, MODULE);

        // register [moduleName, ModuleRegistry]
        modulesRegistry.registerModule(moduleId, module);

        return moduleId;
    }

    // ----------------------------------------------------------------------
    // createResourceNode
    // createLibraryNode
    // createLibraryDependency
    // createSourceNode
    // ----------------------------------------------------------------------

    protected String createResourceNode(Resource resource, Parameters params) {
        // Note: 'this.params' IS NOT FILLED

        String moduleId = params.getString(MODULE_ID);

        Parameters nparams = Parameters.params(
            NAME, resource.getName().getName(),
            FULLNAME, resource.getName().getFullName(),
            PATH, resource.getPath(),
            DIGEST, resource.getDigest()
        ).add(params);

        // (source)
        String sourceId = dg.createNode(RESOURCE, nparams);

        // (resource) -[memberOf]-> (module)
        //createMemberOfEdge(dg, sourceId, moduleId, RESOURCE);
        dg.createEdge(MEMBER_OF, sourceId, moduleId, RESOURCE);

        return sourceId;
    }

    protected String createLibraryNode(Library library, Parameters params) {
        // Note: 'this.params' CAN BE NOT FILLED

        synchronized (librariesRegistry) {

            String libraryId;

            if (librariesRegistry.isLibraryRegistered(library))
                return librariesRegistry.getLibraryId(library);

            Parameters nparams = Parameters.params(
                NAME, library.getName().getName(),
                FULLNAME, library.getName().getFullName(),
                PATH, library.getPath(),
                LIBRARY_TYPE, library.getLibraryType().toString()
            ).add(params);

            if (library.isLocal()) {
                String moduleId = modulesRegistry.getModuleId(library.getModule());
                if (moduleId != null)
                    nparams.put(MODULE_ID, moduleId);
            }

            // (library)
            libraryId = dg.createNode(LIBRARY, nparams);

            librariesRegistry.registerLibrary(libraryId, library);

            return libraryId;
        }

    }

    protected String createLibraryDependency(Module module, Library library, Parameters params) {
        String moduleId = modulesRegistry.getModuleId(module);
        String libraryId = createLibraryNode(library, params);

        // There are TWO type of libraries
        //
        // 1) local libraries(jars): it IS a MEMBER of the module
        // 2) global libraries (jdk & maven): theye are NOT a MEMBER of the module
        //
        // however, a module USES a library

        // (library) -[memberOf] -> (module)
        if (library.isLocal())
            dg.createEdge(MEMBER_OF, libraryId, moduleId, LIBRARY);

        // (module) -[uses]-> (library)
        dg.createEdge(USES, moduleId, libraryId, LIBRARY);
        return libraryId;
    }

    public String createSourceNode(Source source, Parameters params) {
        String moduleId = params.getString(MODULE_ID);

        Parameters nparams = Parameters.params(
            NAME, source.getName().getName(),
            FULLNAME, source.getName().getFullName(),
            PATH, source.getPath(),
            DIGEST, source.getDigest(),
            LANGUAGE, source.getLanguage()
        ).add(params);

        // (source)
        String sourceId = dg.createNode(SOURCE, nparams);

        // (source) -[memberOf]-> (module)
        dg.createEdge(MEMBER_OF, sourceId, moduleId, SOURCE);

        return sourceId;
    }

    // ----------------------------------------------------------------------
    // createNamespaceNode
    // ----------------------------------------------------------------------

    public String createNamespaceNode(Name namespace) {
        return createNamespaceNode(namespace, module, modulesRegistry, params);
    }

    public String createNamespaceNode(Name namespace, Library library, Parameters params) {
        return createNamespaceNode(namespace, library, librariesRegistry, params);
    }

    private String createNamespaceNode(
        Name namespace,
        Named container, TypeRegistry registry,
        Parameters params)
    {
        // check if the namespace is already registered
        String namespaceId = namespacesRegistry.getNamespaceIdOrLock(namespace);
        if (namespaceId != null)
            return namespaceId;

        namespaceId = registry.getTypeId(namespace, container);
        if (namespaceId != null) {
            // the namespace IS A TYPE!!!!
            namespacesRegistry.registerNamespaceAndRelease(namespaceId, namespace);
            return namespaceId;
        }

        try {
            //
            // check if the namespace is a type!
            // For example:  java.util.Map.Entry has as parent java.util.Map that
            // it is a TYPE!!!!
            //

            // create the parent namespace
            String parentId = null;
            if (!namespace.isRoot())
                parentId = createNamespaceNode(namespace.getParent(), container, registry, params);

            // the namespace is specific ONLY at the project level
            Parameters nparams = Parameters.params(params)
                .remove_(MODULE_ID)
                .remove_(SOURCE_ID);

            // (namespace)
            if (namespace.isRoot()) {
                namespaceId = dg.createNode(NAMESPACE, Parameters.params(
                    NAME, namespace.getName(),
                    FULLNAME, namespace.getFullName(),
                    NAMESPACE, null
                ).add(nparams));
            }
            else {
                namespaceId = dg.createNode(NAMESPACE, Parameters.params(
                    NAME, namespace.getName(),
                    FULLNAME, namespace.getFullName(),
                    NAMESPACE, namespace.getParentName()
                ).add(nparams));
            }

            // (namespace) -[memberOf]-> (parentspace)
            dg.createEdge(MEMBER_OF, namespaceId, parentId, NAMESPACE);

        }
        finally {
            namespacesRegistry.registerNamespaceAndRelease(namespaceId, namespace);
        }

        return namespaceId;
    }

    // ----------------------------------------------------------------------
    // createTypeNode
    // createLibraryNamespaceNode
    // createCommentNode
    // createTokenNodes
    // ----------------------------------------------------------------------

    public String createTypeNode(RefType refType, Library library, Parameters params) {
        String libraryId = librariesRegistry.getLibraryId(library);
        if (libraryId == null) {
            logger.warnf("Library %s not registered", library);
            return null;
        }

        Name typeName = refType.getName();
        String namespaceId = namespacesRegistry.getNamespaceId(typeName.getParent());

        Parameters nparams = Parameters.params(
            NAME, typeName.getName(),
            NAMESPACE, typeName.getParentName(),
            FULLNAME, typeName.getFullName(),
            ROLE, refType.getRole().toString(),
            TYPE_PARAMS, refType.getTypeParametersCount(),
            // INNER, refType.isInnerType(),
            // LIBRARY, library.getName().getFullName(),
            LIBRARY_ID, libraryId,
            TYPE, REFTYPE
        ).add(params);

        String typeId = dg.createNode(TYPE, nparams);

        // (refType) -[memberOf]-> (namespace)
        dg.createEdge(MEMBER_OF, typeId, namespaceId, TYPE);

        // (refType) -[memberOf]-> (library)
        dg.createEdge(MEMBER_OF, typeId, libraryId, TYPE);

        // register the refType in the librariesRegistry
        librariesRegistry.registerType(typeId, typeName, library);

        return typeId;
    }

    /**
     * Create a "type" node in the graph.
     * Note: THIS type IS DEFINED in the source file.
     */
    public String createTypeNode(RefType refType) {
        Name typeName = refType.getName();
        String typeId;

        //
        // TODO: trick to handle classes defined inside a method
        //
        typeId = modulesRegistry.getTypeId(typeName, module);
        if (typeId != null)
            return typeId;

        Parameters nparams = Parameters.params(
            NAME, typeName.getName(),
            NAMESPACE, typeName.getParentName(),
            FULLNAME, typeName.getFullName(),
            ROLE, refType.getRole().toString(),
            TYPE_PARAMS, refType.getTypeParametersCount(),
            // INNER, refType.isInnerType(),
            SOURCE, source.getName().getFullName()
        ).add(params);

        if (refType.getRole() == TypeRole.UNKNOWN)
            nparams.put(TYPE, REFTYPE);

        typeId = dg.createNode(TYPE, nparams);

        // (refType) -[memberOf]-> (source)
        String sourceId = modulesRegistry.getSourceId(source);
        dg.createEdge(MEMBER_OF, typeId, sourceId, TYPE);

        // (refType) -[memberOf]-> (namespace)
        String namespaceId = namespacesRegistry.getNamespaceId(typeName.getParent());
        dg.createEdge(MEMBER_OF, typeId, namespaceId, TYPE);

        // register the refType in the modulesRegistry
        modulesRegistry.registerType(typeId, typeName, module);

        return typeId;
    }

    /**
     * Create a type node in the graph.
     * Not: THIS type is a REFERENCE TYPE, defined in the source code or in an external library!
     */
    public String createTypeNode(
        RefType refType,
        Module module,
        Parameters params)
    {
        Name typeName = refType.getName();

        // DEBUG
        //if (typeName.getFullName().equals("java.io.Serializable"))
        //    typeName = typeName;

        //
        // before to create the node, it is necessary to check if it is already defined in
        // 1) current module
        // 2) dependency modules
        // 3) dependency libraries
        //
        // If it is not already defined, the type IS a type defined in an external library.
        // In this case it is necessary to find which library defines it and to create the
        // related node
        String typeId = findTypeId(typeName);
        if (typeId != null) return typeId;

        // 4) not defined
        String symbol = typeName.getFullName();

        // 4.1) if the symbol contains spaces, it is NOT a true symbol,
        //      TODO: THIS IS an error in JavaParser
        if (symbol.contains(" "))
            return null;

        // 4) check if it is an already UNRESOLVED type
        if (da.isUnsolvedSymbol(symbol))
            return null;

        // 5) find the library containing the type
        //
        Library library = findLibrary(typeName, module);
        if (library == null) {
            // DEBUG
            //findTypeId(typeName);
            // library = findLibrary(typeName, module);

            //da.logUnableToFindLibrary(symbol, source);
            //return null;

            library = getUnresolvedSymbolsLibrary(typeName);
        }

        // 7) resolve the reftype INSIDE the library (the current object has no
        //    information about the library)
        // refType = library.getType(typeName);
        refType = new ReferencedType(typeName, library);

        // 8) create a new type node
        typeId = createTypeNode(refType, params);

        return typeId;
    }

    private String/*typeId*/ findTypeId(Name typeName) {
        String typeId;

        // 1) check if it is defined in the current module:
        typeId = modulesRegistry.getTypeId(typeName, module);
        if (typeId != null) return typeId;

        // 2) check if it is defined in the dependency modules
        for(Module dmodule : module.getDependencies(true)) {
            typeId = modulesRegistry.getTypeId(typeName, dmodule);
            if (typeId != null) return typeId;
        }

        // 3.1) check if it is defined in the dependency libraries
        for (Library library : module.getLibraries()) {
            typeId = librariesRegistry.getTypeId(typeName, library);
            if (typeId != null) return typeId;
        }

        // 3.2) check if it is defined in the dependency module's libraries
        for (Module dmodule : module.getDependencies(true)) {
            for (Library library : dmodule.getLibraries()) {
                typeId = librariesRegistry.getTypeId(typeName, library);
                if (typeId != null) return typeId;
            }
        }

        // 3.3) check if is defined in JDK
        typeId = librariesRegistry.getTypeId(typeName, runtimeLibrary);
        if (typeId != null) return typeId;

        // not found
        return null;
    }

    private Library findLibrary(Name typeName, Module module) {
        // 1) check in the dependency libraries
        for (Library library : module.getLibraries()) {
            if (library.contains(typeName))
                return library;
        }

        // 2) search in the dependency module's libraries
        for(Module dmodule : module.getDependencies(true)) {
            for (Library library : dmodule.getLibraries()) {
                if (library.contains(typeName))
                    return library;
            }
        }

        // 3) check in jdk
        if (runtimeLibrary.contains(typeName))
            return runtimeLibrary;

        // not found
        return null;
    }

    private Library getUnresolvedSymbolsLibrary(Name typeName) {
        if (!unresolvedSymbolsLibrary.containsOrAdd(typeName)) {
            logger.errorf("Unable to find the library for symbol %s", typeName);
        }
        return unresolvedSymbolsLibrary;
    }

    private String createTypeNode(RefType refType, Parameters params) {
        Name typeName = refType.getName();
        Library library = refType.getLibrary();
        createLibraryNamespaceNode(typeName.getParent(), library, params);

        String typeId = librariesRegistry.getTypeIdOrLock(typeName, library);
        if (typeId != null) return typeId;
        try {
            typeId =  createTypeNode(refType, library, params);
        }
        finally {
            librariesRegistry.registerTypeAndRelease(typeId, typeName, library);
        }

        return typeId;
    }

    private String createLibraryNamespaceNode(Name namespace, Library library, Parameters params) {
        // check if the library contains the namespace
        // this means that the namespace is a type and the type is an inner type
        if (library.contains(namespace)) {
            RefType refType = new ReferencedType(namespace, library);
            String typeId = createTypeNode(refType, params);
            namespacesRegistry.registerNamespace(typeId, namespace);
            return typeId;
        }

        return createNamespaceNode(namespace, library, params);
    }

    // private String createTypeNode0(RefType refType, Parameters params) {
    //     Library library = refType.getLibrary();
    //     String libraryId = librariesRegistry.getId(library);
    //     Name typeName = refType.getName();
    //     String namespaceId = namespacesRegistry.getId(typeName.getParent());
    //
    //     Parameters nparams = Parameters.params(
    //         NAME, typeName.getName(),
    //         NAMESPACE, typeName.getParentName(),
    //         FULLNAME, typeName.getFullName(),
    //         ROLE, refType.getRole().toString(),
    //         TYPE_PARAMS, refType.getTypeParametersCount(),
    //         // INNER, refType.isInnerType(),
    //         LIBRARY, library.getName().getFullName(),
    //         LIBRARY_ID, libraryId
    //     ).add(params);
    //
    //     if (refType.getRole() == TypeRole.UNKNOWN)
    //         nparams.put(TYPE, REFTYPE);
    //
    //     String typeId = dg.createNode(TYPE, nparams);
    //
    //     // (refType) -[memberOf]-> (namespace)
    //     dg.createEdge(MEMBER_OF, typeId, namespaceId, TYPE);
    //
    //     // (refType) -[memberOf]-> (library)
    //     dg.createEdge(MEMBER_OF, typeId, libraryId, TYPE);
    //
    //     // register the refType in the librariesRegistry
    //     //librariesRegistry.registerType(typeId, typeName, library);
    //
    //     return typeId;
    // }

    // ----------------------------------------------------------------------
    // createCommentNode
    // ----------------------------------------------------------------------

    public void createCommentNode(String nodeId, Parameters params) {
        Parameters nparams = Parameters.params()
            .add(params)
            .put_(NAME, COMMENT)
            .add(this.params);

        String commentId = dg.createNode(COMMENT, nparams);

        dg.createEdge(COMMENT, nodeId, commentId, COMMENT);
    }

    // ----------------------------------------------------------------------
    // createMemberOfEdge
    // createUsesEdge
    // ----------------------------------------------------------------------

    // void createEdge(String edgeType, String fromId, String toId, String subType) {
    //     if (fromId != null && toId != null && !fromId.equals(toId))
    //         dg.createEdge(edgeType, fromId, toId, subType);
    // }

    // ----------------------------------------------------------------------
    // createTypeDependency
    // ----------------------------------------------------------------------

    public void createTypeDependency(
        RefType fromType, RefType toType, String useType,
        Module module, Parameters params) {

        // this is already registered!
        String fromId = modulesRegistry.getTypeId(fromType.getName(), module);
        String toId = createTypeNode(toType, module, params);

        if (fromId == null)
            da.logUnregisteredType(logger, fromType);

        dg.createEdge(USES, fromId, toId, useType);
    }

    // ----------------------------------------------------------------------
    // createFieldNode
    // ----------------------------------------------------------------------

    public String createFieldNode(Name fieldName, RefType fieldType) {
        Name typeName = fieldName.getParent();
        String ownerTypeId = modulesRegistry.getTypeId(typeName, module);
        String typeId = createTypeNode(fieldType, module, params);

        Parameters nparams = Parameters.params(
            NAME, fieldName.getName(),
            NAMESPACE, fieldName.getParentName(),
            FULLNAME, fieldName.getFullName(),
            OWNER_TYPE_ID, ownerTypeId,
            TYPE_ID, typeId
        ).add(params);

        String fieldId = dg.createNode(FIELD, nparams);

        // (field) -[memberOf]-> (type)
        dg.createEdge(MEMBER_OF, fieldId, ownerTypeId, FIELD);

        // (field) -[ofType]-> (type)
        dg.createEdge(OF_TYPE, fieldId, typeId, FIELD);

        return fieldId;
    }

    // ----------------------------------------------------------------------
    // createMethodNode
    // ----------------------------------------------------------------------

    public String  createMethodNode(MethodName methodName, RefType returnType) {
        Name typeName = methodName.getParent();

        //
        // ALL methods with the SAME name and SAME number of parameter are represented with the SAME node.
        // NO!!!! ERROR

        // String methodId = modulesRegistry.getMethodId(methodName, module);
        // if (methodId != null)
        //     return methodId;

        String ownerTypeId = modulesRegistry.getTypeId(typeName, module);
        if (ownerTypeId == null) {
            logger.errorf("Class %s not defined in module %s", typeName, module);
            return null;
        }

        String typeId = createTypeNode(returnType, module, params);

        Parameters nparams = Parameters.params(
            NAME, methodName.getName(),
            NAMESPACE, methodName.getParentName(),
            FULLNAME, methodName.getFullName(),
            TYPENAME, methodName.getParent().getName(),
            NUM_PARAMS,  methodName.getNumParameters(),
            SIGNATURE, methodName.getSignature(),
            OWNER_TYPE_ID, ownerTypeId,
            TYPE_ID, typeId
        ).add(params);

        String methodId = dg.createNode(METHOD, nparams);

        // (method) -[memberOf]-> (type)
        dg.createEdge(MEMBER_OF, methodId, ownerTypeId, METHOD);

        // (method) -[ofType]-> (type)
        dg.createEdge(OF_TYPE, methodId, typeId, RETURN);

        modulesRegistry.registerMethod(methodId, methodName, module);

        return methodId;
    }

    public String createParameterNode(String methodId, Name paramName, RefType paramType) {
        if (paramType == null)
            return null;

        String typeId = createTypeNode(paramType, module, params);
        if (typeId == null) {
            logger.errorf("Parameter type %s not defined in module %s", paramType, module);
            return null;
        }

        Parameters nparams = Parameters.params(
            NAME, paramName.getName(),
            NAMESPACE, paramName.getParentName(),
            FULLNAME, paramName.getFullName(),
            METHODNAME, paramName.getParent().getName(),
            TYPENAME, paramName.getParent().getParent().getName(),
            TYPE, paramType.getName().getFullName(),
            OWNER_METHOD_ID, methodId,
            TYPE_ID, typeId
        ).add(params);


        String parameterId = dg.createNode(PARAMETER, nparams);

        // (param) -[memberOf]-> (method)
        dg.createEdge(MEMBER_OF, parameterId, methodId, PARAMETER);

        // (param) -[ofType]-> (type)
        dg.createEdge(OF_TYPE, parameterId, typeId, PARAMETER);

        return parameterId;
    }

    public void createReturnType(String methodId, RefType returnType)  {
        String typeId = createTypeNode(returnType, module, params);
        if (typeId == null) {
            logger.errorf("Return type %s not defined in module %s", returnType, module);
            return;
        }

        dg.createEdge(OF_TYPE, methodId, typeId, RETURN);
    }

    private static final long[] NO_INDICES = new long[0];

    public void createMethodCall(MethodName callingMethod, MethodName calledMethod) {
        String callingId = modulesRegistry.getMethodId(callingMethod, module);
        String calledId = findCalledMethodId(calledMethod);

        if (callingId == null || calledId == null || callingId.equals(calledId))
            return;

        dg.createEdge(METHOD_CALL, callingId, calledId, Parameters.params(
            EDGE_TYPE, METHOD_CALL,
            INDEX, NO_INDICES
        ));
    }

    public void createMethodCall(MethodName callingMethod, MethodName calledMethod, long callIndex) {
        String callingId = modulesRegistry.getMethodId(callingMethod, module);
        String calledId = findCalledMethodId(calledMethod);

        if (callingId == null || calledId == null || callingId.equals(calledId))
            return;

        // String statementId = dg.createNode(STATEMENT, Parameters.params(
        //     EDGE_TYPE, METHOD_CALL,
        //     INDEX, callIndex
        // ));
        //
        // dg.createEdge(STATEMENT, callingId, statementId, Parameters.params(
        //     TYPE, METHOD_CALL,
        //     INDEX, callIndex
        // ));
        //
        // dg.createEdge(METHOD_CALL, statementId, calledId, METHOD);

        dg.addEdgeProperty(METHOD_CALL, callingId, calledId, INDEX, callIndex);
    }

    private String/*methodId*/ findCalledMethodId(MethodName calledMethod) {
        String calledId = modulesRegistry.getMethodId(calledMethod, module);

        // 1) find the method in the current module
        if (calledId != null)
            return calledId;

        // 2) find the method in the dependency modules
        for(Module dmodule : module.getDependencies(true)) {
            calledId = modulesRegistry.getMethodId(calledMethod, dmodule);
            if (calledId != null)
                return calledId;
        }

        return null;
    }

    // ----------------------------------------------------------------------

    public String createTokenNode(String token, String fullName) {
        Parameters nparams = Parameters.params(
            NAME, token,
            FULLNAME, fullName
        ).add(this.params);

        return dg.createNode(TOKEN, nparams);
    }

    public void createEdge(String edgeType, String fromId, String toId, String subType) {
        dg.createEdge(edgeType, fromId, toId, subType);
    }
    public void createEdge(String edgeType, String fromId, String toId, Map<String, Object> edgeProps) {
        dg.createEdge(edgeType, fromId, toId, edgeProps);
    }

    public void mergeTokens() {
        dg.mergeTokens();
    }

    public void deleteTokensWithoutRelationships() {
        dg.deleteTokensWithoutRelationships();
    }

    public void setStatus(String status, String reason) {
        dg.setStatus(status, reason);
    }
}

package ae.ebtic.spl.analysis.sourcecode.analyzerv2.ant;

import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseProject;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import jext.util.FileUtils;
import jext.util.Parameters;

import java.io.File;
import java.util.Properties;

public class AntProject extends BaseProject {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    public static final String TYPE = "ant";
    public static final String MODULE_FILE = "build.xml";

    // ----------------------------------------------------------------------
    // Static methods
    // ----------------------------------------------------------------------

    public static boolean isProject(File projectDir, Properties props) {
        File projectFile = new File(projectDir, MODULE_FILE);
        if (projectFile.exists())
            return true;
        if (FileUtils.listFiles(projectDir, file -> file.getName().equals(MODULE_FILE)).size() > 0)
            return true;
        return false;
    }

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public AntProject(String projectName, File projectDir, Properties properties) {
        super(projectName, projectDir, properties, TYPE);
        if (!properties.containsKey(PROJECT_MODULE))
            this.properties.setProperty(PROJECT_MODULE, MODULE_FILE);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    protected Module newModule(File moduleDir) {
        return new AntModule(moduleDir, this);
    }

}

package ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle;

import ae.ebtic.spl.analysis.sourcecode.analyzer.gradle.BuildGradleFile;
import ae.ebtic.spl.analysis.sourcecode.analyzer.maven.MavenLibrary;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.collectors.DependenciesCollector;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.collectors.ErrorsCollector;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.collectors.LoggerCollector;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.collectors.ProjectsCollector;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseModule;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.util.OrderedHashSet;
import org.gradle.tooling.BuildException;
import org.gradle.tooling.ProjectConnection;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.stream.Collectors;

public class GradleModule extends BaseModule {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static final String BUILD_GRADLE = "build.gradle";
    private static final String COMPILE_CLASSPATH = "compileClasspath";
    private static final String TEST_COMPILE_CLASSPATH = "testCompileClasspath";

    private List<Name> dmodules;
    private List<Library> dcoords;
    private BuildGradleFile buildGradle;

    // private SettingsGradleFile settingsGradle;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public GradleModule(GradleProject project) {
        super(project.getDirectory(), project);
        init();
    }

    public GradleModule(File moduleDir, GradleProject project) {
        super(moduleDir, project);
        init();
    }

    public GradleModule(String name, GradleModule parent) {
        super(new File(parent.getDirectory(), name), parent.getProject());
        init();
    }

    private void init() {
        File buildGradle = new File(moduleDir, BUILD_GRADLE);
        File directoryGradle = new File(moduleDir, moduleDir.getName() + ".gradle");

        if (directoryGradle.exists())
            this.buildGradle = new BuildGradleFile(directoryGradle);
        else
            this.buildGradle = new BuildGradleFile(buildGradle);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    protected List<Module> getDependencies() {
        //
        // Override 'BaseModule::getDependencies()' to reorder the
        // dependencies based on the 'building system configuration file'
        //

        Set<Module> dependencies = new OrderedHashSet<>();
        List<Name> dnames = getGradleDependencies();

        // speedup: dnames is empty
        if (dnames.isEmpty())
            return super.getDependencies();

        dnames.forEach(dname -> {
            Module dmodule = project.getModule(dname.toString());
            if (dmodule != null)
                dependencies.add(dmodule);
        });

        // speedup: Gradle dependencies is empty
        if (dependencies.isEmpty())
            return super.getDependencies();

        // add the missing dependencies based on the module types intersection
        dependencies.addAll(super.getDependencies());

        // return a list
        return new ArrayList<>(dependencies);
    }

    // ----------------------------------------------------------------------
    // Libraries
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------

    @Override
    protected List<String> getMavenRepositories() {
        return buildGradle.getRepositories();
    }

    @Override
    protected List<Library> getMavenLibraries() {
        if (dcoords == null)
            retrieveDependencies();
        return dcoords;
    }

    private List<Name> getGradleDependencies() {
        if (dmodules == null)
            retrieveDependencies();
        return dmodules;
    }

    private void retrieveDependencies() {
        logger.debugf("retrieveDependencies");

        String dependenciesTask = toTask("dependencies");
        ErrorsCollector err = new ErrorsCollector(logger);
        DependenciesCollector collector = new DependenciesCollector();
        LoggerCollector logcoll = new LoggerCollector(logger, collector);
        try(ProjectConnection connection = getGradleProject().getConnection()) {
            connection
                .newBuild().forTasks(dependenciesTask)
                .setStandardOutput(collector)
                // .setStandardOutput(logcoll)
                .setStandardError(err)
                .run();
        }
        // catch (BuildException e) {
        //     String message = e.getCause().getMessage();
        //     if (!message.contains("not found in root project"))
        //         logger.error(e);
        // }
        catch (Throwable e) {
            String message = e.getCause().getMessage();
            if (!message.contains("not found in root project"))
                logger.error(e);
        }
        finally {
            logcoll.close();
            collector.close();
            err.close();
        }

        MavenDownloader md = project.getLibraryDownloader();

        String gradleConfiguration = project.getProperties().getProperty(GradleProject.GRADLE_CONFIGURATION, COMPILE_CLASSPATH);

        dmodules = collector.getProjects(gradleConfiguration)
            .stream()
            .map(name -> project.getModule(name))
            .filter(Objects::nonNull)
            .map(Module::getName)
            .sorted()
            .collect(Collectors.toList());

        dcoords = collector.getLibraries(gradleConfiguration)
            .stream()
            .map(MavenCoords::new)
            .sorted()
            .map(coords -> new MavenLibrary(coords, md, project))
            .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Modules
    // ----------------------------------------------------------------------

    // Used to retrieve the list of project modules
    public List<GradleModule> getModules(){

        List<GradleModule> modules = new ArrayList<>();

        String projectsTask = toTask("projects");
        ErrorsCollector err = new ErrorsCollector(logger);
        ProjectsCollector projects = new ProjectsCollector();
        try(ProjectConnection connection = getGradleProject().getConnection()) {
            connection
                .newBuild().forTasks(projectsTask)
                .setStandardOutput(projects)
                .setStandardError(err)
                .run();
        }
        catch (BuildException e) {
            String message = e.getCause().getMessage();
            if (!message.contains("not found in root project"))
                logger.error(e, e);
        }
        catch (Throwable t) {
            logger.error(t, t);
        }
        finally {
            projects.close();
            err.close();
        }

        projects.forEach(name -> {
            GradleModule module = (GradleModule) project.getModule(name);
            if (module == null) {
                module = new GradleModule(name, this);
                getGradleProject().addGradleModule(module);
            }
            modules.add(module);
        });

        return modules;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private GradleProject getGradleProject() {
        return (GradleProject) getProject();
    }

    private String toTask(String taskName) {
        String moduleName = getName().toString().replace('/',':');
        if (moduleName.isEmpty())
            return taskName;
        else
            return String.format("%s:%s", moduleName, taskName);
    }
}
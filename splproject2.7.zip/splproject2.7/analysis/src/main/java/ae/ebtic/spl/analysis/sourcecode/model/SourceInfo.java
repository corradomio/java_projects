package ae.ebtic.spl.analysis.sourcecode.model;

public class SourceInfo {
    public long count;
    public long bytes;
    public long totalLines;
    public long blankLines;
    public long codeLines;
}

package ae.ebtic.spl.analysis.runtime;

public interface RuntimeAnalysis {

    RuntimeAnalysis addListener(AnalyzerListener analyzerListener);

    void analyze();

    void abort();

    void delete();
}

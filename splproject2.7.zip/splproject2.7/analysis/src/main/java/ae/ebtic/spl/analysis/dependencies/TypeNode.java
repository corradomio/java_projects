package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import jext.graph.Direction;

import java.util.*;
import java.util.stream.Collectors;

public class TypeNode extends GraphNode implements Type {

    public static List<RefType> ref(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> TypeNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static List<Type> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> TypeNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static TypeNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new TypeNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------
    /*
        Content of the map 'nv':

        $labels: List<String>   list of the graphdb labels (in general there is only 1 label)
        $id: String             id of the graphdb node
        $type: String           type of the node (the unique label)

        projectId: String       id of the 'project' node
        moduleId: String        id of the 'module' node
        sourceId: String        id of the 'source' node

        namespace: String       Java namespace
        name: String            Java type name
        fullname: String        <namespace>.<name>
        role: String            TROLE_*

        type: String            TYPE | REFTYPE
     */

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private TypeNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties: RefType/Type
    // ----------------------------------------------------------------------

    @Override
    public boolean isType() {
        String type = nv.getOrDefault(TYPE, TYPE_UNKNOWN).toString();

        return !TYPE_REFTYPE.equals(type);
    }

    // ----------------------------------------------------------------------
    // Properties: this type
    // ----------------------------------------------------------------------

    /**
     * Check if is a 'valid' type (class or interface)
     */
    @Override
    public boolean isValid() {
        String role = (String)nv.getOrDefault(ROLE, UNKNOWN);
        String type = (String)nv.getOrDefault(TYPE, UNKNOWN);
        String fullname = (String)nv.getOrDefault(FULLNAME, UNKNOWN);
        boolean isLocal = fullname.contains("$");
        return TYPE.equals(type)
            && (TROLE_CLASS.equals(role) || TROLE_INTERFACE.equals(role)
            || TROLE_ENUM.equals(role) || TROLE_ANNOTATION.equals(role))
            && !isLocal;
    }

    @Override
    public TypeRole getRole() {
        String role = (String)nv.getOrDefault(ROLE, UNKNOWN);

        return TypeRole.valueOf(role);
    }

    @Override
    public int getTypeParametersCount() {
        Object count = nv.getOrDefault(TYPE_PARAMS, 0L);
        if (count instanceof Long)
            return (int)(long) count;
        else
            return (int) count;
    }

    // ----------------------------------------------------------------------
    // Properties: navigation
    // ----------------------------------------------------------------------

    @Override
    public String getSourceId() {
        return nv.get(SOURCE_ID).toString();
    }

    @Override
    public String getModuleId() {
        return nv.get(MODULE_ID).toString();
    }

    @Override
    public String getLibraryId() {
        String libraryId = (String)nv.getOrDefault(LIBRARY_ID, null);
        if (libraryId == null)
            libraryId = (String)nv.getOrDefault(LIBRARY, null);

        return libraryId;
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public Module getModule() {
        return dg.getModule(getModuleId());
    }

    @Override
    public Source getSource() {
        return dg.getSource(getSourceId());
    }

    @Override
    public Library getLibrary() {
        String libraryId = getLibraryId();
        return dg.getLibrary(libraryId);
    }

    // ----------------------------------------------------------------------
    // Properties:
    //      type
    //          inheritance (up & down)
    //          implementation (forward, backward)
    //      fields
    //      methods
    // ----------------------------------------------------------------------

    @Override
    public List<Type> getUseTypes(TypeUse useType, Direction direction, boolean recursive, boolean refTypes) {
        return dg.getUseTypes(getId(), useType, direction, recursive, refTypes);
    }

    @Override
    public List<Field> getFields() {
        return dg.getFields(getId());
    }

    @Override
    public List<Method> getMethods() {
        return dg.getMethods(getId());
    }

    // ----------------------------------------------------------------------
    // Components/Features
    // ----------------------------------------------------------------------

    @Override
    public List<Component> getComponents() {
        return dg.getComponents(getId());
    }

    @Override
    public List<Feature> getFeatures() {
        return dg.getFeatures(getId());
    }

    // ----------------------------------------------------------------------
    // Score
    // ----------------------------------------------------------------------

    @Override
    public List<Double> getScore() {
        return (List<Double>) nv.getOrDefault(SCORE, null);
    }


    // ----------------------------------------------------------------------
    // EntryPoint
    // ----------------------------------------------------------------------

    @Override
    public boolean isEntryPoint() {
        return (boolean) nv.getOrDefault(ENTRY_POINT, Boolean.FALSE);
    }

    @Override
    public long[] getCountMethods() {
        if (!nv.containsKey(COUNT_METHODS))
            return null;
        return new long[]{
            (Long) nv.get(COUNT_METHODS),
            (Long) nv.getOrDefault(COUNT_ENTRY_POINTS, 0L)
        };
    }

    // @Override
    // public void setEntryPoint() {
    //     dg.setNodeProperty(getId(), ENTRY_POINT, Boolean.TRUE);
    // }

}

package ae.ebtic.spl.analysis.clustering;

import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import jext.graph.GraphSession;
import jext.util.Parameters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ClusteringGraph extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    public String [] keywords = {
            "Factory",
            "Pool",
            "Builder",
            "Adapter",
            "Bridge",
            "Composite",
            "Decorator",
            "Facade",
            "Proxy",
            "Iterator",
            "Interpreter",
            "Command",
            "Observer",
            "State",
            "Visitor",
            "Template",
            "Bean",
            "Query",
            "EntryKey",
            "Thread",
            "DAO",
            "Impl",
            "Data",
            "View",
            "Model",
            "Handler"
    };

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ClusteringGraph(ProjectGraphAccess pga) {
        super(pga, CLUSTER);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public void initialize() {
        super.initialize();
        this.keywords = new String[]{};
    }

    // ----------------------------------------------------------------------
    // Utilities
    // ----------------------------------------------------------------------

    public String getClusterNodeID(){
        try(GraphSession session = graphdb.connect()){
           List<Map<String, Object>> cNodes = session.queryNodes(CLUSTER,Parameters.params(PROJECT_ID,projectId)).distinct().allValues().toList();

           if(cNodes.size() == 0)
               return this.create();
           else
               return cNodes.get(0).get(GRAPH_NODE_ID).toString();
        }
    }


    public List<Map<String, Object>> getTokens(){
        List<Map<String, Object>> tokens;
        try(GraphSession session = graphdb.connect()){
            tokens = session.queryUsing("getTokenCount",Parameters.params(PROJECT_ID,projectId)).result().toList();
        }
        return tokens;
    }

    public List<Map<String,Object>> clusterDesignPattern(String model){
        List<Map<String, Object>> clusters = null;
        try (GraphSession session = graphdb.connect()) {

            if(model.equals(FEATURE))
                clusters = session.queryUsing("clusterFeaturesByDesignPatterns", Parameters.params(
                        PROJECT_ID, projectId,
                        KEYWORDS, keywords
                )).result().toList();
            else if(model.equals(TYPE))
                clusters = session.queryUsing("clusterTypesByDesignPatterns", Parameters.params(
                        PROJECT_ID, projectId,
                        KEYWORDS, keywords
                )).result().toList();
        }
        return clusters;
    }

    public List<Map<String, Object>> clusterTokensPercentage(List<Long> ids, double p, int numOfTokens){
        List<Map<String, Object>> clusters = null;
        try(GraphSession session = graphdb.connect()){

            clusters = session.queryUsing("clusterNodesByTokensWithPercentage", Parameters.params(
                    PROJECT_ID, projectId,
                    ID,ids,
                    PERCENTAGE,p,
                    "nToken", numOfTokens
            )).result().toList();
        }
        return clusters;

    }

//    public List<Map<String, Object>> clusterTokensInitialPercentageReverse(List<Long> ids, double p){
//        List<Map<String, Object>> clusters = null;
//        try(GraphSession session = graphdb.connect()){
//
//            clusters = session.queryUsing("clusterNodesByTokensInitialWithPercentageReverse", Parameters.params(
//                    PROJECT_ID, projectId,
//                    ID,ids,
//                    KEYWORDS,keywords,
//                    PERCENTAGE,p
//            )).result().toList();
//        }
//        return clusters;
//    }
//
//    public List<Map<String, Object>> clusterTokensPercentage(List<Long> ids, double p){
//        List<Map<String, Object>> clusters = null;
//        try(GraphSession session = graphdb.connect()){
//
//            clusters = session.queryUsing("clusterNodesByTokensWithPercentage", Parameters.params(
//                    PROJECT_ID, projectId,
//                    ID,ids,
//                    PERCENTAGE,p
//            )).result().toList();
//        }
//        return clusters;
//    }

    public List<Map<String, Object>> clusterTokensInitial(List<Long> ids){
        List<Map<String, Object>> clusters = null;
        try (GraphSession session = graphdb.connect()) {

            clusters = session.queryUsing("clusterNodesByTokensInitial", Parameters.params(
                    PROJECT_ID, projectId,
                    ID,ids,
                    KEYWORDS,keywords
            )).result().toList();
        }
        return clusters;
    }

    public List<Map<String, Object>> clusterTokens(List<Long> ids){
        List<Map<String, Object>> clusters = null;
        try (GraphSession session = graphdb.connect()) {

            clusters = session.queryUsing("clusterNodesByTokens", Parameters.params(
                    PROJECT_ID, projectId,
                    ID,ids
            )).result().toList();
        }
        return clusters;
    }

    //technique: 1 -> Normal Clustering, 2 -> Lowest Tokens

    public void writeClusters(List<Map<String, Object>> nodes, String model, int technique){

        if(model.equals(FEATURE))
            try (GraphSession session = graphdb.connect()) {
                session.queryUsing("writeFeatureClusters"+technique,Parameters.params(
                        NODES, nodes
                )).result();
            }
        else if(model.equals(TYPE))
            try (GraphSession session = graphdb.connect()) {
                session.queryUsing("writeTypeClusters"+technique,Parameters.params(
                        NODES, nodes
                )).result();
            }
    }

    //technique: 1 -> Normal Clustering, 2 -> Lowest Tokens
    public Map<String, Object> getClusters(String model, int technique){
        Map<String, Object> cluster = new HashMap<>();
        List<Map<String, Object>> nodes = null;
        try (GraphSession session = graphdb.connect()) {

            if(model.equals(FEATURE))
                nodes = session.queryUsing("getFeatureClusters"+technique, Parameters.params(
                        PROJECT_ID, projectId
                )).result().toList();
            else if(model.equals(TYPE))
                nodes = session.queryUsing("getTypeClusters"+technique, Parameters.params(
                    PROJECT_ID, projectId
                )).result().toList();

            //setClusterAsArray(tokens);
            setClusterAsArray(nodes);

            addComplexity(nodes,model);

            sortMap(nodes);

            cluster.put("name",getProjectName().getName());

            cluster.put("children",new ArrayList<Map<String, Object>>());

            for(Map<String, Object> m: nodes){
                placeMapInCluster(m, ((ArrayList<Integer>)m.get("cluster")), ((ArrayList<Map<String, Object>>)cluster.get("children")),"",model, technique);
            }
        }

        return cluster;

    }

    private void setClusterAsArray(List<Map<String, Object>> mapList){
        for(Map<String, Object> map: mapList){
            List<Integer> clusters = Arrays.asList(map.get("cluster").toString().split("\\."))
                    .stream()
                    .map(r -> Integer.parseInt(r)).collect(Collectors.toList());
            map.put("cluster",clusters);
        }
    }

    private void addComplexity(List<Map<String, Object>> mapList, String model){

        List<Map<String, Object>> fComplexity = null;
        try (GraphSession session = graphdb.connect()) {
            fComplexity = session.queryUsing("getFeatureFattiness", Parameters.params(
                    PROJECT_ID, projectId
            )).result().toList();
        }

        if(model.equals(FEATURE)){


            if(fComplexity != null) {
                for (Map<String, Object> map : mapList) {

                    Map<String, Object> tempF = fComplexity.stream().filter(r -> r.get(FULLNAME).toString().equals(map.get(FULLNAME).toString())).findFirst().orElse(null);

                    if (tempF != null) {
                        map.put("complex", Boolean.parseBoolean(tempF.get("fat").toString())? 1 : 0);

                    }
                }
            }
        }
        else if(model.equals(TYPE)){

            List<Map<String, Object>> typeNodes = (List<Map<String, Object>>) getProjectGraphTypes(false).get(NODES);

            for(Map<String, Object> map: mapList){
                double score;
                try {
                    score = Double.parseDouble(map.get("score").toString());
                }
                catch (Exception e){
                    score = 0;
                }
                Map<String, Object> tempT = typeNodes.stream().filter(r -> getFullName(r).equals(map.get(FULLNAME).toString())).findFirst().orElse(null);

                String role = tempT == null ? "" : tempT.get(ROLE).toString().toLowerCase();

                if(role.startsWith(FEATURE)){
                    Map<String, Object> tempF = fComplexity.stream().filter(r -> r.get(FULLNAME).toString().equals(map.get(FULLNAME).toString())).findFirst().orElse(null);
                    if (tempF != null) {
                        map.put("complex", Boolean.parseBoolean(tempF.get("fat").toString())? 1 : 3);
                    }
                }
                else if(role.startsWith(COMPONENT)){
                    map.put("complex", 5);
                }
                else if(score == 0)
                    map.put("complex", 2);
                else if(score >= 0.7)
                    map.put("complex", 4);
                else
                    map.put("complex", 0);
            }
        }
    }

    private String getFullName(Map <String, Object> r){
        return (r.containsKey(NAMESPACE)? r.get(NAMESPACE).toString() + "." + r.get(NAME).toString() : r.get(NAME).toString());
    }

    private void sortMap(List<Map<String, Object>> mapList){

        Comparator<Map<String, Object>> mapComparator = new Comparator<Map<String, Object>>() {
            public int compare(Map<String, Object> m1, Map<String, Object> m2) {
                List<Integer> l1 = (ArrayList<Integer>) m1.get("cluster");
                List<Integer> l2 = (ArrayList<Integer>) m2.get("cluster");

                int size = Math.max(l1.size(),l2.size());
                for(int i=0; i<size; i++){
                    if(i>= l1.size() && i < l2.size())
                        return -1;
                    else if(i < l1.size() && i >= l2.size())
                        return 1;
                    else if(l1.get(i) < l2.get(i))
                        return -1;
                    else if(l1.get(i) > l2.get(i))
                        return 1;
                }

                String name1 = m1.get("name").toString();
                String name2 = m2.get("name").toString();

                return name1.compareTo(name2);
            }
        };


        mapList.sort(mapComparator);

    }

    private void placeMapInCluster(Map<String, Object> m, List<Integer> clusters, List<Map<String, Object>> list, String prefix, String model, int technique){
        int current = clusters.get(0);

        while(list.size() <= current){
            list.add(new HashMap<>());
            if(list.size() == (current+1)) {
                String x = prefix.equals("") ? "" : prefix + ".";
                list.get(current).put("name", getTokenName(x + current, model, technique));
                list.get(current).put("children", new ArrayList<Map<String, Object>>());
            }
        }

        if(clusters.size() == 1){
            Map<String, Object> tempMap = new HashMap<>();
            tempMap.put("name",m.get("name"));
            tempMap.put("value", 1);
            if(m.containsKey("complex"))
                tempMap.put("complex",m.get("complex"));
            ((ArrayList<Map<String, Object>>)list.get(current).get("children")).add(tempMap);
        }
        else{
            clusters.remove(0);
            placeMapInCluster(m,clusters,((ArrayList<Map<String, Object>>)list.get(current).get("children")),prefix.equals("") ? ""+current : prefix+"."+current, model, technique);
        }
    }

    private String getTokenName(String prefix, String model, int technique){

        List<Map<String, Object>> tokens;

        try (GraphSession session = graphdb.connect()) {
           tokens = session.queryUsing("find"+capitalize(model)+"ClusterToken"+technique,Parameters.params(
                    PROJECT_ID, projectId,
                   CLUSTER,prefix+"."
            )).result().toList();

           if(tokens.size() == 0)
               tokens = session.queryUsing("find"+capitalize(model)+"ClusterTokenExact"+technique,Parameters.params(
                       PROJECT_ID, projectId,
                       CLUSTER,prefix
               )).result().toList();
        }
        String clusterName = "";

        boolean first = true;
        for(Map<String, Object> map: tokens){
            if(!first) clusterName+="_";
            first = false;
            clusterName += map.getOrDefault(NAME,"");
        }

        return clusterName;
//        Comparator<Map<String, Object>> mapComparator = new Comparator<Map<String, Object>>() {
//            public int compare(Map<String, Object> m1, Map<String, Object> m2) {
//                int count1 = Integer.parseInt(m1.get("count").toString());
//                int count2 = Integer.parseInt(m2.get("count").toString());
//                return Integer.compare(count1,count2);
//            }
//        };
//        return tokens.stream().filter(r -> r.get("cluster").toString().startsWith(prefix)).max(mapComparator).get().get("name").toString();
    }

    // public void delete() {
    //     try (GraphSession session = graphdb.connect()) {
    //         session.queryUsing("DeleteClusters",Parameters.params(
    //                 PROJECT_ID, projectId
    //         )).result();
    //     }
    //     super.delete();
    // }

    @Override
    protected void deleteModelElements(String projectId) {
        try (GraphSession session = graphdb.connect()) {
            session.queryUsing("DeleteClusters", Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }

    private static String capitalize(String str) {
        if(str == null || str.isEmpty()) {
            return str;
        }

        return str.substring(0, 1).toUpperCase() + str.substring(1);
    }

}

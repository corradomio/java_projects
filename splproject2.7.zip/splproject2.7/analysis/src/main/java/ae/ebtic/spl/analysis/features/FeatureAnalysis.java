package ae.ebtic.spl.analysis.features;

import java.util.List;

public interface FeatureAnalysis {

    FeatureAnalysis addListener(AnalyzerListener createFeatures);

    void analyze(List<String> features, List<List<String>> components);
    void analyze();

    void abort();

    void delete();
}

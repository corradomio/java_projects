package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.components.util.ComponentInfo;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.logging.Logger;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public abstract class AbstractComponentAnalyzer implements ComponentAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // if the project is aborted
    protected boolean aborted;

    // logger
    protected Logger logger;

    // listeners
    protected AbstractComponentAnalyzer.Listeners listeners = new Listeners();

    protected String componentProjectId;

    // configuration
    protected AnalyzerConfig config;

    // handle the component graph
    protected ComponentGraph cg;

    // Local Component Graph
    protected SimpleDirectedGraph<String, DefaultEdge> lcg;

    protected int processedComponents, totalComponents;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected AbstractComponentAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    protected void initialize() {
        logger = Logger.getLogger(getClass(), config.getProjectName().toString());

        GraphConfig config = new GraphConfig()
                .setGraphDatabase(this.config.getGraphDatabase())
                .setProjectName(this.config.getProjectName())
                .setParameters(this.config.getParameters());

        //cg = ComponentGraph.newComponentGraph(config);
        cg = ProjectGraphAccess.newProjectGraphAccess(config).getComponentGraph();

       // return this;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void abort() {
        this.aborted = true;
    }

    /**
     * Delete the component model
     */
    public void delete() {
        cg.delete();
    }


    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public abstract void analyze() ;
    public abstract void createComponentGraph(List<Map<String, Object>> memberValues, int depth);
    public abstract void createComponents(List<Map<String, Object>> membersValues, int depth);

    // ----------------------------------------------------------------------
    // Graph Operations
    // ----------------------------------------------------------------------

    /**
     * Create the 'project component': this node is used ONLY to check if in the database
     * is present the 'component model' for the current project
     */
    protected void createComponentNode() {
        if (aborted) return;

        //listeners.fireOnProject(project);

        componentProjectId = cg.create();
    }

    protected void analysisDone(boolean failed) {
        cg.setStatus((failed || aborted) ? STATUS_INVALID : STATUS_VALID, null);

        listeners.fireDone();
    }

    protected String createComponent(Map<String, Object> memberValues, int depth) {
        if (aborted) return"";
        String memberId = (String) memberValues.get(GRAPH_NODE_ID);

        listeners.fireComponentsProcessed(++processedComponents, totalComponents);

        // create the 'component' node
        ComponentInfo ci = cg.createComponent(memberValues, depth);

        logger.debugf("Created component %s for member %s", ci.componentId, memberId);

        lcg.addVertex(ci.componentId);

        return ci.componentId;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    protected int setTotalComponents(int totalComponents) {
        this.totalComponents = totalComponents;
        this.processedComponents = 0;
        return totalComponents;
    }

    static class Listeners {

        private List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireCreateComponents(int totalComponents) {
            listeners.forEach(l -> l.onCreateComponents(totalComponents) );
        }

        void fireAggregateComponents(int totalComponents) {
            listeners.forEach(l -> l.onAggregateComponents(totalComponents) );
        }

        void fireComponeDependencies(int totalComponents) {
            listeners.forEach(l -> l.onComponentsDependencies(totalComponents) );
        }

        void fireComponentsProcessed(int componentsProcessed, int totalComponents) {
            listeners.forEach(l -> l.onComponentsProcessed(componentsProcessed, totalComponents) );
        }

        void fireCreateDependencies(int totalDependencies) {
            listeners.forEach(l -> l.onCreateDependencies(totalDependencies) );
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone() );
        }

    }

    public ComponentAnalysis addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }
}

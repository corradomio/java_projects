package ae.ebtic.spl.analysis.dependencyv2;

public interface DependencyAnalysis {

    DependencyAnalysis addListener(AnalyzerListener analyzerListener);

    void analyze();

    void abort();

    void delete();
}

package ae.ebtic.spl.analysis.sourcecode.analyzer;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import jext.javassist.TypeDesc;
import jext.logging.Logger;
import jext.lang.JavaUtils;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ReferencedType extends NamedObject implements RefType {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    public static final ReferencedType JAVA_LANG_VOID = new ReferencedType(JavaUtils.JAVA_LANG_VOID);
    public static final ReferencedType JAVA_LANG_OBJECT = new ReferencedType(JavaUtils.JAVA_LANG_OBJECT);
    public static final ReferencedType JAVA_LANG_CLASS = new ReferencedType(JavaUtils.JAVA_LANG_CLASS);
    public static final ReferencedType ARRAY = new ReferencedType(JavaUtils.ARRAY);

    // ----------------------------------------------------------------------
    // Fields
    // ----------------------------------------------------------------------

    protected static Logger logger = Logger.getLogger(ReferencedType.class);

    public int nTypeParams;
    public TypeRole role = TypeRole.UNKNOWN;
    public Library library;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ReferencedType(Name name, Library library) {
        super(name);
        this.library = library;
        this.role = TypeRole.UNKNOWN;
    }

    public ReferencedType(String fullName, Library library) {
        super(new ObjectName(fullName));
        this.library = library;
        this.role = TypeRole.UNKNOWN;
    }

    public ReferencedType(String fullName) {
        super(new ObjectName(fullName));
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public boolean isType() { return !role.equals(TypeRole.UNKNOWN); }

    @Override
    public Type asType() {
        throw new ClassCastException();
    }

    @Override
    public int getTypeParametersCount() {
        return nTypeParams;
    }

    @Override
    public TypeRole getRole() {
        return role;
    }

    @Override
    public Library getLibrary() {
        return library;
    }

    @Override
    public String getLibraryId() {
        if (library != null)
            return library.getId();
        else
            return null;
    }


    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    public static String toString(RefType refType) {
        return refType.getName().toString();
    }

}

package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import com.github.javaparser.symbolsolver.model.resolution.TypeSolver;
import jext.javaparser.JavaParserPool;
import jext.javaparser.symbolsolver.resolution.typesolvers.JavaParserPoolTypeSolver;
import jext.logging.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class ModulesRegistry extends NameRegistry implements TypeRegistry {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    protected Logger logger = Logger.getLogger(getClass());

    private static class MethodInfo {
        MethodName methodName;
        String methodId;

        MethodInfo(MethodName methodName, String methodId) {
            this.methodName = methodName;
            this.methodId = methodId;
        }

        int getNumParameters() {
            return methodName.getNumParameters();
        }

        String getSignature() {
            return methodName.getSignature();
        }

        boolean matchSignature(String signature) {
            return true;
        }
    }

    private static class Info {

        // sourceName -> sourceId
        NameMap<String> sourceMap = new NameMap<String>();

        // typeName -> typeId
        NameMap<String> typeMap = new NameMap<String>();

        // methodName -> List[  [[name, nParameters, signature], methodId] ]
        //Map<Name, List<MethodInfo>> methodMap = /*new NameMap();*/ new ConcurrentHashMap<>();
        NameMap<List<MethodInfo>> methodMap = new NameMap<>();
    }

    // module name -> Info
    //private final Map<Name, Info> infoMap = Collections.synchronizedMap(new TreeMap<>());
    private final NameMap<Info> infoMap = new NameMap<>();

    // ----------------------------------------------------------------------
    // Module objects
    // ----------------------------------------------------------------------

    public String getModuleId(Module module) {
        return super.getId(module.getName());
    }

    public void registerModule(String moduleId, Module module) {
        Name moduleName = module.getName();
        super.register(moduleId, moduleName);
        infoMap.put(moduleName, new Info());
    }

    // ----------------------------------------------------------------------
    // Source objects
    // ----------------------------------------------------------------------

    public String getSourceId(Source source) {
        return getSourceId(source.getName(), source.getModule());
    }

    public void registerSource(String sourceId, Source source) {
        registerSource(sourceId, source.getName(), source.getModule());
    }

    // ---

    private String getSourceId(Name sourceName, Module module) {
        Name containerName = module.getName();
        checkContainer(containerName);
        return infoMap.get(containerName).sourceMap.getOrDefault(sourceName, null);
    }

    private void registerSource(String sourceId, Name sourceName, Module module) {
        Name containerName = module.getName();
        checkContainer(containerName);
        Info info = infoMap.get(containerName);
        info.sourceMap.put(sourceName, sourceId);
    }

    // ----------------------------------------------------------------------
    // Type objects
    // ----------------------------------------------------------------------

    public String getTypeId(Name typeName, Module module) {
        return getTypeId(typeName, module.getName());
    }

    public void registerType(String typeId, Name typeName, Module module) {
        registerType(typeId, typeName, module.getName());
    }

    public String getTypeId(Name typeName, Named module) {
        return getTypeId(typeName, module.getName());
    }

    public void registerType(String typeId, Name typeName, Named module) {
        registerType(typeId, typeName, module.getName());
    }

    // ---

    private String getTypeId(Name typeName, Name moduleName) {
        checkContainer(moduleName);
        return infoMap.get(moduleName).typeMap.getOrDefault(typeName, null);
    }

    private void registerType(String typeId, Name typeName, Name moduleName) {
        checkContainer(moduleName);
        Info info = infoMap.get(moduleName);
        info.typeMap.put(typeName, typeId);
    }

    private void checkContainer(Name containerName) {
        if (!infoMap.containsKey(containerName))
            infoMap.put(containerName, new Info());
    }

    // ----------------------------------------------------------------------
    // Method objects
    // ----------------------------------------------------------------------

    public void registerMethod(String methodId, MethodName methodName, Module module) {
        registerMethod(methodId, methodName, module.getName());
    }

    public boolean isRegisteredMethod(MethodName methodName, Module module) {
        return isRegisteredMethod(methodName, module.getName());
    }

    public String getMethodId(MethodName methodName, Module module) {
        return getMethodId(methodName, module.getName());
    }

    // -------

    private void registerMethod(String methodId, MethodName methodName, Name containerName) {
        Info info = infoMap.get(containerName);

        synchronized (info.methodMap) {
            if (!info.methodMap.containsKey(methodName))
                info.methodMap.put(methodName, new ArrayList<>());
            info.methodMap.get(methodName).add(new MethodInfo(methodName, methodId));
        }
        // info.methodMap.put(methodName, methodId);
    }

    private boolean isRegisteredMethod(MethodName methodName, Name containerName) {
        Info info = infoMap.get(containerName);
        if (!info.methodMap.containsKey(methodName))
            return false;
        for (MethodInfo mi : info.methodMap.get(methodName))
            if (mi.getNumParameters() == methodName.getNumParameters())
                return true;
        return false;
    }

    private String getMethodId(MethodName methodName, Name containerName) {
        Info info = infoMap.get(containerName);

        // method not defined!
        if (!info.methodMap.containsKey(methodName))
            return null;

        List<MethodInfo> minfos = new ArrayList<>();
        List<MethodInfo> ainfos = info.methodMap.get(methodName);
        if (ainfos != null)
        for (MethodInfo mi : info.methodMap.get(methodName))
            if (mi.getNumParameters() == methodName.getNumParameters())
                minfos.add(mi);

        // no method with the same number of parameters
        if (minfos.isEmpty())
            return null;

        // there is ONLY a method with exactly the same number of parameters
        if (minfos.size() == 1)
            return minfos.get(0).methodId;

        // there are multiple methods the the same number of parameters
        // it is necessary to find the method that matches the signature
        for (MethodInfo mi : minfos)
            if (mi.matchSignature(methodName.getSignature()))
                return mi.methodId;

        // it is not possible to identify the correct method using the signatures
        // FOR now we select a random method
        MethodInfo mi = minfos.get(0);
        logger.warnf("Unable to find a method with signature %s. Selected %s",
            methodName.getSignature(),
            mi.getSignature());

        return mi.methodId;

        // return infoMap.get(containerName).methodMap.getOrDefault(methodName, null);
    }

    // ----------------------------------------------------------------------
    // Type Solvers
    // ----------------------------------------------------------------------

    private final Map<String, JavaParserPool> javaParsers = new HashMap<>();

    public TypeSolver getTypeSolver(Module module) {
        JavaParserPool pool = getJavaParserPool(module);
        return new JavaParserPoolTypeSolver(module.getName().getName(), pool);
    }

    public JavaParserPool getJavaParserPool(Module module) {
        synchronized (javaParsers) {
            String name = module.getName().getFullName();
            if (!javaParsers.containsKey(name))
                javaParsers.put(name, JavaParserPool.newPool(name));
            return javaParsers.get(name);
        }
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import jext.util.MimeTypes;
import jext.util.PathUtils;

import java.io.File;
import java.util.Map;

public class ResourceBase extends GraphNode implements Resource {

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    protected DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ResourceBase(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getPath() { return (String)nv.getOrDefault(PATH, null); }

    @Override
    public File getFile() {
        return new File(getPath());
    }

    @Override
    public String getDigest() {
        return (String)nv.getOrDefault(DIGEST, UNKNOWN);
    }

    @Override
    public String getMimeType() {
        return MimeTypes.guessMimeType(PathUtils.getName(getPath()));
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public String getModuleId() {
        return (String)nv.get(MODULE_ID);
    }

    @Override
    public Module getModule() {
        String moduleId = (String)nv.getOrDefault(MODULE_ID, null);

        return dg.getModule(moduleId);
    }

}

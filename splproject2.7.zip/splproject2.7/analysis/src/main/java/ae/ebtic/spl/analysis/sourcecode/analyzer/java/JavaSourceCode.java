package ae.ebtic.spl.analysis.sourcecode.analyzer.java;

import ae.ebtic.spl.analysis.sourcecode.analyzer.ImplementedType;
import ae.ebtic.spl.analysis.sourcecode.analyzer.SourceCode;
import ae.ebtic.spl.analysis.sourcecode.analyzer.util.FastJavaParser;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

public class JavaSourceCode extends SourceCode {

    private FastJavaParser parser;

    public JavaSourceCode(File file, Module module) {
        super(file, module);
        this.parser = new FastJavaParser(file);
    }

    @Override
    public List<Type> getTypes() {
        Name declaredType = parser.getType();
        if (declaredType == null)
            return Collections.emptyList();

        TypeRole role = parser.getRole();
        return Collections.singletonList(new ImplementedType(declaredType, role, this));
    }

    @Override
    public List<RefType> getUsedTypes() {
        List<Name> importedClasses = parser.getImportedClasses();
        if (importedClasses.isEmpty())
            return Collections.emptyList();

        return importedClasses.stream()
            .map(ImplementedType::new)
            .collect(Collectors.toList());
    }

    public FastJavaParser getParser() {
        return parser;
    }
}

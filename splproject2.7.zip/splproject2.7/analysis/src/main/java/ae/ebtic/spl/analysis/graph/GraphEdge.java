package ae.ebtic.spl.analysis.graph;

import java.util.List;
import java.util.Map;

public class GraphEdge {
    public String edgeType;
    public String subType;
    public String sourceId;
    public String targetId;
    public Map<String, Object> nv;
    public List<Long> index;
}

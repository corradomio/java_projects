package ae.ebtic.spl.analysis.sourcecode.analyzer.configuration;


import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public abstract class CommonConfiguration implements ModuleConfiguration {

    protected Project project;
    protected File configurationFile;
    protected File configurationDir;
    protected Properties properties = new Properties();

    protected CommonConfiguration(File configurationFile) {
        this.configurationFile = configurationFile;
        this.configurationDir = configurationFile.getParentFile();
    }

    @Override
    public boolean isValid() {
        return true;
    }

    @Override
    public MavenCoords getMavenCoords() {
        return null;
    }

    public List<String> getMavenRepositories() {
        return Collections.emptyList();
    }

    @Override
    public Set<MavenCoords> getMavenDependencies() {
        return Collections.emptySet();
    }

    @Override
    public ModuleConfiguration setDownloader(Project project) {
        this.project = project;
        return this;
    }

    @Override
    public ModuleConfiguration addProperties(Properties props) {
        properties.putAll(props);
        return this;
    }

    // @Override
    // public Set<MavenCoords> getLibraries() {
    //     return Collections.emptySet();
    // }

    @Override
    public Set<String> getDependencies(String projectDir) {
        return Collections.emptySet();
    }
}

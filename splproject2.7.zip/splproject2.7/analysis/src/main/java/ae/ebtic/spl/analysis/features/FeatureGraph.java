package ae.ebtic.spl.analysis.features;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentGraph;
import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.Direction;
import jext.graph.GraphSession;
import jext.graph.NodeId;
import jext.util.Parameters;
import jext.util.StringUtils;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;
import org.jgrapht.traverse.BreadthFirstIterator;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import org.apache.poi.common.usermodel.HyperlinkType;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class FeatureGraph extends ProjectModelGraph  {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private Comparator<Map<String, Object>> FEATURE_COMPARATOR = (m1, m2) -> {
        Integer classes2 = Integer.parseInt(m2.get(CLASSES).toString());
        Integer classes1 = Integer.parseInt(m1.get(CLASSES).toString());
        return classes2.compareTo(classes1);
    };

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public FeatureGraph(ProjectGraphAccess pga) {
        super(pga, FEATURE);
    }

    // ----------------------------------------------------------------------
    // Feature operations
    // ----------------------------------------------------------------------

    public Feature newFeature(String fullname) {
        Map<String, Object> nv = new HashMap<>();
        nv.put(FULLNAME, fullname);
        nv.put(NAME, StringUtils.lastOf(fullname, "."));
        nv.put(ROLE, FEATURE);
        nv.put(COUNT, 0L);
        nv.put(PROJECT_ID, projectId);
        nv.put(GRAPH_NODE_ID, UNKNOWN);
        nv.put(GRAPH_NODE_TYPE, FEATURE);
        return FeatureNode.of(this, nv);
    }

    public String/*featureId*/ createFeature(Component component) {
        Map<String, Object> nv = component.getValues();
        String componentId = nv.get(GRAPH_NODE_ID).toString();

        Parameters nparams = Parameters.params(
            PROJECT_ID, projectId,
            NAME, nv.get(NAME),
            FULLNAME, nv.get(FULLNAME),
            COMPONENT_ID, componentId,
            TYPE_ID, nv.get(TYPE_ID),
            COUNT, nv.get(COUNT),

            CLASSES, nv.get(CLASSES),
            COUNT_TYPES, nv.get(COUNT_TYPES),

            ROLE, ROLE_FEATURE
        );

        try(GraphSession session = graphdb.connect()) {
            String featureId = session.createNode(FEATURE, nparams);

            session.createEdge(CONTAINS, featureId, componentId, Parameters.params(TYPE, COMPONENT));

            return featureId;
        }
    }

    public String/*featureId*/ createFeature(String featureName, List<String> componentIds) {
        if (componentIds.isEmpty())
            return null;

        String componentId = componentIds.get(0);

        Component component = pga.getComponentGraph().getComponent(componentId);

        Parameters nparams = Parameters.params(
            PROJECT_ID, projectId,
            NAME, featureName,
            FULLNAME, featureName,
            COMPONENT_ID, componentId,
            TYPE_ID, component.getTypeId(),
            COUNT, (long)componentIds.size(),

            ROLE, ROLE_FEATURE
        );
        try(GraphSession session = graphdb.connect()) {
            String featureId = session.createNode(FEATURE, nparams);

            session.createEdges(CONTAINS, featureId, componentIds, Parameters.params(TYPE, COMPONENT));

            setTypesCount(featureId);

            return featureId;
        }
    }

    private void setTypesCount(String featureId) {

        try(GraphSession session = graphdb.connect()) {
            // set component.countTypes (== classes)
            long nTypes = session.queryAdjacentNodes(featureId,
                CONTAINS, Direction.Output, true,
                TYPE, Parameters.params(PROJECT_ID, projectId), Parameters.empty())
                .distinct().count();

            session.setNodeProperties(featureId, Parameters.params(
                CLASSES, nTypes,        // COMPATIBILITY
                COUNT_TYPES, nTypes
            ));
        }
    }

    public void connectFeatureToComponents(String featureId, Collection<String> componentIds) {
        try (GraphSession session = graphdb.connect()) {
            session.createEdges(CONTAINS, featureId, componentIds,
                Parameters.params(TYPE, COMPONENT));
            session.setNodeProperty(featureId, COUNT, (long)componentIds.size());
        }
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public boolean isEntryPoint(String featureId) {
        try(GraphSession session = graphdb.connect()) {
            return session.queryAdjacentNodes(featureId, CONTAINS,
                Direction.Output, true,
                TYPE, Parameters.params(ENTRY_POINT, true),
                Parameters.empty()).count() > 0;
        }
    }

    // ----------------------------------------------------------------------
    // Operations: features
    // ----------------------------------------------------------------------

    public long getFeaturesCount() {
        try (GraphSession session = graphdb.connect()) {
            return session.queryNodes(FEATURE, Parameters.params(
                PROJECT_ID, projectId,
                ROLE, ROLE_FEATURE
            )).count();
        }
    }

    public List<Feature> getFeatures() {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(FEATURE, Parameters.params(
                    PROJECT_ID, projectId,
                    ROLE, ROLE_FEATURE
            )).allValues().toList();
        }

        return FeatureNode.of(FeatureGraph.this, nvlist);
    }

    public Feature getFeature(String featureId) {
        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            nv = session.getNodeValues(featureId);
        }
        return FeatureNode.of(this, nv);
    }

    public Feature findFeatureByName(String featureName){
        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            nv = session.queryNodes(FEATURE, Parameters.params(
                    PROJECT_ID, projectId,
                    FULLNAME, featureName
            )).values();
        }
        return FeatureNode.of(this, nv);
    }

    // ----------------------------------------------------------------------
    // Types
    // ----------------------------------------------------------------------

    public List<Type> getFeatureTypes(String featureId) {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(featureId,
                CONTAINS, Direction.Output, true,
                TYPE, Parameters.params(PROJECT_ID, projectId),
                Parameters.empty()).allValues().toList();
        }

        DependencyGraph dg = pga.getDependencyGraph();

        return TypeNode.of(dg, nvlist);
    }

    // ----------------------------------------------------------------------
    // Components
    // ----------------------------------------------------------------------

    public List<Component> getFeatureComponents(String featureId) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(featureId,
                CONTAINS, Direction.Output, false,
                COMPONENT, Parameters.params(
                    PROJECT_ID, projectId
                ),
                Parameters.empty()).allValues().toList();
        }

        if (nvlist == null || nvlist.size() == 0)
            return Collections.emptyList();

        ComponentGraph cg = pga.getComponentGraph();

        return nvlist
            .stream()
            .map(nv -> ComponentNode.of(cg, nv))
            //.filter(dt -> dt.isValid())
            .collect(Collectors.toList());
    }

    public List<Feature> getFeaturesByComponents(List<Integer> componentIds){
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryUsing("findFeaturesfromComponents", Parameters.params(
                    PROJECT_ID, projectId,
                    ID, componentIds
            )).allValues().toList();
        }
        return FeatureNode.of(this, nvlist);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public List<Component> findDAGRoots() {
        ComponentGraph cg = pga.getComponentGraph();

        try(GraphSession session = graphdb.connect()) {
            return session.queryNodes(COMPONENT, Parameters.params(
                PROJECT_ID, projectId,
                ROLE, CROLE_DAGROOT
            )).allValues().toList()
                .stream()
                .map(nv -> ComponentNode.of(cg, nv))
                .collect(Collectors.toList());
        }
    }

    // ----------------------------------------------------------------------
    // Operations (CREATE session)
    // ----------------------------------------------------------------------

    public List<Map<String, Object>> getComponentsGraph(String featureId) {
        List<Map<String, Object>> nvlist;
        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    FEATURE_ID, NodeId.asId(featureId));

            nvlist = session.queryUsing("findComponentsLevelOne", params)
                    .distinct().allValues().toList();
        }

        if (nvlist == null || nvlist.size() == 0)
            return Collections.emptyList();

        ComponentGraph cg = pga.getComponentGraph();

        return nvlist
                .stream()
                .map(nv -> ComponentNode.of(cg, nv))
                .map(r -> {
                    return new jext.util.HashMap<String, Object>()
                            .put_(ID, r.getId())
                            .put_(LABEL, r.getName().getName())
                            .put_(ROLE, "COMPONENT"+r.getDepth())
                            .put_("expanded",false);
                })
                .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Model Graph
    // ----------------------------------------------------------------------

    public Map<String, Object> getModelGraph() {
        List<Map<String, Object>> vlist;
        List<Map<String, Object>> elist;

        try (GraphSession session = graphdb.connect()) {

            vlist = session.queryNodes(FEATURE, Parameters.params(
                    PROJECT_ID, projectId
            )).allValues().toList();

            elist = session.queryEdges(USES,
                    FEATURE, Parameters.params(PROJECT_ID, projectId),
                    FEATURE, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).result().toList();
        }

        // compose the nodeList
        List<Map<String, Object>> nodes =
                vlist.stream()
                        .map(r -> {
                            return new jext.util.HashMap<String, Object>()
                                    .put_(ID,r.get(GRAPH_NODE_ID).toString())
                                    .put_(LABEL, r.get(NAME))
                                    .put_(METADATA, r);
                        })
                        .collect(Collectors.toList());

        // compose the edge list
        List<Map<String, Object>> edges =
                elist.stream()
                        .map(r -> {
                            String fromId = r.get("idfrom").toString();
                            String toId = r.get("idto").toString();

                            return new jext.util.HashMap<String, Object>()
                                    .put_(EDGE_SOURCE, fromId)
                                    .put_(EDGE_TARGET, toId)
                                    .put_(EDGE_DIRECTED, true)
                                    .put_(EDGE_RELATION, USES)
                                    .put_(METADATA, Collections.emptyMap());
                        })
                        .collect(Collectors.toList());

        // compose the graph descriptor
        jext.util.HashMap<String, Object> graph = new jext.util.HashMap<>();
        graph
                .put_(GRAPH_DIRECTED, true)
                .put_(GRAPH_TYPE, "FeatureModel graph")
                .put_(LABEL, config.getProjectName().getFullName())
                .put_(GRAPH_NODES, nodes)
                .put_(GRAPH_EDGES, edges);

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getSmallModelGraph() {
        List<Map<String, Object>> vlist;
        List<Map<String, Object>> elist;

        try (GraphSession session = graphdb.connect()) {

            vlist = session.queryNodes(FEATURE, Parameters.params(
                    PROJECT_ID, projectId
            )).allValues().toList();

            elist = session.queryEdges(USES,
                    FEATURE, Parameters.params(PROJECT_ID, projectId),
                    FEATURE, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).result().toList();
        }

        // compose the nodeList
        List<Map<String, Object>> nodes =
                vlist.stream()
                        .map(r -> {
                            return new jext.util.HashMap<String, Object>()
                                    .put_(ID, r.get(GRAPH_NODE_ID).toString())
                                    .put_(LABEL, r.get(NAME))
                                    .put_(ROLE, r.get(ROLE))
                                    .put_(CLASSES,r.get(CLASSES) != null ? r.get(CLASSES) : 0)
                                    .put_("expanded",r.get(ROLE).equals("PROJECT"));
                        })
                        .collect(Collectors.toList());

        // compose the edge list
        List<Map<String, Object>> edges =
                elist.stream()
                        .map(r -> {
                            String fromId = r.get("idfrom").toString();
                            String toId = r.get("idto").toString();

                            return new jext.util.HashMap<String, Object>()
                                    .put_(EDGE_SOURCE, fromId)
                                    .put_(EDGE_TARGET, toId)
                                    //.put_(EDGE_DIRECTED, true)
                                    .put_(LABEL, USES);
                            //.put_(METADATA, jext.collection.Collections.emptyMap());
                        })
                        .collect(Collectors.toList());

        Collections.sort(nodes, FEATURE_COMPARATOR);

        // compose the graph descriptor
        jext.util.HashMap<String, Object> graph = new jext.util.HashMap<>();
        graph
                // .put_(GRAPH_DIRECTED, true)
                // .put_(GRAPH_TYPE, "FeatureModel graph")
                //.put_(LABEL, config.getProjectName().getFullName())
                .put_(GRAPH_NODES, nodes)
                .put_(GRAPH_EDGES, edges);

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> findIntegrationPoints(List<String> featureIds){
        List<Map<String, Object>> graph;
        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, NodeId.asIds(featureIds));

            graph = session.queryUsing("findIntegrationPointsWithLibraries", params).result().toList();
        }
        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    // ----------------------------------------------------------------------

    public void setTypesCount(){
        if(checkSetTypeCount())
            return;
        try (GraphSession session = graphdb.connect()) {
            session.queryUsing("setFeatureTypesCount",Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }

    public Map<String, Object> getTypesCount(){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);
            graph = session.queryUsing("getFeatureTypesCount", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> listTypes(String featureId){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, NodeId.asId(featureId));
            graph = session.queryUsing("getFeatureTypes", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    private String getFeatureTypeId(String featureId){
        List<Map<String, Object>> nodes = (List<Map<String, Object>>) listTypes(featureId).get(GRAPH);
        Feature feature = getFeature(featureId);
        String fName = feature.getName().getFullName();
        return nodes.stream().filter(n -> n.get("fullName").equals(fName)).findFirst().get().get(ID).toString();
    }

    public Map<String, Object> listTypesWInterfaces(String featureId, boolean links, boolean implementation){
        jext.util.HashMap<String, Object> graph = new jext.util.HashMap<>();
        List<Map<String, Object>> types = null;
        List<Map<String, Object>> edges = null;
        try (GraphSession session = graphdb.connect()) {

            List<String> featureIds = new ArrayList<>();
            featureIds.add(featureId);

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, NodeId.asIds(featureIds));

            types = session.queryUsing("findTypesFromFeaturesWithIDs",params).distinct().allValues().toList();

            if(implementation) {

                List<String> allIds = types.stream().map(nv -> nv.get(GRAPH_NODE_ID).toString())
                        .collect(Collectors.toList());

                List<String> interfaceIds = types.stream().filter(nv -> nv.get(ROLE).toString().equals(TROLE_INTERFACE))
                        .map(nv -> nv.get(GRAPH_NODE_ID).toString())
                        .collect(Collectors.toList());

                Parameters interfaceParams = Parameters.params(
                        PROJECT_ID, projectId,
                        ID, NodeId.asIds(interfaceIds));

                List<Map<String, Object>> implementationTypes = session.queryUsing(
                    "getTypeImplementationsByIds",
                    interfaceParams)
                    .distinct()
                    .allValues()
                    .toList();

                implementationTypes = implementationTypes
                    .stream()
                    .filter(nv -> allIds.stream().noneMatch(id -> id.equals(nv.get(GRAPH_NODE_ID).toString())))
                    .collect(Collectors.toList());

                types.addAll(implementationTypes);
            }


            if(links){

                Parameters typeParams = Parameters.params(
                        PROJECT_ID, projectId,
                        TYPE, TYPE);

                edges = session.queryEdges(USES, TYPE, typeParams,TYPE, typeParams, Parameters.empty())
                    .result().toList();

                Set<String> allIds = types.stream()
                        .map(nv -> nv.get(GRAPH_NODE_ID).toString())
                        .collect(Collectors.toSet());

                edges = edges.stream().filter(nv ->
                        allIds.contains(nv.get(EDGE_FROM).toString()) &&
                        allIds.contains(nv.get(EDGE_TO).toString()))
                        .collect(Collectors.toList());
            }

        }

        List<Map<String, Object>> typesFinal = types.stream().map(nv -> {

            jext.util.HashMap<String, Object> node = new jext.util.HashMap<String, Object>()
                    .put_(ID, Long.parseLong(nv.get(GRAPH_NODE_ID).toString()))
                    .put_(NAME, nv.get(NAME))
                    .put_(ROLE, nv.get(ROLE))
                    .put_(NAMESPACE, nv.get(NAMESPACE))
                    .put_(SCORE, nv.get(SCORE));

            return node;
        }).collect(Collectors.toList());

        graph.put(GRAPH_NODES, typesFinal);

        if(links){
            List<Map<String, Object>> edgesFinal = edges
                    .stream()
                    .map(r -> {
                        return new jext.util.HashMap<String, Object>()
                                .put_(SOURCE, r.get("idfrom"))
                                .put_(EDGE_TARGET, r.get("idto"))
                                .put_(USES, r.get(USES))
                                .put_(ID,r.get("idfrom")+"_"+r.get("idto"));
                    })
                    .collect(Collectors.toList());
            graph.put_(GRAPH_EDGES,edgesFinal);
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> listTypesWInterfacesComplete(String featureId, boolean links, boolean implementation){
        jext.util.HashMap<String, Object> graph = new jext.util.HashMap<>();
        List<Map<String, Object>> types = null;
        List<Map<String, Object>> edges = null;
        try (GraphSession session = graphdb.connect()) {

            List<String> featureIds = new ArrayList<>();
            featureIds.add(featureId);
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, featureIds);

            types = session.queryUsing("findTypesFromFeaturesWithIDs",params).distinct().allValues().toList();

            if(implementation) {

                List<Map<String, Object>> typesToCheck = types;

                while(!typesToCheck.isEmpty()) {

                    List<Integer> allIds = types.stream().map(i -> Integer.parseInt(i.get(GRAPH_NODE_ID).toString()))
                            .collect(Collectors.toList());

                    List<Integer> interfaceIds = typesToCheck.stream().filter(i -> i.get(ROLE).toString().equals(TROLE_INTERFACE))
                            .map(i -> Integer.parseInt(i.get(GRAPH_NODE_ID).toString()))
                            .collect(Collectors.toList());

                    Parameters interfaceParams = Parameters.params(
                            PROJECT_ID, projectId,
                            ID, interfaceIds);

                    List<Map<String, Object>> implementationTypes = session.queryUsing("getTypeImplementationsAndExtendsByIds", interfaceParams).distinct().allValues().toList();

                    implementationTypes = implementationTypes.stream().filter(i -> allIds.stream().noneMatch(k -> k.toString().equals(i.get(GRAPH_NODE_ID).toString())))
                            .collect(Collectors.toList());
                    types.addAll(implementationTypes);

                    List<Map<String, Object>> finalTypes = types;

                    List<Map<String, Object>> implementationClosureTypes = new ArrayList<>();

                    for (Map<String, Object> tempImplementation: implementationTypes) {
                        String tempId = tempImplementation.get(GRAPH_NODE_ID).toString();

                        Parameters closureParams = Parameters.params(PROJECT_ID, projectId,
                                ID,Integer.parseInt(tempId));
                        List<Map<String, Object>> tempClosures = session.queryUsing("findTypeClosureAlgorithm", closureParams).distinct().allValues().toList();

                        tempClosures = tempClosures.stream().filter(i -> {
                            String id = i.get(GRAPH_NODE_ID).toString();
                            return implementationClosureTypes.stream().noneMatch(k -> k.get(GRAPH_NODE_ID).toString().equals(id));
                        }).collect(Collectors.toList());

                        implementationClosureTypes.addAll(tempClosures);
                    }

                    typesToCheck = implementationClosureTypes.stream().filter(i -> finalTypes.stream().noneMatch(k -> k.get(GRAPH_NODE_ID).toString().equals(i.get(GRAPH_NODE_ID).toString())))
                            .collect(Collectors.toList());

                    types.addAll(typesToCheck);

                }
            }


            if(links){

                Parameters edgeParams = Parameters.params(
                        PROJECT_ID, projectId,
                        TYPE, TYPE);

                edges = session.queryEdges(USES,TYPE,edgeParams,TYPE,edgeParams,Parameters.empty()).result().toList();

                List<Integer> allIds = types.stream()
                        .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                        .boxed()
                        .collect(Collectors.toList());

                edges = edges.stream().filter(r -> allIds.contains(Integer.parseInt(r.get(EDGE_FROM).toString())) && allIds.contains(Integer.parseInt(r.get(EDGE_TO).toString())))
                        .collect(Collectors.toList());
            }

        }

        List<Map<String, Object>> typesFinal = types.stream().map(r ->{

            jext.util.HashMap<String, Object> node = new jext.util.HashMap<String, Object>()
                    .put_(ID, Long.parseLong(r.get(GRAPH_NODE_ID).toString()))
                    .put_(NAME, r.get(NAME))
                    .put_(ROLE, r.get(ROLE))
                    .put_(NAMESPACE, r.get(NAMESPACE))
                    .put_(SCORE, r.get(SCORE));

            return node;
        }).collect(Collectors.toList());
        graph.put(GRAPH_NODES, typesFinal);

        if(links){
            List<Map<String, Object>> edgesFinal = edges
                    .stream()
                    .map(r -> {
                        return new jext.util.HashMap<String, Object>()
                                .put_(SOURCE, r.get("idfrom"))
                                .put_(EDGE_TARGET, r.get("idto"))
                                .put_(USES, r.get(USES))
                                .put_(ID,r.get("idfrom")+"_"+r.get("idto"));
                    })
                    .collect(Collectors.toList());
            graph.put_(GRAPH_EDGES,edgesFinal);
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public boolean checkSetTypeCount(){
        List<Map<String, Object>> graph = null;

        try (GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);
            graph = session.queryUsing("checkSetFeatureTypesCount", params).distinct().allValues().toList();
        }

        //Result needs to be less than 1 because of $Standalonetypes
        return (graph != null && graph.size() <= 1);
    }

    public Map<String, Object> exportFeatureToXLSX(String featureId, boolean implementation, double coreThreshold, boolean fullName){
        Map<String, Object> graph = (Map<String, Object>) listTypesWInterfacesComplete(featureId,true,implementation).get(GRAPH);

        List<Map<String, Object>> nodes = (List<Map<String, Object>>) graph.get(GRAPH_NODES);

        List<Map<String, Object>> edges = (List<Map<String, Object>>) graph.get(GRAPH_EDGES);

        // create a simple directed graph
        Graph<String, UsesEdge> g = new SimpleDirectedGraph<>(UsesEdge.class);

        HashMap<String,String> nodeNames = new HashMap<>();

        ArrayList<String> startVertices = new ArrayList<>();
        String typeID = getFeatureTypeId(featureId);
        //startVertices.add(FeatureVertex);

        (nodes).forEach(node -> {
            String name;
            if(fullName) {
                name = node.get(NAMESPACE) + "." + node.get(NAME);
                node.put(NAME,name);
            }
            else{
                List<Map<String, Object>> dups = nodes.stream().filter(n -> n.get(NAME).toString().equals(node.get(NAME).toString())).collect(Collectors.toList());
                boolean full = false;
                while(dups.size()>1 && !full){
                    String tName = node.get(NAME).toString();
                    nodes.stream().filter(n -> n.get(NAME).toString().equals(tName)).forEach(n -> {
                        String tempName = n.get(NAME).toString();
                        String tempNamespace = n.get(NAMESPACE).toString();
                        String[] splitName = tempName.split("\\.");
                        String[] splitNamespace = tempNamespace.split("\\.");
                        if(splitName.length <= splitNamespace.length){
                            int offset = splitName.length - 1;
                            int index = splitNamespace.length - offset  - 1;
                            tempName = splitNamespace[index]+"."+tempName;
                            n.put(NAME,tempName);
                        }
//                        int indexOfDot = tempName.lastIndexOf(".");
//                        String namespacePart = (indexOfDot == -1)? "" : tempName.substring(0,indexOfDot);
//                        tempNamespace = (namespacePart.equals(""))? tempNamespace: tempNamespace.substring(0, tempNamespace.lastIndexOf(namespacePart)-1);
//                        indexOfDot = tempNamespace.lastIndexOf(".");
//                        tempNamespace = (indexOfDot == -1)? tempNamespace : tempNamespace.substring(indexOfDot+1);
//                        tempName = (tempNamespace.equals(""))? tempName : tempNamespace + "." + tempName;

                    });
                    full = node.get(NAME).toString().startsWith(node.get(NAMESPACE).toString());
                    dups = nodes.stream().filter(n -> n.get(NAME).toString().equals(node.get(NAME).toString())).collect(Collectors.toList());
                }
                name = node.get(NAME).toString();
            }
            if(node.get(ID).toString().equals(typeID))
                startVertices.add(name);

            if(node.get(SCORE) != null) {
                ArrayList<Double> score = new ArrayList<>((Collection<Double>) node.get("score"));
                double core = 0.75 * score.get(0) + 0.25 * score.get(1);
                node.put("isCore", core >= coreThreshold);
            }
            else{
                node.put("isCore",false);
            }
            g.addVertex(name);
            nodeNames.put(node.get(ID).toString(), name);
        });

        (edges).forEach(edge -> {
            String source = nodeNames.get(edge.get(SOURCE).toString());
            String target = nodeNames.get(edge.get(EDGE_TARGET).toString());
            String uses = edge.get(USES).toString();
            UsesEdge tempEdge = new UsesEdge(uses);
            g.addEdge(source,target, tempEdge);
        });

        Workbook workbook = new XSSFWorkbook();

        HashMap<String,Boolean> visited = new HashMap<>();
        while(!startVertices.isEmpty()) {

            String startVertex = startVertices.get(0);
            startVertices.remove(0);
            CSVBreadthFirstIterator<String> bfsi = new CSVBreadthFirstIterator<String>(g, startVertex, nodes, workbook);
            if(!(visited.containsKey(startVertex) && visited.get(startVertex))) {
                visited.put(startVertex, true);
                List<String> implementations = bfsi.traverse();
                workbook = bfsi.getXLSXObject();
                startVertices.addAll(implementations);
            }

            if(startVertices.isEmpty()){
                workbook = bfsi.buildImplementationLinks();
            }
        }

//        File currDir = new File(".");
//        String path = currDir.getAbsolutePath();
//        String fileLocation = path.substring(0, path.length()-1) + "temp.xlsx";

        byte [] bArray = null;

        try {
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            workbook.write(bos);
            bArray = bos.toByteArray();
        }
        catch (IOException e) {
            e.printStackTrace();
        }

        HashMap<String, Object> result = new HashMap<>();

        result.put("result",bArray);
        result.put("filename",getFeature(String.valueOf(featureId)).getName().getName());

        return result;
    }
}

class CSVBreadthFirstIterator<V> extends BreadthFirstIterator<V, UsesEdge> implements GraphConstants {

    HashMap<String, Object> CSVObject;

    List<Map<String, Object>> nodes;

    HashMap<String, HashMap<String, Object>> firstInstance;

    HashMap<V, HashMap<String,List<V>>> backwardLinks;

    HashMap<String, String> firstAddress;

    int maxDepth;

    V startV;

    Workbook workbook;

    int currentRow;

    CellStyle hlinkStyle, interfaceStyle, coreStyle;

    Font hlinkFont;

    int sheetNameLimit = 30;

    public CSVBreadthFirstIterator(Graph<V, UsesEdge> g, V startVertex, List<Map<String, Object>> n, Workbook w) {
        super(g, startVertex);
        startV = startVertex;
        nodes = n;
        backwardLinks = new HashMap<>();
        firstInstance = new HashMap<>();
        firstAddress = new HashMap<>();
        workbook = w;
        initializeStyles();
    }

    public List<V> traverse(){
        while(hasNext())
            next();

        checkImplementations();

        return backwardLinks.values().stream().flatMap(e -> e.values().stream().flatMap(i -> i.stream())).collect(Collectors.toList());
    }

    public Workbook getWorkbook(){
        return workbook;
    }

    @Override
    protected void encounterVertex(V vertex, UsesEdge edge) {

        super.encounterVertex(vertex, edge);

        V parent = this.getParent(vertex);

        if (parent == null) {
            maxDepth = 0;
            firstInstance = new HashMap<>();
            CSVObject = new HashMap<>();
            CSVObject.put("Name", vertex.toString());
            CSVObject.put("Children", new ArrayList<HashMap<String, Object>>());

            firstInstance.put(vertex.toString(), CSVObject);
        } else {
            int depth = this.getDepth(vertex);
            if (depth > maxDepth)
                maxDepth = depth;
            HashMap<String, Object> parentObject = firstInstance.get(parent);

            ArrayList<HashMap<String, Object>> children = (ArrayList<HashMap<String, Object>>) parentObject.get("Children");

            HashMap<String, Object> temp = new HashMap<>();

            temp.put("Name", vertex.toString());
            temp.put("Children", new ArrayList<HashMap<String, Object>>());

            children.add(temp);

            parentObject.put("Children", children);

            firstInstance.put(vertex.toString(), temp);
        }
    }

    protected void checkImplementations() {
        List<V> vertices = graph.vertexSet().stream().collect(Collectors.toList());

        for (V vertex : vertices) {
            if (this.getParent(vertex) != null)
                checkBackwardLinks(vertex);
        }
    }

    protected void checkBackwardLinks(V vertex) {

        List<V> sources = graph.incomingEdgesOf(vertex).stream().map(i -> graph.getEdgeSource(i)).collect(Collectors.toList());
        V parent = this.getParent(vertex);

        for (V source : sources) {

            V sourceParent = this.getParent(source);

            if (parent.equals(source) || sourceParent != null)
                continue;

            UsesEdge tempEdge = graph.getEdge(source, vertex);

            String uses = tempEdge.getUses();

            if (uses.equals(DEPENDS_ON))
                continue;


            if (!backwardLinks.containsKey(vertex)) {
                HashMap<String, List<V>> temp = new HashMap<>();
                temp.put(EXTENDS,new ArrayList<>());
                temp.put(IMPLEMENTS, new ArrayList<>());
                backwardLinks.put(vertex, temp);
            }

            HashMap<String, List<V>> tempHM = backwardLinks.get(vertex);
            ArrayList<V> imps = (ArrayList<V>) tempHM.get(uses);
            imps.add(source);
            tempHM.put(uses,imps);
            backwardLinks.put(vertex, tempHM);
        }

    }

    @Override
    protected void encounterVertexAgain(V vertex, UsesEdge edge) {
        super.encounterVertexAgain(vertex, edge);

//        String edgeString = edge.toString();
//
//        String source = edgeString.substring(1,edgeString.indexOf(' '));

        String source = graph.getEdgeSource(edge).toString();

        HashMap<String, Object> sourceObject = firstInstance.get(source);

        ArrayList<HashMap<String, Object>> children = (ArrayList<HashMap<String, Object>>) sourceObject.get("Children");

        HashMap<String, Object> temp = new HashMap<>();

        temp.put("Name", vertex.toString());
        temp.put("Children", new ArrayList<HashMap<String, Object>>());

        children.add(temp);

        sourceObject.put("Children", children);

    }

    public Workbook getXLSXObject() {
        currentRow = 0;
        int tempDepth = maxDepth;
        if (maxDepth < 2)
            maxDepth = 2;

//        int lastIndex = startV.toString().lastIndexOf(".");
        String sheetName = startV.toString();

        if(sheetName.equals("com.openreach.framework.caching.business.ORPGCacheManagerImpl")){
            int testss = 1;
        }

        if(sheetName.length()>sheetNameLimit){
            sheetName = sheetName.substring(0,sheetNameLimit);
        }

//        String remainder = startV.toString().substring(0,lastIndex);
        int count = 1;
        while(workbook.getSheetIndex(sheetName)!=-1){
            String countStr = String.valueOf(count);
            sheetName = sheetName.substring(0,sheetName.length()-countStr.length())+count;
            count++;
        }


        Sheet sheet = workbook.createSheet(sheetName);

        Row header = sheet.createRow(currentRow);
        Cell cell = header.createCell(0);
        cell.setCellValue("Source");

        for (int i = 1; i <= maxDepth; i++) {
            cell = header.createCell(i);
            cell.setCellValue("Level" + i);
        }

        currentRow++;
        buildCSVBody(CSVObject, 0, false, sheet, 0);
        currentRow++;
        buildBackwardCSV(sheet);

        buildLinks(sheet);

        maxDepth = tempDepth;

        return workbook;
    }

    private void buildCSVBody(HashMap<String, Object> HM, int currentDepth, boolean firstChild, Sheet sheet, int startColumn) {
        Row row;
        if (firstChild)
            row = sheet.getRow(currentRow);
        else
            row = sheet.createRow(currentRow);


//        if(!firstChild)
//            for(int i=0;i<currentDepth;i++){
//                csvBody+=",";
//            }


        String name = HM.get("Name").toString();
        HashMap<String, Object> temp = firstInstance.get(name);
        boolean isFirstInstance = HM == temp;
        Cell cell = row.createCell(startColumn);
        cell.setCellValue(name);
        if (isFirstInstance) {
            firstAddress.put(name, cell.getAddress().toString());
        }

        if (isNodeCore(name)) {
            cell.setCellStyle(coreStyle);
        } else if (isNodeInterface(name)) {
            cell.setCellStyle(interfaceStyle);
        }

        ArrayList<HashMap<String, Object>> Children = (ArrayList<HashMap<String, Object>>) HM.get("Children");

        for (int i = 0; i < Children.size(); i++) {
            if (i != 0)
                currentRow++;
            buildCSVBody(Children.get(i), currentDepth + 1, i == 0, sheet, startColumn + 1);
        }

//        if(Children.size() == 0) {
//            for (int i = currentDepth + 1; i < maxDepth; i++) {
//                csvBody += ",";
//            }
//        }
//
//        csvBody+="\r\n";

    }

    private void initializeStyles() {
        //Hyperlink Font
        hlinkStyle = workbook.createCellStyle();
        hlinkFont = workbook.createFont();
        hlinkFont.setUnderline(Font.U_SINGLE);
        hlinkFont.setColor(IndexedColors.BLUE.getIndex());
        hlinkStyle.setFont(hlinkFont);

        //Interface Style
        interfaceStyle = workbook.createCellStyle();
        interfaceStyle.setFillForegroundColor(IndexedColors.LIGHT_GREEN.getIndex());
        interfaceStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);

        //Core Style
        coreStyle = workbook.createCellStyle();
        coreStyle.setFillForegroundColor(IndexedColors.PINK.getIndex());
        coreStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);


    }

    private void buildLinks(Sheet sheet) {
        CreationHelper createHelper = workbook.getCreationHelper();

        int startRow = sheet.getFirstRowNum();
        if (startRow != -1) {
            startRow++;
            for (int i = startRow; i <= sheet.getLastRowNum(); i++) {
                Row row = sheet.getRow(i);
                for (int j = row.getFirstCellNum(); j < row.getLastCellNum(); j++) {
                    Cell cell = row.getCell(j);
                    String val = cell.getStringCellValue();
                    if (firstAddress.containsKey(val)) {
                        String address = firstAddress.get(val);
                        if (!address.equals(cell.getAddress().toString())) {
                            Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
                            link.setAddress("'" + sheet.getSheetName() + "'!" + address);
                            cell.setHyperlink(link);
                            CellStyle temp = cell.getCellStyle();
                            if(temp == interfaceStyle || temp == coreStyle) {
                                temp.setFont(hlinkFont);
                                cell.setCellStyle(temp);
                            }
                            else{
                                cell.setCellStyle(hlinkStyle);
                            }
                        }
                    }
                }
            }
        }
    }

    private void buildBackwardCSV(Sheet sheet) {
        if (backwardLinks.isEmpty())
            return;

        Row row = sheet.createRow(currentRow);
        CellStyle bRowStyle = workbook.createCellStyle();
        bRowStyle.setFillForegroundColor(IndexedColors.GREY_25_PERCENT.getIndex());
        bRowStyle.setFillPattern(FillPatternType.SOLID_FOREGROUND);
        row.setRowStyle(bRowStyle);
        Cell cell = row.createCell(0);
        cell.setCellValue("Backward Dependency");
        cell.setCellStyle(bRowStyle);


        List<V> keys = backwardLinks.keySet().stream().collect(Collectors.toList());

        currentRow++;

        for (V key : keys) {
            HashMap<String, List<V>> tempHM = backwardLinks.get(key);

            for(String uses: tempHM.keySet()){
                List<V> list = tempHM.get(uses);
                if(list.isEmpty())
                    continue;

                row = sheet.createRow(currentRow);
                cell = row.createCell(0);
                cell.setCellValue(key.toString());
                cell = row.createCell(1);
                if(uses.equals(IMPLEMENTS))
                    cell.setCellValue("implemented by");
                else
                    cell.setCellValue("extended by");
                cell = row.createCell(2);
                cell.setCellValue(list.get(0).toString());
                currentRow++;

                for (int i = 1; i < list.size(); i++) {
                    row = sheet.createRow(currentRow);
                    cell = row.createCell(2);
                    cell.setCellValue(list.get(i).toString());
                    currentRow++;
                }
            }
//            List<V> list = backwardLinks.get(key);
//
//            row = sheet.createRow(currentRow);
//            cell = row.createCell(0);
//            cell.setCellValue(key.toString());
//            cell = row.createCell(1);
//            cell.setCellValue("implemented by");
//            cell = row.createCell(2);
//            cell.setCellValue(list.get(0).toString());
//            currentRow++;
//
//            for (int i = 1; i < list.size(); i++) {
//                row = sheet.createRow(currentRow);
//                cell = row.createCell(2);
//                cell.setCellValue(list.get(i).toString());
//                currentRow++;
//            }
        }
    }

    public Workbook buildImplementationLinks(){
        CreationHelper createHelper = workbook.getCreationHelper();

        for(int a = 0; a < workbook.getNumberOfSheets(); a++) {
            Sheet currentSheet = workbook.getSheetAt(a);
            String currentName = currentSheet.getRow(1).getCell(0).getStringCellValue(); //Name of class for Sheet

            for (int i = 0; i < workbook.getNumberOfSheets(); i++) {
                if (i == a)
                    continue;
                Sheet tempSheet = workbook.getSheetAt(i);
                int tempStartRow = tempSheet.getFirstRowNum();
                int tempLastRow = tempSheet.getLastRowNum();
                if (tempStartRow != -1) {
                    while(tempStartRow<=tempLastRow){
                        Cell tCell = tempSheet.getRow(tempStartRow).getCell(0);
                        if(tCell != null) {
                            String tValue = tCell.getStringCellValue();
                            if (tValue != null && tValue.equals("Backward Dependency"))
                                break;
                        }
                        tempStartRow++;
                    }
                    tempStartRow++;
                    for (int j = tempStartRow; j <= tempLastRow; j++) {
                        Row tempRow = tempSheet.getRow(j);
                        Cell tempCell = tempRow.getCell(2); //Column for Implementations
                        if(tempCell == null)
                            continue;
                        String tempVal = tempCell.getStringCellValue();
                        if (currentName.equals(tempVal)) {
                            Hyperlink link = createHelper.createHyperlink(HyperlinkType.DOCUMENT);
                            link.setAddress("'" + currentSheet.getSheetName() + "'!A2");
                            tempCell.setHyperlink(link);
                            tempCell.setCellStyle(hlinkStyle);
                        }
                    }
                }
            }
        }

        return workbook;
    }


    private boolean isNodeInterface(String nodename) {
        return nodes.stream().filter(node -> {

            String fullname = node.get("name").toString();
            return fullname.equals(nodename);
        }).findFirst().get().get("role").equals("INTERFACE");
    }

    private boolean isNodeCore(String nodename) {
        return Boolean.parseBoolean(nodes.stream().filter(node -> {

            String fullname = node.get("name").toString();
            return fullname.equals(nodename);
        }).findFirst().get().get("isCore").toString());
    }

    public int getMaxDepth() {
        return maxDepth;
    }

    @Override
    public V getParent(V v) {
        V parent;
        try {
            parent = super.getParent(v);
        }
        catch (Exception e) {
            parent = null;
        }

        return parent;
    }

}

class UsesEdge extends DefaultEdge{

    protected String uses;

    public UsesEdge(String u){
        uses = u;
    }

    public String getUses(){
        return uses;
    }

}

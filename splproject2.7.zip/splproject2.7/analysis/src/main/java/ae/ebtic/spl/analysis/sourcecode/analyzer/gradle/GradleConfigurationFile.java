package ae.ebtic.spl.analysis.sourcecode.analyzer.gradle;

import ae.ebtic.spl.analysis.sourcecode.analyzer.configuration.CommonConfiguration;
import jext.maven.MavenCoords;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class GradleConfigurationFile extends CommonConfiguration {

    private BuildGradleFile gradle;

    public GradleConfigurationFile(File configurationFile) {
        super(configurationFile);
        this.gradle = new BuildGradleFile(configurationFile);
    }

    @Override
    public List<String> getMavenRepositories() {
        return gradle.getRepositories();
    }

    @Override
    public Set<MavenCoords> getMavenDependencies() {
        return gradle.getMavenDependencies();
    }

    // @Override
    // public Set<MavenCoords> getLibraries() {
    //     return gradle.getMavenDependencies();
    // }

    @Override
    public Set<String> getDependencies(String projectDir) {
        return gradle.getModuleDependencies()
            .stream()
            .map(moduleId -> toModuleName(projectDir, moduleId))
            .collect(Collectors.toSet())
            ;
    }

    private String toModuleName(String projectPath, String moduleId) {
        // String modulePath = FileUtils.toCanonicalPath(parentDir, moduleId);
        // String moduleName = PathUtils.relativePath(projectPath, modulePath);
        // return moduleName;
        return moduleId;
    }

}

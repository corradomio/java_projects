package ae.ebtic.spl.analysis.sourcecode.model;

import jext.logging.Logger;

import java.util.HashMap;
import java.util.TreeMap;

public class NameMap extends TreeMap<Name, String> {

    // ----------------------------------------------------------------------
    // Fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(NameMap.class);

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public NameMap() { }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public synchronized String put(Name typeName, String typeId) {
        if (super.containsKey(typeName)) {
            String registeredId = super.get(typeName);
            if (!typeId.equals(registeredId))
                logger.warnf("Object %s already present with id %s (new id: %s)", typeName, super.get(typeName), typeId);
            else
                typeId = registeredId;
            return registeredId; //super.get(typeName);
        }
        else
            return super.put(typeName, typeId);
    }

    public synchronized String get(Name typeName) {
        return super.getOrDefault(typeName, null);
    }
}

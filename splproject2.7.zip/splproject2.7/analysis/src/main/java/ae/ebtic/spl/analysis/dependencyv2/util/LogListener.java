package ae.ebtic.spl.analysis.dependencyv2.util;

import ae.ebtic.spl.analysis.dependencyv2.AnalyzerListener;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import jext.logging.Logger;

public class LogListener implements AnalyzerListener {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private Logger logger;
    private int nTasks, iTask;
    private int nSteps, iStep;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public LogListener(Logger l) {
        logger = l;
    }

    // ----------------------------------------------------------------------
    // Events
    // ----------------------------------------------------------------------

    @Override
    public void onStart(String label, int nTasks) {
        logger.infof("Starting %s ...", label);
        this.nTasks = nTasks;
        this.iTask = 0;
        this.iStep = 0;
    }

    @Override
    public void onBegin(String label, int nSteps) {
        iTask += 1;
        this.nSteps = nSteps;
        this.iStep = 0;
        logger.infof("  %s [%d/%d]", label, iTask, nTasks);
    }

    @Override
    public void onDone(String label) {
        logger.infof("Done %s", label);
    }

    @Override
    public void onDone() {
        logger.infof("Done");
    }

    @Override
    public void onProject(Project project) {
        logger.infof("Project %s", project.getName());
    }

    @Override
    public void onModule(Module module) {
        iStep += 1;
        logger.infof("    Module '%s' [%d: %d/%d]", module.getName(), iTask, iStep, nSteps);
    }

    @Override
    public void onLibrary(Library library) {
        logger.infoft("      Library %s", library.getName());
    }

    @Override
    public void onDependency(Module dependency) {
        logger.infof("      Dependency %s", dependency.getName());
    }

    @Override
    public void onSource(Source source) {
        logger.infoft("      Source %s (%s)", source.getName(), source.getPath());
    }

    @Override
    public void onResource(Resource resource) {
        logger.infoft("      Resource %s (%s)", resource.getName(), resource.getPath());
    }

    @Override
    public void onNamespace(Name namespace) {
        logger.infoft("        Namespace %s", namespace.getName());
    }

    @Override
    public void onType(String typeName) {
        logger.infoft("        Type %s", typeName);
    }

}

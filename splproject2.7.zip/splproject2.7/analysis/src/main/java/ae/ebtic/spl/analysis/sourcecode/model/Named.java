package ae.ebtic.spl.analysis.sourcecode.model;

/**
 * An object with a name
 */
public interface Named extends Comparable<Named> {

    Name getName();

}

package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.util.MethodObjectName;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.expr.MethodCallExpr;
import com.github.javaparser.ast.expr.MethodReferenceExpr;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import com.github.javaparser.ast.stmt.BlockStmt;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.resolution.declarations.ResolvedConstructorDeclaration;
import com.github.javaparser.resolution.declarations.ResolvedMethodDeclaration;
import jext.javaparser.util.JPUtils;
import jext.util.Parameters;

import java.util.Optional;

public class ASTMethodDependencies extends ASTAnalyzer {

    public ASTMethodDependencies(DependencyAnalyzer da) {
        super(da);
    }

    public void analyze(Source source, Parameters params) {
        super.analyze(source, params);
    }

    protected void analyze(CompilationUnit cu) {
        super.analyze(cu);

        try {
            // resolve the method dependencies using ONLY modules
            ts = composeTypeSolver();
            ts.setCu(cu);

            cu.findAll(ConstructorDeclaration.class)
                .forEach(this::analyze);
            cu.findAll(MethodDeclaration.class)
                .forEach(this::analyze);
        }
        finally {
            if (ts != null)
                ts.detach();
        }
    }

    private void analyze(ConstructorDeclaration n) {
        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent())
            return;

        // get the full qualified class name
        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent())
            return;

        int nParameters = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) compose the method name
        MethodObjectName methodName = new MethodObjectName(qname.get(), n.getName().getIdentifier(), nParameters, signature);

        analyze(methodName, n.getBody());
    }

    private void analyze(MethodDeclaration n) {
        // getNameAsString() == getName().getIdentifier()
        String mname = n.getNameAsString();

        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent())
            return;

        // get the full qualified class name
        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent())
            return;

        // body not present ("abstract")
        if (!n.getBody().isPresent())
            return;

        int nParams = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) compose the method name
        MethodName methodName = new MethodObjectName(qname.get(), mname, nParams, signature);

        analyze(methodName, n.getBody().get());
    }

    protected void analyze(MethodName methodName, BlockStmt body) {
        body.findAll(ObjectCreationExpr.class)
            .forEach(oce -> analyze(methodName, oce));
        body.findAll(MethodCallExpr.class)
            .forEach(mce -> analyze(methodName, mce));
        body.findAll(MethodReferenceExpr.class)
            .forEach(mre -> analyze(methodName, mre));
    }

    private void analyze(MethodName callingMethod, MethodCallExpr mce) {

        try {
            ResolvedMethodDeclaration rmd = ts.resolve(mce);
            if (rmd == null)
                return;

            int nArgs = mce.getArguments().size();
            String signature = JPUtils.getSignature(rmd);

            MethodName calledMethod = new MethodObjectName(rmd.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod);

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }

    private void analyze(MethodName callingMethod, ObjectCreationExpr oce) {

        try {
            ResolvedConstructorDeclaration rcm = ts.resolve(oce);
            if (rcm == null)
                return;

            int nArgs = oce.getArguments().size();
            String signature = JPUtils.getSignature(rcm);

            MethodName calledMethod = new MethodObjectName(rcm.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod);

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }

    private void analyze(MethodName callingMethod, MethodReferenceExpr mre) {

        try {
            ResolvedMethodDeclaration rmd = ts.resolve(mre);
            if (rmd == null)
                return;

            int nArgs = rmd.getNumberOfParams();
            String signature = JPUtils.getSignature(rmd);

            MethodName calledMethod = new MethodObjectName(rmd.getQualifiedName(), nArgs, signature);

            datodg.createMethodCall(callingMethod, calledMethod);

            // logger.debugft("  %s -> %s", callingMethod, calledMethod);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (UnsupportedOperationException e) {
            // no problem
        }
        catch (RuntimeException e) {
            String message = e.getMessage();
            if (message == null || !message.startsWith("Unable to calculate") && !message.startsWith("Ambiguous method call"))
                logger.error(e, e);
        }
        catch (Throwable e) {
            logger.error(e, e);
        }
    }
}

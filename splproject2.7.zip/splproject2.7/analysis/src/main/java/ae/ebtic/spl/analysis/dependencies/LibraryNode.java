package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryType;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import jext.maven.MavenCoords;
import jext.util.StringUtils;

import java.io.File;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class LibraryNode extends GraphNode implements Library {

    public static List<Library> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> LibraryNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static LibraryNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new LibraryNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private LibraryNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public Project getProject() {
        return dg.getProject();
    }

    @Override
    public String getPath() { return (String)nv.getOrDefault(PATH, StringUtils.empty()); }

    @Override
    public LibraryType getLibraryType() {
        String type = (String)nv.getOrDefault(LIBRARY_TYPE, StringUtils.empty());
        return StringUtils.isEmpty(type) ? LibraryType.INVALID : LibraryType.valueOf(type);
    }

    @Override
    public boolean isLocal() {
        LibraryType ltype = getLibraryType();
        return !(ltype == LibraryType.MAVEN/* || ltype == LibraryType.MAVEN_COLLECTION*/);
    }

    @Override
    public String getDigest() {
        return (String)nv.getOrDefault(DIGEST, StringUtils.empty());
    }

    @Override
    public List<Library> getDependencies() {
        return Collections.emptyList();
    }

    @Override
    public List<File> getFiles() {
        return Collections.emptyList();
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public String getModuleId() {
        return (String)nv.getOrDefault(MODULE_ID, null);
    }

    @Override
    public Module getModule() {
        String moduleId = (String)nv.getOrDefault(MODULE_ID, null);
        if (moduleId != null)
            return dg.getModule(moduleId);
        else
            return null;
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public boolean contains(Name typeName) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Set<RefType> getTypes() {
        return new HashSet<>(dg.getLibraryTypes(getId()));
    }

    // ----------------------------------------------------------------------
    // Version
    // ----------------------------------------------------------------------

    @Override
    public String getVersion() {
        MavenCoords coords = new MavenCoords(getName().getFullName());
        return coords.version;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

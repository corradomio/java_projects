package ae.ebtic.spl.analysis.sourcecode.model;

public interface Parameter extends IdNamed {

    // -- method

    String getOwnerMethodId();

    Method getOwnerMethod();

    // -- owner type (of the method)

    String getOwnerTypeId();

    // -- parameter type

    String getTypeId();

    RefType getType();

}

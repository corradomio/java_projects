package ae.ebtic.spl.analysis.sourcecode.analyzer;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import jext.graph.Direction;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ImplementedType extends NamedObject implements Type {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private Source source;
    private TypeRole role;
    public boolean innerType;
    public int nParams;

    // ----------------------------------------------------------------------
    // Constructors
    // ----------------------------------------------------------------------

    public ImplementedType(Name name) {
        super(name);
        this.role = TypeRole.UNKNOWN;
    }

    public ImplementedType(Name name, TypeRole role, Source source) {
        super(name);
        this.source = source;
        this.role = role;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- Type conversion

    @Override
    public boolean isType() {
        return true;
    }

    @Override
    public Type asType() {
        return this;
    }

    // -- type role

    @Override
    public TypeRole getRole() {
        return role;
    }

    @Override
    public boolean isValid() {
        return true;
    }

    // --

    @Override
    public int getTypeParametersCount() {
        return nParams;
    }

    @Override
    public Library getLibrary() {
        return null;
    }

    @Override
    public String getLibraryId() {
        return null;
    }

    // -- Source

    @Override
    public String getSourceId() {
        return source.getId();
    }

    @Override
    public Source getSource() {
        return source;
    }

    // -- Module

    @Override
    public String getModuleId() {
        return source.getModule().getId();
    }

    @Override
    public Module getModule() {
        return source.getModule();
    }

    // -- Types/fields/methods

    @Override
    public List<Type> getUseTypes(TypeUse useType, Direction direction, boolean recursive, boolean refTypes) {
        return Collections.emptyList();
    }

    @Override
    public List<Field> getFields() {
        return Collections.emptyList();
    }

    @Override
    public List<Method> getMethods() {
        return Collections.emptyList();
    }

    // -- Score

    @Override
    public List<Double> getScore() {
        return null;
    }

    // -- Other models

    @Override
    public List<Component> getComponents() {
        return Collections.emptyList();
    }

    @Override
    public List<Feature> getFeatures() {
        return Collections.emptyList();
    }

    // -- Entry point

    @Override
    public boolean isEntryPoint() {
        // none to do in the source code
        return false;
    }

    @Override
    public long[] getCountMethods() {
        return null;
    }
}

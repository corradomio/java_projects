package ae.ebtic.spl.analysis.sourcecode.model;

public interface MethodName extends Name {

    String getSignature();
    int getNumParameters();

}

package ae.ebtic.spl.analysis.dependencyv2;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;

public interface AnalyzerListener {

    void onStart(String label, int nTasks);

        void onBegin(String label, int nSteps);

        void onDone(String label);

    void onDone();

    void onProject(Project project);

    void onModule(Module module);

    void onLibrary(Library library);

    void onDependency(Module dependency);

    void onSource(Source source);

    void onResource(Resource resource);

    void onNamespace(Name namespace);

    void onType(String typeName);

}

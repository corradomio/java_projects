package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import jext.util.MimeTypes;
import jext.util.PathUtils;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class ResourceNode extends ResourceBase {

    public static List<Resource> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> ResourceNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static ResourceNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new ResourceNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ResourceNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg, nv);
    }

}

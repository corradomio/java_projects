package ae.ebtic.spl.analysis.dependencyv2.java;

// import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
// import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
// import ae.ebtic.spl.analysis.sourcecode.model.Library;
// import ae.ebtic.spl.analysis.sourcecode.model.Name;
// import ae.ebtic.spl.analysis.sourcecode.model.RefType;
// import ae.ebtic.spl.analysis.sourcecode.model.Source;
// import com.github.javaparser.ast.CompilationUnit;
// import com.github.javaparser.ast.ImportDeclaration;
// import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
// import com.github.javaparser.ast.type.ClassOrInterfaceType;
// import com.github.javaparser.resolution.UnsolvedSymbolException;
// import com.github.javaparser.resolution.types.ResolvedReferenceType;
// import com.github.javaparser.resolution.types.ResolvedType;
// import jext.javaparser.symbolsolver.resolution.typesolvers.ContextTypeSolver;
// import jext.util.HashSet;
// import jext.util.Parameters;
//
// import java.util.Objects;
// import java.util.Set;

public class ASTTypeDependencies { }

// public class ASTTypeDependencies extends ASTAnalyzer {
//
//     public ASTTypeDependencies(DependencyAnalyzer da) {
//         super(da);
//     }
//
//     public void analyze(Source source, Parameters params) {
//         super.analyze(source, params);
//     }
//
//     protected void analyze(CompilationUnit cu) {
//         super.analyze(cu);
//
//         try {
//             ts = composeTypeSolver(false);
//             ts.setCu(cu);
//
//             cu.findAll(ClassOrInterfaceDeclaration.class)
//                 .forEach(this::analyze);
//         }
//         finally {
//             ts.detach();
//         }
//     }
//
//     // DEBUG
//     // static Set<String> MISSING = new HashSet<String>() {{
//     //     add("java.awt.event.InputEvent");
//     //     add("java.lang.Math");
//     //     add("java.lang.Runtime");
//     //     add("java.lang.Short");
//     //     add("java.lang.System");
//     //     add("java.util.concurrent.Executors");
//     //     add("javax.swing.BorderFactory");
//     //     add("javax.swing.Box");
//     //     add("javax.swing.JOptionPane");
//     //     add("javax.swing.SwingConstants");
//     //     add("javax.swing.UIManager");
//     // }};
//
//     private void analyze(ClassOrInterfaceDeclaration cid) {
//         // DEBUG
//         // String symbol = cid.getNameAsString();
//         // if (MISSING.contains(symbol))
//         //     System.out.println(symbol);
//
//         RefType fromType = toRefType(cid);
//         analyzeImports(fromType, cid);
//         analyzeInheritance(fromType, cid);
//         analyzeImplementation(fromType, cid);
//     }
//
//     private void analyzeImports(RefType fromType, ClassOrInterfaceDeclaration cid) {
//         cu.findAll(ImportDeclaration.class)
//             .stream()
//             .map(this::toRefType)
//             .filter(Objects::nonNull)
//             .forEach(toType -> createTypeDependency(fromType, toType, DEPENDS_ON));
//     }
//
//     private void analyzeInheritance(RefType fromType, ClassOrInterfaceDeclaration cid) {
//         cid.getExtendedTypes()
//             .stream()
//             .map(this::toRefType)
//             .filter(Objects::nonNull)
//             .filter(toType -> !fromType.equals(toType))
//             .forEach(toType -> createTypeDependency(fromType, toType, EXTENDS));
//
//         cid.getImplementedTypes()
//             .stream()
//             .map(this::toRefType)
//             .filter(Objects::nonNull)
//             .filter(toType -> !fromType.equals(toType))
//             .forEach(toType -> createTypeDependency(fromType, toType, IMPLEMENTS));
//     }
//
//     private RefType toRefType(ClassOrInterfaceType cit) {
//         // String symbol = cit.resolve().getQualifiedName();
//         // Exception exception;
//         try {
//             ResolvedType rt = ts.resolve(cit);
//             if (rt == null)
//                 return null;
//             if (rt.isReferenceType()) {
//                 ResolvedReferenceType rrt = rt.asReferenceType();
//                 ReferencedType refType = new ReferencedType(rrt.getQualifiedName());
//                 refType.nTypeParams = rrt.getTypeParametersMap().size();
//                 return refType;
//             }
//             else {
//                 return new ReferencedType(rt.describe());
//             }
//         }
//         catch (Exception e) {
//             //da.logUnsolvedSymbol(cit.getNameAsString(), cit.toString());
//             //return null;
//         }
//
//         String symbol = cit.getNameAsString();
//
//         // check if the symbol is a namespace
//         if (ts.isNamespace(symbol))
//             return null;
//
//         // if the name is composed by 1 or two characters at 99.999% is a TypeParameter
//         // T, E, O1, ...
//         if (symbol.length() <= 2)
//             return null;
//
//         // if it is an already unresolved symbol, skip
//         if (da.isUnsolvedSymbol(symbol))
//             return null;
//
//         // Sometimes the library consider a "namespace" as a 'ClassOrInterfaceType'.
//         // This check skip this problem
//         // if (da.isNamespace(symbol))
//         //     return null;
//
//         // ResolvedReferenceType rrt;
//         // In "Set<Characteristics>" it can be not able to solve "Characteristics" AND
//         // in this case, the exception skip the solution of the COMPLETE type ("Set<...>").
//         // HERE we try to solve ONLY the plain type
//         try {
//             ResolvedType rt = ts.resolve(cit);
//             if (rt.isReferenceType()) {
//                 ResolvedReferenceType rrt = rt.asReferenceType();
//                 ReferencedType refType = new ReferencedType(rrt.getQualifiedName());
//                 refType.nTypeParams = rrt.getTypeParametersMap().size();
//                 return refType;
//             }
//             else {
//                 return new ReferencedType(rt.describe());
//             }
//         }
//         catch (UnsolvedSymbolException e) {
//             da.logUnsolvedSymbol(e.getName(), cit.toString(), source);
//         }
//         catch (UnsupportedOperationException e) {
//             da.logUnsolvedSymbol(cit.toString(), null, source);
//         }
//         catch (Throwable t) {
//             // da.logUnsolvedSymbol(symbol, null, source);
//             logger.error(t, t);
//         }
//
//         return null;
//     }
//
//     private void createTypeDependency(RefType fromType, RefType toType, String useType) {
//         datodg.createTypeNode(toType, module, params);
//         datodg.createTypeDependency(fromType, toType, useType, module, params);
//     }
//
//     private void analyzeImplementation(RefType fromType, ClassOrInterfaceDeclaration cid) {
//         cid.findAll(ClassOrInterfaceType.class)
//             .stream()
//             .filter(cit -> !isInheritanceNode(cid, cit))
//             .map(this::toRefType)
//             .filter(Objects::nonNull)
//             .filter(toType -> !fromType.equals(toType))
//             .forEach(toType -> createTypeDependency(fromType, toType, DEPENDS_ON));
//     }
//
//     private boolean isInheritanceNode(ClassOrInterfaceDeclaration cid, ClassOrInterfaceType cit) {
//         for (ClassOrInterfaceType t : cid.getExtendedTypes())
//             if (t == cit)
//                 return true;
//         for (ClassOrInterfaceType t : cid.getImplementedTypes())
//             if (t == cit)
//                 return true;
//         return false;
//     }
//
// }

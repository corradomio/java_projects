package ae.ebtic.spl.analysis.runtime;

import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.Projects;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.ProjectUtils;
import jext.jfr.JfrEvents;
import jext.jfr.ThreadDumps;
import jext.logging.Logger;
import org.gradle.tooling.model.ProjectModel;
import org.openjdk.jmc.flightrecorder.CouldNotLoadRecordingException;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class RuntimeAnalyzer implements RuntimeAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    protected Logger logger;

    protected boolean aborted;
    protected AnalyzerConfig config;
    protected Project project;
    protected RuntimeGraph rtg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected RuntimeAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void abort() {
        aborted = true;
    }

    public void initialize() {
        Name projectName = this.config.getProjectName();

        logger = Logger.getLogger(RuntimeAnalyzer.class, projectName.getFullName());

        GraphConfig config = new GraphConfig()
            .setGraphDatabase(this.config.getGraphDatabase())
            .setProjectName(this.config.getProjectName())
            .setParameters(this.config.getParameters());

        this.rtg = ProjectGraphAccess.newProjectGraphAccess(config).getRuntimeGraph();
        this.project = Projects.newProject(config.getProjectName(), config.getGraphDatabase());
    }

    public void analyze() {
        try {

            // ------------------------
            // DEBUG ONLY    DEBUG ONLY
            // if (config.getTest() != 0)
            //     rtg.setEntryPointRandom(config.getTest());
            // else
            // DEBUG ONLY    DEBUG ONLY
            // ------------------------

            // processFiles();

            List<File> jfrFiles = checkFiles();

            ThreadDumps tdumps = getThreadDumps(jfrFiles);

            Set<String> definedTypes = getDefinedTypes();

            Map<String, Set<String>> entryPoints = getEntryPointInfos(tdumps, definedTypes);

            setEntryPointTypes(entryPoints);

            propagateEntryPoints();

            done(STATUS_VALID, null);
        }
        catch (Exception e) {
            done(STATUS_INVALID, e.getMessage());
        }
    }

    public void delete() {
        rtg.delete();
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    protected ThreadDumps getThreadDumps(List<File> jfrFiles) throws IOException, CouldNotLoadRecordingException {
        // load the "events" files
        JfrEvents events = JfrEvents.loadEvents(jfrFiles);
        // extract the thread dumps
        ThreadDumps tdumps = events.getThreadDumps();

        return tdumps;
    }

    protected Set<String> getDefinedTypes() {
        //
        // retrieve the list of defined types in the project
        //
        Set<String> definedTypes = ProjectUtils.getTypes(project)
            .stream()
            .map(type -> type.getName().getFullName())
            .collect(Collectors.toSet());

        logger.debugf("Found %d types defined in the project", definedTypes.size());

        //
        // filter the set of defined types in project based on configuration
        //
        // apply the filter based on "excluded" namespaces
        if (!config.getExclude().isEmpty() || !config.getSelect().isEmpty()) {
            if (!config.getExclude().isEmpty()) {
                definedTypes = definedTypes.stream()
                    .filter(this::isNotExcluded)
                    .collect(Collectors.toSet());
            }

            // apply the filter based on "selected" namespaces
            if (!config.getSelect().isEmpty()) {
                definedTypes = definedTypes.stream()
                    .filter(this::isSelected)
                    .collect(Collectors.toSet());
            }

            logger.infof("Found %d filtered types", definedTypes.size());
        }

        return definedTypes;
    }

    protected Map<String, Set<String>> getEntryPointInfos(ThreadDumps tdumps, Set<String> definedTypes) {
        //
        // filter the thread dumps to identify the "entryPoints" based on (filtered) types defined in the project
        //
        Map<String, Set<String>> entryPoints = tdumps.getEntryPointInfos(definedTypes);

        logger.infof("Found %d classes used as 'entryPoints'", entryPoints.size());

        return entryPoints;
    }

    protected void setEntryPointTypes(Map<String, Set<String>> entryPoints) {
        // set the entry point types
        rtg.setEntryPointTypeInfos(entryPoints);
        rtg.setTypesCountMethods();
    }

    protected void propagateEntryPoints() {
        // update the flag "entryPoints" to components & features
        rtg.resetEntryPoints();
        rtg.updateEntryPoints();
    }

    protected void done(String status, String reason) {
        rtg.setStatus(status, reason);
    }

    // private void processFiles() {
    //     List<File> jfrFiles = checkFiles();
    //
    //     try {
    //         logger.debugf("%d .jfr files to process", jfrFiles.size());
    //
    //         // load the "events" files
    //         JfrEvents events = JfrEvents.loadEvents(jfrFiles);
    //         // extract the thread dumps
    //         ThreadDumps tdumps = events.getThreadDumps();
    //
    //         logger.debugf("Found %d thread dumps", tdumps.getDumps().size());
    //
    //         //
    //         // retrieve the list of defined types in the project
    //         //
    //         Set<String> definedTypes = ProjectUtils.getTypes(project)
    //             .stream()
    //             .map(type -> type.getName().getFullName())
    //             .collect(Collectors.toSet());
    //
    //         logger.debugf("Found %d types defined in the project", definedTypes.size());
    //
    //         //
    //         // filter the set of defined types in project based on configuration
    //         //
    //         // apply the filter based on "excluded" namespaces
    //         if (!config.getExclude().isEmpty() || !config.getSelect().isEmpty()) {
    //             if (!config.getExclude().isEmpty()) {
    //                 definedTypes = definedTypes.stream()
    //                     .filter(this::isNotExcluded)
    //                     .collect(Collectors.toSet());
    //             }
    //
    //             // apply the filter based on "selected" namespaces
    //             if (!config.getSelect().isEmpty()) {
    //                 definedTypes = definedTypes.stream()
    //                     .filter(this::isSelected)
    //                     .collect(Collectors.toSet());
    //             }
    //
    //             logger.infof("Found %d filtered types", definedTypes.size());
    //         }
    //
    //         //
    //         // filter the thread dumps to identify the "entryPoints" based on (filtered) types defined in the project
    //         //
    //         Map<String, Set<String>> entryPoints = tdumps.getEntryPointInfos(definedTypes);
    //
    //         logger.infof("Found %d classes used as 'entryPoints'", entryPoints.size());
    //
    //         // set the entry point types
    //         rtg.setEntryPointTypeInfos(entryPoints);
    //         rtg.setTypesCountMethods();
    //
    //         // update the flag "entryPoints" to components & features
    //         rtg.resetEntryPoints();
    //         rtg.updateEntryPoints();
    //
    //     } catch (Exception e) {
    //         logger.error(e, e);
    //     }
    // }

    private boolean isNotExcluded(String typeName) {
        for (String exclude : this.config.getExclude())
            if (typeName.startsWith(exclude))
                return true;
        return false;
    }

    private boolean isSelected(String typeName) {
        for (String select : this.config.getSelect())
            if (typeName.startsWith(select))
                return true;
        return false;
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    /** Convert the list of strings in configuration into a list of File objects */
    private List<File> checkFiles() {
        // List<File> jfrFiles = new ArrayList<>();
        //
        // for (String filePath : config.getFiles()) {
        //
        //     // Java File Recorder file
        //     File jfrFile = new File(filePath);
        //     if (!jfrFile.exists()) {
        //         logger.warnf("Unable to process %s: file not found", FileUtils.getAbsolutePath(jfrFile));
        //     }
        //
        //     jfrFiles.add(jfrFile);
        // }
        //
        // return jfrFiles;
        return config.getFiles().stream()
            .map(File::new)
            .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    public RuntimeAnalysis addListener(AnalyzerListener l) {
        return this;
    }
}

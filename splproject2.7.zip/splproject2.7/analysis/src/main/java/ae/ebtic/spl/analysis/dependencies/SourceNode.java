package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.SourceInfo;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.util.FileUtils;

import java.io.File;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SourceNode extends ResourceBase implements Source {

    public static List<Source> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> SourceNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static SourceNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new SourceNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------
    /*
        Content of the map 'nv':

        $labels: List<String>   list of the graphdb labels (in general there is only 1 label)
        $id: String             id of the graphdb node
        $type: String           type of the node (the unique label)

        projectId: String       id of the 'project' node
        moduleId: String        id of the 'module' node

        name: String            name of the file (with extension)
        namespace: String       relative directory of the file based on the root of the module
        fullname: String        <namespace>/<name>
        path: String            ABSOLUTE path of the file inside the local filesystem
        digest: String          MD5 of the file content
        type: String            type of the node (SOURCE)
     */

    // private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private SourceNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg, nv);
        // this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // @Override
    // public String getPath() { return (String)nv.getOrDefault(PATH, null); }

    // @Override
    // public File getFile() { return new File(getPath()) ;}

    @Override
    public String getLanguage() {
        return (String)nv.getOrDefault(LANGUAGE, JAVA_LANG);
    }

    // @Override
    // public boolean isValid() {
    //     return true;
    // }

    // @Override
    // public String getDigest() {
    //     return (String)nv.getOrDefault(DIGEST, UNKNOWN);
    // }

    @Override
    public SourceInfo getSourceInfo() {
        SourceInfo info = new SourceInfo();

        File file = new File(getPath());

        List<String> lines = FileUtils.toStrings(file);

        info.count = 1;
        info.bytes = file.length();
        info.totalLines = lines.size();
        info.blankLines = lines
            .stream()
            .map(String::trim)
            .filter(String::isEmpty)
            .count();
        info.codeLines = info.totalLines - info.blankLines;

        return info;
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    // @Override
    // public String getModuleId() {
    //     return (String)nv.get(MODULE_ID);
    // }

    // @Override
    // public Module getModule() {
    //     return dg.getModule(getModuleId());
    // }

    @Override
    public List<Type> getTypes() {
        return dg.getSourceTypes(getId());
    }

    @Override
    public List<RefType> getUsedTypes() {
        return Collections.emptyList();
    }

}

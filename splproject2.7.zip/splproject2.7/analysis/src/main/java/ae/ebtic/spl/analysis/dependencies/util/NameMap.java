package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import jext.lang.JavaUtils;

import java.util.AbstractMap;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class NameMap<T> extends AbstractMap<Name, T> {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private static class TreeEntry<T> implements Entry<Name, T> {

        TreeEntry<T> parent;
        String qname;
        String name;
        T value;
        Map<String, TreeEntry<T>> children = new HashMap<>();

        TreeEntry(String name, TreeEntry<T> parent) {
            this.parent = parent;
            this.name = name;
            if (parent == null)
                qname = name;
            else
                qname = JavaUtils.fullName(parent.qname, name);
        }

        int count() {
            int count = 0;
            for (TreeEntry<T> child : children.values())
                count += child.count();
            return 1+count;
        }

        synchronized TreeEntry<T> getEntry(String name, boolean create) {
            if (!children.containsKey(name))
                if (create)
                    children.put(name, new TreeEntry<>(name, this));
                else
                    return null;
            return children.get(name);
        }

        // ------------------------------------------------------------------

        List<TreeEntry<T>> getEntries() {
            List<TreeEntry<T>> entries = new ArrayList<>();
            if (this.value != null)
                entries.add(this);
            for (TreeEntry<T> child : children.values()) {
                entries.addAll(child.getEntries());
            }
            return entries;
        }

        // ------------------------------------------------------------------

        @Override
        public Name getKey() {
            return new ObjectName(qname);
        }

        @Override
        public T getValue() {
            return value;
        }

        @Override
        public T setValue(T value) {
            return null;
        }

        @Override
        public int hashCode() {
            return qname.hashCode();
        }

        @Override
        public boolean equals(Object obj) {
            TreeEntry<T> that = (TreeEntry<T>) obj;
            return qname.equals(that.qname);
        }
    }

    private TreeEntry<T> root = new TreeEntry<>("", null);

    private TreeEntry<T> getEntry(Name name, boolean create) {
        String[] parts = name.getParts();
        TreeEntry<T> current = root;
        for (String part : parts) {
            current = current.getEntry(part, create);
            if (current == null)
                break;
        }
        return current;
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    public NameMap() { }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    @Override
    public int size() {
        return root.count() - 1;
    }

    @Override
    public boolean isEmpty() {
        return size() == 0;
    }

    @Override
    public synchronized boolean containsKey(Object key) {
        Name name = (Name) key;
        return getEntry(name, false) != null;
    }

    @Override
    public synchronized T get(Object key) {
        Name name = (Name) key;
        TreeEntry<T> entry = getEntry(name, false);
        return entry != null ? entry.value : null;
    }

    @Override
    public synchronized T put(Name name, T value) {
        TreeEntry<T> entry = getEntry(name, true);
        T previous = entry.value;
        entry.value = value;
        return previous;
    }

    // ----------------------------------------------------------------------
    // Not necessary
    // ----------------------------------------------------------------------

    @Override
    public boolean containsValue(Object value) {
        throw new UnsupportedOperationException();
    }

    @Override
    public Set<Entry<Name, T>> entrySet() {
        return new HashSet<>(root.getEntries());
    }

}

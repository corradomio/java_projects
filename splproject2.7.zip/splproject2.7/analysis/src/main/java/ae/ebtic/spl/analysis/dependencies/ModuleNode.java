package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;

import java.io.File;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

public class ModuleNode extends GraphNode implements Module {

    public static List<Module> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> ModuleNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static ModuleNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new ModuleNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------
    /*
        Content of the map 'nv':

        $labels: List<String>   list of the graphdb labels (in general there is only 1 label)
        $id: String             id of the graphdb node
        $type: String           type of the node (the unique label)

        projectId: String       id of the 'project' node

        name: String            name of the module (with extension)
        namespace: String       relative directory of the module based on the root of the project
        fullname: String        <namespace>/<name>
        path: String            ABSOLUTE path of the module inside the local filesystem
        type: String            type of the node (MODULE)
     */

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ModuleNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getPath() { return (String)nv.get(PATH); }

    @Override
    public File getDirectory() {
        return new File(getPath());
    }

    @Override
    public Properties getProperties() {
        return jext.util.Properties.empty();
    }

    // ----------------------------------------------------------------------
    // Overrides
    // ----------------------------------------------------------------------

    @Override
    public Project getProject() {
        return dg.getProject();
    }

    @Override
    public List<Module> getDependencies(boolean recursive) {
        return dg.getModuleDependencies(getId(), recursive);
    }

    @Override
    public List<Source> getSources() {
        return dg.getSources(getId());
    }

    @Override
    public Source getSource(String name) {
        List<Source> sources = getSources();
        for(Source source : sources) {
            String sname = source.getName().toString();
            String sid = source.getId();
            if (sname.equals(name) || sid.equals(name))
                return source;
        }
        return null;
    }

    @Override
    public List<Library> getLibraries() {
        return dg.getLibraries(getId());
    }

    @Override
    public Library getLibrary(String libraryId) {
        List<Library> libraries = getLibraries();
        for(Library library : libraries) {
            String lname = library.getName().toString();
            String lid = library.getId();
            if (lname.equals(name) || lid.equals(name))
                return library;
        }
        return null;
    }

    @Override
    public List<Resource> getResources() {
        return dg.getResources(getId());
    }

    // types

    @Override
    public Set<RefType> getTypes(boolean includeLibraries) {
        Set<RefType> types = new HashSet<>();

        getSources().forEach(source -> {
            types.addAll(source.getTypes());
        });

        // -- includeLibraries not implemented

        return types;
    }

    @Override
    public Set<RefType> getUsedTypes() {
        Set<RefType> usedTypes = new HashSet<>();

        getSources().forEach(source -> {
            usedTypes.addAll(source.getUsedTypes());
        });

        return usedTypes;
    }

}

package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.dependencies.FieldNode;
import ae.ebtic.spl.analysis.dependencies.LibraryNode;
import ae.ebtic.spl.analysis.dependencies.MethodNode;
import ae.ebtic.spl.analysis.dependencies.ModuleNode;
import ae.ebtic.spl.analysis.dependencies.ParameterNode;
import ae.ebtic.spl.analysis.dependencies.ProjectNode;
import ae.ebtic.spl.analysis.dependencies.ResourceNode;
import ae.ebtic.spl.analysis.dependencies.SourceNode;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.features.FeatureNode;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.util.NodeName;

import java.util.Map;

public class GraphNode extends NamedObject implements GraphConstants {

    protected ProjectGraphAccess pga;
    protected Map<String, Object> nv;
    protected String id;
    protected Name name;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected GraphNode(ProjectGraphAccess pga, Map<String, Object> nv) {
        super(new NodeName(nv));

        this.pga = pga;
        this.nv = nv;
        this.id = (String)nv.get(GRAPH_NODE_ID);
        this.name = new NodeName(nv);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public ProjectGraphAccess getProjectGraphAccess() {
        return pga;
    }

    public String getId() {
        return this.id;
    }

    public Name getName() {
        return this.name;
    }

    public Map<String, Object> getValues() {
        return this.nv;
    }

    // ----------------------------------------------------------------------
    // Check & cast Dependency Model
    // ----------------------------------------------------------------------

    private boolean isa(Class<? extends GraphNode> nodeClass) {
        return getClass().equals(nodeClass);
    }

    // --

    public boolean isField() {
        return isa(FieldNode.class);
    }

    public boolean isLibrary() {
        return isa(LibraryNode.class);
    }

    public boolean isMethod() {
        return isa(MethodNode.class);
    }

    public boolean isModule() {
        return isa(ModuleNode.class);
    }

    public boolean isParameter() {
        return isa(ParameterNode.class);
    }

    public boolean isProject() {
        return isa(ProjectNode.class);
    }

    public boolean isSource() {
        return isa(SourceNode.class);
    }

    public boolean isResource() {
        return isa(ResourceNode.class);
    }

    public boolean isType() {
        return isa(TypeNode.class);
    }

    // --

    public FieldNode asField() {
        return (FieldNode)this;
    }

    public LibraryNode asLibrary() {
        return (LibraryNode)this;
    }

    public MethodNode asMethod() {
        return (MethodNode)this;
    }

    public ModuleNode asModule() {
        return (ModuleNode)this;
    }

    public ParameterNode asParameter() {
        return (ParameterNode) this;
    }

    public ProjectNode asProject() {
        return (ProjectNode) this;
    }

    public SourceNode asSource() {
        return (SourceNode) this;
    }

    public ResourceNode asResource() {
        return (ResourceNode) this;
    }

    public TypeNode asType() {
        return (TypeNode) this;
    }

    // ----------------------------------------------------------------------
    // Check & cast Component Model
    // ----------------------------------------------------------------------

    public boolean isComponent() {
        return isa(ComponentNode.class);
    }

    public ComponentNode asComponent() {
        return (ComponentNode)this;
    }

    // ----------------------------------------------------------------------
    // Check & cast Feature Model
    // ----------------------------------------------------------------------

    public boolean isFeature() {
        return isa(FeatureNode.class);
    }

    public FeatureNode asFeature() {
        return (FeatureNode)this;
    }

}

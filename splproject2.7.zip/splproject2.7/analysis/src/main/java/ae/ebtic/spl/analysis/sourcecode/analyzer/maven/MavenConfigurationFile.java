package ae.ebtic.spl.analysis.sourcecode.analyzer.maven;

import ae.ebtic.spl.analysis.sourcecode.analyzer.configuration.CommonConfiguration;
import ae.ebtic.spl.analysis.sourcecode.analyzer.configuration.ModuleConfiguration;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.maven.MavenPom;
import jext.util.FileUtils;
import jext.util.HashSet;
import jext.util.PathUtils;
import jext.xml.XPathUtils;
import org.w3c.dom.Element;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class MavenConfigurationFile extends CommonConfiguration {

    private MavenPom pom;

    public MavenConfigurationFile(File configurationFile) {
        super(configurationFile);
        this.pom = new MavenPom(configurationFile);
    }

    @Override
    public boolean isValid() {
        try {
            Element elt = XPathUtils.parse(configurationFile).getDocumentElement();
            return "project".equals(elt.getTagName());
        }
        catch (Throwable t) {
            return false;
        }
    }

    @Override
    public ModuleConfiguration setDownloader(Project project) {
        super.setDownloader(project);
        MavenDownloader md = project.getLibraryDownloader();
        this.pom.setDownloader(md);
        return this;
    }

    @Override
    public MavenCoords getMavenCoords() {
        return pom.getCoords();
    }

    @Override
    public List<String> getMavenRepositories() {
        return pom.getRepositories();
    }

    @Override
    public Set<MavenCoords> getMavenDependencies() {
        // Properties properties = new Properties();
        // addProperties(properties, pom);
        // return pom.getDependencies(properties);
        return new HashSet<>(pom.getDependencyCoords());
    }

    // @Override
    // public Set<MavenCoords> getLibraries() {
    //     Properties properties = new Properties();
    //     addProperties(properties, pom);
    //     return pom.getDependencies(properties);
    // }

    @Override
    public Set<String> getDependencies(String projectDir) {
        return pom.getModules()
            .stream()
            .map(moduleId -> toModuleName(projectDir, moduleId))
            .collect(Collectors.toSet());
    }

    private String toModuleName(String projectPath, String moduleId) {
        String modulePath = FileUtils.toCanonicalPath(configurationDir, moduleId);
        String moduleName = PathUtils.relativePath(projectPath, modulePath);
        return moduleName;
    }

    // private void addProperties(Properties properties, MavenPom pom) {
    //     if (pom == null) return;
    //     MavenPom parentPom = pom.getParentPom();
    //
    //     addProperties(properties, parentPom);
    //
    //     properties.putAll(pom.getProperties());
    //
    //     PropertiesUtils.resolveProperties(properties);
    // }
}

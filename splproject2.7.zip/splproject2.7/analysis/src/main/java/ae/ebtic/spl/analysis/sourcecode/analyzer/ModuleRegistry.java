package ae.ebtic.spl.analysis.sourcecode.analyzer;

import ae.ebtic.spl.analysis.sourcecode.model.Module;
import jext.logging.Logger;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class ModuleRegistry {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static Logger logger = Logger.getLogger(ModuleRegistry.class);

    private Map<String, Module> moduleMap = new HashMap<>();
    private List<Module> modules = new ArrayList<>();
    private Set<File> moduleDirs = new HashSet<>();

    private Set<String> missingModules = new HashSet<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public List<Module> getModules(Module parentModule, boolean recursive) {
        boolean isProject = (parentModule.getProject() == parentModule);
        if (isProject && recursive)
            return modules;

        String parentName = parentModule.getName().getFullName();
        List<Module> modules = new ArrayList<>();
        this.modules.forEach(module -> {
            String moduleName = module.getName().getFullName();
            if (isSubModule(parentName, moduleName, recursive))
                modules.add(module);
        });
        return modules;
    }

    private static boolean isSubModule(String parentName, String moduleName, boolean recursive) {

        if (parentName.isEmpty()) {
            if (recursive)
                return true;
            else
                return !moduleName.contains("/");
        }

        // parent ::= <name>
        //  child ::= <name>/<sub>...
        // subsub ::= <name>/<sub>/<sub>...
        boolean isChild = moduleName.length() > parentName.length()
            && moduleName.startsWith(parentName)
            && moduleName.charAt(parentName.length()) == '/';
        boolean isSubSub = moduleName.indexOf("/", parentName.length()+2) != -1;
        return recursive && isChild || isChild && !isSubSub;
    }

    public Module getModule(String moduleName) {
        if (moduleName == null)
            moduleName = "";
        if (moduleMap.containsKey(moduleName))
            return moduleMap.get(moduleName);

        // search a module with suffix
        for(Module module : modules) {
            String mname = module.getName().getName();
            String mid = module.getId();
            if (moduleName.equals(mname) || moduleName.equals(mid))
                return module;
        }

        if (!missingModules.contains(moduleName)) {
            missingModules.add(moduleName);
            logger.errorf("No module %s available", moduleName);
        }
        return null;
    }

    public Set<File> getModuleDirs() {
        return moduleDirs;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public ModuleRegistry register(Module module) {

        // checkParentModule(module);
        registerModule(module);

        return this;
    }

    private void registerModule(Module module) {

        // register the module
        String moduleName = module.getName().getFullName();
        if (moduleMap.containsKey(moduleName))
            logger.errorf("Module '%s' (%s) already registered (%s)",
                moduleName,
                module.getPath(),
                moduleMap.get(moduleName).getPath());

        moduleMap.put(moduleName, module);
        modules.add(module);
        moduleDirs.add(new File(module.getPath()));
    }
}

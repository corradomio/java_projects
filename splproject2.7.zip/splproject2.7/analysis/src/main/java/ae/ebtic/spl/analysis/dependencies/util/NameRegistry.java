package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import jext.logging.Logger;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Semaphore;

public class NameRegistry {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    protected Logger logger = Logger.getLogger(getClass());

    // name -> id
    protected NameMap<String> nameIdMap = new NameMap<>();

    // ----------------------------------------------------------------------
    // Registration for Name objects
    // ----------------------------------------------------------------------

    protected void register(String id, Name name) {
        nameIdMap.put(name, id);
    }

    protected boolean isRegistered(Name name) {
        if (name == null) return false;
        return nameIdMap.containsKey(name);
    }

    protected String/*id*/ getId(Name name) {
        if (name == null) return null;
        return nameIdMap.getOrDefault(name, null);
    }

    // ----------------------------------------------------------------------
    // Support for parallel
    // ----------------------------------------------------------------------

    // semaphores
    private final Map<String, Semaphore> semaMap = new HashMap<>();

    protected String getIdOrLock(Name name) {
        lock(name);
        if (isRegistered(name)) {
            String nameId = getId(name);
            release(name);
            return nameId;
        }
        else
            return null;
    }

    protected NameRegistry registerAndRelease(String id, Name name) {
        if (id != null)
            register(id, name);
        release(name);
        return this;
    }

    protected void lock(Name name) {
        Semaphore sema;
        synchronized (this) {
            String fullName = name.getFullName();
            if (!semaMap.containsKey(fullName))
                semaMap.put(fullName, new Semaphore(1));
            sema = semaMap.get(fullName);
        }

        try {
            sema.acquire();
        }
        catch (InterruptedException e) {
            throw new RuntimeException(e);
        }
    }

    protected void release(Name name) {
        Semaphore sema;
        synchronized (this) {
            String fullName = name.getFullName();
            sema = semaMap.getOrDefault(fullName, null);
        }

        if (sema == null) {
            logger.errorf("Try to release a not acquired lock: %s", name);
            return;
        }

        if (sema.availablePermits() != 0)
            logger.errorf("%s RELEASED TOO TIMES!!!!!", name);
        else
            sema.release();
    }

}

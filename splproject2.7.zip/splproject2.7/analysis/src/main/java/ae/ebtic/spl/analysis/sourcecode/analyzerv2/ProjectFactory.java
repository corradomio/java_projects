package ae.ebtic.spl.analysis.sourcecode.analyzerv2;

import ae.ebtic.spl.analysis.sourcecode.analyzerv2.ant.AntProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.eclipse.EclipseProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.GradleProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.maven.MavenProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.simple.SimpleProject;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.logging.Logger;
import jext.util.Parameters;

import java.io.File;
import java.io.IOException;
import java.nio.file.FileVisitResult;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.SimpleFileVisitor;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import static ae.ebtic.spl.analysis.sourcecode.analyzerv2.GuessProjectType.guessProjectType;
import static ae.ebtic.spl.analysis.sourcecode.analyzerv2.GuessRuntimeLibrary.guessRuntimeLibrary;
import static ae.ebtic.spl.analysis.sourcecode.model.Project.PROJECT_TYPE;
import static ae.ebtic.spl.analysis.sourcecode.model.Project.RUNTIME_LIBRARY;

public class ProjectFactory {

    // ----------------------------------------------------------------------
    // Static Methods
    // ----------------------------------------------------------------------

    public static List<Project> findProjects(File directory, Properties props) {
        List<Project> projects = new ArrayList<>();
        Properties nprops = new Properties();
        nprops.putAll(nprops);
        nprops.setProperty("check.moduleOnly", "true");

        try {
            Files.walkFileTree(directory.toPath(), new SimpleFileVisitor<Path>() {

                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs)
                {
                    File projectDir = dir.toFile();
                    if (guessProjectType(projectDir, nprops).equals(SimpleProject.TYPE))
                        return FileVisitResult.CONTINUE;

                    projects.add(newProject(projectDir, props));
                    return FileVisitResult.SKIP_SUBTREE;
                }
            });
        } catch (IOException e) {
            Logger.getLogger(ProjectFactory.class).error(e, e);
        }

        return projects;
    }


    public static Project newProject(String projectName, File projectDir, Properties properties) {

        Project project;
        String projectType;
        String runtimeLibrary;

        //
        // If the project type is not specified, we try to understand it based on
        // presence of 'building system configuration files' (for example 'pom.xml',
        // 'build.gradle', etc) following the SPECIFIC order:
        //
        //      1) Gradle
        //      2) Maven
        //      3) Eclipse
        //      4) Ant
        //      5) Simple
        //

        projectType = properties.getProperty(PROJECT_TYPE, null);
        if (projectType == null)
            projectType = guessProjectType(projectDir, properties);

        if (AntProject.TYPE.equals(projectType))
            project = new AntProject(projectName, projectDir, properties);
        else if (MavenProject.TYPE.equals(projectType))
            project = new MavenProject(projectName, projectDir, properties);
        else if (GradleProject.TYPE.equals(projectType))
            project = new GradleProject(projectName, projectDir, properties);
        else if (EclipseProject.TYPE.equals(projectType))
            project = new EclipseProject(projectName, projectDir, properties);
        else if (SimpleProject.TYPE.equals(projectType))
            project = new SimpleProject(projectName, projectDir, properties);
        else
            project = new SimpleProject(projectName, projectDir, properties);

        //
        // Check the runtimeLibrary to use
        // In theory it is possible to identify the correct version of Java or Android
        // But this can be expensive.
        //

        runtimeLibrary = project.getProperties().getProperty(RUNTIME_LIBRARY, null);
        if (runtimeLibrary == null)  {
            runtimeLibrary = guessRuntimeLibrary(project);
            project.getProperties().setProperty(RUNTIME_LIBRARY, runtimeLibrary);
        }

        return project;
    }

    public static Project newProject(Name name, File projectDir, Properties properties) {
        return newProject(name.getFullName(), projectDir, properties);
    }

    // ----------------------------------------------------------------------
    // DEBUG
    // ----------------------------------------------------------------------

    public static Project newProject(File projectDir) {
        return newProject(projectDir, Parameters.empty());
    }

    public static Project newProject(String projectDir) {
        return newProject(new File(projectDir), Parameters.empty());
    }

    public static Project newProject(String projectDir, Parameters params) {
        return newProject(new File(projectDir), params);
    }

    public static Project newProject(File projectDir, Properties properties) {
        return newProject(projectDir.getName(), projectDir, properties);
    }

    public static Project newProject(File projectDir, Parameters params) {
        return newProject(projectDir.getName(), projectDir, params.toProperties());
    }
}

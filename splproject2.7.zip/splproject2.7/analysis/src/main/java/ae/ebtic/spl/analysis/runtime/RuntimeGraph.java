package ae.ebtic.spl.analysis.runtime;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.features.FeatureNode;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.Direction;
import jext.graph.GraphSession;
import jext.util.HashMap;
import jext.util.Parameters;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Set;

import static jext.graph.NodeId.asIds;


public class RuntimeGraph  extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public RuntimeGraph(ProjectGraphAccess pga) {
        super(pga, RUNTIME);
    }

    // ----------------------------------------------------------------------
    // Model descriptor
    // ----------------------------------------------------------------------

    @Override
    public long getTimestamp() {
        Map<String, Object> nv = null;
        try(GraphSession session = graphdb.connect()) {
            String nodeId = session.findNode(RUNTIME, Parameters.params(
                PROJECT_ID, projectId
            ));
            if (nodeId != null)
                nv = session.getNodeValues(nodeId);

            if (nv != null)
                return (Long)nv.getOrDefault(TIMESTAMP, 0L);
            else
                return 0L;
        }
    }

    @Override
    protected void deleteModelElements(String projectId) {
        deleteEntryPoints();
    }

    /**
     * Delete the property 'entryPoint' to all nodes (of the current project)
     * in the database
     */
    private void deleteEntryPoints() {
        try(GraphSession session = graphdb.connect()) {
            // delete the 'flag' node
            // session.deleteNodes(RUNTIME, Parameters.params(PROJECT_ID, projectId));

            // delete the entryPoints
            Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                ENTRY_POINT, null
            );

            List<String> ids = session.queryNodes(null, params).ids().toList();
            session.deleteNodesProperties(ids, Arrays.asList(ENTRY_POINT, COUNT_ENTRY_POINTS/*, ENTRY_POINT_SCORE*/));
        }
    }

    /**
     * Update the flag 'entryPoint' to components & features, using, as starting point, the
     * list of types with the flag!
     * A component/feature is marked 'entryPoint' if the reference type is marked 'entryPoint'
     * The 'entryPointScore' is computed as #entryPointTypes/#types
     *
     * Entrypoint scores:
     *
     *      [0]     score of the reference type IF it is a 'entryPoint type', 0 otherwise
     *      [1]     #local_entryPointTypes/#local_types
     *      [2]     #local_entryPointTypes/#global_entryPointTypes
     */
    public void updateEntryPoints() {

        try(GraphSession session = graphdb.connect()) {

            EntryPointTypes epTypes = findEntryPointTypes(session);

            updateReferencedEntryPoints(session, COMPONENT, epTypes);
            updateReferencedEntryPoints(session, FEATURE, epTypes);

            updateOtherEntryPoints(session, COMPONENT, epTypes);
            updateOtherEntryPoints(session, FEATURE, epTypes);

            // updateEntryPoints(session, COMPONENT, typeNames);
            // updateEntryPoints(session, FEATURE, typeNames);

            // updateEntryPointScores(session, COMPONENT, typeIds);
            // updateEntryPointScores(session, FEATURE, typeIds);
        }
    }

    // delete component/features entry points
    public void resetEntryPoints() {
        List<String> ids;
        try(GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                ENTRY_POINT, null
            );

            ids = session.queryNodes(COMPONENT, params).ids().toList();
            session.deleteNodesProperties(ids, Arrays.asList(ENTRY_POINT, COUNT_ENTRY_POINTS/*, ENTRY_POINT_SCORE*/));

            ids = session.queryNodes(FEATURE, params).ids().toList();
            session.deleteNodesProperties(ids, Arrays.asList(ENTRY_POINT, COUNT_ENTRY_POINTS/*, ENTRY_POINT_SCORE*/));
        }
    }

    // ----------------------------------------------------------------------

    /**
     * Retrieve the number of types/components/features marked as entry point
     */
    public Map<String, Long> getEntryPointsCounts() {
        Map<String, Long> counts = new HashMap<>();
        try(GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                ENTRY_POINT, true
            );

            counts.put(TYPE, session.queryNodes(TYPE, params).count());
            counts.put(COMPONENT, session.queryNodes(COMPONENT, params).count());
            counts.put(FEATURE, session.queryNodes(FEATURE, params).count());
        }
        return counts;
    }

    // ----------------------------------------------------------------------
    // Handle 'entryPoint' for types

    /** set the property 'countMethods'  */
    public void setTypesCountMethods() {
        try(GraphSession session = graphdb.connect()) {
            List<String> ids = session.queryUsing("findTypesWithoutCountMethods", Parameters.params(
                PROJECT_ID, projectId
            )).ids().toList();

            for (String typeId : ids) {
                // count the number of methods
                long count = session.queryAdjacentNodes(typeId,
                    MEMBER_OF, Direction.Input, false, METHOD,
                    Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).count();

                session.setNodeProperty(typeId, COUNT_METHODS, count);
            }
        }
    }

    // /**
    //  * Assign the flag "entryPoint" to the list of specified classes
    //  * @param typeEntryPoints
    //  */
    // public void setEntryPointTypeInfos(Set<String> typeEntryPoints) {
    //     Parameters isEntryPoint = Parameters.params(ENTRY_POINT, true);
    //
    //     try(GraphSession session = graphdb.connect()) {
    //         Parameters params = Parameters.params(
    //             PROJECT_ID, projectId,
    //             FULLNAME, new ArrayList<>(typeEntryPoints)
    //         );
    //         List<String> ids = session.queryNodes(TYPE, params).ids().toList();
    //
    //         session.setNodesProperties(ids, isEntryPoint);
    //     }
    // }

    public void setEntryPointTypeInfos(Map<String, Set<String>> epInfos) {

        // list of entry point types
        List<String> entryPointTypes = new ArrayList<>(epInfos.keySet());

        // set the flag 'entryPoint=true' to the types in set entryPointTypes
        try(GraphSession session = graphdb.connect()) {
            // retrieve the list of 'entry point type' ids
            List<String> ids = session.queryNodes(TYPE, Parameters.params(
                PROJECT_ID, projectId,
                FULLNAME, entryPointTypes
            )).ids().toList();

            // set the flag 'entryPoint=true'
            session.setNodesProperties(ids, Parameters.params(ENTRY_POINT, true));
        }

        // set the 'entryPointCount' based on the method count
        try(GraphSession session = graphdb.connect()) {

            // scan the list of type names
            for(String typeName : epInfos.keySet()) {
                Set<String> methods = epInfos.get(typeName);

                setEntryPointTypeCount(session, typeName, methods);

                // mark each method as 'entry point'
                for(String methodName : methods)
                    setEntryPointMethod(session, typeName, methodName);
            }
        }
    }

    private void setEntryPointTypeCount(GraphSession session, String typeName, Set<String> methods) {

        // find the nodeId for the node 'type' with the selected 'typeName'
        String typeId = session.queryNodes(TYPE, Parameters.params(
            PROJECT_ID, projectId,
            FULLNAME, typeName
        )).id();

        // node not found
        if (typeId == null) {
            logger.warnf("Type %s not found", typeName);
            return;
        }

        // count the number of methods in the type
        int nMethods = (int)session.queryAdjacentNodes(typeId,
            MEMBER_OF, Direction.Input, false, METHOD,
            Parameters.params(PROJECT_ID, projectId),
            Parameters.empty())
            .count();

        int nEpMethods = methods.size();

        session.setNodeProperty(typeId, COUNT_METHODS, nMethods);
        session.setNodeProperty(typeId, COUNT_ENTRY_POINTS, nEpMethods);
    }

    private void setEntryPointMethod(GraphSession session, String typeName, String methodName) {

        // search the method with the specified name in the specified type
        String methodId = session.queryNodes(METHOD,
            Parameters.params(
                PROJECT_ID, projectId,
                NAMESPACE, typeName,
                NAME, methodName
            )).id();

        if (methodId == null) {
            logger.warnf("Method %s::%s not found", typeName, methodName);
            return;
        }

        session.setNodeProperty(methodId, ENTRY_POINT, true);
    }

    // ----------------------------------------------------------------------
    // getEntryPointXXX()
    // ----------------------------------------------------------------------

    public List<Type> getEntryPointTypes() {
        List<Map<String, Object>> nvlist = getEntryPointObjects(TYPE);

        return TypeNode.of(pga.getDependencyGraph(), nvlist);
    }

    public List<Component> getEntryPointComponents() {
        List<Map<String, Object>> nvlist = getEntryPointObjects(COMPONENT);

        return ComponentNode.of(pga.getComponentGraph(), nvlist);
    }

    public List<Feature> getEntryPointFeatures() {
        List<Map<String, Object>> nvlist = getEntryPointObjects(FEATURE);

        return FeatureNode.of(pga.getFeatureGraph(), nvlist);
    }

    private List<Map<String, Object>> getEntryPointObjects(String objectType) {
        try(GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                ENTRY_POINT, true
            );

            return session.queryNodes(objectType, params).allValues().toList();
        }
    }

    // --

    static class Info {
        String id;
        String name;
        long nMethods;
        long nEpMethods;

        Info(String id, String name, long nMethods, long nEpMethods) {
            this.id = id;
            this.name = name;
            this.nMethods = nMethods;
            this.nEpMethods = nEpMethods;
        }
    }

    static class EntryPointTypes {
        List<String> names = new ArrayList<>();
        List<String> ids = new ArrayList<>();
        Map<String, Info> idMap = new HashMap<>();
        Map<String, Info> nameMap = new HashMap<>();

        void add(Info info) {
            idMap.put(info.id, info);
            nameMap.put(info.name, info);
            names.add(info.name);
            ids.add(info.id);
        }

        // int count() {
        //     return infos.size();
        // }
    }

    // retrieve the set of id an fullname of all types defined as 'entryPoint'
    private EntryPointTypes findEntryPointTypes(GraphSession session) {
        List<Map<String, Object>> nvlist;
        EntryPointTypes typeInfos = new EntryPointTypes();

        Parameters params = Parameters.params(
            PROJECT_ID, projectId,
            TYPE, TYPE,
            ENTRY_POINT, true
        );

        // select types with 'entryPoint=true'
        nvlist = session.queryNodes(TYPE, params).allValues().toList();

        nvlist.forEach(nv -> {
            String typeId = nv.get(GRAPH_NODE_ID).toString();
            String typeName = (String) nv.get(FULLNAME);
            long nMethods = (Long) nv.getOrDefault(COUNT_METHODS, 0L);
            long nEpMethods = (Long)nv.getOrDefault(COUNT_ENTRY_POINTS, 0L);

            Info info = new Info(typeId, typeName, nMethods, nEpMethods);
            typeInfos.add(info);
        });

        return typeInfos;
    }


    // ----------------------------------------------------------------------
    // Update entryPoints for components & features
    // ----------------------------------------------------------------------
    // entryPoint=true IF the referencedType is 'entryPoint=true'
    // countEntryPoints: long[3]
    //      [0]: n of methods marked as 'entryPoint method' in the 'referenced type' This can be '0'
    //      [1]: n of contained types marked as 'entryPoint type' : valid
    //      [2]: n of 'entryPoint methods' (sum of the n_of_entryPoint_methods present inside the closure)


    private void updateReferencedEntryPoints(GraphSession session, String nodeType, EntryPointTypes epTypes) {

        // 1) search the objects with the 'reference type'
        List<Map<String, Object>> nvlist = session.queryNodes(nodeType,
            Parameters.params(
                PROJECT_ID, projectId,
                FULLNAME, epTypes.names
            )).allValues().toList();

        // 2) set the flag "entryPoint" and the count "countEntryPoints"
        for (Map<String, Object> nv : nvlist) {
            String nodeId = nv.get(GRAPH_NODE_ID).toString();
            String typeId = nv.get(TYPE_ID).toString();

            // long nTypes =  (Long)nv.get(COUNT_TYPES);
            // count the number of types marked 'entryPoint'
            long nEpTypes = session.queryAdjacentNodes(nodeId,
                CONTAINS, Direction.Output, true, TYPE,
                Parameters.params(
                    PROJECT_ID, projectId,
                    ENTRY_POINT, true,
                    FULLNAME, epTypes.names),
                Parameters.empty())
                .distinct().count();

            long nEpMethodsType = 0;
            if (epTypes.idMap.containsKey(typeId))
                nEpMethodsType = epTypes.idMap.get(typeId).nEpMethods;
            long nEpMethods = countEpMethods(session, nv, epTypes);

            session.setNodeProperties(nodeId, Parameters.params(
                ENTRY_POINT, true,
                COUNT_ENTRY_POINTS, new long[]{
                    nEpMethodsType,
                    nEpTypes,
                    nEpMethods
                }
            ));

        }
    }

    private void updateOtherEntryPoints(GraphSession session, String nodeType, EntryPointTypes epTypes) {
        // 1) search all objects containing some 'entry point type'

        List<Map<String, Object>> nvlist = session.queryAdjacentNodes(epTypes.ids,
            CONTAINS, Direction.Input, true, nodeType,
            Parameters.params(PROJECT_ID, projectId),
            Parameters.empty()).distinct().allValues().toList();

        for(Map<String, Object> nv : nvlist) {
            // check if already processed
            if (nv.containsKey(ENTRY_POINT))
                continue;

            String nodeId = nv.get(GRAPH_NODE_ID).toString();
            String typeId = nv.get(TYPE_ID).toString();

            // long nTypes =  (Long)nv.get(COUNT_TYPES);
            long nEpTypes = session.queryAdjacentNodes(nodeId,
                CONTAINS, Direction.Output, true, TYPE,
                Parameters.params(
                    PROJECT_ID, projectId,
                    ENTRY_POINT, true,
                    FULLNAME, epTypes.names),
                Parameters.empty())
                .distinct().count();

            long nEpMethodsType = 0;
            if (epTypes.idMap.containsKey(typeId))
                nEpMethodsType = epTypes.idMap.get(typeId).nEpMethods;
            long nEpMethods = countEpMethods(session, nv, epTypes);

            session.setNodeProperties(nodeId, Parameters.params(
                ENTRY_POINT, false,
                COUNT_ENTRY_POINTS, new long[]{
                    nEpMethodsType,
                    nEpTypes,
                    nEpMethods
                }
            ));
        }
    }

    // private long[] countTypes(GraphSession session, Map<String, Object> nv, EntryPointTypes epTypes) {
    //     String nodeId = nv.get(GRAPH_NODE_ID).toString();
    //     long[] countTypes = new long[2];
    //     countTypes[0] =  (Long)nv.get(COUNT_TYPES);
    //     countTypes[1] = session.queryAdjacentNodes(nodeId,
    //         CONTAINS, Direction.Output, true, TYPE,
    //         Parameters.params(
    //             PROJECT_ID, projectId,
    //             ENTRY_POINT, true,
    //             FULLNAME, epTypes.names),
    //         Parameters.empty())
    //         .distinct().count();
    //
    //     return countTypes;
    // }

    private long countEpMethods(GraphSession session, Map<String, Object> nv, EntryPointTypes epTypes) {
        String nodeId = nv.get(GRAPH_NODE_ID).toString();

        List<String> typeIds = session.queryAdjacentNodes(nodeId,
            CONTAINS, Direction.Output, true, TYPE,
            Parameters.params(PROJECT_ID, projectId),
            Parameters.empty())
            .distinct().ids().toList();

        List<Map<String, Object>> results = session.queryUsing("countEntryPointsAndMethods", Parameters.params(
            PROJECT_ID, projectId,
            "ids", asIds(typeIds)
        )).result().toList();

        if (results.isEmpty())
            return 0;
        else
            return (Long)results.get(0).get("nEpMethods");
    }

    // ----------------------------------------------------------------------
    // ONLY FOR DEBUG
    // ----------------------------------------------------------------------
    //
    // Generate random entry points
    // public void setEntryPointRandom(double prob) {
    //     Random rnd = new Random();
    //     try(GraphSession session = graphdb.connect()) {
    //         Parameters params = Parameters.params(
    //             PROJECT_ID, projectId,
    //             TYPE, TYPE
    //         );
    //
    //         List<String> nodeIds = session.queryNodes(TYPE, params).ids().toList();
    //         for (String nodeId : nodeIds) {
    //             double r = rnd.nextDouble();
    //             if (r < prob)
    //                 session.setNodeProperty(nodeId, ENTRY_POINT, true);
    //         }
    //         session.setNodesProperties(nodeIds, params);
    //     }
    // }
}

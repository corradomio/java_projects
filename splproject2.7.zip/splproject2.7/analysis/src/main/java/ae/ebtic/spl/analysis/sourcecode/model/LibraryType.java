package ae.ebtic.spl.analysis.sourcecode.model;

public enum LibraryType {
    INVALID,
    LOCAL,
    MAVEN,
    RUNTIME,

    // LOCAL_JAR,
    // LOCAL_COLLECTION,
    // MAVEN_COLLECTION,
    // MODULE
    // DESCRIPTOR,
}

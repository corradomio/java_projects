package ae.ebtic.spl.analysis.sourcecode.analyzerv2;

import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;

import java.util.Set;

public class GuessRuntimeLibrary {

    // ----------------------------------------------------------------------
    // Constants
    // ----------------------------------------------------------------------

    private static final String DEFAULT_JAVA_RUNTIME_LIBRARY = "jdk8";
    private static final String DEFAULT_ANDROID_RUNTIME_LIBRARY = "pie";
    private static final String DEFAULT_ANDROIDX_RUNTIME_LIBRARY = "pie";
    private static final String ANDROID_NS  ="android.";
    private static final String ANDROIDX_NS  ="androidx.";

    // ----------------------------------------------------------------------
    // Static method
    // ----------------------------------------------------------------------

    public static String guessRuntimeLibrary(Project project) {

        String runtimeName;
        GuessRuntimeLibrary grtl = new GuessRuntimeLibrary(project);

        runtimeName = grtl.checkConfiguration();
        if (runtimeName != null)
            return runtimeName;

        runtimeName = grtl.checkAndroidProject();
        if (runtimeName != null)
            return runtimeName;

        runtimeName = grtl.checkJavaProject();
        if (runtimeName != null)
            return runtimeName;

        return DEFAULT_JAVA_RUNTIME_LIBRARY;
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private Project project;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private GuessRuntimeLibrary(Project project) {
        this.project = project;
    }

    private String checkConfiguration() {
        return project.getProperties().getProperty(Project.RUNTIME_LIBRARY, null);
    }

    private String checkAndroidProject() {

        int androidCount = 0;
        for (Module module : project.getModules()) {
            Set<RefType> usedTypes = module.getUsedTypes();
            for (RefType refType : usedTypes) {
                if (refType.getName().getFullName().startsWith(ANDROID_NS) ||
                    refType.getName().getFullName().startsWith(ANDROIDX_NS) )
                    androidCount += 1;
            }
        }

        if (androidCount > 0)
            return DEFAULT_ANDROID_RUNTIME_LIBRARY;
        else
            return null;
    }

    private String checkJavaProject() {
        return null;
    }
}

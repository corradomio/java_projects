package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import jext.util.Parameters;

public class ASTTypeDeclarations extends ASTAnalyzer {

    public ASTTypeDeclarations(DependencyAnalyzer da) {
        super(da);
    }

    public void analyze(Source source, Parameters params) {
        super.analyze(source, params);
    }

    protected void analyze(CompilationUnit cu) {
        super.analyze(cu);

        cu.findAll(ClassOrInterfaceDeclaration.class)
            .forEach(this::createTypeNode);

        cu.findAll(EnumDeclaration.class)
            .forEach(this::createTypeNode);

        cu.findAll(AnnotationDeclaration.class)
            .forEach(this::createTypeNode);
    }

    private void createTypeNode(ClassOrInterfaceDeclaration cid) {
        RefType refType = toRefType(cid);
        String typeId = createTypeNode(refType);

        createCommentNode(typeId, cid, false);
        createTokenNodes(typeId, cid.getNameAsString());
    }

    private void createTypeNode(EnumDeclaration cid) {
        RefType refType = toRefType(cid);
        String typeId = createTypeNode(refType);

        createCommentNode(typeId, cid, false);
        createTokenNodes(typeId, cid.getNameAsString());
    }

    private void createTypeNode(AnnotationDeclaration cid) {
        RefType refType = toRefType(cid);
        String typeId = createTypeNode(refType);

        createCommentNode(typeId, cid, false);
    }

    protected String createTypeNode(RefType refType) {
        datodg.createNamespaceNode(refType.getName().getParent());
        return datodg.createTypeNode(refType);
    }

    // ----------------------------------------------------------------------
    // Tokens
    // ----------------------------------------------------------------------

    protected void createTokenNodes(String nodeId, String fullName) {

        /*
        regex to split in the following way:
        given N uppercase chars:

        if the N chars are followed by lower case chars, the groups should be: (N-1 chars) / (N-th char + lower chars)
        if the N chars are at the end, the group should be: (N chars).
         */
        String[] names = fullName.split("(?<!(^|[A-Z]))(?=[A-Z])|(?<!^)(?=[A-Z][a-z])");

        String prevTokenId = null;
        for(String token: names){
            String tokenId = datodg.createTokenNode(token, fullName);
            datodg.createEdge(CONTEXT, nodeId, tokenId, CONTEXT);
            if(prevTokenId != null){
                datodg.createEdge(FOLLOWS, prevTokenId, tokenId, FOLLOWS);
            }
            prevTokenId = tokenId;
        }

    }


}

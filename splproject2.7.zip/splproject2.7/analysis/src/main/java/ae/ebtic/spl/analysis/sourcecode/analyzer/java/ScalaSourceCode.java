package ae.ebtic.spl.analysis.sourcecode.analyzer.java;

import ae.ebtic.spl.analysis.sourcecode.analyzer.SourceCode;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Type;

import java.io.File;
import java.util.Collections;
import java.util.List;

public class ScalaSourceCode extends SourceCode {

    public ScalaSourceCode(File file, Module module) {
        super(file, module);
    }

    @Override
    public List<Type> getTypes() {
        return Collections.emptyList();
    }

    @Override
    public List<RefType> getUsedTypes() {
        return Collections.emptyList();
    }
}

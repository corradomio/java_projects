package ae.ebtic.spl.analysis.statistics.core;

import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.logging.Logger;
import jext.util.KCoreAnalyzer;

import java.util.*;

public class CoreAnalyzer implements GraphConstants {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static CoreAnalyzer newAnalyzer(AnalyzerConfig config) {
        CoreAnalyzer analyzer = new CoreAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }


    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // if aborted
    private boolean aborted;

    // Configuration
    private AnalyzerConfig config;

    // Handle the component graph
    private CoreGraph cg;

    // core project id
    private String coreProjectId;

    // logger
    private Logger logger;

    // listeners
    private Listeners listeners = new Listeners();

    //feature count list
    ArrayList<Map<String, Object>> featureNodes;

    //KCore score list
    ArrayList<Map<String, Object>> kCoreNodes;
    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private CoreAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    private CoreAnalyzer initialize() {

        logger = Logger.getLogger("%s.%s.%s",
                getClass(), config.getProjectName().getParentName(), config.getProjectName().getName());

        GraphConfig config = new GraphConfig()
                .setGraphDatabase(this.config.getGraphDatabase())
                .setProjectName(this.config.getProjectName())
                .setParameters(this.config.getParameters());

        //cg = CoreGraph.newCoreGraph(config);
        cg = ProjectGraphAccess.newProjectGraphAccess(config).getCoreGraph();

        return this;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    /**
     * Abort the analysis
     */
    public void abort() {
        this.aborted = true;
    }

    public void analyze(){

        if (aborted) return;

        try (CoreGraph cg = (CoreGraph) this.cg.connect()) {
            createCoreNode();

            // Find Node-Feature count
            getTypeFeaturesNormalized();

            // K-Core Decomposition of the graph
            findKCore();

            aggregateScores();

            analysisDone(false);
        }
        catch (Throwable t) {
            logger.error(t, t);
            analysisDone(true);
        }

    }

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------

    private void createCoreNode() {
        if (aborted) return;

        coreProjectId = cg.create();
    }

    private void findKCore(){

        if (aborted) return;

        listeners.fireKCoreDecomposition(0);
        ArrayList<Map<String, Object>> nodes = (ArrayList<Map<String, Object>>) cg.getTypeGraph();

        listeners.fireKCoreDecomposition(1);

        kCoreNodes = (ArrayList<Map<String, Object>>)  KCoreAnalyzer.computeKCore(nodes);

        listeners.fireTypesProcessed(1,nodes.size());
    }

    private void getTypeFeaturesNormalized(){

        if (aborted) return;

        listeners.fireFindFeatureCount(0);
        ArrayList<Map<String, Object>> nodes = (ArrayList<Map<String, Object>>) cg.getTypeFeaturesCount();

        listeners.fireFindFeatureCount(nodes.size());

        int processed = 0;

        int maxFeatures = nodes.stream()
                .mapToInt(map->Integer.parseInt(map.getOrDefault("features",Integer.MIN_VALUE).toString()))
                .max().orElse(1);
        for(Map<String, Object> node: nodes){
            Double k = Integer.parseInt(node.get("features").toString()) * 1.0;
            k = k/(maxFeatures * 1.0);
            node.put("features", k);

            listeners.fireTypesProcessed(++processed, nodes.size());
        }
        featureNodes = nodes;
    }

    private void aggregateScores(){

        if(aborted) return;
        listeners.fireAggregateScores(kCoreNodes.size());

        int processed = 0;
        int i = 0;
        for(Map<String, Object> kNode: kCoreNodes){
            if (aborted) return;
            int id = Integer.parseInt(kNode.get("id").toString());
            double fScore = 0;
            for(;i<featureNodes.size();i++){
                Map<String, Object> fNode = featureNodes.get(i);
                int fid = Integer.parseInt(fNode.get("id").toString());
                if(fid > id)
                    break;
                if(fid == id){
                    fScore = Double.parseDouble(fNode.get("features").toString());
                    break;
                }
            }
            double KCore = Double.parseDouble(kNode.get("core").toString());
//            double score = (alpha * fScore) + (beta * KCore);
            ArrayList<Double> score = new ArrayList<>();
            score.add(fScore);
            score.add(KCore);
            kNode.put("score",score);

            listeners.fireTypesProcessed(++processed, kCoreNodes.size());
        }

        if (aborted) return;

        for(Map<String, Object> node: kCoreNodes){
            System.out.println(node.get("name")+" "+node.get("score"));
        }

        cg.writeScores(kCoreNodes);
    }


    // ----------------------------------------------------------------------
    // Utility Operations
    // ----------------------------------------------------------------------

    private Map<String, Object> getNode(List<Map<String, Object>> nodes, int id){

        for(Map<String, Object> node: nodes){
            if(Integer.parseInt(node.get("id").toString()) > id)
                break;
            if(Integer.parseInt(node.get("id").toString()) == id)
                return node;
        }

        return null;
    }

    private void analysisDone(boolean failed) {
        cg.setStatus((failed || aborted) ? STATUS_INVALID : STATUS_VALID, null);

        listeners.fireDone();
    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    private static class Listeners {

        private List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireFindFeatureCount(int types) {
            listeners.forEach(l -> l.onFindFeatureCount(types) );
        }

        void fireKCoreDecomposition(int types) {
            listeners.forEach(l -> l.onKCoreDecomposition(types) );
        }

        void fireAggregateScores(int types) {
            listeners.forEach(l -> l.onAggregateScore(types) );
        }

        void fireTypesProcessed(int typesProcessed, int totalTypes){
            listeners.forEach(l -> l.onTypesProcessed(typesProcessed, totalTypes) );
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone() );
        }

    }

    public CoreAnalyzer addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }
}

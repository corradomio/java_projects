package ae.ebtic.spl.analysis.components;

public interface ComponentAnalysis {

    ComponentAnalysis addListener(AnalyzerListener analyzerListener);

    void analyze();

    void abort();

    void delete();
}

package ae.ebtic.spl.analysis.sourcecode.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.TypeName;
import jext.lang.JavaUtils;

public class TypeObjectName extends ObjectName implements TypeName {

    public TypeObjectName(String name) {
        super(name);
    }

    // public TypeObjectName(String namespace, String name) {
    //     super(namespace, name);
    // }

    // public TypeObjectName(Name parent, String name) {
    //     super(parent, name);
    // }

    public TypeName getParent() {
        return new TypeObjectName(JavaUtils.namespaceOf(name));
    }
}

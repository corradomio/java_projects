package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Comment;

import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class CommentNode extends GraphNode implements Comment {

    public static List<CommentNode> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> CommentNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static CommentNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new CommentNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------
    private CommentNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }
}

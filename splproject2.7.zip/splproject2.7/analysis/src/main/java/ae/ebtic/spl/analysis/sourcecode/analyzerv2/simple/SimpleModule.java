package ae.ebtic.spl.analysis.sourcecode.analyzerv2.simple;

import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseModule;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;

import java.io.File;
import java.util.Collections;
import java.util.List;


public class SimpleModule extends BaseModule {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public SimpleModule(File moduleDir, Project project) {
        super(moduleDir, project);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    protected List<Module> getDependencies() {
        return Collections.emptyList();
    }
}

package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import ae.ebtic.spl.analysis.util.AnalysisConfig;
import jext.graph.GraphDatabase;
import jext.util.Parameters;


public class GraphConfig extends AnalysisConfig {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public GraphConfig() { }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // -- projectName

    public GraphConfig setProjectName(Name projectName) {
        this.projectName = projectName;
        return this;
    }

    public GraphConfig setProjectName(String repository, String projectName) {
        return setProjectName(new PathName(repository, projectName));
    }

    // -- properties

    public GraphConfig setParameters(Parameters params) {
        if (params != null)
            this.parameters.putAll(params);
        return this;
    }

    // -- graphdatabase

    public GraphConfig setGraphDatabase(GraphDatabase graphdb) {
        this.graphdb = graphdb;
        return this;
    }

}

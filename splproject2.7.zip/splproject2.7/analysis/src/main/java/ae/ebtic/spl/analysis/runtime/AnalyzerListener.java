package ae.ebtic.spl.analysis.runtime;

public interface AnalyzerListener {

    void onStartAnalysis();

    void onCheckFiles();

    void onThreadDumps();

    void onDefinedTypes();

    void onEntryPoints();

    void onPropagateEntryPoints();

    void onDone();
}

package ae.ebtic.spl.analysis.sourcecode.analyzer.configuration;

import ae.ebtic.spl.analysis.sourcecode.analyzer.gradle.GradleConfigurationFile;
import ae.ebtic.spl.analysis.sourcecode.analyzer.maven.MavenConfigurationFile;
import jext.logging.Logger;

import java.io.File;
import java.util.Properties;

public class ConfigurationFactory {

    private static Logger logger = Logger.getLogger(ConfigurationFactory.class);

    /*
        add("build.gradle");
        add("pom.xml");
        add("build.pom");
        add(".classpath");

        add("${directoryName}.gradle");
        add("${directoryName}.pom");
        add("${directoryName}.xml");
     */

    public static ModuleConfiguration newConfiguration(File configurationFile, Properties props) {
        ModuleConfiguration configuration = null;
        String name = configurationFile.getName();
        if (name.endsWith(".gradle"))
            configuration = new GradleConfigurationFile(configurationFile).addProperties(props);
        // else if (name.endsWith(".classpath") || name.endsWith(".project"))
        //     configuration = new EclipseConfigurationFile(configurationFile).addProperties(props);
        else if (name.endsWith("pom.xml"))
            configuration = new MavenConfigurationFile(configurationFile).addProperties(props);
        else if (name.endsWith(".pom"))
            configuration = new MavenConfigurationFile(configurationFile).addProperties(props);
        // else if (name.endsWith(".iml"))
        //     configuration = new IdeaConfigurationFile(configurationFile).addProperties(props);
        // else if (name.endsWith(".sbt"))
        //     configuration = new SbtConfigurationFile(configurationFile).addProperties(props);
        else {
            // logger.errorf("Unsupported configuration file %s. Used NullConfigurationFile", configurationFile);
            // configuration = new NullConfigurationFile().addProperties(props);
        }
        return configuration;
    }
}

package ae.ebtic.spl.analysis.sourcecode.analyzerv2.eclipse;

import ae.ebtic.spl.analysis.sourcecode.analyzer.java.ArchiveUtils;
import ae.ebtic.spl.analysis.sourcecode.analyzer.java.JarLibrary;
import ae.ebtic.spl.analysis.sourcecode.analyzer.maven.MavenLibrary;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.eclipse.util.ClasspathFile;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseModule;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;

import java.io.File;
import java.util.List;
import java.util.stream.Collectors;

public class EclipseModule extends BaseModule {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private ClasspathFile classpathFile;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public EclipseModule(File moduleDir, Project project) {
        super(moduleDir, project);
        this.classpathFile = new ClasspathFile(moduleDir);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    public ClasspathFile getClasspathFile() {
        return classpathFile;
    }

    @Override
    protected List<Library> getLocalLibraries() {
        return classpathFile.getLocalLibraries().stream()
            .map(jarFile -> ArchiveUtils.newLibrary(jarFile, this))
            .collect(Collectors.toList());
    }

    @Override
    protected List<Library> getMavenLibraries() {

        MavenDownloader md = project.getLibraryDownloader();

        return classpathFile.getMavenLibraries()
            .stream()
            .map(MavenCoords::new)
            .sorted()
            .map(coords -> new MavenLibrary(coords, md, project))
            .collect(Collectors.toList());
    }

}
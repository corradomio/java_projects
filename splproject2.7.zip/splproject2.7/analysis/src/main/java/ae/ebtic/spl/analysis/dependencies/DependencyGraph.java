package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentGraph;
import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.features.FeatureGraph;
import ae.ebtic.spl.analysis.features.FeatureNode;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.graph.ProjectModelGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Parameter;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.model.TypeUse;
import jext.graph.Direction;
import jext.graph.GraphSession;
import jext.graph.NodeDegree;
import jext.util.HashMap;
import jext.util.HashSet;
import jext.util.Parameters;
import jext.util.StringUtils;
import org.neo4j.driver.exceptions.TransientException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Collectors;

// import org.neo4j.driver.v1.exceptions.TransientException;

public class DependencyGraph extends ProjectModelGraph {

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public DependencyGraph(ProjectGraphAccess pga) {
        super(pga, PROJECT);
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    // public String/*projectId*/ createProjectNode(Parameters params) {
    //     if (projectId != null)
    //         return projectId;
    //
    //     // Name projectName = config.getProjectName();
    //
    //     Parameters nparams = Parameters.params(
    //         // NAME, projectName.getName(),
    //         // REPOSITORY, projectName.getParentName(),
    //         // FULLNAME, projectName.getFullName(),
    //         TYPE, PROJECT,
    //         ROLE, ROLE_PROJECT,
    //         STATUS, STATUS_TASK_RUNNING,
    //         TIMESTAMP, System.currentTimeMillis()
    //     ).add(params);
    //
    //     try(GraphSession session = graphdb.connect()) {
    //         projectId = session.createNode(PROJECT, nparams);
    //         modelId = projectId;
    //
    //         session.setNodeProperty(projectId, PROJECT_ID, projectId);
    //     }
    //
    //     return projectId;
    // }

    public DependencyGraph clone() {
        DependencyGraph dg = new DependencyGraph(pga);
        dg.initialize();
        return dg;
    }

    protected void deleteModelElements(String projectId) {
        deleteModelElements(MODULE, projectId);
        deleteModelElements(RESOURCE, projectId);
        deleteModelElements(LIBRARY, projectId);
        deleteModelElements(SOURCE, projectId);
        deleteModelElements(TYPE, projectId);
        deleteModelElements(FIELD, projectId);
        deleteModelElements(METHOD, projectId);
        deleteModelElements(PARAMETER, projectId);
        deleteModelElements(NAMESPACE, projectId);
        deleteModelElements(TOKEN, projectId);
        deleteModelElements(COMMENT, projectId);
        // super delete the node 'project'
        super.deleteModelElements(projectId);
    }

    // ----------------------------------------------------------------------
    // Operation using local session
    // ----------------------------------------------------------------------

    public Project getProject() {

        Map<String, Object> nv;

        try (GraphSession session = graphdb.connect()) {
            nv = session.getNodeValues(projectId);
        }

        return ProjectNode.of(this, nv);
    }

    // ----------------------------------------------------------------------
    // Generic operations on nodes/edges
    // ----------------------------------------------------------------------

    public String/*nodeId*/ createNode(String type, Parameters params) {

        Parameters nparams = Parameters.params(
            TYPE, type,
            PROJECT_ID, projectId
        ).add(params);

        try(GraphSession session = graphdb.connect()) {
            return session.createNode(type, nparams);
        }
    }

    public void deleteNode(String nodeId) {
        try(GraphSession session = graphdb.connect()) {
            session.deleteNode(nodeId);
        }
    }

    public String/*edgeId*/ createEdge(String edgeType, String fromId, String toId, String subType) {
        Parameters edgeProps = Parameters.params(EDGE_TYPE, subType);

        return createEdge(edgeType, fromId, toId, edgeProps);
    }

    public String/*edgeId*/ createEdge(String edgeType, String fromId, String toId, Map<String, Object> edgeProps) {
        if (fromId == null || toId == null || fromId.equals(toId))
            return null;

        try (GraphSession session = graphdb.connect()) {
            return session.findEdge(edgeType, fromId, toId,
                edgeProps,
                edgeProps);
        }
        catch (TransientException t) {
            logger.warnf("Retry createEdge(%s, %s, %s, %s)", edgeType, fromId, toId, edgeProps.toString());
        }
        try (GraphSession session = graphdb.connect()) {
            return session.findEdge(edgeType, fromId, toId,
                edgeProps,
                edgeProps);
        }
    }

    public void setNodeProperty(String nodeId, String name, Object value) {
        try (GraphSession session = graphdb.connect()) {
            session.setNodeProperty(nodeId, name, value);
        }
    }

    public void addEdgeProperty(String edgeType, String fromId, String toId, String edgeProp, Object value) {
        try (GraphSession session = graphdb.connect()) {
            String edgeId = session.findEdge(edgeType, fromId, toId, Parameters.empty(), Parameters.empty());
            if (edgeId == null)
                return;
            Map<String, Object> edgeProps = session.getEdgeProperties(edgeId);
            // it is 'readonly' list!
            List propValue = (List) edgeProps.getOrDefault(edgeProp, Collections.emptyList());

            propValue = new ArrayList(propValue);
            propValue.add(value);

            session.setEdgeProperty(edgeId, edgeProp, propValue, true);
        }
    }

    // ----------------------------------------------------------------------
    // Operation: module
    // ----------------------------------------------------------------------

    public long getModulesCount() {
        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(PROJECT_ID, projectId);
            return session.queryNodes(MODULE, params).count();
        }
    }

    public List<Module> getModules() {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(PROJECT_ID, projectId);
            nvlist = session.queryNodes(MODULE, params).allValues().toList();
        }

        return ModuleNode.of(this, nvlist);
    }

    public Module getModule(String moduleId) {
        if (moduleId == null)
            return null;

        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(moduleId);
            }
            catch (NumberFormatException e) {
                nv = session.queryNodes(MODULE, Parameters.params(
                        NAME, moduleId,
                        PROJECT_ID, projectId
                )).values();
            }
        }

        return ModuleNode.of(this, nv);
    }

    public List<Module> getModuleDependencies(String moduleId, boolean recursive) {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(moduleId, USES, Direction.Output, recursive,
                    MODULE, Parameters.params(PROJECT_ID, projectId), Parameters.empty())
                    .allValues().toList();
        }

        return ModuleNode.of(this, nvlist);
    }

    public List<Module> getModules(String parentId, boolean recursive) {
        List<Module> modules = new ArrayList<>();
        Set<String> visitedIds = new HashSet<>();
        Queue<String> toVisit = new LinkedList<>();

        try (GraphSession session = graphdb.connect()) {
            getModules(session, parentId, visitedIds, toVisit)
                    .stream()
                    .map(nv -> ModuleNode.of(this, nv))
                    .forEach(module -> modules.add(module));

            while(recursive && !toVisit.isEmpty()) {
                parentId = toVisit.remove();
                if (!visitedIds.contains(parentId))
                    getModules(session, parentId, visitedIds, toVisit)
                            .stream()
                            .map(nv -> ModuleNode.of(this, nv))
                            .forEach(module -> modules.add(module));
            }
        }

        return modules;
    }

    private List<Map<String, Object>> getModules(
        GraphSession session,
        String parentId,
        Set<String> visitedIds,
        Queue<String> toVisitIds)
    {
        List<Map<String, Object>> nvlist = new ArrayList<>();
        if(!visitedIds.add(parentId))
            return nvlist;

        session.queryAdjacentNodes(parentId,
                MEMBER_OF, Direction.Input, false,
                MODULE, Parameters.params(
                        PROJECT_ID, projectId,
                        TYPE, MODULE),
                Parameters.empty()).allValues().forEach(values -> {
            String id = values.get(GRAPH_NODE_ID).toString();
            if (!visitedIds.contains(id)) {
                toVisitIds.add(id);
                nvlist.add(values);
            }
        });

        return nvlist;
    }

    public List<Type> getModuleTypes(String moduleId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(TYPE,
                    Parameters.params(
                            PROJECT_ID, projectId,
                            MODULE_ID, moduleId
                    ))
                    .allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    public List<Library> getModuleLibraries(String moduleId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(moduleId,
                    USES, Direction.Output, false,
                    LIBRARY, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).allValues().toList();
        }

        return LibraryNode.of(this, nvlist);
    }

    // ----------------------------------------------------------------------
    // Operations: resources
    // ----------------------------------------------------------------------

    public List<Resource> getResources(String moduleId) {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(moduleId,
                    MEMBER_OF, Direction.Input, false,
                    RESOURCE, Parameters.params(
                            PROJECT_ID, projectId,
                            MODULE_ID, moduleId,
                            TYPE, RESOURCE),
                    Parameters.empty()).allValues().toList();
        }

        return ResourceNode.of(this, nvlist);
    }

    // ----------------------------------------------------------------------
    // Operations: libraries
    // ----------------------------------------------------------------------

    public List<Library> getLibraries() {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(LIBRARY, Parameters.params(PROJECT_ID, projectId))
                    .allValues().toList();
        }

        return LibraryNode.of(this, nvlist);
    }

    public List<Library> getLibraries(String moduleId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(moduleId,
                    USES, Direction.Output, false,
                    LIBRARY, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).allValues().toList();
        }

        return LibraryNode.of(this, nvlist);
    }

    public Library getLibrary(String libraryId) {
        if (libraryId == null)
            return null;

        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(libraryId);
            }
            catch (NumberFormatException e) {
                nv = session.queryNodes(LIBRARY, Parameters.params(
                        NAME, libraryId,
                        PROJECT_ID, projectId
                )).values();
            }

            return LibraryNode.of(this, nv);
        }
    }

    public List<RefType> getLibraryTypes(String libraryId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(libraryId,
                    MEMBER_OF, Direction.Input, false,
                    TYPE, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).allValues().toList();
        }

        return TypeNode.ref(this, nvlist);
    }

    // public String findLibraryId(String libraryName) {
    //     try(GraphSession session = graphdb.connect()) {
    //         return session.queryNodes(LIBRARY, Parameters.params(
    //                 FULLNAME, libraryName,
    //                 PROJECT_ID, projectId
    //         )).id();
    //     }
    // }

    // ----------------------------------------------------------------------
    // Operations: sources
    // ----------------------------------------------------------------------

    public long getSourcesCount() {
        try (GraphSession session = graphdb.connect()) {
            return session.queryNodes(SOURCE, Parameters.params(
                    PROJECT_ID, projectId,
                    TYPE, SOURCE)).count();
        }
    }

    public List<Source> getSources() {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(SOURCE, Parameters.params(
                    PROJECT_ID, projectId,
                    TYPE, SOURCE)).allValues().toList();
        }

        return nvlist
                .stream()
                .map(nv -> SourceNode.of(this, nv))
                .collect(Collectors.toList());
    }

    public List<Source> getSources(String moduleId) {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(moduleId,
                    MEMBER_OF, Direction.Input, false,
                    SOURCE, Parameters.params(
                            PROJECT_ID, projectId,
                            MODULE_ID, moduleId,
                            TYPE, SOURCE),
                    Parameters.empty()).allValues().toList();
        }

        return nvlist
                .stream()
                .map(nv -> SourceNode.of(this, nv))
                .collect(Collectors.toList());
    }

    public Source getSource(String sourceId) {
        if (sourceId == null)
            return null;

        Map<String, Object> nv;

        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(sourceId);
            }
            catch (NumberFormatException e) {
                nv = session.queryNodes(SOURCE, Parameters.params(
                        NAME, sourceId,
                        PROJECT_ID, projectId
                )).values();
            }
        }

        return SourceNode.of(this, nv);
    }

    // ----------------------------------------------------------------------
    // Operations: types
    // ----------------------------------------------------------------------

    public long getTypesCount(boolean refType) {
        Parameters params = Parameters.params(
                PROJECT_ID, projectId,
                TYPE, refType ? REFTYPE : TYPE
        );

        try (GraphSession session = graphdb.connect()) {
            return session.queryNodes(TYPE, params).count();
        }
    }

    public List<Type> getTypes() {
        List<Map<String, Object>> nvlist;
        List<Type> tlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(TYPE, Parameters.params(
                TYPE, TYPE,
                PROJECT_ID, projectId
            )).allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    public List<Type> getTypes(String moduleId) {
        List<Map<String, Object>> nvlist;
        List<Type> tlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodes(TYPE, Parameters.params(
                    PROJECT_ID, projectId,
                    MODULE_ID, moduleId
            )).allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    public List<Type> getTypes(NodeDegree ndegree, String role) {

        List<Map<String, Object>> nvlist;

        Parameters nodeProps = Parameters.params(
            PROJECT_ID, projectId,
            TYPE, TYPE);
        if (!StringUtils.isEmpty(role))
            nodeProps.put(ROLE, role);

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryNodesWithDegree(TYPE, USES, ndegree,
                    nodeProps,
                    Parameters.empty()).allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    public List<Type> getSourceTypes(String sourceId) {
        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(sourceId,
                    MEMBER_OF, Direction.Input, false,
                    TYPE, Parameters.params(
                            PROJECT_ID, projectId,
                            TYPE, TYPE),
                    Parameters.empty()).allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    public Type getType(String typeId) {
        if (typeId == null)
            return null;

        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(typeId);
            }
            catch (NumberFormatException e) {
                nv = session.queryNodes(TYPE, Parameters.params(
                        PROJECT_ID, projectId,
                        FULLNAME, typeId
                )).values();
            }
        }

        return TypeNode.of(this, nv);
    }

    public List<Type> getUseTypes(String typeId, TypeUse useType, Direction direction, boolean recursive, boolean refTypes) {
        String edgeType;
        Parameters nodeProps = Parameters.params(PROJECT_ID, projectId);
        if (!refTypes)
            nodeProps.put(TYPE, TYPE);

        Parameters edgeProps;
        switch(useType) {
            case HIERARCHY:
                edgeType = USES;
                edgeProps = Parameters.params(
                    USES, Arrays.asList(EXTENDS, IMPLEMENTS)
                );
                break;
            case EXTENDS:
                edgeType = USES;
                edgeProps = Parameters.params(
                    USES, EXTENDS
                );
                break;
            case IMPLEMENTS:
                edgeType = USES;
                edgeProps = Parameters.params(
                    USES, IMPLEMENTS
                );
                break;
            case DEPENDS_ON:
                edgeType = USES;
                edgeProps = Parameters.params(
                    USES, DEPENDS_ON
                );
                break;
            default:
                edgeType = USES;
                edgeProps = Parameters.params();
                break;
        }

        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(typeId,
                    edgeType, direction, recursive,
                    TYPE,
                    nodeProps,
                    edgeProps).distinct().allValues().toList();
        }

        return TypeNode.of(this, nvlist);
    }

    // ----------------------------------------------------------------------
    // Operations: methods & parameters
    // ----------------------------------------------------------------------

    public List<Method> getMethods(String typeId) {
        Parameters nodeProps = Parameters.empty();
        Parameters edgeProps = Parameters.empty();

        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(typeId,
                MEMBER_OF, Direction.Input, false,
                METHOD,
                nodeProps,
                edgeProps).allValues().toList();
        }

        return MethodNode.of(this, nvlist);
    }

    public Method getMethod(String methodId) {
        if (methodId == null)
            return null;

        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(methodId);
            }
            catch (NumberFormatException e) {
                nv = null;
            }
        }

        return MethodNode.of(this, nv);
    }

    public List<Method> getMethodCalls(String methodId) {
        Parameters nodeProps = Parameters.empty();
        Parameters edgeProps = Parameters.empty();

        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(methodId,
                    METHOD_CALL, Direction.Output, false,
                    METHOD,
                    nodeProps,
                    edgeProps).allValues().toList();
        }

        return MethodNode.of(this, nvlist);
    }

    public List<Parameter> getParameters(String methodId) {
        Parameters nodeProps = Parameters.params(
                PROJECT_ID, projectId);
        Parameters edgeProps = Parameters.empty();

        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(methodId,
                    MEMBER_OF, Direction.Input, false,
                    PARAMETER,
                    nodeProps,
                    edgeProps).allValues().toList();
        }

        return ParameterNode.of(this, nvlist);
    }

    public Parameter getParameter(String parameterId) {
        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            nv = session.getNodeValues(parameterId);
        }

        return ParameterNode.of(this, nv);
    }

    // ----------------------------------------------------------------------
    // Operations: fields
    // ----------------------------------------------------------------------

    public List<Field> getFields(String typeId) {
        Parameters nodeProps = Parameters.empty();
        Parameters edgeProps = Parameters.empty();

        List<Map<String, Object>> nvlist;
        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(typeId,
                    MEMBER_OF, Direction.Input, false,
                    FIELD,
                    nodeProps,
                    edgeProps).allValues().toList();
        }

        return FieldNode.of(this, nvlist);
    }

    public Field getField(String fieldId) {
        if (fieldId == null)
            return null;

        Map<String, Object> nv;
        try (GraphSession session = graphdb.connect()) {
            try {
                nv = session.getNodeValues(fieldId);
            }
            catch (NumberFormatException e) {
                nv = null;
            }
        }

        return FieldNode.of(this, nv);
    }

    // ----------------------------------------------------------------------
    // Operations: components/features
    // ----------------------------------------------------------------------

    public List<Component> getComponents(String typeId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(typeId,
                    CONTAINS, Direction.Input, true,
                    COMPONENT,
                Parameters.params(PROJECT_ID, projectId),
                Parameters.empty())
                .distinct().allValues().toList();
        }

        ComponentGraph cg = pga.getComponentGraph();

        return nvlist
                .stream()
                .map(nv -> ComponentNode.of(cg, nv))
                .collect(Collectors.toList());
    }

    public List<Feature> getFeatures(String typeId) {
        List<Map<String, Object>> nvlist;

        try (GraphSession session = graphdb.connect()) {
            nvlist = session.queryAdjacentNodes(typeId,
                    CONTAINS, Direction.Input, true,
                    FEATURE, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).distinct().allValues().toList();
        }

        FeatureGraph fg = pga.getFeatureGraph();

        return FeatureNode.of(fg, nvlist);
    }

    // ----------------------------------------------------------------------
    // Create Dependency Nodes
    // ----------------------------------------------------------------------

    // ----------------------------------------------------------------------
    // Query dependency nodes
    // ----------------------------------------------------------------------

    /**
     *
     * @param types lits of types to analyze
     * @param interfaces add the interface implemented by a class
     * @param links
     * @param implementations
     * @return
     */
    public List<Type> addContext(List<Type> types, boolean interfaces, boolean links, boolean implementations) {

        Set<Type> context = new HashSet<>(types);

        // interface
        if (interfaces)
            for (Type type : types) {
                TypeRole role = type.getRole();
                if (role == TypeRole.CLASS)
                    context.addAll(type.getUseTypes(TypeUse.IMPLEMENTS, Direction.Output, false, false));
                else if (role == TypeRole.INTERFACE)
                    context.addAll((type.getUseTypes(TypeUse.EXTENDS, Direction.Output, false, false)));
            }

        // implementation
        if (implementations)
            for (Type type : types) {
                TypeRole role = type.getRole();
                if (role == TypeRole.INTERFACE)
                    context.addAll(type.getUseTypes(TypeUse.IMPLEMENTS, Direction.Input, false, false));
            }

        // links
        if (links)
            for (Type type : types) {
                context.addAll(type.getUseTypes(TypeUse.DEPENDS_ON, Direction.Output, false, false));
            }

        return new ArrayList<>(context) ;
    }

    // ----------------------------------------------------------------------
    // Token handling
    // ----------------------------------------------------------------------

    public void mergeTokens(){
        try(GraphSession session = graphdb.connect()) {
            session.queryUsing("mergeTokens", Parameters.params(
                    PROJECT_ID, projectId
            )).result();

            session.queryUsing("deleteDuplicateTokenRelationships", Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }

    public void deleteTokensWithoutRelationships(){
        try(GraphSession session = graphdb.connect()) {
            session.queryUsing("deleteTokensWithoutRelationships", Parameters.params(
                    PROJECT_ID, projectId
            )).result();
        }
    }

    // ----------------------------------------------------------------------
    // Model Graph
    // ----------------------------------------------------------------------

    public Map<String, Object> getModelGraph() {
        List<Map<String, Object>> vlist;
        List<Map<String, Object>> elist;

        try (GraphSession session = graphdb.connect()) {

            vlist = session.queryNodes(TYPE, Parameters.params(
                    PROJECT_ID, projectId
            )).allValues().toList();

            elist = session.queryEdges(USES,
                    TYPE, Parameters.params(PROJECT_ID, projectId),
                    TYPE, Parameters.params(PROJECT_ID, projectId),
                    Parameters.empty()).result().toList();
        }

        // compose the nodeList
        List<Map<String, Object>> nodes =
                vlist.stream()
                        .map(r -> {
                            return new HashMap<String, Object>()
                                    .put_(ID, r.get(GRAPH_NODE_ID).toString())
                                    .put_(LABEL, r.get(NAME))
                                    .put_(METADATA, r);
                        })
                        .collect(Collectors.toList());

        // compose the edge list
        List<Map<String, Object>> edges =
                elist.stream()
                        .map(r -> {
                            String fromId = r.get("idfrom").toString();
                            String toId = r.get("idto").toString();

                            return new HashMap<String, Object>()
                                    .put_(EDGE_SOURCE, fromId)
                                    .put_(EDGE_TARGET, toId)
                                    .put_(EDGE_DIRECTED, true)
                                    .put_(EDGE_RELATION, USES)
                                    .put_(METADATA, Collections.emptyMap());
                        })
                        .collect(Collectors.toList());

        // compose the graph descriptor
        HashMap<String, Object> graph = new HashMap<>();
        graph
                .put_(GRAPH_DIRECTED, true)
                .put_(GRAPH_TYPE, "DependencyModel graph")
                .put_(LABEL, config.getProjectName().getFullName())
                .put_(GRAPH_NODES, nodes)
                .put_(GRAPH_EDGES, edges);

        return new HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getFeaturesOld(String typeId){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, Integer.parseInt(typeId));

            graph = session.queryUsing("getTypeFeatures", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getClosure(String typeId, boolean refTypes, boolean implementation, boolean links){
        Map<String, Object> graph = new HashMap<>();
        List<Map<String, Object>> types;
        List<Map<String, Object>> edges = new ArrayList<>();

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID, Integer.parseInt(typeId));

            types = session.queryUsing("findTypeClosureAlgorithm", params).distinct().allValues().toList();


            if (!refTypes) {
                types = types.stream().filter(i -> !i.get(TYPE).toString().equals(REFTYPE)).collect(Collectors.toList());
            }

            if (implementation) {

                List<Integer> allIds = types.stream().map(i -> Integer.parseInt(i.get(GRAPH_NODE_ID).toString()))
                        .collect(Collectors.toList());

                List<Integer> interfaceIds = types.stream().filter(i -> i.get(ROLE).toString().equals(TROLE_INTERFACE))
                        .map(i -> Integer.parseInt(i.get(GRAPH_NODE_ID).toString()))
                        .collect(Collectors.toList());

                if (!interfaceIds.isEmpty()) {
                    Parameters interfaceParams = Parameters.params(
                            PROJECT_ID, projectId,
                            ID, interfaceIds);

                    List<Map<String, Object>> implementationTypes = session.queryUsing("getTypeImplementationsByIds", interfaceParams).distinct().allValues().toList();

                    implementationTypes = implementationTypes.stream().filter(i -> allIds.stream().noneMatch(k -> k.toString().equals(i.get(GRAPH_NODE_ID).toString())))
                            .collect(Collectors.toList());

                    types.addAll(implementationTypes);
                }
            }


            if (links) {

                Parameters edgeParams = Parameters.params(
                        PROJECT_ID, projectId);

                edges = session.queryEdges(USES, TYPE, edgeParams, TYPE, edgeParams, Parameters.empty()).result().toList();

                List<Integer> allIds = types.stream()
                        .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                        .boxed()
                        .collect(Collectors.toList());

                edges = edges.stream().filter(r -> allIds.contains(Integer.parseInt(r.get(EDGE_FROM).toString())) && allIds.contains(Integer.parseInt(r.get(EDGE_TO).toString())))
                        .collect(Collectors.toList());
            }
        }

        List<Map<String, Object>> typesFinal = types.stream().map(r ->new jext.util.HashMap<String, Object>()
                .put_(ID, Long.parseLong(r.get(GRAPH_NODE_ID).toString()))
                .put_(NAME, r.get(NAME))
                .put_(ROLE, r.get(ROLE))
                .put_(NAMESPACE, r.get(NAMESPACE))
                .put_(SCORE, r.get(SCORE))).collect(Collectors.toList());
        graph.put(GRAPH_NODES, typesFinal);

        if(links){
            List<Map<String, Object>> edgesFinal = edges
                    .stream()
                    .map(r -> new HashMap<String, Object>()
                            .put_(SOURCE, r.get("idfrom"))
                            .put_(EDGE_TARGET, r.get("idto"))
                            .put_(USES, r.get(USES))
                            .put_(ID,r.get("idfrom")+"_"+r.get("idto")))
                    .collect(Collectors.toList());
            graph.put(GRAPH_EDGES,edgesFinal);
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getClosures(List<String> typeIds, boolean refTypes, boolean implementation, boolean links){
        Map<String, Object> graph = new HashMap<>();
        jext.util.Set<Map<String, Object>> typeSet = new HashSet<>();
        List<Map<String, Object>> edges;

        typeIds.stream().forEach(t -> {
            Map<String, Object> temp = getClosure(t, refTypes, implementation, false);
            Map<String, Object> tempGraph = (Map<String, Object>) temp.get(GRAPH);
            List<Map<String, Object>> tempNodes = (List<Map<String, Object>>) tempGraph.get(GRAPH_NODES);
            typeSet.addAll(tempNodes);
        });

        List<Map<String, Object>> types = new ArrayList<>(typeSet);
        graph.put(GRAPH_NODES, types);

        if (links) {

            try (GraphSession session = graphdb.connect()) {
                Parameters edgeParams = Parameters.params(
                        PROJECT_ID, projectId);

                edges = session.queryEdges(USES, TYPE, edgeParams, TYPE, edgeParams, Parameters.empty()).result().toList();

                List<Integer> allIds = types.stream()
                        .mapToInt(r -> Integer.parseInt(r.get(ID).toString()))
                        .boxed()
                        .collect(Collectors.toList());

                edges = edges.stream().filter(r -> allIds.contains(Integer.parseInt(r.get(EDGE_FROM).toString())) && allIds.contains(Integer.parseInt(r.get(EDGE_TO).toString())))
                        .collect(Collectors.toList());
            }

            List<Map<String, Object>> edgesFinal = edges
                    .stream()
                    .map(r -> new HashMap<String, Object>()
                            .put_(SOURCE, r.get("idfrom"))
                            .put_(EDGE_TARGET, r.get("idto"))
                            .put_(USES, r.get(USES))
                            .put_(ID,r.get("idfrom")+"_"+r.get("idto"))
                    )
                    .collect(Collectors.toList());
            graph.put(GRAPH_EDGES,edgesFinal);
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);

    }

    public List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, String typeId){

        //keep track of ids that have been checked
        Map<String, Boolean> visited = new HashMap<>();
        Map<String, Map<String, Object>> idToMap = new HashMap<>();
        List<Map<String, Object>> interfacesToCheck = new ArrayList<>();
        interfacesToCheck.addAll(interfaces);

        while(!interfacesToCheck.isEmpty()){
            Map<String, Object> tempInterface = interfacesToCheck.remove(0);
            String id = tempInterface.get(ID).toString();
            idToMap.put(id,tempInterface);
            if(tempInterface.containsKey("CHILDREN")){
                visited.put(id, true);
                List<Map<String, Object>> implementations = (ArrayList<Map<String, Object>>) tempInterface.get("CHILDREN");
                interfacesToCheck.addAll(implementations);
            }
            if(tempInterface.containsKey("PARENT")) {
                List<String> parents = (ArrayList<String>) tempInterface.get("PARENT");
                for (String parent : parents) {
                    if (!parent.equals(""))
                        visited.put(parent, true);
                }
            }
        }

        //Collect the interfaces for checking
        List<Map<String,Object>> typesToCheck = new ArrayList<>();
        HashMap<String, Object> initialMap = new HashMap<>();
        initialMap.put("PARENT", typeId);
        initialMap.put("ID", typeId);
        // initialMap.put("Level","0");
        typesToCheck.add(initialMap);



        while(!typesToCheck.isEmpty()){
            Map<String, Object> tempMap = typesToCheck.remove(0);
            String parent = tempMap.get("PARENT").toString();
            String tempId = tempMap.get("ID").toString();
            TypeNode type = (TypeNode) getType(tempId);


            if(visited.getOrDefault(tempId,false)){
//                if(type.getRole() == TypeRole.INTERFACE){
//
//                    Map<String, Object> tempInterface = idToMap.get(tempId);
//
//                    if(tempInterface == null)
//                        continue;
//
//                    int level = Integer.parseInt(tempInterface.get("LEVEL").toString());
//
//                    if(idToMap.containsKey(parent)) {
//                        Map<String, Object> parentMap = idToMap.get(parent);
//                        int pLevel = Integer.parseInt(parentMap.get("LEVEL").toString());
//
//                        if(pLevel != (level-1)){
//                            continue;
//                        }
//                    }
//
//                    List<String> parents = (ArrayList<String>) tempInterface.get("PARENT");
//                    if (!parents.contains((parent))) {
//                        parents.add(parent);
//                        tempInterface.put("PARENT", parents);
//                    }
//
//                    if(idToMap.containsKey(parent)){
//                        Map<String, Object> parentMap = idToMap.get(parent);
//                        if(parentMap.containsKey("PARENT")){
//                            List<String> grandParents = (ArrayList<String>) parentMap.get("PARENT");
//                            if(grandParents.contains(tempId))
//                                continue;
//                        }
//                        if(!parentMap.containsKey("CHILDREN")){
//                            List<Map<String, Object>> children = new ArrayList<>();
//                            parentMap.put("CHILDREN", children);
//                        }
//                        List<Map<String, Object>> children = (ArrayList<Map<String, Object>>) parentMap.get("CHILDREN");
//                        if(!children.contains(tempInterface)) {
//                            children.add(tempInterface);
//                            parentMap.put("CHILDREN", children);
//                        }
//                    }
//                }
                continue;
            }

            visited.put(tempId, true);

            if(type.getRole() == TypeRole.INTERFACE){

                int level = 0;
                if(idToMap.containsKey(parent)){
                    Map<String, Object> parentMap = idToMap.get(parent);
                    if(parentMap.containsKey("LEVEL")){
                        int pLevel = Integer.parseInt(parentMap.get("LEVEL").toString());
                        level = pLevel+1;
                    }
                }

                ArrayList<Integer> interfaceIds = new ArrayList<Integer>();

                interfaceIds.add(Integer.parseInt(tempId));

                Parameters interfaceParams = Parameters.params(
                        PROJECT_ID, projectId,
                        ID, interfaceIds);
                List<Map<String, Object>> implementationTypes = null;
                try (GraphSession session = graphdb.connect()) {
                    implementationTypes = session.queryUsing("getTypeImplementationsByIds", interfaceParams).distinct().allValues().toList();
                }
                int finalLevel = level;
                ArrayList<String> parentList = new ArrayList<>();
                parentList.add(tempId);
                implementationTypes = implementationTypes.stream().map(r -> new HashMap<String, Object>()
                        .put_(ID,r.get(GRAPH_NODE_ID))
                        .put_(NAME, r.get(NAME))
                        .put_(FULLNAME, r.get(FULLNAME))
                        .put_("PARENT",parentList)
                        .put_("LEVEL", finalLevel +1)
                        .put_(TYPE, "IMPLEMENTATION")
                ).collect(Collectors.toList());

                if(!implementationTypes.isEmpty()) {
                    List<String> parents = new ArrayList<>();
                    parents.add(parent);

                    Map<String, Object> tempInterface = new HashMap<String, Object>()
                            .put_(ID, tempId)
                            .put_(NAME, type.getName().getName())
                            .put_(FULLNAME, type.getName().getFullName())
                            .put_("PARENT", parents)
                            .put_("CHILDREN", implementationTypes)
                            .put_("LEVEL",level)
                            .put_(TYPE, "INTERFACE");

                    idToMap.put(tempId,tempInterface);
                    implementationTypes.stream().forEach(r -> {
                        String nID = r.get(ID).toString();
                        HashMap<String, Object> tMap = new HashMap<>();
                        tMap.put("PARENT", tempId);
                        tMap.put("ID", nID);
                        typesToCheck.add(tMap);
                        idToMap.put(nID,r);
                    });
                    if(parent.equals("") || !idToMap.containsKey(parent)) {
                        interfaces.add(tempInterface);
                    }
                    else{
                        Map<String, Object> parentMap = idToMap.get(parent);
                        if(!parentMap.containsKey("CHILDREN")){
                            List<Map<String, Object>> children = new ArrayList<>();
                            parentMap.put("CHILDREN", children);
                        }
                        List<Map<String, Object>> children = (ArrayList<Map<String, Object>>) parentMap.get("CHILDREN");
                        children.add(tempInterface);
                        parentMap.put("CHILDREN",children);
                    }
                }
            }
            // else {
            try (GraphSession session = graphdb.connect()) {
                Parameters closureParams = Parameters.params(PROJECT_ID, projectId,
                        ID, Integer.parseInt(tempId));
                List<Map<String, Object>> tempNeighbors = session.queryUsing("getTypeOutgoingNeighbors", closureParams).distinct().allValues().toList();
                tempNeighbors.stream().forEach(r -> {
                    String nID = r.get(GRAPH_NODE_ID).toString();
                    HashMap<String, Object> tMap = new HashMap<>();
                    if(idToMap.containsKey(tempId))
                        tMap.put("PARENT", tempId);
                    else
                        tMap.put("PARENT",parent);
                    tMap.put("ID", nID);
                    typesToCheck.add(tMap);
                });
            }
            //}
        }

        return interfaces;
    }

    public List<Map<String, Object>> getInterfaceImplementations(List<Map<String, Object>> interfaces, List<String> typeIds){
        if(typeIds.size() == 0)
            return interfaces;
        for(int i = 0; i < typeIds.size(); i++){
            interfaces = getInterfaceImplementations(interfaces, typeIds.get(i));
        }
        return interfaces;
    }

    // ----------------------------------------------------------------------
    // Extras
    // ----------------------------------------------------------------------

    private long getCoreTypesCount(double threshold) {
        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                "threshold", threshold,
                PROJECT_ID, projectId
            );

            return session.queryUsing("findTypesWithKCore", params).count();
        }
    }

    public double getComplexity(double threshold) {
        long nTypes = getTypesCount(false);
        long nCoreTypes = getCoreTypesCount(threshold);
        return nTypes == 0 ? 0. : (0. + nCoreTypes)/(0. + nTypes);
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

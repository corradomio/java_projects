package ae.ebtic.spl.analysis.clustering;

import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.logging.Logger;

import java.util.*;
import java.util.stream.Collectors;

public class ClusteringAnalyzer implements GraphConstants {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ClusteringAnalyzer newAnalyzer(AnalyzerConfig config) {
        ClusteringAnalyzer analyzer = new ClusteringAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // if aborted
    protected boolean aborted;

    // Configuration
    protected AnalyzerConfig config;

    // Handle the clustering graph
    protected ClusteringGraph cg;

    // logger
    protected Logger logger;

    // listeners
    protected Listeners listeners = new Listeners();

    //Clusters from design patterns
    protected List<Map<String, Object>> dPClusters;

    //Clusters from tokens
    protected List<Map<String, Object>> tClusters;

    //Final clusters
    protected List<Map<String, Object>> fClusters;

    protected String clusterProjectId;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ClusteringAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    protected ClusteringAnalyzer initialize() {

        logger = Logger.getLogger("%s.%s.%s",
                getClass(), config.getProjectName().getParentName(), config.getProjectName().getName());

        GraphConfig config = new GraphConfig()
                .setGraphDatabase(this.config.getGraphDatabase())
                .setProjectName(this.config.getProjectName())
                .setParameters(this.config.getParameters());

        //cg = ClusteringGraph.newClusteringGraph(config);
        cg = ProjectGraphAccess.newProjectGraphAccess(config).getClusteringGraph();

        return this;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    /**
     * Abort the analysis
     */
    public void abort() {
        this.aborted = true;
    }

    public void analyze(){

        if (aborted) return;

        try (ClusteringGraph cg = (ClusteringGraph) this.cg.connect()) {

            createClusterNode();

            clusterNodes(TYPE);

            clusterNodes(FEATURE);

            analysisDone(false);
        }
        catch (Throwable t) {
            logger.error(t, t);

            analysisDone(true);
        }

    }

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------
    private void createClusterNode() {
        if (aborted) return;

        clusterProjectId = cg.getClusterNodeID();
    }

    protected void clusterNodes(String model){

        clusterOnDesignPatterns(model);

        extractUnclustered();

        clusterOnTokens();

        iterativeClustering();

        writeClusters(model,1);
    }


    protected void clusterOnDesignPatterns(String model){
        if(aborted) return;

        dPClusters =  cg.clusterDesignPattern(model);
    }


    protected void extractUnclustered(){
        if(aborted) return;

        tClusters = dPClusters.stream().filter(r -> ((Collection<Long>)r.get(IDS)).size() == 1).collect(Collectors.toList());

        dPClusters = dPClusters.stream().filter(r -> ((Collection<Long>)r.get(IDS)).size() > 1).collect(Collectors.toList());

        fClusters = new ArrayList<>();

        int i = 0;
        for(Map<String, Object> map: dPClusters){

            for(Long id: new ArrayList<>((Collection<Long>)map.get(IDS))){
                Map<String, Object> tMap = new HashMap<>();

                tMap.put(ID, id);
                tMap.put(CLUSTER,""+i);
                fClusters.add(tMap);
            }
            i++;
        }
    }

    protected void clusterOnTokens(){
        if(aborted) return;

        List<Long> ids = tClusters.stream().map(r ->

        {
            List<Long> x = new ArrayList<>((Collection<Long>)r.get(IDS));
            return x.get(0);

        }).collect(Collectors.toList());

        tClusters = cg.clusterTokensInitial(ids);
    }

    protected void iterativeClustering(){
        if(aborted) return;

        int i = dPClusters.size();

        List<Map<String, Object>> iClusters = new ArrayList<>();

        for(Map<String, Object> map:tClusters){

            List<Long> ids = new ArrayList<>((Collection<Long>)map.get(IDS));

            Map<String, Object> temp = new HashMap<>();

            temp.put(CLUSTER,""+i);

            temp.put(IDS, ids);

            iClusters.add(temp);
            i++;
        }

        while(iClusters.size()>0){
            Map<String, Object> temp = iClusters.remove(0);

            String cluster = String.valueOf(temp.get(CLUSTER));

            List<Long> ids = new ArrayList<>((Collection<Long>)temp.get(IDS));

            if(ids.size()>1) {
                List<Map<String, Object>> tempClusters = cg.clusterTokens(ids);


                if (tempClusters.size() == 1) {
                    for (Long id : new ArrayList<>((Collection<Long>) tempClusters.get(0).get(IDS))) {
                        Map<String, Object> tMap = new HashMap<>();
                        tMap.put(ID, id);
                        tMap.put(CLUSTER, cluster);
                        fClusters.add(tMap);
                    }
                } else {
                    int j = 0;

                    for (Map<String, Object> map : tempClusters) {
                        List<Long> tIds = new ArrayList<>((Collection<Long>) map.get(IDS));

                        Map<String, Object> tempM = new HashMap<>();

                        tempM.put(CLUSTER, cluster + "." + j);

                        tempM.put(IDS, tIds);

                        iClusters.add(tempM);

                        j++;
                    }
                }
            }
            else{
                Map<String, Object> tMap = new HashMap<>();
                tMap.put(ID, ids.get(0));
                tMap.put(CLUSTER, cluster);
                fClusters.add(tMap);
            }
        }

    }

    protected void writeClusters(String model, int technique){
        if(aborted) return;
        cg.writeClusters(fClusters,model, technique);
    }

//    public List<Map<String, Object>> getFinalClusters(){
//        return fClusters;
//    }
    // ----------------------------------------------------------------------
    // Utility Operations
    // ----------------------------------------------------------------------

    protected void analysisDone(boolean failed) {
        cg.setStatus((failed || aborted) ? STATUS_INVALID : STATUS_VALID, null);

        listeners.fireDone();
    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    private static class Listeners {

        private List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireClusteringDesignPatterns(int types) {
            listeners.forEach(l -> l.onClusteringDesignPatterns(types) );
        }

        void fireClusteringTokens(int clusters) {
            listeners.forEach(l -> l.onClusteringTokens(clusters) );
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone() );
        }

    }

    public ClusteringAnalyzer addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }
}

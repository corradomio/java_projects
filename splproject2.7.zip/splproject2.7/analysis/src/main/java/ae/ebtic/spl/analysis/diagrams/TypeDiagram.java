package ae.ebtic.spl.analysis.diagrams;

import ae.ebtic.spl.analysis.graph.GraphEdge;
import ae.ebtic.spl.analysis.sourcecode.model.Field;
import ae.ebtic.spl.analysis.sourcecode.model.Method;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.util.SetUtils;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

public class TypeDiagram {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private TypeDiagramConfig config;

    private final Map<String/*nodeId*/, Type> typesMap = new HashMap<>();
    private final List<GraphEdge> typeDeps = new ArrayList<>();

    private final Map<String/*nodeId*/, Field> fieldsMap = new HashMap<>();
    private final List<GraphEdge> fieldDeps = new ArrayList<>();

    private final Map<String/*nodeId*/, Method> methodsMap = new HashMap<>();
    private final List<GraphEdge> methodCalls = new ArrayList<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public TypeDiagram(TypeDiagramConfig config) {
        this.config = config;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public TypeDiagramConfig getConfig() {
        return config;
    }

    // ----------------------------------------------------------------------
    // Types
    // ----------------------------------------------------------------------

    public void addTypes(Collection<Type> typeNodes) {
        typeNodes.forEach(this::addType);
    }

    public void addType(Type typeNode) {
        this.typesMap.put(typeNode.getId(), typeNode);
    }

    public Collection<Type> getTypeNodes() {
        return this.typesMap.values();
    }

    public Set<String/*nodeId*/> getTypeIds() {
        return this.typesMap.keySet();
    }

    // ----------------------------------------------------------------------

    public void addTypeDeps(Collection<GraphEdge> typeDeps) {
        this.typeDeps.addAll(typeDeps);
    }

    public List<GraphEdge> getTypeDeps() {
        return this.typeDeps;
    }

    // ----------------------------------------------------------------------
    // Fields
    // ----------------------------------------------------------------------

    // public void addField(FieldNode fieldNode) {
    //     this.fieldsMap.put(fieldNode.getId(), fieldNode);
    // }

    public void addFields(Collection<Field> fieldNodes) {
        fieldNodes.forEach(this::addField);
    }

    public void addField(Field fieldNode) {
        this.fieldsMap.put(fieldNode.getId(), fieldNode);
    }

    public Collection<Field> getFields() {
        return fieldsMap.values();
    }

    // ----------------------------------------------------------------------
    // Methods
    // ----------------------------------------------------------------------

    public void addMethods(Collection<Method> methods) {
        methods.forEach(this::addMethod);
    }

    public void addMethod(Method method) {
        this.methodsMap.put(method.getId(), method);
    }

    public Collection<Method> getMethods() {
        return this.methodsMap.values();
    }

    public Set<String/*nodeId*/> getMethodIds() {
        return this.methodsMap.keySet();
    }

    // ----------------------------------------------------------------------

    public void addMethodCalls(Collection<GraphEdge> methodCalls) {
        this.methodCalls.addAll(methodCalls);

        if (!config.orphanOperations)
            cleanupOrphanOperations();
    }

    private void cleanupOrphanOperations() {
        // remove methods not used in method calls

        // 1) collect the set of methods used in a call
        Set<String> methodsInCall = new HashSet<>();
        for (GraphEdge call : methodCalls) {
            methodsInCall.add(call.sourceId);
            methodsInCall.add(call.targetId);
        }

        // 2) identify the set of methods not used in a call
        Set<String> methodsToRemove = SetUtils.difference(methodsMap.keySet(), methodsInCall);

        // 3) remove the methods non used in a call
        for (String methodId : methodsToRemove)
            methodsMap.remove(methodId);
    }

    public List<GraphEdge> getMethodCalls() {
        return this.methodCalls;
    }

    // ----------------------------------------------------------------------
    //
    // ----------------------------------------------------------------------

    public void done() {

    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

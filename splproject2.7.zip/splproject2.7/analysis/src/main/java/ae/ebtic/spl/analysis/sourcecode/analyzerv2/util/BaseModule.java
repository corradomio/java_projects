package ae.ebtic.spl.analysis.sourcecode.analyzerv2.util;

import ae.ebtic.spl.analysis.sourcecode.analyzer.java.ArchiveUtils;
import ae.ebtic.spl.analysis.sourcecode.analyzer.java.JarLibrary;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.NamedObject;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import jext.cache.Cache;
import jext.cache.CacheManager;
import jext.io.util.FileFilters;
import jext.logging.Logger;
import jext.util.FileUtils;
import jext.util.PathUtils;
import jext.util.SetUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Properties;
import java.util.Queue;
import java.util.Set;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

public abstract class BaseModule extends NamedObject implements /*Directory*/Module {

    // ----------------------------------------------------------------------
    // Protected fields
    // ----------------------------------------------------------------------

    // private String id;

    protected Project project;
    protected File moduleDir;
    private Properties properties;

    protected List<File> directories;
    protected List<Library> libraries;
    protected List<Module> dependencies;
    protected List<Source> sources;

    // protected Set<RefType> types;
    // protected Set<RefType> usedTypes;

    protected Logger logger;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected BaseModule(File moduleDir, Project project) {
        super(null);
        this.moduleDir = moduleDir;
        this.project = project;
        this.properties = new Properties();

        String rpath = FileUtils.relativePath(project.getDirectory(), moduleDir);
        setName(new PathName(rpath));

        this.logger = Logger.getLogger("%s.%s.%s",
            getClass().getSimpleName(),
            project.getName().getName(),
            getName().getName());

        // this.id = new HashCode()
        //     .add(project.getName().getFullName())
        //     .add(getName().getFullName())
        //     .toHashCodeString64();
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    // @Override
    // public String getId() {
    //     return id;
    // }

    @Override
    public Project getProject(){
        return project;
    }

    @Override
    public Properties getProperties() {
        return properties;
    }

    @Override
    public String getPath() {
        return FileUtils.getAbsolutePath(moduleDir);
    }

    @Override
    public File getDirectory() {
        return moduleDir;
    }

    // ----------------------------------------------------------------------
    // Module dependencies
    // ----------------------------------------------------------------------

    @Override
    public List<Module> getDependencies(boolean recursive) {
        if (dependencies == null)
            dependencies = getDependencies();

        if (!recursive)
            return dependencies;
        else
            return getRecursiveDependencies();
    }


    protected List<Module> getDependencies() {
        //
        // WARN: DON'T CALL IT directly!
        //
        // It is better to call 'getDependencies(false)'  because
        // that method checks if 'dependencies' is already evaluated!
        //

        // used to order the dependencies based on the intersection size
        class DepInfo implements Comparable<DepInfo> {
            Module dmodule;
            int isize;

            DepInfo(Module m, int s) {
                dmodule = m;
                isize = s;
            }

            @Override
            public int compareTo(DepInfo that) {
                // decreasing order
                return that.isize - this.isize;
            }
        }

        //
        // Identify a module dependency based on the following rule:
        //
        // 1) each module defines a set of types ('types')
        // 2) the implementation of these types use other types ('usedTypes')
        //    defined in other modules or external libraries
        //
        // there is a 'module dependency' if the intersection between the current
        // module's 'usedTypes' with another module's 'types' is NOT EMPTY.
        //
        // However it is possible to have 'false positive', that is the intersection
        // is not empty but this is only a case.
        //
        // This can happen when two or more modules define the same type.
        // In theory, the correct definition is selected based on the 'module order'
        // defined in the 'building system configuration file'. But it is possible that
        // this file is not available or it is not possible to analyze (for example
        // Gradle 'build.gradle') for some reason.
        //
        // To resolve this problem we use the following trick:
        //
        // - we order the module dependencies based on the intersection size, in
        //   decreasing order
        //
        // In this way we hope to test the dependencies with the most probable
        // module.
        //
        // The correct order is implemented inside the derived classes on this class
        // because each derived class is specialized on a specific 'building system'
        //

        List<DepInfo> dependencies = new ArrayList<>();

        // Union of LOCAL DEFINED types PLUS types DEFINED inside the LOCAL libraries
        Set<RefType> allTypes = getTypes(true);

        // EXTERNAL USED types: LOCAL USED types MINUS all LOCAL DEFINED types
        Set<RefType> usedTypes = SetUtils.difference(getUsedTypes(), allTypes);

        project.getModules().forEach(dmodule -> {
            if (dmodule.getName().equals(this.getName()))
                return;

            // EXTERNAL DEFINED types (EXCLUDING the same types defined in the common libraries)
            Set<RefType> dtypes = SetUtils.difference(dmodule.getTypes(true), allTypes);

            // LOCAL USED types available in the EXTERNAL DEFINED types
            Set<RefType> itypes = SetUtils.intersection(usedTypes, dtypes);
            int isize = itypes.size();
            if (isize == 0)
                return;

            dependencies.add(new DepInfo(dmodule, isize));
        });

        // List<Module> dependencies = project.getModules().stream()
        //     // skip itself
        //     .filter(dmodule -> !dmodule.getName().equals(this.getName()))
        //     // evaluate the type intersection size
        //     .map(dmodule -> new DepInfo(dmodule, SetUtils.intersection(usedTypes, dmodule.getTypes()).size()))
        //     // remove invalid dependencies (intersection size == 0)
        //     .filter(depinfo -> depinfo.isize > 0)
        //     // order by intersection size in decreasing way
        //     .sorted()
        //     // extract the module
        //     .map(depInfo -> depInfo.dmodule)
        //     // collect the modules
        //     .collect(Collectors.toList());

        return dependencies.stream()
            .map(di -> di.dmodule)
            .collect(Collectors.toList());
    }

    // evaluate the recursive dependencies (breath first)
    private List<Module> getRecursiveDependencies() {
        Queue<Module> toVisit = new LinkedList<>(getDependencies(false));
        Set<Module> visited = new HashSet<>();

        while (!toVisit.isEmpty()) {
            Module dmodule = toVisit.remove();
            if (visited.contains(dmodule))
                continue;

            visited.add(dmodule);
            toVisit.addAll(dmodule.getDependencies(false));
        }

        return new ArrayList<>(visited);
    }

    // ----------------------------------------------------------------------
    // Module content
    // ----------------------------------------------------------------------

    @Override
    public List<Source> getSources() {
        if (sources != null)
            return sources;

        sources = new ArrayList<>();

        getDirectories().forEach(dir -> {
            List<Source> srclist = getBaseProject().getSources(dir, this);
            sources.addAll(srclist);
        });

        return sources;
    }

    @Override
    public Source getSource(String name) {
        for (Source source : getSources()) {
            if (source.getId().equals(name))
                return source;
            if (source.getName().getFullName().equals(name))
                return source;
            if (source.getName().getName().equals(name))
                return source;
            if (source.getPath().equals(name))
                return source;
        }
        return null;
    }

    // ----------------------------------------------------------------------
    // Libraries
    // ----------------------------------------------------------------------

    @Override
    public List<Library> getLibraries() {
        if (libraries != null)
            return libraries;

        libraries = new ArrayList<>();

        libraries.addAll(getLocalLibraries());

        libraries.addAll(getMavenLibraries());

        libraries.add(project.getRuntimeLibrary());

        return libraries;
    }

    @Override
    public Library getLibrary(String name) {
        for (Library library : getLibraries()) {
            if (library.getId().equals(name))
                return library;
            if (library.getName().getFullName().equals(name))
                return library;
            if (library.getName().getName().equals(name))
                return library;
            if (library.getPath().equals(name))
                return library;
        }
        return null;
    }


    /**
     * List of local libraries (*.jar files)
     */
    protected List<Library> getLocalLibraries() {
        List<File> jarFiles = new ArrayList<>();

        // check the module directory
        {
            FileUtils.listFiles(jarFiles, moduleDir, FileFilters.IS_JAR);
        }

        // check the sub directories
        getDirectories().forEach(dir ->{
            FileUtils.listFiles(jarFiles, dir, FileFilters.IS_JAR);
        });

        return jarFiles.stream()
            .map(jarFile -> ArchiveUtils.newLibrary(jarFile, this))
            .collect(Collectors.toList());
    }

    /**
     * List of Maven libraries, specified by a Maven Coordinate
     */
    protected List<Library> getMavenLibraries() {
        return Collections.emptyList();
    }

    protected List<String> getMavenRepositories() {
        return Collections.emptyList();
    }

    // ----------------------------------------------------------------------
    // Resources
    // ----------------------------------------------------------------------

    @Override
    public List<Resource> getResources() {

        List<Resource> resources = new ArrayList<>();

        // local resources
        resources.addAll(getBaseProject().getResources(moduleDir, this));

        // sub resources
        getDirectories().forEach(dir -> {
            List<Resource> reslist = getBaseProject().getResources(dir, this);
            resources.addAll(reslist);
        });

        return resources;
    }

    // ----------------------------------------------------------------------
    // Types
    // ----------------------------------------------------------------------

    @Override
    public Set<RefType> getTypes(boolean includeLibraries) {

        // cache names:
        //
        //      dependency.{project}.module.types
        //      dependency.{project}.module.allTypes
        //

        Cache<String, Set<RefType>> cache;

        if (!includeLibraries) {
            cache = CacheManager.getCache("dependency.%s.module.types", project.getId());
            return cache.get(getId(), () -> {
                Set<RefType> types = new HashSet<>();

                getSources().forEach(source -> types.addAll(source.getTypes()));

                return types;
            });
        } else {
            cache = CacheManager.getCache("dependency.%s.module.allTypes", project.getId());
            return cache.get(getId(), () -> {
                Set<RefType> allTypes = new HashSet<>(getTypes(false));

                getLibraries().forEach(library -> allTypes.addAll(library.getTypes()));

                return allTypes;
            });
        }

    }

    @Override
    public Set<RefType> getUsedTypes() {
        Cache<String, Set<RefType>> cache;

        cache = CacheManager.getCache("dependency.%s.module.usedTypes", project.getId());
        return cache.get(getId(), () -> {
                Set<RefType> usedTypes = new HashSet<>();

                getSources().forEach(source -> {
                    usedTypes.addAll(source.getUsedTypes());
                });

                return usedTypes;
            });
    }

    // ----------------------------------------------------------------------
    // Implementations
    // ----------------------------------------------------------------------

    protected List<File> getDirectories() {
        if (directories == null)
            directories = getBaseProject().getDirectories(moduleDir);
        return directories;
    }

    private BaseProject getBaseProject() {
        return (BaseProject) project;
    }

}

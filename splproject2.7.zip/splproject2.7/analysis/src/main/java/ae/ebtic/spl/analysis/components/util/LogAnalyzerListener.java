package ae.ebtic.spl.analysis.components.util;

import ae.ebtic.spl.analysis.components.AnalyzerListener;
import jext.logging.Logger;

public class LogAnalyzerListener implements AnalyzerListener {

    private Logger logger;

    public LogAnalyzerListener(Logger logger) {
        this.logger = logger;
    }

    @Override
    public void onCreateComponents(int totalComponents) {

    }

    @Override
    public void onAggregateComponents(int totalComponents) {

    }

    @Override
    public void onComponentsDependencies(int totalComponents) {

    }

    @Override
    public void onCreateDependencies(int totalComponents) {

    }

    @Override
    public void onComponentsProcessed(int componentsProcessed, int totalComponents) {

    }

    @Override
    public void onDone() {

    }
}

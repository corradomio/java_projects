package ae.ebtic.spl.analysis.features;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.sourcecode.model.IdNamed;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Type;

import java.util.Collection;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Set;

public interface Feature extends IdNamed {

    /** Reference component id */
    String getComponentId();

    /** Reference type id */
    String getTypeId();

    // -- Properties

    /** Number of components members of this feature */
    long getCount();

    /** Number of types, union of component's types */
    long getTypesCount();

    /** List of components members of the feature */
    List<Component> getComponents();

    /** Union of the component's types */
    List<Type> getTypes();

    /** Feature complexity */
    double getComplexity();

    // -- EntryPoint

    /** A feature is 'entryPoint' if it contains one or more 'entryPoint' types */
    boolean isEntryPoint();
    long[] getCountEntryPoints();

    // -- Neo4j

    /** Neo4j node values */
    Map<String, Object> getValues();

}

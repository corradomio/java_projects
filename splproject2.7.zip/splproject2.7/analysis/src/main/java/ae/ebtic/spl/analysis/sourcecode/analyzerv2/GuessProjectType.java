package ae.ebtic.spl.analysis.sourcecode.analyzerv2;

import ae.ebtic.spl.analysis.sourcecode.analyzerv2.ant.AntProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.eclipse.EclipseProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.gradle.GradleProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.maven.MavenProject;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.simple.SimpleProject;

import java.io.File;
import java.util.Properties;

public class GuessProjectType {

    // ----------------------------------------------------------------------
    // Static Methods
    // ----------------------------------------------------------------------

    public static String guessProjectType(File projectDir, Properties props) {
        if (GradleProject.isProject(projectDir, props))
            return GradleProject.TYPE;
        else if (MavenProject.isProject(projectDir, props))
            return  MavenProject.TYPE;
        else if (EclipseProject.isProject(projectDir, props))
            return  EclipseProject.TYPE;
        else if (AntProject.isProject(projectDir, props))
            return AntProject.TYPE;
        else // project type not defined
            return SimpleProject.TYPE;
    }

}

package ae.ebtic.spl.analysis.sourcecode.model;

import java.util.List;
import java.util.Map;

public interface Method extends IdNamed {

    // Name getName();

    // String getId();

    String getSignature();

    String getOwnerTypeId();

    String getTypeId();

    Map<String, Object> getValues();

    /**
     * Type where the method is defined
     */
    Type getOwnerType();

    /**
     * Return type of the method
     */
    Type getType();

    /**
     * List of method parameters
     */
    List<Parameter> getParameters();

    /**
     * List of the referenced types in the body:
     *
     * - local variable types
     * - exception catch
     * - etc
     */
    List<Type> getReferencedTypes();

    /**
     * List of method calls
     */
    List<Method> getMethodCalls();

    // runtime analysis
    boolean isEntryPoint();
}

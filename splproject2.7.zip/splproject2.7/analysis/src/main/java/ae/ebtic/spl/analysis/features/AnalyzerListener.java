package ae.ebtic.spl.analysis.features;

public interface AnalyzerListener {

    void onCreateFeatures(int totalFeatures);

    void onDone();
}

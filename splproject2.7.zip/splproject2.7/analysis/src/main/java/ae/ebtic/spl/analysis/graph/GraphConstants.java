package ae.ebtic.spl.analysis.graph;

public interface GraphConstants {

    // ----------------------------------------------------------------------
    // Dependency Graph
    // ----------------------------------------------------------------------

    String UNKNOWN = "UNKNOWN";
    String EMPTY = "";

    String REPOSITORY = "repository";
    String PROJECT = "project";
    String   MODULE = "module";
    String     LIBRARY = "library";
    String       LIBRARY_TYPE = "libraryType";
    String     SOURCE = "source";
    String     RESOURCE = "resource";

    String NAMESPACE = "namespace";
    String   TYPE = "type";
    String     FIELD = "field";
    String     METHOD = "method";
    String       TYPE_PARAMS = "typeParams";
    String       NUM_PARAMS = "nParams";
    String       SIGNATURE = "signature";
    String       RETURN = "return";
    String       PARAMETER = "parameter";
    String       COMMENT = "comment";
    String     REFTYPE = "reftype";

    String ID = "id";
    String IDS = "ids";
    String PROJECT_ID  = "projectId";
    String   MODULE_ID = "moduleId";
    String     TYPE_ID = "typeId";
    String     METHOD_ID = "methodId";
    String     NAMESPACE_ID = "namespaceId";
    String     LIBRARY_ID = "libraryId";
    String     SOURCE_ID = "sourceId";
    String     RESOURCE_ID = "resourceId";
    String     MEMBER_ID = "memberId";
    String     OWNER_TYPE_ID = "ownerTypeId";
    String     OWNER_METHOD_ID = "ownerMethodId";
    String     FIELD_ID = "fieldId";

    String NAME = "name";
    String      FULLNAME = "fullname";
    String      TYPENAME = "typename";
    String      METHODNAME = "methodname";
    String PATH = "path";
    String DIGEST = "digest";
    String TIMESTAMP = "timestamp";
    String STATUS = "status";
    String REASON = "reason";
    String LANGUAGE = "language";
    String PROJECT_TYPE = "projectType";

    // Aliases (NOT IN DATABASE!)
    String FULL_NAME = "fullName";
    String METHOD_NAME = "methodName";
    String TYPE_NAME = "typeName";
    // End aliases

    String ROLE = "role";
    String CONTEXT = "context";

    String EDGE_TYPE = "type";          // property used to specialize an edge
    // ing USES_TYPE = "uses";          // property used to specialize an 'uses' edge. It contains ALSO 'type'

    String MEMBER_OF = "memberOf";
    String USES = "uses";
        String EXTENDS = "extends";
        String IMPLEMENTS = "implements";
        String DEPENDS_ON = "dependsOn";
    String OF_TYPE = "ofType";
    String FOLLOWS = "follows";

    String METHOD_CALL = "call";

    String TOKEN = "token";
    String PERCENTAGE = "percentage";
    String ISINTERFACE = "isInterface";
    String ISEXTENDED = "isExtended";

    String STATEMENT = "statement";
        String INDEX = "index";

    // ----------------------------------------------------------------------
    // EntryPoint (type/component/feature)
    // ----------------------------------------------------------------------

    String RUNTIME = "runtime";
    String ENTRY_POINT = "entryPoint";
    // String ENTRY_POINT_SCORE = "entryPointScore";
    String COUNT_ENTRY_POINTS = "countEntryPoints";
    String COUNT_METHODS = "countMethods";

    // ----------------------------------------------------------------------
    // Type roles
    // ----------------------------------------------------------------------

    String TROLE_PRIMITIVE = "PRIMITIVE";
    String TROLE_INTERFACE = "INTERFACE";
    String TROLE_CLASS = "CLASS";
    String TROLE_ENUM = "ENUM";
    String TROLE_ANNOTATION = "ANNOTATION";
    String TROLE_TYPE_PARAMETER = "TYPE_PARAMETER";
    String TROLE_REFTYPE = "REFTYPE";


    // ----------------------------------------------------------------------
    // Component Graph
    // ----------------------------------------------------------------------

    String COMPONENT = "component";
    String COMPONENT_ID = "componentId";

    String CONTAINS = "contains";
    String DEPTH = "depth";
    String ALL = "all";
    String COUNT = "count";
    String COUNT_TYPES = "countTypes";
    String TYPES_COUNT = "typesCount";

    String CLASSES = "classes";

    // ----------------------------------------------------------------------
    // Type types
    // ----------------------------------------------------------------------

    String TYPE_UNKNOWN = "unknown";
    String TYPE_REFTYPE = "reftype";

    // ----------------------------------------------------------------------
    // Component roles
    // ----------------------------------------------------------------------

    // String CROLE_PROJECT   = "PROJECT";
    String CROLE_TYPE      = "TYPE";
    String CROLE_COMPONENT = "COMPONENT";
    String CROLE_DAGROOT   = "DAGROOT";

    // ----------------------------------------------------------------------
    // Feature Graph
    // ----------------------------------------------------------------------

    String FEATURE = "feature";
    String FEATURE_ID = "featureId";

    String COMPLEXITY = "complexity";

    // ----------------------------------------------------------------------
    // Core Graph
    // ----------------------------------------------------------------------

    String SCORE = "score";
    String CORE = "core";
    String NODES = "nodes";
    String ALPHA = "alpha";

    // ----------------------------------------------------------------------
    // Clustering Graph
    // ----------------------------------------------------------------------

    String KEYWORDS = "keywords";
    String CLUSTER = "cluster";

    // ----------------------------------------------------------------------
    // Feature roles
    // ----------------------------------------------------------------------

    String ROLE_PROJECT = "PROJECT";
    String ROLE_COMPONENT = "COMPONENT";
    String ROLE_FEATURE = "FEATURE";

    // ----------------------------------------------------------------------
    // Language Specific
    // ----------------------------------------------------------------------
    // Java

    String JAVA_LANG = "java";
    String JAVA_LANG_OBJECT = "java.lang.Object";

    // ----------------------------------------------------------------------
    // Database Graph elements
    // ----------------------------------------------------------------------

    String GRAPH_NODE_ID = "$id";
    String GRAPH_NODE_TYPE = "$type";
    String GRAPH_EDGE_TYPE = "$type";

    // ----------------------------------------------------------------------
    // JSON Graph elements
    // ----------------------------------------------------------------------

    String LABEL = "label";
    String METADATA = "metadata";
    String DIRECTED = "directed";

    String GRAPH = "graph";
    String GRAPH_DIRECTED = DIRECTED;
    String GRAPH_TYPE = "type";
    String GRAPH_NODES = "nodes";
    String GRAPH_EDGES = "edges";

    String EDGE_SOURCE = "source";
    String EDGE_TARGET = "target";
    String EDGE_FROM = "idfrom";
    String EDGE_TO = "idto";
    String EDGE_RELATION = "relation";
    String EDGE_DIRECTED = DIRECTED;

    // ----------------------------------------------------------------------
    // Model Status
    // ----------------------------------------------------------------------

    String MODEL_STATUS = "modelStatus";
    String TASK_ID = "taskId";
    String TASK_TYPE = "taskType";
    String STATUS_MESSAGE = "message";

    // Model status
    String STATUS_CREATED = "CREATED";
    String STATUS_NOT_EXISTENT = "NOT_EXISTENT";
    String STATUS_TASK_RUNNING = "TASK_RUNNING";
    String STATUS_VALID = "VALID";
    String STATUS_INVALID = "INVALID";

    String REASON_CREATE = "Creating ...";
    String REASON_ABORTED = "Aborted";
    String REASON_FAILED = "Failed for exception";
    String REASON_DELETE = "Deleting ...";
}

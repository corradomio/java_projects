package ae.ebtic.spl.analysis.statistics.core;

public interface AnalyzerListener {

    void onFindFeatureCount(int types);

    void onKCoreDecomposition(int types);

    void onAggregateScore(int types);

    void onTypesProcessed(int typesProcessed, int totalTypes);

    void onDone();
}

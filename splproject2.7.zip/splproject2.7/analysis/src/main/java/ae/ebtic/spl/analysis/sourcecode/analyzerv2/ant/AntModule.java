package ae.ebtic.spl.analysis.sourcecode.analyzerv2.ant;

import ae.ebtic.spl.analysis.sourcecode.analyzer.maven.MavenLibrary;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.ant.util.IvyFile;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.util.BaseModule;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.util.FileUtils;

import java.io.File;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class AntModule extends BaseModule {

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private List<IvyFile> ivyFiles;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public AntModule(File moduleDir, Project project) {
        super(moduleDir, project);
        findIvyFile();
    }

    private void findIvyFile() {
        ivyFiles = FileUtils.asList(moduleDir.listFiles((dir, name) -> name.startsWith("ivy")))
            .stream()
            .map(IvyFile::new)
            .collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    protected List<Library> getMavenLibraries(){
        if (ivyFiles.isEmpty())
            return Collections.emptyList();

        List<MavenCoords> coords = new ArrayList<>();
        ivyFiles.forEach(ivyFile -> {
            coords.addAll(ivyFile.getDependencyCoords());
        });

        MavenDownloader md = project.getLibraryDownloader();

        coords.sort(Comparator.naturalOrder());
        return coords.stream()
            .map(lcoords -> new MavenLibrary(lcoords, md, project))
            .collect(Collectors.toList());
    }
}
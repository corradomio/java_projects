package ae.ebtic.spl.analysis.features;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.logging.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class FeatureAnalyzer implements FeatureAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static FeatureAnalysis newAnalyzer(AnalyzerConfig config) {
        FeatureAnalyzer analyzer = new FeatureAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // if the process is aborted
    private boolean aborted;

    // logger
    private Logger logger;

    // listeners
    private Listeners listeners = new Listeners();

    // feature project id
    private String featureProjectId;

    // configuration
    private AnalyzerConfig config;

    // handle the component graph
    private FeatureGraph fg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private FeatureAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    private FeatureAnalyzer initialize() {
        logger = Logger.getLogger("%s.%s.%s",
            getClass(), config.getProjectName().getParentName(), config.getProjectName().getName());

        GraphConfig config = new GraphConfig()
            .setGraphDatabase(this.config.getGraphDatabase())
            .setProjectName(this.config.getProjectName())
            .setParameters(this.config.getParameters());

        //fg = FeatureGraph.newFeatureGraph(config);
        fg = ProjectGraphAccess.newProjectGraphAccess(config).getFeatureGraph();

        return this;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void abort() {
        aborted = true;
    }

    /**
     * Delete all projects with the same name
     */
    public void delete() {
        fg.delete();
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void analyze() {
        if (aborted) return;

        try (FeatureGraph fg = (FeatureGraph) this.fg.connect()) {
            createFeatureNode();

            createFeatures();

            analysisDone(false);
        }
        catch (Throwable t) {
            logger.error(t, t);

            analysisDone(true);
        }
    }

    public void analyze(List<String> features, List<List<String>> components){
        if(aborted) return;

        try (FeatureGraph fg = (FeatureGraph) this.fg.connect()) {
            createFeatureNode();

            createFeatures(features, components);

            analysisDone(false);
        }
        catch (Throwable t) {
            logger.error(t, t);
            analysisDone(true);
        }
    }

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------

    private void createFeatureNode() {
        if (aborted) return;

        featureProjectId = fg.create();
    }

    private void createFeatures() {

        List<Component> components = fg.findDAGRoots();

        for(Component component : components) {
            fg.createFeature(component);
        }
    }

    private void analysisDone(boolean failed) {
        if (aborted)
            fg.setStatus(STATUS_INVALID, "Aborted");
        else if (failed)
            fg.setStatus(STATUS_INVALID, "Failed");
        else
            fg.setStatus(STATUS_VALID, null);

        listeners.fireDone();
    }

    private void createFeatures(List<String> featureNames, List<List<String>> fToCIds){

        for (int i=0; i<featureNames.size(); ++i) {
            String featureName = featureNames.get(i);
            List<String> componentIds = fToCIds.get(i);
            fg.createFeature(featureName, componentIds);
        }

        // for (int i=0; i<featureNames.size(); ++i) {
        //     String featureName = featureNames.get(i);
        //     List<String> componentIds = fToCIds.get(i);
        //
        //     Map<String, Object> nv = new HashMap<>();
        //     nv.put(NAME, featureName);
        //     nv.put(FULLNAME, featureName);
        //
        //     String featureId = fg.createFeature(nv);
        //
        //     fg.connectFeatureToComponents(featureId, componentIds);
        // }

    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    private static class Listeners {

        private List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        void fireCreateComponents(int totalComponents) {
            listeners.forEach(l -> l.onCreateFeatures(totalComponents) );
        }

        void fireDone() {
            listeners.forEach(l -> l.onDone() );
        }

    }

    public FeatureAnalyzer addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }

}

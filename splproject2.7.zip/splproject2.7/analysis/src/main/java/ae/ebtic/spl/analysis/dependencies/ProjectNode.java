package ae.ebtic.spl.analysis.dependencies;

import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.extlibs.NullLibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.ProjectUtils;
import jext.maven.MavenDownloader;
import jext.util.PropertiesUtils;

import java.io.File;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;
import java.util.stream.Collectors;

public class ProjectNode extends GraphNode implements Project {

    public static List<Project> of(DependencyGraph dg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> ProjectNode.of(dg, nv))
            .collect(Collectors.toList());
    }

    public static ProjectNode of(DependencyGraph dg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new ProjectNode(dg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Field
    // ----------------------------------------------------------------------

    private DependencyGraph dg;

    private LibraryFinder lfinder = NullLibraryFinder.instance();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ProjectNode(DependencyGraph dg, Map<String, Object> nv) {
        super(dg.getProjectGraphAccess(), nv);
        this.dg = dg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public String getProjectType() {
        return (String) nv.getOrDefault(GraphConstants.PROJECT_TYPE, null);
    }

    @Override
    public Properties getProperties() {
        return PropertiesUtils.empty();
    }

    @Override
    public String getPath() {
        return (String) nv.get(PATH);
    }

    @Override
    public File getDirectory() {
        return new File(getPath());
    }

    // ----------------------------------------------------------------------
    // Modules
    // ----------------------------------------------------------------------

    @Override
    public List<Module> getModules() {
        return dg.getModules(getId(), true);
    }

    @Override
    public Module getModule(String moduleName) {
        List<Module> modules = getModules();
        for (Module module : modules)
            if (module.getName().getFullName().equals(moduleName))
                return module;
        return null;
    }

    // ----------------------------------------------------------------------
    // Library finder
    // ----------------------------------------------------------------------

    @Override
    public Project setLibraryFinder(LibraryFinder lfinder) {
        this.lfinder = lfinder;
        return this;
    }

    @Override
    public MavenDownloader getLibraryDownloader() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Library getRuntimeLibrary() {
        throw new UnsupportedOperationException();
    }

    // ----------------------------------------------------------------------
    // Extras
    // ----------------------------------------------------------------------

    @Override
    public double getComplexity(double threshold) {
        return dg.getComplexity(threshold);
    }

}

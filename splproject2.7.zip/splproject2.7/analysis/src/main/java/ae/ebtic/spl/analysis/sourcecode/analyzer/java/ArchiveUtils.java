package ae.ebtic.spl.analysis.sourcecode.analyzer.java;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;

import java.io.File;

public class ArchiveUtils {

    public static Library newLibrary(File archiveFile, Module module) {
        String name = archiveFile.getName();
        if (name.endsWith(".aar"))
            return new AarLibrary(archiveFile, module);
        else
            return new JarLibrary(archiveFile, module);
    }
}

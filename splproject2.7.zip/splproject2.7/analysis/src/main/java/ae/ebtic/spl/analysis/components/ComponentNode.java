package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.features.Feature;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.graph.Direction;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;


public class ComponentNode extends GraphNode implements Component, GraphConstants {

    public static List<Component> of(ComponentGraph cg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> ComponentNode.of(cg, nv))
            .collect(Collectors.toList());
    }

    public static ComponentNode of(ComponentGraph cg, Map<String, Object> nv) {
        if (nv == null) 
            return null;
        else
            return new ComponentNode(cg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------
    /*
        Content of the map 'nv':

        $labels: List<String>   list of the graphdb labels (in general there is only 1 label)
        $id: String             id of the graphdb node
        $type: String           type of the node (the unique label)

        name: String            name of the component
        fullname: STring        full name of the component
        count: int              number of members
        depth: int              level of the component
        role: String            CROLE_*
        projectId: String       id of the owner's project
     */

    private ComponentGraph cg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ComponentNode(ComponentGraph cg, Map<String, Object> nv) {
        super(cg.getProjectGraphAccess(), nv);
        this.cg = cg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public long getDepth() {
        return (long)nv.getOrDefault(DEPTH, 0L);
    }

    @Override
    public long getCount() {
        return (long)nv.getOrDefault(COUNT, 0L);
    }

    // -- Types

    @Override
    public long getTypesCount() {
        return (long)nv.getOrDefault(COUNT_TYPES, 0L);
    }

    @Override
    public String getTypeId() {
        if (nv.containsKey(TYPE_ID))
            return nv.get(TYPE_ID).toString();
        else
            return null;
    }

    // -- EntryPoint

    @Override
    public boolean isEntryPoint() {
        return (Boolean)nv.getOrDefault(ENTRY_POINT, Boolean.FALSE);
    }

    @Override
    public long[] getCountEntryPoints() {
        List<Long> counts = (List<Long>)nv.getOrDefault(COUNT_ENTRY_POINTS, null);
        if (counts == null)
            return null;
        return new long[] {
            counts.get(0),
            counts.get(1),
            counts.get(2)
        };
    }

    // ----------------------------------------------------------------------
    // Navigate
    // ----------------------------------------------------------------------

    @Override
    public List<Type> getTypes() {
        return cg.getComponentTypes(getId(), getDepth());
    }

    @Override
    public List<Component> getUsesComponents(Direction direction) {
        return cg.getUsesComponents(getId(), direction);
    }

    @Override
    public List<Component> getMembers(){
        return cg.getMembers(getId());
    }

    @Override
    public List<Feature> getFeatures() {
        return cg.getFeatures(getId());
    }

    // ----------------------------------------------------------------------
    // Navigation
    // ----------------------------------------------------------------------

    public Set<Type> getTypeNodes() {
        if (getDepth() == 0)
            return new HashSet<>(getTypes());

        Set<Type> typeNodes = new HashSet<>();
        getMembers().forEach(member -> {
            typeNodes.addAll(((ComponentNode)member).getTypeNodes());
        });

        return typeNodes;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;

public interface TypeRegistry {

    void registerType(String typeId, Name typeName, Named container);

    String getTypeId(Name typeName, Named container);
}

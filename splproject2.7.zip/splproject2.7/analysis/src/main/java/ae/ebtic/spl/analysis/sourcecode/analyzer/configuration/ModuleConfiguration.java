package ae.ebtic.spl.analysis.sourcecode.analyzer.configuration;

import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;

import java.util.List;
import java.util.Properties;
import java.util.Set;

public interface ModuleConfiguration {

    // check if the file is a valid configuration
    boolean isValid();

    ModuleConfiguration setDownloader(Project project);

    ModuleConfiguration addProperties(Properties props);

    MavenCoords getMavenCoords();

    List<String> getMavenRepositories();

    Set<MavenCoords> getMavenDependencies();

    Set<String> getDependencies(String projectDir);
}

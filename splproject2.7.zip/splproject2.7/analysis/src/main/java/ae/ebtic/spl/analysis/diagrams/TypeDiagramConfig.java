package ae.ebtic.spl.analysis.diagrams;

import java.util.ArrayList;
import java.util.List;

/*

          (1:P)
            ↑
            |
   (3:A)--→[T]--→(4:B)
            ↑
            |
          (2:D)

    (1) T extends/implements P
    (2) D extends/implements T
    (3) A dependsOn T
    (4) T dependsOn B

Note:
    class     extends class,... implements interface, ...
    interface extends interface, ...


Relation directions:
    vertical:   class/interface hierarchy
    horizontal: fields/methods implementation
    refType:    include the external types

    for example, following the relations:

        only forward:   T, B, P
        only backward:  T, A, D
        all directions: T, P, B, D, A


We need ONLY directions 2 & 4

click on gray circle    -> direction (4)
double click on the box -> direction (2)


closure
    i follow forward the 'uses' edges.


USES edges
    uses/implements
    uses/extends
    uses/dependsOn
 */

public class TypeDiagramConfig {

    public List<String> ids = new ArrayList<>();

    public boolean compatibility;

    public boolean dependsOn = true;       // typeDeps
    public boolean extend = false;         // extends
    public boolean implement = true;       // implements/implementation
    public boolean refTypes = false;       // typeRefs
    public boolean recursive = false;      // recursive

    public boolean operations = false;      // show methods
    public boolean operationCalls = false;  // show method calls
    public boolean orphanOperations = true; // show methods with 'method call degree' = 0

    public boolean attributes = false;
    public boolean attributeTypes = false;

    // ----------------------------------------------------------------------
    // Used in web configuration
    // ----------------------------------------------------------------------

    // -- ids

    public void addId(String id) {
        this.ids.add(id);
    }

    /**
     *
     * @param ids List[String|Integer]
     */
    public void setIds(List ids) {
        ids.forEach(id -> {
            this.ids.add(id.toString());
        });
    }

    // -- inheritance

    public void setImplement(boolean value) {
        this.implement = value;
    }

    public void setExtend(boolean value) {
        this.extend = value;
    }

    public void setRecursive(boolean value) {
        this.recursive = value;
    }

    // -- typeDeps

    public void setDependsOn(boolean value) {
        this.dependsOn = value;
    }

    // -- refTypes

    public void setRefTypes(boolean value) {
        this.refTypes = value;
    }

    // -- operations

    public void setOperations(boolean value) {
        this.operations = value;
    }
    public void setOperationCalls(boolean value) {
        this.operationCalls = value;
    }

    public void setHideStandaloneOperations(boolean value) {
        orphanOperations = !value;
    }

    // -- fields

    public void setAttributes(boolean value) {
        this.attributes = value;
    }
    public void setAttributeTypes(boolean value) { this.attributeTypes = value; }

    // ----------------------------------------------------------------------
    // Compatibility
    // ----------------------------------------------------------------------

    public void setCompatibility(boolean value) {
        this.compatibility = value;
    }

    public void setRefType(boolean value) {
        this.refTypes = value;
    }
    public void setTypeDeps(boolean value) {
        this.dependsOn = value;
    }

    public void setImp(boolean value) {
        this.implement = value;
    }
    public void setExt(boolean value) {
        this.extend = value;
    }
    public void setRec(boolean value) {
        this.recursive = value;
    }
    public void setDep(boolean value) {
        this.dependsOn = value;
    }
    public void setRef(boolean value) {
        this.refTypes = value;
    }

    public void setEdges(boolean value) { this.dependsOn = value; }
    public void setLink(boolean value) {
        this.dependsOn = value;
    }

    public void setOp(boolean value) {
        this.operations = value;
    }
    public void setOpc(boolean value) {
        this.operationCalls = value;
    }
    public void setOpEdges(boolean value) { this.operationCalls = value; }
    public void setOpLink(boolean value) {
        this.operationCalls = value;
    }

    public void setAtt(boolean value)  {
        this.attributes = value;
    }
    public void setAtyp(boolean value)  {
        this.attributeTypes = value;
    }
    public void setAttEdges(boolean value)  {
        this.attributeTypes = value;
    }
    public void setAttLink(boolean value)  {
        this.attributeTypes = value;
    }

    public void setOrph(boolean value) {
        this.orphanOperations= value;
    }

}

package ae.ebtic.spl.analysis.clustering;

import ae.ebtic.spl.analysis.clustering.AnalyzerConfig;
import ae.ebtic.spl.analysis.clustering.ClusteringAnalyzer;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import jext.logging.Logger;

import java.util.*;
import java.util.stream.Collectors;

public class ClusteringAnalyzerLowestTokens extends ClusteringAnalyzer {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ClusteringAnalyzerLowestTokens newAnalyzer(AnalyzerConfig config) {
        ClusteringAnalyzerLowestTokens analyzer = new ClusteringAnalyzerLowestTokens(config);
        analyzer.initialize();
        return analyzer;
    }

    public static ClusteringAnalyzerLowestTokens newAnalyzer(AnalyzerConfig config, double percentage) {
        ClusteringAnalyzerLowestTokens analyzer = new ClusteringAnalyzerLowestTokens(config, percentage);
        analyzer.initialize();
        return analyzer;
    }

    private List<String> commonKeywords = new ArrayList<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ClusteringAnalyzerLowestTokens(AnalyzerConfig config) {
        super(config);
        percentage = 0.35;
    }

    private ClusteringAnalyzerLowestTokens(AnalyzerConfig config, double percentage) {
        super(config);
        this.percentage = percentage;
    }

    protected ClusteringAnalyzerLowestTokens initialize() {
        super.initialize();
//        logger = Logger.getLogger("%s.%s.%s",
//                getClass(), config.getProjectName().getParentName(), config.getProjectName().getName());
//
//        GraphConfig config = new GraphConfig()
//                .setGraphDatabase(this.config.getGraphDatabase())
//                .setProjectName(this.config.getProjectName())
//                .setParameters(this.config.getParameters());
//
//        // cg = ClusteringGraph.newClusteringGraph(config);
//        cg = ProjectGraphAccess.newProjectGraphAccess(config).getClusteringGraph();

        return this;
    }


    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    // percentage to exclude
    private double percentage;

    private int numOfClusters;

    private int numOfTokens;

    private List<Map<String, Object>> tokens;

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------

    protected void clusterNodes(String model){

        cg.keywords = new String[]{};

        clusterOnDesignPatterns(model);

        extractUnclustered();

        clusterOnTokens();

        iterativeClustering();

        writeClusters(model,2);
    }


    @Override
    protected void clusterOnTokens(){
        if(aborted) return;

        cg.keywords = new String[]{
                "Factory",
                "Pool",
                "Builder",
                "Adapter",
                "Bridge",
                "Composite",
                "Decorator",
                "Facade",
                "Proxy",
                "Iterator",
                "Interpreter",
                "Command",
                "Observer",
                "State",
                "Visitor",
                "Template",
                "Bean",
                "Query",
                "EntryKey",
                "Thread",
                "DAO",
                "Impl",
                "Data",
                "View",
                "Model",
                "Handler"
        };

        commonKeywords = Arrays.asList(new String[]{"All","An","And","As","By","A","For","From","I","In","Is", "No", "Of", "On", "Or", "Out", "To", "Up", "With"});

        //List<String> keywords =  Arrays.asList(cg.keywords);
        tokens = cg.getTokens().stream().filter(t -> !commonKeywords.contains(t.get(NAME).toString())).collect(Collectors.toList());

    }

    protected void iterativeClustering(){
        if(aborted) return;

        List<String> keywords =  Arrays.asList(cg.keywords);

        List<Map<String, Object>> keywordTokens = tokens.stream().filter(t -> keywords.contains(t.get(NAME).toString())).collect(Collectors.toList());
        List<Long> keywordTokenIDs = keywordTokens.stream().map(i -> Long.parseLong(i.get(ID).toString())).collect(Collectors.toList());
        tokens = tokens.stream().filter(t -> !keywords.contains(t.get(NAME).toString())).collect(Collectors.toList());

        List<Map<String, Object>> singleTokens = tokens.stream().filter(t -> Integer.parseInt(t.get(COUNT).toString())==1).collect(Collectors.toList());
        List<Long> singleTokenIDs = singleTokens.stream().map(i -> Long.parseLong(i.get(ID).toString())).collect(Collectors.toList());

        tokens = tokens.stream().filter(t -> Integer.parseInt(t.get(COUNT).toString())>1).collect(Collectors.toList());
        List<Long> allTokenIDs = tokens.stream().map(i -> Long.parseLong(i.get(ID).toString())).collect(Collectors.toList());

        int i = dPClusters.size();

        List<Map<String, Object>> iClusters = new ArrayList<>(); //stores clusters to be further clustered.

        List<Long> typeIDs = tClusters.stream().map(r ->
        {
            List<Long> x = new ArrayList<>((Collection<Long>)r.get(IDS));
            return x.get(0);

        }).collect(Collectors.toList());

        Map<String, Object> tempMap = new HashMap<>();
        tempMap.put("types",typeIDs);
        tempMap.put("tokens", allTokenIDs);
        tempMap.put(CLUSTER, i);
        tempMap.put("isClustered",false);

        iClusters.add(tempMap);
        boolean first = true;
        boolean added = false;
        boolean added2 = false;
//        i++;

        while(!iClusters.isEmpty()){
            Map<String, Object> currentMap = iClusters.remove(0);
            List<Long> currentTypeIds = (List<Long>)currentMap.get("types");
            List<Long> currentTokenIds = (List<Long>) currentMap.get("tokens");
            String currentCluster = currentMap.get(CLUSTER).toString();
            boolean isClustered = Boolean.parseBoolean(currentMap.get("isClustered").toString());

            List<Long> currentIds = new ArrayList<>();
            currentIds.addAll(currentTypeIds);
            currentIds.addAll(currentTokenIds);

            List<Map<String, Object>> tempClusters = cg.clusterTokensPercentage(currentIds,percentage,currentTokenIds.size());


            List<Long> includedIds = tempClusters.stream().map(tc -> ((Collection<Long>) tc.get(IDS))).flatMap(Collection::stream).collect(Collectors.toList());
            List<Long> skippedTokens = currentTokenIds.stream().filter(st -> !includedIds.contains(st)).collect(Collectors.toList());


            if(tempClusters.size() == 1){
                if(!isClustered)
                    currentCluster = String.valueOf(i++);
                for (Long id : new ArrayList<>((Collection<Long>) tempClusters.get(0).get(IDS))) {
                    Map<String, Object> tMap = new HashMap<>();
                    tMap.put(ID, id);
                    tMap.put(CLUSTER, currentCluster);
                    fClusters.add(tMap);
                }
            }
            else{
                int j = 0;
                List<Map<String, Object>> hasClustered = tempClusters.stream().filter(c -> ((Collection<Long>)c.get(IDS)).size()>1).collect(Collectors.toList());
                List<Map<String, Object>> notClustered = tempClusters.stream().filter(c -> ((Collection<Long>)c.get(IDS)).size()==1).collect(Collectors.toList());


                if(notClustered.size()>0 && !isClustered) {
                    List<Long> unclusteredIds = new ArrayList<>();
                    for (Map<String, Object> map : notClustered) {
                        List<Long> tIds = new ArrayList<>((Collection<Long>) map.get(IDS));
                        unclusteredIds.addAll(tIds);
                    }
                    List<Long> unClusteredTokenIds = unclusteredIds.stream().filter(id -> allTokenIDs.contains(id) || singleTokenIDs.contains(id) || keywordTokenIDs.contains(id)).collect(Collectors.toList());
                    //int uctiSize = unClusteredTokenIds.size();
                    unClusteredTokenIds.addAll(skippedTokens);

                    if(iClusters.size() == 0 && !added){
                        if(!first) {
                            unClusteredTokenIds.addAll(singleTokenIDs);
                            added = true;
                        }
                        first = false;
                        //allTokenIDs.addAll(singleTokenIDs);
                    }
                    else if(iClusters.size() == 0 && added && !added2){
                        unClusteredTokenIds.addAll(keywordTokenIDs);
                        added2 = true;
                    }
                    else if(iClusters.size() == 0 && added2){
                        break;
                    }
                    List<Long> unClusteredTypeIds = unclusteredIds.stream().filter(id -> !unClusteredTokenIds.contains(id)).collect(Collectors.toList());
                    //System.out.println(uctiSize + " " + unClusteredTokenIds.size() + " "+iClusters.size()+" "+unClusteredTypeIds.size());
                    Map<String, Object> unClusteredM = new HashMap<>();
                    unClusteredM.put(CLUSTER, currentCluster);
                    unClusteredM.put("types",unClusteredTypeIds);
                    unClusteredM.put("tokens", unClusteredTokenIds);
                    unClusteredM.put("isClustered",false);
                    iClusters.add(unClusteredM);
                }
                else if(isClustered){
//                    for (Long id : skippedTokens) {
//                        Map<String, Object> tMap = new HashMap<>();
//                        tMap.put(ID, id);
//                        tMap.put(CLUSTER, currentCluster+"."+j);
//                        fClusters.add(tMap);
//                    }
//                    for (Long id : notClustered.stream().map(tc -> ((Collection<Long>) tc.get(IDS))).flatMap(Collection::stream).collect(Collectors.toList())) {
//                        Map<String, Object> tMap = new HashMap<>();
//                        tMap.put(ID, id);
//                        tMap.put(CLUSTER, currentCluster+"."+j);
//                        fClusters.add(tMap);
//                    }
                    if(notClustered.size() == 0){
                        for (Long id : skippedTokens) {
                            Map<String, Object> tMap = new HashMap<>();
                            tMap.put(ID, id);
                            tMap.put(CLUSTER, currentCluster+"."+j);
                            fClusters.add(tMap);
                        }
                    }
                    else if(skippedTokens.size() == 1){
                        for (Long id : skippedTokens) {
                            Map<String, Object> tMap = new HashMap<>();
                            tMap.put(ID, id);
                            tMap.put(CLUSTER, currentCluster+"."+j);
                            fClusters.add(tMap);
                        }
                        for (Long id : notClustered.stream().map(tc -> ((Collection<Long>) tc.get(IDS))).flatMap(Collection::stream).collect(Collectors.toList())) {
                            Map<String, Object> tMap = new HashMap<>();
                            tMap.put(ID, id);
                            tMap.put(CLUSTER, currentCluster+"."+j);
                            fClusters.add(tMap);
                        }
                    }
                    else{
                        List<Long> unClusteredIds = notClustered.stream().map(tc -> ((Collection<Long>) tc.get(IDS))).flatMap(Collection::stream).collect(Collectors.toList());
                        List<Long> unClusteredTokenIds = unClusteredIds.stream().filter(id -> allTokenIDs.contains(id) || singleTokenIDs.contains(id) || keywordTokenIDs.contains(id)).collect(Collectors.toList());
                        unClusteredTokenIds.addAll(skippedTokens);
                        List<Long> unClusteredTypeIds = unClusteredIds.stream().filter(id -> !unClusteredTokenIds.contains(id)).collect(Collectors.toList());
                        Map<String, Object> unClusteredM = new HashMap<>();
                        unClusteredM.put(CLUSTER, currentCluster+"."+j);
                        unClusteredM.put("types",unClusteredTypeIds);
                        unClusteredM.put("tokens", unClusteredTokenIds);
                        unClusteredM.put("isClustered",true);
                        iClusters.add(unClusteredM);

                    }
                    j++;
                }

                for (Map<String, Object> map : hasClustered) {
                    List<Long> tIds = new ArrayList<>((Collection<Long>) map.get(IDS));
                    List<Long> tTokenIds = tIds.stream().filter(id -> allTokenIDs.contains(id) || singleTokenIDs.contains(id) || keywordTokenIDs.contains(id)).collect(Collectors.toList());
                    List<Long> tTypeIds = tIds.stream().filter(id -> !tTokenIds.contains(id)).collect(Collectors.toList());
                    Map<String, Object> tempM = new HashMap<>();
                    if(isClustered)
                        tempM.put(CLUSTER, currentCluster + "." + j);
                    else
                        tempM.put(CLUSTER, i++);
                    tempM.put("types",tTypeIds);
                    tempM.put("tokens", tTokenIds);
                    tempM.put("isClustered",true);
                    iClusters.add(tempM);
                    j++;
                }
            }
        }
    }

}

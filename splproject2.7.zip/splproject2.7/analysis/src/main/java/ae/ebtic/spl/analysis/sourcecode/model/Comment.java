package ae.ebtic.spl.analysis.sourcecode.model;

public interface Comment {
}

package ae.ebtic.spl.analysis.dependencyv2.util;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import jext.util.Pair;
import org.jgrapht.Graph;
import org.jgrapht.graph.DefaultEdge;
import org.jgrapht.graph.SimpleDirectedGraph;

import java.util.ArrayList;
import java.util.List;

/**
 * Class used to create the dependencies between the libraries.
 * It is used to:
 *
 * 1) speed up the creation of the dependency graph
 * 2) create a dependency ONLY between the libraries already registered
 * 3) to be ensure that there exists only a dependency between tro libraries
 */
public class LibrariesDependencyGraph {

    private Graph<Library, DefaultEdge> graph = new SimpleDirectedGraph<>(DefaultEdge.class);

    public LibrariesDependencyGraph() {

    }

    public void addAll(List<Library> libraries) {
        libraries.forEach(this::addLibrary);
    }

    public void addDependencies(Library library, List<Library> dlibs) {
        dlibs.forEach(dlibrary -> {
            if (graph.containsVertex(dlibrary) && !library.equals(dlibrary))
                graph.addEdge(library, dlibrary);
        });
    }

    public void addLibrary(Library library) {
        graph.addVertex(library);
    }

    public List<Pair<Library, Library>> getDependencies() {
        List<Pair<Library, Library>> dependencies = new ArrayList<>();
        graph.edgeSet().forEach(e -> {
            Library source = graph.getEdgeSource(e);
            Library target = graph.getEdgeTarget(e);
            dependencies.add(new Pair<>(source, target));
        });
        return dependencies;
    }

}

package ae.ebtic.spl.analysis.sourcecode.model;

import java.io.File;
import java.util.List;
import java.util.Properties;
import java.util.Set;

public interface Module extends IdNamed {

    /** Owner project */
    Project getProject();

    /** Module properties */
    Properties getProperties();

    /** Module home directory */
    String getPath();
    File   getDirectory();

    // -- modules

    /** Module dependencies */
    List<Module> getDependencies(boolean recursive);

    // -- sources

    /** Sources defined inside the module */
    List<Source> getSources();

    /** Retrieve a source by id/full name/name */
    Source getSource(String name);

    // -- resources/libraries

    /** Libraries used by the module (local & remote) */
    List<Library> getLibraries();

    /** Retrieve a library by id/full name/name */
    Library getLibrary(String name);

    /** Resources used by the module */
    List<Resource> getResources();

    // -- types

    /**
     * List of types defined inside the module
     * It is possible to specify if to include the types
     * defined inside included external libraries
     */
    Set<RefType> getTypes(boolean includeLibraries);

    /** List of types used (in imports) in the implementations */
    Set<RefType> getUsedTypes();

}

package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.graph.GraphDatabase;
import jext.util.Parameters;

public class Projects {

    public static Project newProject(Name projectName, GraphDatabase graphdb) {
        return newProject(projectName, graphdb, Parameters.empty());
    }

    public static Project newProject(Name projectName, GraphDatabase graphdb, Parameters params) {
        GraphConfig config = new GraphConfig()
            .setGraphDatabase(graphdb)
            .setProjectName(projectName)
            .setParameters(params);

        DependencyGraph dg = ProjectGraphAccess.newProjectGraphAccess(config).getDependencyGraph();
        return dg.getProject();
    }
}

package ae.ebtic.spl.analysis.sourcecode.extlibs;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import jext.maven.MavenCoords;
import jext.maven.MavenDownloader;
import jext.util.Parameters;

public class NullLibraryFinder implements LibraryFinder {

    private static LibraryFinder instance = new NullLibraryFinder();

    public static LibraryFinder instance() {
        return instance;
    }

    private NullLibraryFinder() {

    }

    @Override
    public LibraryFinder configure(Parameters params) {
        return this;
    }

    @Override
    public LibraryFinder setProject(Project project) {
        return this;
    }

    @Override
    public Library getLibrary(MavenCoords coords) {
        return null;
    }

    @Override
    public Library getLibrary(String libraryName) {
        return null;
    }

    @Override
    public MavenDownloader getDownloader() {
        return null;
    }

}

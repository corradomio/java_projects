package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.sourcecode.model.MethodName;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.util.MethodObjectName;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.Node;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.ConstructorDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.FieldDeclaration;
import com.github.javaparser.ast.body.MethodDeclaration;
import com.github.javaparser.ast.body.Parameter;
import com.github.javaparser.ast.body.VariableDeclarator;
import com.github.javaparser.ast.expr.ObjectCreationExpr;
import jext.javaparser.util.JPUtils;
import jext.util.Parameters;

import java.util.Optional;

public class ASTMethodDeclarations extends ASTAnalyzer {

    public ASTMethodDeclarations(DependencyAnalyzer da) {
        super(da);
    }

    public void analyze(Source source, Parameters params) {
        super.analyze(source, params);
    }

    protected void analyze(CompilationUnit cu) {
        super.analyze(cu);

        try {

            ts = composeTypeSolver();
            ts.setCu(cu);

            //  main:
            //      BodyDeclaration
            //          CallableDeclaration
            //              ConstructorDeclaration
            //              MethodDeclaration
            //          InitializerDeclaration
            //
            // extras:
            //      BodyDeclaration
            //          AnnotationMemberDeclaration
            //          EnumConstantDeclaration
            //          FieldDeclaration

            cu.findAll(FieldDeclaration.class)
                .forEach(this::analyze);

            cu.findAll(ConstructorDeclaration.class)
                .forEach(this::analyze);
            cu.findAll(MethodDeclaration.class)
                .forEach(this::analyze);
        }
        finally {
            if (ts != null)
                ts.detach();
        }

    }

    // ----------------------------------------------------------------------
    // Methods & Constructors
    // ----------------------------------------------------------------------

    private void analyze(ConstructorDeclaration n) {
        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent()) {
            Optional<Node> nd = JPUtils.findParentDeclaration(n);
            if (nd.isPresent() && nd.get().getClass().equals(EnumDeclaration.class))
                return;
            if (nd.isPresent() && nd.get().getClass().equals(ObjectCreationExpr.class))
                return;

            da.logUnableToFindClassDeclaration(logger, n.getNameAsString());
            return;
        }

        // get the full qualified class name
        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent()) {
            da.logNotFullQualifiedName(logger, n.getNameAsString());
            return;
        }

        int nParams = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) create the method node
        MethodName methodName = new MethodObjectName(qname.get(), n.getName().getIdentifier(), nParams, signature);
        RefType constructorType = toRefType(cid.get());
        String methodId = datodg.createMethodNode(methodName, constructorType);

        // 2) create the method's comment node
        createCommentNode(methodId, n, true);

        // 3) analyze parameters (a constructor has not a return type)
        n.getParameters().forEach(param -> {
            createParameterTypeDependency(methodId, methodName, param);
        });
    }

    private void analyze(MethodDeclaration n) {
        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> cid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!cid.isPresent()) {
            Optional<Node> nd = JPUtils.findParentDeclaration(n);
            if (nd.isPresent() && nd.get().getClass().equals(EnumDeclaration.class))
                return;
            if (nd.isPresent() && nd.get().getClass().equals(ObjectCreationExpr.class))
                return;

            da.logUnableToFindClassDeclaration(logger, n.getNameAsString());
            return;
        }

        Optional<String> qname = cid.get().getFullyQualifiedName();
        if (!qname.isPresent())
            qname = JPUtils.getFullyQualifiedName(cid.get());

        int nParams = n.getParameters().size();
        String signature = JPUtils.getSignature(n);

        // 1) create the method node
        MethodName methodName = new MethodObjectName(qname.get(), n.getName().getIdentifier(), nParams, signature);
        RefType returnType = toRefType(n.getType());
        String methodId = datodg.createMethodNode(methodName, returnType);

        // 2) create the method's comment node
        createCommentNode(methodId, n, true);

        // 3) analyze parameters
        n.getParameters().forEach(param -> {
            createParameterTypeDependency(methodId, methodName, param);
        });
    }

    // private String createMethodNode(MethodName methodName, RefType returnType) {
    //     logger.debugft("Method %s::%s/%d", methodName.getParentName(), methodName.getName(), methodName.getNumParameters());
    //
    //     return datodg.createMethodNode(methodName, returnType);
    // }

    private void createParameterTypeDependency(String methodId, Name methodName, Parameter param) {
        try {
            String pname = param.getName().getIdentifier();
            RefType refType = toRefType(param);
            datodg.createParameterNode(methodId, new ObjectName(methodName, pname), refType);
        }
        catch (Throwable t) {
            logger.error(t, t);
        }
    }

    // private void createReturnTypeDependency(String methodId, ConstructorDeclaration md) {
    //     try {
    //         Optional<ClassOrInterfaceDeclaration> optCid = JPUtils.findClassOrInterfaceDeclaration(md);
    //         if (optCid.isPresent()) {
    //             RefType refType = toRefType(optCid.get());
    //             if (refType != null)
    //                 datodg.createReturnType(methodId, refType);
    //         }
    //     }
    //     catch (Throwable t) {
    //         logger.error(t, t);
    //     }
    // }

    // private void createReturnTypeDependency(String methodId, MethodDeclaration md) {
    //     try {
    //         RefType refType = toRefType(md.getType());
    //         if (refType != null)
    //             datodg.createReturnType(methodId, refType);
    //     }
    //     catch (Throwable t) {
    //         logger.error(t, t);
    //     }
    // }

    // ----------------------------------------------------------------------
    // Fields
    // ----------------------------------------------------------------------

    private void analyze(FieldDeclaration n) {
        // find the owner class containing this method
        Optional<ClassOrInterfaceDeclaration> optCid = JPUtils.findClassOrInterfaceDeclaration(n);
        if(!optCid.isPresent()) {
            Optional<Node> nd = JPUtils.findParentDeclaration(n);
            if (nd.isPresent() && nd.get().getClass().equals(EnumDeclaration.class))
                return;
            if (nd.isPresent() && nd.get().getClass().equals(ObjectCreationExpr.class))
                return;

            da.logUnableToFindClassDeclaration(logger, n.getVariables().toString());
            return;
        }

        ClassOrInterfaceDeclaration cid = optCid.get();
        n.getVariables().forEach(v -> analyze(n, v, cid));
    }

    private void analyze(FieldDeclaration n, VariableDeclarator v, ClassOrInterfaceDeclaration cid) {
        Optional<String> qname = cid.getFullyQualifiedName();
        if (!qname.isPresent())
            qname = JPUtils.getFullyQualifiedName(cid);

        RefType fieldType = toRefType(v.getType());
        Name fieldName = new ObjectName(qname.get(), v.getNameAsString());

        // 1) create the field node
        String fieldId = datodg.createFieldNode(fieldName, fieldType);

        // 2) create the field type Node
        String typeId = datodg.createTypeNode(fieldType, module, params);

        // 3) create the field's comment node
        createCommentNode(fieldId, n, true);
    }

}

package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.body.TypeDeclaration;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.type.ClassOrInterfaceType;
import com.github.javaparser.ast.type.Type;
import jext.util.Parameters;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Stack;

public class ASTVTypeDependencies extends ASTVisitor {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private Stack<RefType> fromTypeStack = new Stack<>();

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ASTVTypeDependencies(DependencyAnalyzer da) {
        super(da);
    }

    // ----------------------------------------------------------------------
    // Analyze
    // ----------------------------------------------------------------------

    public void analyze(Source source, Parameters params) {
        super.analyze(source, params);
    }

    public ASTVTypeDependencies analyze(CompilationUnit cu) {
        try {
            ts = composeTypeSolver();

            super.analyze(cu);
        }
        finally {
            if (ts != null)
                ts.detach();
        }

        return this;
    }

    // ----------------------------------------------------------------------
    // Visit Overrides
    // ----------------------------------------------------------------------
    // PackageDeclaration & ImportDeclaration are processed
    // 1) Imports
    // 2) package
    // 3) enum/class/interface declaration      <==
    //

    //
    //  package a.b.c
    //
    // public void visit(PackageDeclaration n, Void arg) {
    //     analyzePackageDecl(n);
    //
    //     super.visit(n, arg);
    // }

    //
    //  import a.b.c.*
    //  import a.b.Class
    //  import static a.b.Class.symbol;
    //
    ////

    // ----------------------------------------------------------------------

    @Override
    public void visit(EnumDeclaration n, Void arg) {
        analyzeTypeDecl(n);

        super.visit(n, arg);

        popDecl();
    }

    @Override
    public void visit(ClassOrInterfaceDeclaration n, Void arg) {
        analyzeTypeDecl(n);

        super.visit(n, arg);

        popDecl();
    }

    @Override   /// new T[]
    public void visit(AnnotationDeclaration n, Void arg) {
        analyzeTypeDecl(n);

        super.visit(n, arg);

        popDecl();
    }

    // ----------------------------------------------------------------------

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   /// new T[]
    // public void visit(ArrayCreationExpr n, Void arg) {
    //     Type elementType = n.getElementType();
    //     usingType(elementType);
    //
    //     super.visit(n, arg);
    // }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   // cast  (T) ...
    // public void visit(CastExpr n, Void arg) {
    //     Type type = n.getType();
    //     usingType(type);
    //
    //     super.visit(n, arg);
    // }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   // T.class
    // public void visit(ClassExpr n, Void arg) {
    //     Type classType = n.getType();
    //     usingType(classType);
    //
    //     super.visit(n, arg);
    // }

    @Override   // la parte implements di class
    public void visit(ClassOrInterfaceType n, Void arg) {
        usingType(n);

        super.visit(n, arg);
    }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   //  dichiarazione di un metodo Result method(...)
    // public void visit(MethodDeclaration n, Void arg) {
    //     usingType(n.getType());
    //     n.getParameters().forEach(p -> usingType(p.getType()));
    //
    //
    //     super.visit(n, arg);
    // }

    @Override   // classe usata nell method call
    public void visit(NameExpr n, Void arg) {
        analyzeNameExpr(n);

        super.visit(n, arg);
    }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   // new Type
    // public void visit(ObjectCreationExpr n, Void arg) {
    //     Type type = n.getType();
    //     usingType(type);
    //
    //     super.visit(n, arg);
    // }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   // definizione di un parametro
    // public void visit(Parameter n, Void arg) {
    //     Type paramType = n.getType();
    //     usingType(paramType);
    //
    //     super.visit(n, arg);
    // }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   /// Type[n]
    // public void visit(ArrayType n, Void arg) {
    //     Type componentType = n.getComponentType();
    //     usingType(componentType);
    //
    //     super.visit(n, arg);
    // }

    //
    // NOT necessary, because T is intercepted by 'ClassOrInterfaceType'
    //
    // @Override   // la parte di assegmaneto
    // public void visit(VariableDeclarator n, Void arg) {
    //     Type varType = n.getType();
    //     usingType(varType);
    //
    //     super.visit(n, arg);
    // }

    // ----------------------------------------------------------------------
    // Analyzing
    // ----------------------------------------------------------------------
    // [CompilationUnit] package jdumper.stat;
    // [ImportDeclaration] import java.util.*;
    // [ImportDeclaration] import jpcap.packet.Packet;
    // [PackageDeclaration] package jdumper.stat;
    // [body.ClassOrInterfaceDeclaration] public class FreeMemStat extends JDStatisticsTaker { ^ ^    String[] labels = { "Free Memory" }; ^ ^...
    //

    private List<ClassOrInterfaceType> hierarchy = new ArrayList<>();

    private void registerHierarchy(ClassOrInterfaceType n) {
        hierarchy.add(n);
    }

    private boolean isHierarchy(ClassOrInterfaceType n) {
        for (ClassOrInterfaceType t : hierarchy)
            if (n == t)
                return true;
        return false;
    }

    private boolean isHierarchy(ImportDeclaration n) {
        if (n.isStatic()) return false;
        if (n.isAsterisk()) return false;

        String importedType = n.getNameAsString();
        for (ClassOrInterfaceType t : hierarchy)
            if (t.getNameAsString().equals(importedType))
                return true;
        return false;
    }

    // ----------------------------------------------------------------------

    private void analyzeTypeDecl(EnumDeclaration n) {
        RefType fromType = toRefType(n);
        analyzeInheritance(fromType, n);
        analyzeImports(fromType, n);

        this.fromTypeStack.push(fromType);
    }

    private void analyzeTypeDecl(ClassOrInterfaceDeclaration n) {
        RefType fromType = toRefType(n);
        analyzeInheritance(fromType, n);
        analyzeImports(fromType, n);

        this.fromTypeStack.push(fromType);
    }

    private void analyzeTypeDecl(AnnotationDeclaration n) {
        RefType fromType = toRefType(n);
        // analyzeInheritance(fromType, n);
        analyzeImports(fromType, n);

        this.fromTypeStack.push(fromType);
    }

    private void popDecl() {
        this.fromTypeStack.pop();
    }

    private void analyzeImports(RefType fromType, TypeDeclaration<?> n) {
        // cu.getImports().forEach(imp -> analyzeImport(fromType, imp));
        cu.findAll(ImportDeclaration.class)
            .stream()
            .filter(impdecl -> !isHierarchy(impdecl))
            .map(this::toRefType)
            .filter(Objects::nonNull)
            .forEach(toType -> createTypeDependency(fromType, toType, DEPENDS_ON));
    }

    private void analyzeInheritance(RefType fromType, ClassOrInterfaceDeclaration n) {
        n.getExtendedTypes()
            .stream()
            .peek(this::registerHierarchy)
            .map(this::toRefType)
            .filter(Objects::nonNull)
            .filter(toType -> !fromType.equals(toType))
            .forEach(toType -> createTypeDependency(fromType, toType, EXTENDS));

        n.getImplementedTypes()
            .stream()
            .peek(this::registerHierarchy)
            .map(this::toRefType)
            .filter(Objects::nonNull)
            .filter(toType -> !fromType.equals(toType))
            .forEach(toType -> createTypeDependency(fromType, toType, IMPLEMENTS));
    }

    private void analyzeInheritance(RefType fromType, EnumDeclaration n) {
        n.getImplementedTypes()
            .stream()
            .peek(this::registerHierarchy)
            .map(this::toRefType)
            .filter(Objects::nonNull)
            .filter(toType -> !fromType.equals(toType))
            .forEach(toType -> createTypeDependency(fromType, toType, IMPLEMENTS));
    }

    private void createTypeDependency(RefType fromType, RefType toType, String useType) {
        // toType is null for primitive types
        if (toType == null) return;
        datodg.createTypeNode(toType, module, params);
        datodg.createTypeDependency(fromType, toType, useType, module, params);
    }

    // ----------------------------------------------------------------------

    private void analyzeNameExpr(NameExpr n) {
        if (fromTypeStack.isEmpty())
            return;

        RefType fromType = fromTypeStack.peek();
        RefType toType = toRefType(n);
        createTypeDependency(fromType, toType, DEPENDS_ON);
    }

    private void usingType(Type type) {
        if (fromTypeStack.isEmpty())
            return;
        if (type.isClassOrInterfaceType() && isHierarchy(type.asClassOrInterfaceType()))
            return;

        RefType fromType = fromTypeStack.peek();
        RefType toType = toRefType(type);
        createTypeDependency(fromType, toType, DEPENDS_ON);
    }

}

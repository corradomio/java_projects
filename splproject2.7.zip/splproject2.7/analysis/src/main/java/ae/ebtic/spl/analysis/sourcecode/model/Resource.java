package ae.ebtic.spl.analysis.sourcecode.model;

import java.io.File;

public interface Resource extends IdNamed {

    // Name getName();

    String getPath();
    File   getFile();

    Module getModule();

    String getModuleId();

    String getDigest();

    String getMimeType();

}

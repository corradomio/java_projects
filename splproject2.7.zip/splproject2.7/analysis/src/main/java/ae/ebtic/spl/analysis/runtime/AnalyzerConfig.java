package ae.ebtic.spl.analysis.runtime;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.util.PathName;
import ae.ebtic.spl.analysis.util.AnalysisConfig;
import jext.graph.GraphDatabase;
import jext.util.Parameters;

import java.util.ArrayList;
import java.util.List;

public class AnalyzerConfig extends AnalysisConfig {

    private List<String> files = new ArrayList<>();
    private List<String> select = new ArrayList<>();
    private List<String> exclude = new ArrayList<>();
    private double test; // DEBUG

    // -- projectName

    public AnalyzerConfig setProjectName(Name projectName) {
        this.projectName = projectName;
        return this;
    }

    public AnalyzerConfig setProjectName(String repository, String projectName) {
        return setProjectName(new PathName(repository, projectName));
    }

    // -- properties

    public AnalyzerConfig setParameters(Parameters params) {
        if (params != null)
            this.parameters.putAll(params);
        return this;
    }

    // -- files

    public AnalyzerConfig setFiles(List<String> files) {
        if (files != null)
            this.files = files;
        return this;
    }

    public List<String> getFiles() {
        return files;
    }

    // -- selected/excluded

    public AnalyzerConfig setSelect(List<String> selected) {
        if (selected != null)
            this.select = selected;
        return this;
    }

    public List<String> getSelect() {
        return select;
    }

    public AnalyzerConfig setExclude(List<String> excluded) {
        if (excluded != null)
            this.exclude = excluded;
        return this;
    }

    public List<String> getExclude() {
        return exclude;
    }


    // -- debug

    public AnalyzerConfig setTest(double test) {
        this.test = test;
        return this;
    }

    public double getTest() {
        return this.test;
    }

    // -- graphdatabase

    public AnalyzerConfig setGraphDatabase(GraphDatabase graphdb) {
        this.graphdb = graphdb;
        return this;
    }

}

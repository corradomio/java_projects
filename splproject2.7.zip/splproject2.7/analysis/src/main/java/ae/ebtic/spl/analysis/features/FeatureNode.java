package ae.ebtic.spl.analysis.features;

import ae.ebtic.spl.analysis.components.Component;
import ae.ebtic.spl.analysis.components.ComponentNode;
import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.GraphNode;
import ae.ebtic.spl.analysis.sourcecode.model.Type;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class FeatureNode extends GraphNode implements Feature, GraphConstants {

    public static List<Feature> of(FeatureGraph fg, List<Map<String, Object>> nvlist) {
        return nvlist.stream()
            .map(nv -> FeatureNode.of(fg, nv))
            .collect(Collectors.toList());
    }

    public static FeatureNode of(FeatureGraph fg, Map<String, Object> nv) {
        if (nv == null) return null;
        return new FeatureNode(fg, nv);
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------
    /*
        Content of the map 'nv':

        $labels: List<String>   list of the graphdb labels (in general there is only 1 label)
        $id: String             id of the graphdb node
        $type: String           type of the node (the unique label)

        name: String            name of the component
        fullname: STring        full name of the component
        role: String            FROLE_*
        projectId: String       id of the owner's project
     */

    private FeatureGraph fg;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private FeatureNode(FeatureGraph fg, Map<String, Object> nv) {
        super(fg.getProjectGraphAccess(), nv);
        this.fg = fg;
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public long getCount() {
        Object value = nv.getOrDefault(COUNT, 0L);
        if (value instanceof Integer)
            return ((Integer)value).longValue();
        else
            return (Long) value;
    }

    @Override
    public double getComplexity(){
        return (Double) nv.getOrDefault(COMPLEXITY,0.0);
    }

    // -- Components

    @Override
    public String getComponentId() {
        return nv.get(COMPONENT_ID).toString();
    }

    @Override
    public List<Component> getComponents() {
        return fg.getFeatureComponents(getId());
    }

    // -- Types

    @Override
    public String getTypeId() {
        return nv.get(TYPE_ID).toString();
    }

    @Override
    public long getTypesCount() {
        return (Long)nv.getOrDefault(COUNT_TYPES, 0L);
    }

    // -- EntryPoint

    @Override
    public boolean isEntryPoint() {
        return (Boolean)nv.getOrDefault(ENTRY_POINT, Boolean.FALSE);
    }

    @Override
    public long[] getCountEntryPoints() {
        List<Long> counts = (List<Long>)nv.getOrDefault(COUNT_ENTRY_POINTS, null);
        if (counts == null)
            return null;
        return new long[] {
            counts.get(0),
            counts.get(1),
            counts.get(2)
        };
    }

    // ----------------------------------------------------------------------
    // Graph navigation
    // ----------------------------------------------------------------------

    @Override
    public List<Type> getTypes() {
        return fg.getFeatureTypes(getId());
    }

    public Set<ComponentNode> getComponentNodes() {
        return fg.getFeatureComponents(getId()).stream()
            .map(c -> (ComponentNode)c)
            .collect(Collectors.toSet());
    }

    public Set<TypeNode> getTypeNodes() {
        return fg.getFeatureTypes(getId()).stream()
            .map(t -> (TypeNode)t)
            .collect(Collectors.toSet());
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

package ae.ebtic.spl.analysis.dependencyv2;

import ae.ebtic.spl.analysis.dependencyv2.util.LogListener;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import jext.util.Parameters;

import java.util.ArrayList;
import java.util.List;

public class ListenableDependencyAnalyzer extends DependencyAnalyzer {
    
    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static DependencyAnalysis newAnalyzer(AnalyzerConfig config) throws Exception {
        ListenableDependencyAnalyzer analyzer = new ListenableDependencyAnalyzer(config);
        analyzer.initialize();
        return analyzer;
    }

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    // listeners
    protected Listeners listeners = new Listeners();
    private int nModules;
    private volatile boolean aborted;
    
    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected ListenableDependencyAnalyzer(AnalyzerConfig config) {
        super(config);
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    @Override
    public boolean isAborted() { return aborted; }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    @Override
    public void abort() { aborted = true; }

    @Override
    public void initialize() {
        super.initialize();

        nModules = project.getModules().size();
    }

    @Override
    public void analyze() {
        if (aborted) return;

        String label = String.format("DependencyAnalysis[%s]", project.getName().getFullName());

        listeners.addListener(new LogListener(logger));
        listeners.fireStart(label, 8);

        super.analyze();
    }

    // ----------------------------------------------------------------------

    private boolean isSkipped(String what) {
        return config.getParameters().getBoolean(what, false);
    }

    private boolean isSkipped(Source source) {
        return isSkipped("skip.sources")
            || isSkipped("skip.test.sources")
            && source.getName().getFullName().contains("test");
    }

    // ----------------------------------------------------------------------

    @Override
    protected Parameters createProjectStructure() {
        if (aborted) return Parameters.empty();

        return super.createProjectStructure();
    }

    // -- Module

    // @Override
    // protected void createModuleDependencies(Parameters params) {
    //     if (aborted) return;
    //
    //     listeners.fireBegin("createModuleDependencies", nModules);
    //     super.createModuleDependencies(params);
    // }

    // @Override
    // protected void createModuleDependencies(Module module, Parameters params) {
    //     if (aborted) return;
    //
    //     listeners.fireModule(module);
    //     super.createModuleDependencies(module, params);
    // }

    // @Override
    // protected void createModuleDependencies(Module module, Module dmodule, Parameters params) {
    //     if (aborted) return;
    //
    //     super.createModuleDependencies(module, dmodule, params);
    // }

    // -- Resources

    @Override
    protected void analyzeModuleResources(Parameters params) {
        if (aborted) return;

        listeners.fireBegin("analyzeModuleResources", nModules);
        super.analyzeModuleResources(params);
    }

    @Override
    protected void analyzeModuleResources(Module module, Parameters params) {
        if (aborted) return;

        listeners.fireModule(module);
        super.analyzeModuleResources(module, params);
    }

    @Override
    protected void createResourceDependency(Resource resource, Parameters params) {
        if (aborted) return;
        if (isSkipped("skip.resources")) return; // DEBUG

        listeners.fireResource(resource);
        super.createResourceDependency(resource, params);
    }

    @Override
    protected void createLibraryDependency(Module module, Library library, Parameters params) {
        if (aborted) return;
        if (isSkipped("skip.libraries")) return; // DEBUG

        listeners.fireLibrary(library);
        super.createLibraryDependency(module, library, params);
    }

    @Override
    protected void createSourceDependency(Source source, Parameters params) {
        if (aborted) return;
        if (isSkipped(source)) return; // DEBUG

        listeners.fireSource(source);
        super.createSourceDependency(source, params);
    }

    // --

    // @Override
    // protected void analyzeLibraryDependencies(Parameters params) {
    //     if (aborted) return;
    //     if (isSkipped("skip.library.dependencies")) return;
    //
    //     listeners.fireBegin("analyzeLibraryDependencies", nModules);
    //     super.analyzeLibraryDependencies(params);
    // }

    // @Override
    // protected void analyzeLibraryDependencies(Module module, Parameters params) {
    //     if (aborted) return;
    //
    //     listeners.fireModule(module);
    //     super.analyzeLibraryDependencies(module, params);
    // }

    // @Override
    // protected void createLibraryDependencies(Library library, Parameters params) {
    //     if (aborted) return;
    //
    //     listeners.fireLibrary(library);
    //     super.createLibraryDependencies(library, params);
    // }

    // @Override
    // protected void createLibraryDependency(Library library, Library dlibrary, Parameters params) {
    //     if (aborted) return;
    //     if (isSkipped("skip.libraries")) return;
    //
    //     super.createLibraryDependency(library, dlibrary, params);
    // }

    // ----------------------------------------------------------------------
    // analyzeTypeDefinitions
    // ----------------------------------------------------------------------

    @Override
    protected void createDefaultTypes(Parameters params) {
        if (aborted) return;

        listeners.fireBegin("createDefaultTypes", nModules);
        super.createDefaultTypes(params);
    }

    @Override
    protected void analyzeTypeDeclarations(Parameters params) {
        if (aborted) return;

        listeners.fireBegin("analyzeTypeDefinitions", nModules);
        super.analyzeTypeDeclarations(params);
    }

    @Override
    protected void analyzeTypeDeclarations(Module module, Parameters params) {
        if (aborted) return;

        listeners.fireModule(module);
        super.analyzeTypeDeclarations(module, params);
    }

    @Override
    protected void analyzeTypeDeclarations(Source source, Parameters params) {
        if (aborted) return;
        if (isSkipped(source)) return;

        listeners.fireSource(source);
        super.analyzeTypeDeclarations(source, params);
    }

    // ----------------------------------------------------------------------
    // analyzeTypeDependencies
    // ----------------------------------------------------------------------

    @Override
    protected void analyzeTypeDependencies(Parameters params) {
        if (aborted) return;
        if (isSkipped("skip.type.dependencies")) return;

        listeners.fireBegin("analyzeTypeDependencies", nModules);
        super.analyzeTypeDependencies(params);
    }

    @Override
    protected void analyzeTypeDependencies(Module module, Parameters params) {
        if (aborted) return;

        listeners.fireModule(module);
        super.analyzeTypeDependencies(module, params);
    }

    @Override
    protected void analyzeTypeDependencies(Source source, Parameters params) {
        if (aborted) return;
        if (isSkipped(source)) return;

        listeners.fireSource(source);
        super.analyzeTypeDependencies(source, params);
    }

    // ----------------------------------------------------------------------
    // analyzeMethodDeclarations
    // ----------------------------------------------------------------------

    protected void analyzeMethodDeclarations(Parameters params) {
        if (aborted) return;
        if (isSkipped("skip.methods")) return;

        listeners.fireBegin("analyzeMethodDefinitions", nModules);
        super.analyzeMethodDeclarations(params);
    }

    protected void analyzeMethodDeclarations(Module module, Parameters params) {
        if (aborted) return;

        listeners.fireModule(module);
        super.analyzeMethodDeclarations(module, params);
    }

    protected void analyzeMethodDeclarations(Source source, Parameters params) {
        if (aborted) return;
        if (isSkipped(source)) return;

        listeners.fireSource(source);
        super.analyzeMethodDeclarations(source, params);
    }

    // ----------------------------------------------------------------------
    // Method dependencies
    // ----------------------------------------------------------------------

    protected void analyzeMethodDependencies(Parameters params) {
        if (aborted) return;
        if (isSkipped("skip.methods")) return;

        listeners.fireBegin("analyzeMethodDependencies", nModules);
        super.analyzeMethodDependencies(params);
    }

    protected void analyzeMethodDependencies(Module module, Parameters params) {
        if (aborted) return;

        listeners.fireModule(module);
        super.analyzeMethodDependencies(module, params);
    }

    protected void analyzeMethodDependencies(Source source, Parameters params) {
        if (aborted) return;
        if (isSkipped(source)) return;

        listeners.fireSource(source);
        super.analyzeMethodDependencies(source, params);
    }

    // protected void finalizeAnalysis() {
    //     if (aborted) return;
    //
    //     listeners.fireBegin("finalizeAnalysis", 1);
    //     super.finalizeAnalysis();
    // }

    // ----------------------------------------------------------------------
    // Done
    // ----------------------------------------------------------------------

    @Override
    protected void analysisDone(boolean failed) {
        listeners.fireDone();

        super.analysisDone(failed);
    }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    private static class Listeners {

        protected List<AnalyzerListener> listeners;

        // ----------------------------------------------------------------------
        // Constructor
        // ----------------------------------------------------------------------

        Listeners() {
            this.listeners = new ArrayList<>();
        }

        // ----------------------------------------------------------------------
        // Add/remove listeners
        // ----------------------------------------------------------------------

        void addListener(AnalyzerListener l) {
            listeners.add(l);
        }

        // ----------------------------------------------------------------------
        // Fire events
        // ----------------------------------------------------------------------

        public void fireStart(String label, int nTasks) {
            listeners.forEach(l -> l.onStart(label, nTasks));
        }

        public void fireBegin(String label, int nSteps) {
            listeners.forEach(l -> l.onBegin(label, nSteps) );
        }

        public void fireDone(String label) {
            listeners.forEach(l -> l.onDone(label));
        }

        public void fireDone() {
            listeners.forEach(AnalyzerListener::onDone);
        }

        public void fireModule(Module module) {
            listeners.forEach(l -> l.onModule(module) );
        }

        public void fireLibrary(Library library) {
            listeners.forEach(l -> l.onLibrary(library) );
        }

        public void fireDependency(Module dependency) {
            listeners.forEach(l -> l.onDependency(dependency) );
        }

        public void fireSource(Source source) {
            listeners.forEach(l -> l.onSource(source) );
        }

        public void fireResource(Resource resource) {
            listeners.forEach(l -> l.onResource(resource) );
        }

        public void fireProject(Project project) {
            listeners.forEach(l -> l.onProject(project) );
        }

        public void fireNamespace(Name namespace) {
            listeners.forEach(l -> l.onNamespace(namespace) );
        }

        public void fireType(String typeName) {
            listeners.forEach(l -> l.onType(typeName) );
        }
    }

    public DependencyAnalyzer addListener(AnalyzerListener l) {
        listeners.addListener(l);
        return this;
    }

}

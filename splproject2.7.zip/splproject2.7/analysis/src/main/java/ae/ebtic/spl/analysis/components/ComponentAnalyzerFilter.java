package ae.ebtic.spl.analysis.components;

import ae.ebtic.spl.analysis.dependencies.TypeNode;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.model.Type;
import jext.jgrapht.Graphs;
import jext.util.PathUtils;

import java.util.Collections;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class ComponentAnalyzerFilter extends ComponentAnalyzer implements ComponentAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Factory methods
    // ----------------------------------------------------------------------

    public static ComponentAnalysis newAnalyzer(AnalyzerConfig config, List<String> filterKeywords) {
        ComponentAnalyzerFilter analyzer = new ComponentAnalyzerFilter(config, filterKeywords);
        analyzer.initialize();
        return analyzer;
    }


    // ----------------------------------------------------------------------
    // Private fields
    // ----------------------------------------------------------------------

    private ArrayList<String> filterKeywords;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    private ComponentAnalyzerFilter(AnalyzerConfig config, List<String> filterKeywords) {
        super(config);
        this.filterKeywords = (ArrayList<String>) filterKeywords.stream().map(r -> r.toLowerCase()).collect(Collectors.toList());
    }

    // ----------------------------------------------------------------------
    // Analysis Operations
    // ----------------------------------------------------------------------

    protected void deleteComponents(int depth) {

        Set<String> toRemove = Collections.emptySet();
        //check components to be filtered
        if(depth > 0) {
            ArrayList<Component> components = (ArrayList<Component>) cg.getComponents(depth, null);
            for (Component component : components) {
                ArrayList<Type> types = (ArrayList<Type>) component.getTypes().stream().filter(r -> r.getName().getFullName().equals(component.getName().getFullName())).collect(Collectors.toList());
                for (Type type : types) {
                    String path = type.getSource().getPath().toLowerCase();
                    if (checkFilterPath(path)) {
                        toRemove.add(component.getId());
                        break;
                    }
                }
            }
        }

        cg.deleteComponents(toRemove);
        Graphs.removeVertices(lcg, toRemove);
        logger.infof( "    [%d] filtered %d components", depth, toRemove.size());

        super.deleteComponents(depth);
    }

    private boolean checkFilterPath(String path){
        String parent = PathUtils.getParent(path).toLowerCase();
        for(String tPath: filterKeywords){
            if(parent.equals(tPath))
                return true;
        }
        return false;
    }




}

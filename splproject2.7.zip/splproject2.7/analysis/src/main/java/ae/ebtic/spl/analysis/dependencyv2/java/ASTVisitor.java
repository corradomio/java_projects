package ae.ebtic.spl.analysis.dependencyv2.java;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.dependencyv2.DAtoDG;
import ae.ebtic.spl.analysis.dependencyv2.DependencyAnalyzer;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.sourcecode.analyzer.ImplementedType;
import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import ae.ebtic.spl.analysis.sourcecode.model.TypeRole;
import ae.ebtic.spl.analysis.sourcecode.util.ObjectName;
import com.github.javaparser.ParseResult;
import com.github.javaparser.ast.CompilationUnit;
import com.github.javaparser.ast.ImportDeclaration;
import com.github.javaparser.ast.body.AnnotationDeclaration;
import com.github.javaparser.ast.body.ClassOrInterfaceDeclaration;
import com.github.javaparser.ast.body.EnumDeclaration;
import com.github.javaparser.ast.expr.NameExpr;
import com.github.javaparser.ast.type.Type;
import com.github.javaparser.resolution.UnsolvedSymbolException;
import com.github.javaparser.resolution.types.ResolvedType;
import jext.javaparser.JavaParserPool;
import jext.javaparser.analysis.BaseVisitorAdapter;
import jext.javaparser.symbolsolver.resolution.typesolvers.ContextTypeSolver;
import jext.javaparser.symbolsolver.resolution.typesolvers.JarFilesTypeSolver;
import jext.javaparser.util.ClassPoolRegistry;
import jext.javaparser.util.JPUtils;
import jext.logging.Logger;
import jext.util.HashSet;
import jext.lang.JavaUtils;
import jext.util.Parameters;

import java.io.File;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeSet;

public class ASTVisitor extends BaseVisitorAdapter implements GraphConstants {

    // ----------------------------------------------------------------------
    // Private Data
    // ----------------------------------------------------------------------

    protected Logger logger = Logger.getLogger(getClass());

    protected DependencyAnalyzer da;
    protected DAtoDG datodg;

    protected Project project;
    protected Module module;
    protected Source source;

    protected Parameters params;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ASTVisitor(DependencyAnalyzer da) {
        this.da = da;
    }

    // ----------------------------------------------------------------------
    // Analysis
    // ----------------------------------------------------------------------

    public void analyze(Source source, Parameters params) {
        this.source = source;
        this.module = source.getModule();
        this.project = source.getModule().getProject();

        this.logger = Logger.getLogger("%s.%s.%s",
            this.project.getName().getName(),
            this.module.getName().getName(),
            this.source.getName().getName());

        this.params = params;

        DependencyGraph dg = da.getDependencyGraph().clone();
        datodg = new DAtoDG(da, dg, source, params);

        File sourceFile = new File(source.getPath());
        JavaParserPool pool = da.getJavaParserPool(module);

        // DEBUG
        if (pool == null)
            pool = da.getJavaParserPool(module);

        try(DependencyGraph session = (DependencyGraph) dg.connect()) {
            ParseResult<CompilationUnit> result = pool.parse(sourceFile);
            Optional<CompilationUnit> optCu = result.getResult();

            if (!optCu.isPresent()) {
                result.getProblems().forEach(problem -> {
                    logger.error(problem);
                });
                return;
            }

            this.cu = optCu.get();
            analyze(cu);
        }
        catch (Throwable t) {
            logger.error(t, t);
        }
    }

    public ASTVisitor analyze(CompilationUnit cu) {
        super.analyze(cu);
        // super.visit(cu, null);
        return this;
    }

    // ----------------------------------------------------------------------
    // Compose TypeResolver
    // ----------------------------------------------------------------------

    protected ContextTypeSolver composeTypeSolver() {
        // if (cu == null)
        //     throw new IllegalStateException("CompilationUnit not set");

        ContextTypeSolver ts = new ContextTypeSolver(module.getName().getFullName());

        //
        // add the type solvers
        //
        // 1) current module
        // 2) dependency modules
        // 3) current libraries
        // 4) dependency module libraries? recursively? BOH
        // 5) jdk
        //

        //
        // 1) Modules
        //

        // 1.1) current module
        ts.add(da.getModuleTypeSolver(module));

        // 1.2) dependency modules
        module.getDependencies(true).forEach(dmodule -> {
            ts.add(da.getModuleTypeSolver(dmodule));
        });

        //
        // 2) Libraries
        //

        ClassPoolRegistry classPoolregistry = da.getClassPoolRegistry(module);

        //
        // 3) type solvers for jars
        //

        // 3.1) collect the jars
        JarFilesTypeSolver jfts = new JarFilesTypeSolver(module.getName().getName(), classPoolregistry);

        // 3.2) add the type solver
        ts.add(jfts);

        //
        // 4) done
        //
        return ts;
    }

    // ----------------------------------------------------------------------
    // RefType
    // ----------------------------------------------------------------------

    protected RefType toRefType(ImportDeclaration id) {
        String importedName;
        if (id.isAsterisk())
            return null;
        importedName = id.getNameAsString();
        if (id.isStatic())
            importedName = JavaUtils.namespaceOf(importedName);

        RefType refType = new ReferencedType(importedName);
        return refType;
    }

    protected RefType toRefType(ClassOrInterfaceDeclaration cid) {
        Optional<String> qname = cid.getFullyQualifiedName();
        if (!qname.isPresent())
            qname = JPUtils.getFullyQualifiedName(cid);

        Name name = qname.map(ObjectName::new).orElseGet(() -> new ObjectName(cid.getNameAsString()));
        TypeRole role = cid.isInterface() ? TypeRole.INTERFACE : TypeRole.CLASS;
        ImplementedType refType = new ImplementedType(name, role, source);
        refType.innerType = cid.isNestedType();
        refType.nParams = cid.getTypeParameters().size();
        return refType;
    }

    protected RefType toRefType(EnumDeclaration ed) {
        Optional<String> qname = ed.getFullyQualifiedName();
        if (!qname.isPresent())
            qname = JPUtils.getFullyQualifiedName(ed);

        Name name = qname.map(ObjectName::new).orElseGet(() -> new ObjectName(ed.getNameAsString()));
        ImplementedType refType = new ImplementedType(name, TypeRole.ENUM, source);
        refType.innerType = ed.isNestedType();
        refType.nParams = ed.getImplementedTypes().size();
        return refType;
    }

    protected RefType toRefType(AnnotationDeclaration ad) {
        Optional<String> qname = ad.getFullyQualifiedName();
        if (!qname.isPresent())
            qname = JPUtils.getFullyQualifiedName(ad);

        Name name = qname.map(ObjectName::new).orElseGet(() -> new ObjectName(ad.getNameAsString()));
        ImplementedType refType = new ImplementedType(name, TypeRole.ANNOTATION, source);
        refType.innerType = ad.isNestedType();
        refType.nParams = 0; // ??
        return refType;
    }

    // ----------------------------------------------------------------------

    protected RefType toRefType(Type type) {
        try {
            while (type.isArrayType())
                type = type.asArrayType().getComponentType();

            ResolvedType rt = ts.resolve(type);
            return toRefType(rt);
        }
        catch (UnsupportedOperationException e) {
            // the type is a type parameter with name 'T', 'O2', ... (we hope!!)
        }
        catch (UnsolvedSymbolException e) {
            // logger.error(e.getMessage());
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (Throwable t) { // strange error
            logger.error(t, t);
        }

        // unable to resolve the type
        return null;
    }

    // protected RefType toRefType(String typeName) {
    //     ReferencedType refType = new ReferencedType(typeName);
    //     return refType;
    // }

    protected RefType toRefType(NameExpr n) {
        try {
            ResolvedType rt = ts.resolve(n);
            return toRefType(rt);
        }
        catch (UnsupportedOperationException e) {
            da.logUnsolvedSymbol(logger, n.toString(), null);
        }
        catch (UnsolvedSymbolException e) {
            da.logUnsolvedSymbol(logger, e.getName(), null);
        }
        catch (Throwable t) { // strange error
            da.logUnsolvedSymbol(logger, n.toString(), null);
        }
        return null;
    }

    private RefType toRefType(ResolvedType rt) {
        if (rt == null)
            return null;
        else if (rt.isReferenceType())
            return new ReferencedType(rt.asReferenceType().getQualifiedName());
        else if (rt.isReference())
            ;
        else if (rt.isArray())
            ;
        else if (rt.isNull())
            ;
        else if (rt.isPrimitive())
            ;
        else if (rt.isTypeVariable())
            ;
        else if (rt.isUnionType())
            ;
        else if (rt.isVoid())
            ;
        else if (rt.isWildcard())
            ;
        else
            return new ReferencedType(rt.describe());
        return null;
    }

}

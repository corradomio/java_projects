package ae.ebtic.spl.analysis.dependencies.util;

import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Named;


public class LibrariesRegistry extends NameRegistry implements TypeRegistry {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    private static class Info {
        NameMap<String> typeMap = new NameMap<>();
    }

    // library name -> Info
    //private final Map<Name, Info> infoMap = Collections.synchronizedMap(new TreeMap<>());
    private final NameMap<Info> infoMap = new NameMap<>();

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public boolean isLibraryRegistered(Library library) {
        return super.isRegistered(library.getName());
    }

    public void registerLibrary(String libraryId, Library library) {
        Name libraryName = library.getName();
        super.register(libraryId, libraryName);
        infoMap.put(libraryName, new Info());
    }

    public String getLibraryId(Library library) {
        return super.getId(library.getName());
    }

    // --

    public void registerType(String typeId, Name typeName, Named library) {
        infoMap.get(library.getName()).typeMap.put(typeName, typeId);
    }

    public String getTypeId(Name typeName, Named library) {
        if (infoMap.get(library.getName()) == null)
            return null;
        return infoMap.get(library.getName()).typeMap.getOrDefault(typeName, null);
    }

    // ----------------------------------------------------------------------
    // Parallel Operations
    // ----------------------------------------------------------------------

    public String getTypeIdOrLock(Name typeName, Library library) {
        Name libraryName = library.getName();
        String typeId;
        lock(libraryName);
        typeId = getTypeId(typeName, library);
        if (typeId != null) {
            release(libraryName);
            return typeId;
        }
        return null;
    }

    public void registerTypeAndRelease(String typeId, Name typeName, Library library) {
        Name libraryName = library.getName();
        if (typeId != null)
            registerType(typeId, typeName, library);
        release(libraryName);
    }

    // ----------------------------------------------------------------------
    // New implementation
    // ----------------------------------------------------------------------
    // It is not possible to REUSE a type solver because it is member of a
    // hierarchy that has as root the current source code!

    // public TypeSolver getTypeSolver(Library library) {
    //
    //     TypeSolver typeSolver;
    //     switch(library.getLibraryType()) {
    //         case LOCAL_JAR:
    //             typeSolver = getJarTypeSolver((JarLibrary)library);
    //             break;
    //         case MAVEN:
    //         case MAVEN_COLLECTION:
    //             typeSolver = getMavenTypeSolver((MavenLibrary)library);
    //             break;
    //         case JAVA_JDK:
    //         case LOCAL_COLLECTION:
    //             typeSolver = getJdkTypeSolver((DirectoryLibrary)library);
    //             break;
    //         // case MODULE:
    //         //     typeSolver = getTypeSolver(((ModuleLibrary)library).get());
    //         //     break;
    //
    //         case INVALID:
    //         default:
    //             typeSolver = new InvalidTypeSolver(library.getName().getName());
    //             break;
    //     }
    //
    //     return typeSolver;
    // }
    //
    // private TypeSolver getJarTypeSolver(JarLibrary library) {
    //     return cptss.getTypeSolver(library.getName().getFullName(), library.getFile());
    // }
    //
    // private TypeSolver getMavenTypeSolver(MavenLibrary library) {
    //     return cptss.getTypeSolver(library.getName().getFullName(), library.getFiles());
    // }
    //
    // private TypeSolver getJdkTypeSolver(DirectoryLibrary library) {
    //     return cptss.getTypeSolver(library.getName().getFullName(), library.getFiles());
    // }

    // private TypeSolver getJarTypeSolver(JarLibrary library) {
    //     return newJarTypeSolver(library.getFile());
    // }
    //
    // private TypeSolver getMavenTypeSolver(MavenLibrary library) {
    //     List<File> files = library.getFiles();
    //     if (files.size() == 1)
    //         return newJarTypeSolver(files.get(0));
    //
    //     CombinedTypeSolver cts = new CombinedTypeSolver();
    //     files.forEach(jarFile -> cts.add(newJarTypeSolver(jarFile)));
    //     return cts;
    // }
    //
    // private TypeSolver newJarTypeSolver(File jarFile) {
    //     try {
    //         return new JarTypeSolver(jarFile);
    //     }
    //     catch (IOException e) {
    //         logger.error(e, e);
    //         return new InvalidTypeSolver(jarFile);
    //     }
    // }
    //
    // private TypeSolver getJdkTypeSolver(DirectoryLibrary library) {
    //     JDKTypeSolver jdkts = new JDKTypeSolver(library.getName().getName(), library.getFiles());
    //     return jdkts;
    // }

}

package ae.ebtic.spl.analysis.graph;

import ae.ebtic.spl.analysis.sourcecode.model.Name;
import jext.graph.GraphDatabase;
import jext.graph.GraphSession;
import jext.util.Parameters;
import jext.logging.Logger;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public abstract class ProjectModelGraph implements GraphConstants, AutoCloseable {

    // ----------------------------------------------------------------------
    // Private Fields
    // ----------------------------------------------------------------------

    // logger
    protected Logger logger = Logger.getLogger(getClass());

    // collector for all graph access types
    protected ProjectGraphAccess pga;

    // information to access the GraphDB
    protected GraphConfig config;

    /** connection to the Graph database */
    protected GraphDatabase graphdb;

    // MAIN node type used in the graph
    protected String nodeType;

    /** id of the current project */
    protected String projectId;

    /** id of the model node */
    protected String modelId;

    // in db model status
    protected String status = STATUS_NOT_EXISTENT;

    // in db model timestamp
    protected long timestamp = 0;

    // in db model status reason
    protected String reason;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    public ProjectModelGraph(ProjectGraphAccess pga, String nodeType) {
        this.pga = pga;
        this.config = pga.getConfig();
        this.nodeType = nodeType;
    }

    public void initialize() {
        setStatus(STATUS_CREATED, REASON_CREATE);

        graphdb = config.getGraphDatabase();
        checkModelId();
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------
    // exists(): if the model node (and the graph model) exists
    // create(): create the model node used as flag for the existence of the model
    // delete(): delete the model graph
    // setStatus(): set the status of the model graph in the model node
    //
    // getStatus() -> CREATED | TASK_RUNNING | VALID | INVALID
    // getReason() -> String
    // getTimestamp() -> long

    public boolean exists() {
        // the check is already done when this class is created!

        return modelId != null;

        // try(GraphSession session = graphdb.connect()) {
        //     String projectName = config.getProjectName().getName();
        //     String repository  = config.getProjectName().getParentName();
        //
        //     return session.queryNodes(nodeType, Parameters.params(
        //         NAME, projectName,
        //         REPOSITORY, repository
        //     )).exists();
        // }
    }


    public final String create() {
        return create(Parameters.empty());
    }

    public final String create(Parameters params) {
        if (modelId != null)
            return modelId;

        String fullname = config.getProjectName().getFullName();
        String name = config.getProjectName().getName();
        String repository = config.getProjectName().getParentName();

        // logger.infof("Create 'project component' %s", name);

        setStatus(STATUS_TASK_RUNNING, REASON_CREATE);

        Parameters nparams = Parameters.params(
            NAME, name,
            REPOSITORY, repository,
            FULLNAME, fullname,
            TYPE, PROJECT,
            ROLE, ROLE_PROJECT,
            STATUS, this.status,
            TIMESTAMP, this.timestamp
        ).add(params);

        try(GraphSession session = graphdb.connect()) {

            if (PROJECT.equals(nodeType)) {
                projectId = session.createNode(nodeType, nparams);

                modelId = projectId;
                session.setNodeProperty(projectId, PROJECT_ID, projectId);
            }
            else {
                nparams.setValue(PROJECT_ID, this.projectId);

                modelId = session.createNode(nodeType, nparams);
            }
        }
        return modelId;
    }

    public final void delete() {
        setStatus(STATUS_NOT_EXISTENT, REASON_DELETE);

        for(String projectId : findProjectIds()) {
            // for default it delete the model node
            deleteModelElements(projectId);
        }
        checkModelId();
    }

    public void setStatus(String status, String reason) {
        if (reason == null)
            reason = status;

        this.status = status;
        this.timestamp = System.currentTimeMillis();
        this.reason = reason;

        if (modelId != null)
        try(GraphSession session = graphdb.connect()) {
            session.setNodeProperties(modelId, Parameters.params(
                STATUS, status,
                TIMESTAMP, timestamp,
                REASON, reason
            ));
        }
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public ProjectGraphAccess getProjectGraphAccess() {
        return pga;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public String getStatus() {
        return status;
    }

    public String getReason() {
        return reason;
    }

    public String getProjectId() { return projectId; }

    public String getModelId() { return modelId; }

    public Name getProjectName() { return config.getProjectName(); }


    // ----------------------------------------------------------------------
    // Operations: setStatus
    // ----------------------------------------------------------------------

    // public void setNodeStatus(String nodeId, String status) {
    //     if (nodeId == null)
    //         return;
    //
    //     try(GraphSession session = graphdb.connect()) {
    //         session.setNodeProperty(nodeId, STATUS, status);
    //     }
    //
    // }

    // ----------------------------------------------------------------------
    // Operations: create
    // ----------------------------------------------------------------------

    // public String/*nodeId*/ createProjectNode() {
    //     create();
    //     return modelId;
    // }

    // ----------------------------------------------------------------------
    // Operations: delete
    // ----------------------------------------------------------------------

    protected void deleteModelElements(String projectId) {
        // delete the model node
        deleteModelElements(nodeType, projectId);
    }

    protected void deleteModelElements(String nodeType, String projectId) {

        try(GraphSession session = graphdb.connect()) {

            if (PROJECT.equals(nodeType)) {
                String projectName = config.getProjectName().getName();
                String repository  = config.getProjectName().getParentName();

                session.queryNodes(nodeType, Parameters.params(
                    NAME, projectName,
                    REPOSITORY, repository
                )).delete();

                session.queryNodes(nodeType, Parameters.params(
                    PROJECT_ID, projectId
                )).delete();
            }
            else {
                session.deleteNodes(nodeType, Parameters.params(
                    PROJECT_ID, projectId
                ));
            }
        }
    }

    // ----------------------------------------------------------------------
    // Connection operations
    // ----------------------------------------------------------------------
    // Note: REMOVED

    public ProjectModelGraph connect() {
        return this;
    }

    public void close() { }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private void checkModelId() {

        List<Map<String, Object>> nvlist;
        // node id's of the project
        List<String> projectIds;

        String projectName = config.getProjectName().getName();
        String repository  = config.getProjectName().getParentName();

        //
        // default values
        //
        projectId = null;
        modelId = null;
        status = STATUS_NOT_EXISTENT;
        timestamp = 0;
        reason = status;

        // check the db
        try(GraphSession session = graphdb.connect()) {

            // 1) check the node for the current model;

            nvlist = session.queryNodes(nodeType, Parameters.params(
                NAME, projectName,
                REPOSITORY, repository
            )).allValues().toList();

            if (nvlist.size() > 0) {
                Map<String, Object> nv = nvlist.get(0);
                modelId = nv.get(GRAPH_NODE_ID).toString();
                projectId = (String)nv.get(PROJECT_ID);

                status = (String)nv.getOrDefault(STATUS, STATUS_INVALID);
                timestamp = (Long)nv.getOrDefault(TIMESTAMP, 0L);
                reason = (String)nv.getOrDefault(REASON, status);

                // ERROR: more of a node for the same model
                if (nvlist.size() > 1)
                    logger.errorf("Multiple %s with the same name '%s/%s'", nodeType, repository, projectName);

                return;
            }

            // ok, the model doesn't exist.
            // Find the projectId from the node 'project'

            projectIds = session.queryNodes(PROJECT, Parameters.params(
                NAME, projectName,
                REPOSITORY, repository
            )).ids().toList();

            if (projectIds.size() > 0) {
                projectId = projectIds.get(0);

                // ERROR: more of a node for the same project
                if (projectIds.size() > 1)
                    logger.errorf("Multiple %s with the same name '%s/%s'", PROJECT, repository, projectName);
            }
        }
    }

    // /**
    //  * Retrieve the projectId from the Dependency Model
    //  */
    // protected void checkModelId() {
    //
    //     if (projectId != null && modelId != null)
    //         return;
    //
    //     List<String> projectIds = findProjectIds();
    //     if (projectIds.size() == 0)
    //         return;
    //
    //     projectId = projectIds.get(0);
    //
    //     retrieveStatus();
    // }

    // protected void retrieveStatus() {
    //     timestamp = 0;
    //     status = STATUS_NOT_EXISTENT;
    //
    //     try(GraphSession session = graphdb.connect()) {
    //         Map<String, Object> values = session.queryNodes(nodeType, Parameters.params(
    //             PROJECT_ID, projectId,
    //             TYPE, PROJECT
    //         )).values();
    //
    //         if (values == null)
    //             return;
    //
    //         timestamp = (Long)values.getOrDefault(TIMESTAMP, 0);
    //         status = values.getOrDefault(STATUS, STATUS_NOT_EXISTENT).toString();
    //     }
    // }

    protected List<String> findProjectIds() {
        // node id's of the model
        List<Map<String, Object>> nvlist;
        // node id's of the project
        List<String> projectIds;

        try(GraphSession session = graphdb.connect()) {

            String projectName = config.getProjectName().getName();
            String repository = config.getProjectName().getParentName();

            //
            // check if there are projects with the specified repository/name
            // for the current graph type
            //
            // otherwise, check if there are projects with the same repository/name
            // between the nodes of type "project"
            //

            // retrieve the 'projectId' from node 'project'
            projectIds = session.queryNodes(PROJECT, Parameters.params(
                NAME, projectName,
                REPOSITORY, repository
            )).ids().toList();
            if (!projectIds.isEmpty())
                return projectIds;

            // retrieve the 'projectId' from the current model
            nvlist = session.queryNodes(nodeType, Parameters.params(
                NAME, projectName,
                REPOSITORY, repository
            )).allValues().toList();

            return nvlist.stream()
                .map(nv -> nv.get(PROJECT_ID).toString())
                .collect(Collectors.toList());
        }
    }

    // ----------------------------------------------------------------------
    // Utilities
    // ----------------------------------------------------------------------

    //TODO: Refactor into analysis supportive graph model

    public Map<String, Object> getProjectGraph(boolean limit) {

        //  List<String> roles = new ArrayList<>();
        int MaxNodes = 300;
        List<Map<String, Object>> nvlist;
        List<Map<String, Object>> elist = new ArrayList<>();
        String labels[] = new String[] {COMPONENT,TYPE};
        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);

            nvlist = session.queryUsing("findProjectGraph", params)
                    .distinct().allValues().toList();

            if(limit && nvlist.size() > MaxNodes){
                //params.put(DEPTH, 2);
                nvlist = session.queryUsing("getFeatureTypesCount",params).result().toList();

                int limitSize = 10;
                if(limitSize > nvlist.size()) limitSize /= 4;

                List<Integer> FeatIDs = nvlist.subList(0, limitSize).stream()
                        .mapToInt(r -> Integer.parseInt(r.get(ID).toString()))
                        .boxed()
                        .collect(Collectors.toList());

                return getProjectGraph(FeatIDs);
            }

            List<Map<String, Object>> tempEList = session.queryUsing("findEdgesBetweenFeatureAndDepthOne",params).result().toList();

            elist.addAll(tempEList);

            List<Integer> comp1IDs = getComponentDepthOneIDs(nvlist);

            params.put(ID,comp1IDs);

            tempEList = session.queryUsing("findEdgesBetweenComponentsAndTypes",params).result().toList();

            elist.addAll(tempEList);

            //get modules
            params.remove_(ID);
            List<Map<String,Object>> moduleList = session.queryUsing("getTypeModules",params).result().toList();
            nvlist = addModuleToTypes(nvlist,moduleList);

        }

        Map<String, Object> graph = generateFinalGraph(nvlist, elist);

        return graph;


    }

    public Map<String, Object> getProjectGraph(List<Integer> FeatureIds) {

        //  List<String> roles = new ArrayList<>();
        List<Map<String, Object>> nvlist = new ArrayList<>();
        List<Map<String, Object>> elist = new ArrayList<>();
        String labels[] = new String[] {COMPONENT,TYPE};
        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);

            //GET COMPONENTS LEVEL 2 aka FEATURES
            params.put(ID,FeatureIds);
            List<Map<String, Object>> tempNList = session.queryUsing("findFeaturesWithIDs",params).distinct().allValues().toList();
            nvlist.addAll(tempNList);

            //GET COMPONENTS LEVEL 1
            tempNList = session.queryUsing("findComponentsConnectedtoFeaturesWithIDs",params).distinct().allValues().toList();
            nvlist.addAll(tempNList);

            //GET EDGES BETWEEN COMPONENTS
            List<Map<String, Object>> tempEList = session.queryUsing("findEdgesBetweenFeatureAndDepthOneWithIDs",params).result().toList();
            elist.addAll(tempEList);

            //GET TYPES
            List<Integer> comp1IDs = getComponentDepthOneIDs(nvlist);

            params.put(ID,comp1IDs);
            tempNList = session.queryUsing("findTypesFromComponentsWithIDs",params).distinct().allValues().toList();
            nvlist.addAll(tempNList);

            //GET EDGES BETWEEN COMPONENTS AND TYPES
            tempEList = session.queryUsing("findEdgesBetweenComponentsAndTypes",params).result().toList();
            elist.addAll(tempEList);

            //GET MODULES
            List<Integer> typeIDs =  tempNList.stream()
                    .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                    .boxed()
                    .collect(Collectors.toList());
            params.put(ID,typeIDs);
            List<Map<String,Object>> moduleList = session.queryUsing("getTypeModulesWithIDs",params).result().toList();

            //ADD MODULES TO TYPE NODES
            nvlist = addModuleToTypes(nvlist,moduleList);
        }


        Map<String, Object> graph = generateFinalGraph(nvlist, elist);

        return graph;


    }


    List<Map<String, Object>> addModuleToTypes(List<Map<String, Object>> nvlist, List<Map<String, Object>> moduleList){
        return nvlist.stream().map(r -> {
            List<Map<String,Object>> tempList = moduleList.stream()
                    .filter(m -> m.get(NAME) != null && m.get(ID).toString().equals(r.get(GRAPH_NODE_ID).toString())).collect(Collectors.toList());
            if(tempList.size()>0){
                r.put(MODULE,tempList.get(0).get(NAME));
            }
            return r;
        }).collect(Collectors.toList());
    }

    List<Integer> getComponentDepthOneIDs(List<Map<String, Object>> nvlist){
       return nvlist.stream()
                .filter(r -> (r.get(GRAPH_NODE_TYPE).equals(COMPONENT) && r.get("depth").toString().equals("1")))
                .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                .boxed()
                .collect(Collectors.toList());
    }

    Map<String, Object> generateFinalGraph(List<Map<String, Object>> nvlist, List<Map<String, Object>> elist){

        long maxID = nvlist.stream().mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString())).max().orElse(0);
        maxID = Math.max(maxID, Long.parseLong(projectId));

        Map<String, Object> projectNode = new HashMap<>();
        projectNode.put(ID,Long.parseLong(projectId));
        projectNode.put(NAME, getProjectName().getName());

        Map<String, Object> componentTwoParent = new HashMap<>();
        componentTwoParent.put(ID,++maxID);
        componentTwoParent.put(NAME, COMPONENT+2+"Parent");
        componentTwoParent.put("parent", Long.parseLong(projectId));

        Map<String, Object> componentOneParentOneNode = new HashMap<>();
        componentOneParentOneNode.put(ID,++maxID);
        componentOneParentOneNode.put(NAME, COMPONENT+1+"Parent1");
        componentOneParentOneNode.put("parent", Long.parseLong(projectNode.get(ID).toString()));

        Map<String, Object> componentOneParentTwoNode = new HashMap<>();
        componentOneParentTwoNode.put(ID,++maxID);
        componentOneParentTwoNode.put(NAME, COMPONENT+1+"Parent2");
        componentOneParentTwoNode.put("parent", Long.parseLong(componentOneParentOneNode.get(ID).toString()));

        Map<String, Object> componentOneNode = new HashMap<>();
        componentOneNode.put(ID,++maxID);
        componentOneNode.put(NAME, COMPONENT+1);
        componentOneNode.put("parent", Long.parseLong(componentOneParentTwoNode.get(ID).toString()));

        Map<String, Object> typeParentOneNode = new HashMap<>();
        typeParentOneNode.put(ID,++maxID);
        typeParentOneNode.put(NAME, TYPE+"Parent1");
        typeParentOneNode.put("parent", projectNode.get(ID).toString());

        Map<String, Object> typeParentTwoNode = new HashMap<>();
        typeParentTwoNode.put(ID,++maxID);
        typeParentTwoNode.put(NAME, TYPE+"Parent2");
        typeParentTwoNode.put("parent", Long.parseLong(typeParentOneNode.get(ID).toString()));

        Map<String, Object> typeParentThreeNode = new HashMap<>();
        typeParentThreeNode.put(ID,++maxID);
        typeParentThreeNode.put(NAME, TYPE+"Parent3");
        typeParentThreeNode.put("parent", Long.parseLong(typeParentTwoNode.get(ID).toString()));

        Map<String, Object> typeNode = new HashMap<>();
        typeNode.put(ID,++maxID);
        typeNode.put(NAME, TYPE);
        typeNode.put("parent", Long.parseLong(componentTwoParent.get(ID).toString()));

        Map<String, Object> componentTwoNode = new HashMap<>();
        componentTwoNode.put(ID,++maxID);
        componentTwoNode.put(NAME, COMPONENT+2);
        componentTwoNode.put("parent", Long.parseLong(typeParentThreeNode.get(ID).toString()));


        List<Map<String, Object>> isInterfaceList = getIsInterfaceorExtended();


        List<Map<String, Object>> nodes = nvlist
                .stream()
                .map(r -> {
                    Map<String, Object> tempIsInterface = isInterfaceList.stream()
                                                         .filter(i -> i.get(FULLNAME).toString().equals(r.get(FULLNAME).toString()))
                                                         .findFirst()
                                                         .orElse(null);
                    boolean isInterface = false;
                    boolean isExtended = false;
                    if(tempIsInterface != null){
                        isInterface = Boolean.parseBoolean(tempIsInterface.get(ISINTERFACE).toString());
                        isExtended = Boolean.parseBoolean(tempIsInterface.get(ISEXTENDED).toString());
                    }

                    jext.util.HashMap<String, Object> n = new jext.util.HashMap<String, Object>()
                            .put_(ID, Long.parseLong(r.get(GRAPH_NODE_ID).toString()))
                            .put_(NAME, r.get(NAME))
                            .put_(ROLE, r.get(GRAPH_NODE_TYPE) + "-" + r.get(ROLE))
                            .put_(NAMESPACE, r.get(NAMESPACE))
                            .put_(ISINTERFACE, isInterface)
                            .put_(ISEXTENDED,isExtended)
                            .put_(SCORE, r.get(SCORE));

                    if(r.containsKey("compid"))
                        n.put_("compid",r.get("compid"));

                    if(r.containsKey("featid"))
                        n.put_("featid",r.get("featid"));

                    if(r.get(GRAPH_NODE_TYPE).equals(FEATURE)){
                        n.put_("parent", Long.parseLong(componentTwoNode.get(ID).toString()));
                    }
                    else if(r.get(GRAPH_NODE_TYPE).equals(COMPONENT)){
                        if( Integer.parseInt(r.get("depth").toString()) == 2) {
                            n.put_("parent", Long.parseLong(componentTwoNode.get(ID).toString()));
                        }
                        else {
                            n.put_("parent", Long.parseLong(componentOneNode.get(ID).toString()));
                        }
                    }
                    else {
                        n.put_("parent", Long.parseLong(typeNode.get(ID).toString()));
                        n.put_(MODULE, r.get(MODULE));
                    }

                    return n;
                })
                .collect(Collectors.toList());

        nodes.add(projectNode);
        nodes.add(componentTwoNode);
        nodes.add(componentOneNode);
        nodes.add(typeNode);
        nodes.add(componentOneParentOneNode);
        nodes.add(componentOneParentTwoNode);
        nodes.add(typeParentOneNode);
        nodes.add(componentTwoParent);
        nodes.add(typeParentTwoNode);
        nodes.add(typeParentThreeNode);


        List<Map<String, Object>> edges = elist
                .stream()
                .map(r -> {
                    return new jext.util.HashMap<String, Object>()
                            .put_(SOURCE, r.get("idfrom"))
                            .put_(EDGE_TARGET, r.get("idto"))
                            .put_(USES, r.get(USES))
                            .put_(ID,r.get("idfrom")+"_"+r.get("idto"));
                })
                .collect(Collectors.toList());

        jext.util.HashMap<String, Object> graph = new jext.util.HashMap<>();
        graph.put_(GRAPH_NODES, nodes)
                .put_(GRAPH_EDGES,edges);


        return graph;
    }

    public List<Map<String, Object>> getIsInterfaceorExtended(){
        List<Map<String, Object>> isInterfaceList = null;

        try (GraphSession session = graphdb.connect()){
            isInterfaceList = session.queryUsing("getIsInterfaceOrExtended", Parameters.params(
                    PROJECT_ID, projectId
            )).result().toList();
        }

        return isInterfaceList;
    }

    public Map<String, Object> getModulesWithTypes(){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);
            graph = session.queryUsing("getModulesWTypes", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> findModulesIP(Map<String, Integer> ids){
        List<Map<String, Object>> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID+1, ids.get(ID+1),
                    ID+2, ids.get(ID+2));
            graph = session.queryUsing("findModulesIP", params).result().toList();
        }

        return new jext.util.HashMap<String, Object>().put_(GRAPH, graph);
    }

    public Map<String, Object> getModelsSize(){
        Map<String, Object> graph;

        try (GraphSession session = graphdb.connect()) {
            Parameters params = Parameters.params(
                    PROJECT_ID, projectId);
            graph = session.queryUsing("getModelsSize", params).result().toList().get(0);
        }

        return graph;
    }


    public Map<String, Object> getProjectGraphTypes(boolean limit) {

        int maxNodes = 300;
        List<Map<String, Object>> nvlist;
        List<Map<String, Object>> elist;
        boolean hasLimit = false;
        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params   (
                    PROJECT_ID, projectId,
                    TYPE,TYPE);

            nvlist = session.queryNodes(TYPE,params).distinct().allValues().toList();

            if(limit && nvlist.size() > maxNodes){
                hasLimit = true;
                nvlist = nvlist.subList(0,maxNodes);
            }

            params = Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH,1);
            List<Map<String, Object>> compList = session.queryNodes(COMPONENT,params).distinct().allValues().toList();


            nvlist = nvlist.stream().map(r -> {
                List<Map<String,Object>> tempList = compList.stream()
                        .filter(m -> m.get(FULLNAME) != null && m.get(FULLNAME).toString().equals(r.get(FULLNAME).toString())).collect(Collectors.toList());
                if(tempList.size()>0){
                    r.put(ROLE,tempList.get(0).get(ROLE));
                    r.put(GRAPH_NODE_TYPE,tempList.get(0).get(GRAPH_NODE_TYPE));
                    r.put(DEPTH,1);
                    r.put("compid",tempList.get(0).get(GRAPH_NODE_ID));
                }
                return r;
            }).collect(Collectors.toList());


            params = Parameters.params(
                    PROJECT_ID, projectId);
            List<Map<String, Object>> featureList = session.queryNodes(FEATURE,params).distinct().allValues().toList();


            nvlist = nvlist.stream().map(r -> {
                List<Map<String,Object>> tempList = featureList.stream()
                        .filter(m -> m.get(FULLNAME) != null && m.get(FULLNAME).toString().equals(r.get(FULLNAME).toString())).collect(Collectors.toList());
                if(tempList.size()>0){
                    r.put(ROLE,tempList.get(0).get(ROLE));
                    r.put(GRAPH_NODE_TYPE,tempList.get(0).get(GRAPH_NODE_TYPE));
                    r.put("featid",tempList.get(0).get(GRAPH_NODE_ID));
                }
                return r;
            }).collect(Collectors.toList());

            List<Map<String,Object>> moduleList = session.queryUsing("getTypeModules",params).result().toList();
            nvlist = addModuleToTypes(nvlist,moduleList);

            params = Parameters.params(
                    PROJECT_ID, projectId,
                    TYPE, TYPE);


            elist = session.queryEdges(USES,TYPE,params,TYPE,params,Parameters.empty()).result().toList();

            if(hasLimit) {
                List<Integer> IDs = nvlist.stream()
                        .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                        .boxed()
                        .collect(Collectors.toList());
                elist = elist.stream().filter(r -> IDs.contains(Integer.parseInt(r.get(EDGE_FROM).toString())) && IDs.contains(Integer.parseInt(r.get(EDGE_TO).toString())))
                        .collect(Collectors.toList());
            }
        }

        Map<String, Object> graph = generateFinalGraph(nvlist, elist);

        return graph;
    }

    public Map<String, Object> getProjectGraphTypes(List<Integer> FeatureIds) {

        List<Map<String, Object>> nvlist;
        List<Map<String, Object>> elist;
        try(GraphSession session = graphdb.connect()) {

            Parameters params = Parameters.params(
                    PROJECT_ID, projectId,
                    ID,FeatureIds);

            nvlist = session.queryUsing("findTypesFromFeaturesWithIDs",params).distinct().allValues().toList();


            params = Parameters.params(
                    PROJECT_ID, projectId,
                    DEPTH,1);
            List<Map<String, Object>> compList = session.queryNodes(COMPONENT,params).distinct().allValues().toList();


            nvlist = nvlist.stream().map(r -> {
                List<Map<String,Object>> tempList = compList.stream()
                        .filter(m -> m.get(FULLNAME) != null && m.get(FULLNAME).toString().equals(r.get(FULLNAME).toString())).collect(Collectors.toList());
                if(tempList.size()>0){
                    r.put(ROLE,tempList.get(0).get(ROLE));
                    r.put(GRAPH_NODE_TYPE,tempList.get(0).get(GRAPH_NODE_TYPE));
                    r.put(DEPTH,1);
                    r.put("compid",tempList.get(0).get(GRAPH_NODE_ID));
                }
                return r;
            }).collect(Collectors.toList());


            params = Parameters.params(
                    PROJECT_ID, projectId);
            List<Map<String, Object>> featureList = session.queryNodes(FEATURE,params).distinct().allValues().toList();


            nvlist = nvlist.stream().map(r -> {
                List<Map<String,Object>> tempList = featureList.stream()
                        .filter(m -> m.get(FULLNAME) != null && m.get(FULLNAME).toString().equals(r.get(FULLNAME).toString())).collect(Collectors.toList());
                if(tempList.size()>0){
                    r.put(ROLE,tempList.get(0).get(ROLE));
                    r.put(GRAPH_NODE_TYPE,tempList.get(0).get(GRAPH_NODE_TYPE));
                    r.put("featid",tempList.get(0).get(GRAPH_NODE_ID));
                }
                return r;
            }).collect(Collectors.toList());

            List<Map<String,Object>> moduleList = session.queryUsing("getTypeModules",params).result().toList();
            nvlist = addModuleToTypes(nvlist,moduleList);

            params = Parameters.params(
                    PROJECT_ID, projectId,
                    TYPE, TYPE);


            elist = session.queryEdges(USES,TYPE,params,TYPE,params,Parameters.empty()).result().toList();

            List<Integer> IDs = nvlist.stream()
                    .mapToInt(r -> Integer.parseInt(r.get(GRAPH_NODE_ID).toString()))
                    .boxed()
                    .collect(Collectors.toList());

            elist = elist.stream().filter(r -> IDs.contains(Integer.parseInt(r.get(EDGE_FROM).toString())) && IDs.contains(Integer.parseInt(r.get(EDGE_TO).toString())))
                    .collect(Collectors.toList());
        }

        Map<String, Object> graph = generateFinalGraph(nvlist, elist);

        return graph;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

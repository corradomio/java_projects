package ae.ebtic.spl.analysis.dependencyv2;

import ae.ebtic.spl.analysis.dependencies.DependencyGraph;
import ae.ebtic.spl.analysis.dependencies.util.LibrariesRegistry;
import ae.ebtic.spl.analysis.dependencies.util.ModulesRegistry;
import ae.ebtic.spl.analysis.dependencies.util.NamespacesRegistry;
import ae.ebtic.spl.analysis.dependencyv2.java.ASTVMethodCalls;
import ae.ebtic.spl.analysis.dependencyv2.java.ASTMethodDeclarations;
import ae.ebtic.spl.analysis.dependencyv2.java.ASTMethodDependencies;
import ae.ebtic.spl.analysis.dependencyv2.java.ASTTypeDeclarations;
import ae.ebtic.spl.analysis.dependencyv2.java.ASTVTypeDependencies;
import ae.ebtic.spl.analysis.dependencyv2.util.ParallelizeAnalysis;
import ae.ebtic.spl.analysis.dependencyv2.util.UnresolvedSymbolsLibrary;
import ae.ebtic.spl.analysis.graph.GraphConfig;
import ae.ebtic.spl.analysis.graph.GraphConstants;
import ae.ebtic.spl.analysis.graph.ProjectGraphAccess;
import ae.ebtic.spl.analysis.sourcecode.analyzer.ReferencedType;
import ae.ebtic.spl.analysis.sourcecode.analyzerv2.Projects;
import ae.ebtic.spl.analysis.sourcecode.model.Library;
import ae.ebtic.spl.analysis.sourcecode.model.LibraryFinder;
import ae.ebtic.spl.analysis.sourcecode.model.Module;
import ae.ebtic.spl.analysis.sourcecode.model.Name;
import ae.ebtic.spl.analysis.sourcecode.model.Project;
import ae.ebtic.spl.analysis.sourcecode.model.RefType;
import ae.ebtic.spl.analysis.sourcecode.model.Resource;
import ae.ebtic.spl.analysis.sourcecode.model.Source;
import com.github.javaparser.symbolsolver.javaparsermodel.JavaParserFacade;
import com.github.javaparser.symbolsolver.model.resolution.TypeSolver;
import jext.cache.CacheManager;
import jext.javaparser.JavaParserPool;
import jext.javaparser.util.ClassPoolRegistry;
import jext.lang.JavaUtils;
import jext.logging.Logger;
import jext.nio.file.WildcardFileFilter;
import jext.util.ConcurrentHashSet;
import jext.util.Parameters;
import jext.util.SetUtils;

import java.io.File;
import java.util.Set;

public class DependencyAnalyzer implements DependencyAnalysis, GraphConstants {

    // ----------------------------------------------------------------------
    // Package/Protected/Private fields
    // ----------------------------------------------------------------------

    // logger (used by "DAtoDG")
    Logger logger;

    // configuration
    protected AnalyzerConfig config;

    // project on the filesystem
    protected Project project;

    // handle the component graph
    private DependencyGraph dg;

    // DependencyAnalyzer to DependencyGraph
    // used to access the graphdb
    private DAtoDG datodg;

    // Project Library Finder used to resolve external libraries
    private LibraryFinder lfinder;

    // id of the project node in the graphdb
    // private String projectId;

    // Filters to exclude some files from the analysis
    // (wildcards or regular expression)
    private WildcardFileFilter pathFilter;

    //
    // Used by ASTAnalyzer classes
    //

    // jdk version
    public Library runtimeLibrary;

    // list of full qualified symbols not resolved for some
    // reason
    UnresolvedSymbolsLibrary unresolvedLibrary;

    // module -> id
    //    module type   -> id
    //    module method -> id
    //    module source -> id
    ModulesRegistry modulesRegistry = new ModulesRegistry();

    // library -> id
    //    library type -> id
    LibrariesRegistry librariesRegistry = new LibrariesRegistry();

    // namespace -> id
    NamespacesRegistry namespacesRegistry = new NamespacesRegistry();

    //
    // Used to avoid multiple logs on the same symbol
    //

    Set<String> unresolvedTypes = new ConcurrentHashSet<>();

    //
    // ClassPoolRegistry
    //
    private Module classPoolModule;
    private ClassPoolRegistry classPoolRegistry;

    // ----------------------------------------------------------------------
    // Constructor
    // ----------------------------------------------------------------------

    protected DependencyAnalyzer(AnalyzerConfig config) {
        this.config = config;
    }

    protected void initialize() {

        File projectRoot = this.config.getProjectRoot();
        Parameters params = this.config.getParameters();
        Name projectName = this.config.getProjectName();

        logger = Logger.getLogger(getClass(), projectName.getFullName());

        GraphConfig config = new GraphConfig()
            .setGraphDatabase(this.config.getGraphDatabase())
            .setProjectName(this.config.getProjectName())
            .setParameters(this.config.getParameters());

        dg = ProjectGraphAccess.newProjectGraphAccess(config).getDependencyGraph();

        project = Projects.newProject(projectName, projectRoot, params.toProperties());

        // create a library finder specific for this project
        lfinder = this.config.getLibraryFinder();
        // add extra configuration saved in the project configuration
        lfinder.configure(params);

        // assign the library finder to this project
        project.setLibraryFinder(lfinder);

        // project jdk library
        runtimeLibrary = project.getRuntimeLibrary();

        // library used to aggregate the 'unresolved' symbols
        unresolvedLibrary = new UnresolvedSymbolsLibrary(null);

        // filter used to select the files to analyze
        composeFilesFilter();

        // Initialzie the parser pool
        JavaParserFacade.clearInstances();
    }

    private void composeFilesFilter() {
        pathFilter = new WildcardFileFilter();

        // initialize the pathFilters

        if (this.config.getPathFilters() != null)
            this.config.getPathFilters()
                .forEach(pattern -> {
                    pathFilter.addPattern(pattern);
                });

        for (String key : this.config.getParameters().keySet()) {
            if (key.startsWith("exclude")) {
                String pattern = this.config.getParameters().getString(key);
                pathFilter.addPattern(pattern);
            }
        }
    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public Project getProject() {
        return project;
    }

    public Library getRuntimeLibrary() {
        return runtimeLibrary;
    }

    public DependencyGraph getDependencyGraph() {
        return dg;
    }

    public LibraryFinder getLibraryFinder() { return lfinder; }

    public TypeSolver getModuleTypeSolver(Module module) {
        return modulesRegistry.getTypeSolver(module);
    }

    public synchronized ClassPoolRegistry getClassPoolRegistry(Module module) {
        if (module == classPoolModule)
            return classPoolRegistry;

        classPoolModule = module;
        classPoolRegistry = new ClassPoolRegistry();

        //
        // 2) Libraries
        //

        // 2.1) jdk library
        classPoolRegistry.addAll(getRuntimeLibrary().getFiles());

        // 2.2) current module libraries
        module.getLibraries().forEach(library -> {
            classPoolRegistry.addAll(library.getFiles());
        });

        // 2.3) dependency modules libraries
        module.getDependencies(true).forEach(dmodule -> {
            dmodule.getLibraries().forEach(library -> {
                classPoolRegistry.addAll(library.getFiles());
            });
        });

        return classPoolRegistry;
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void abort() { }

    public boolean isAborted() { return false; }

    /**
     * Delete the dependency model
     */
    public void delete() {
        dg.delete();
    }

    // ----------------------------------------------------------------------
    // Operations
    // ----------------------------------------------------------------------

    public void analyze() {

        boolean failed = false;

        try (DependencyGraph dg = (DependencyGraph) this.dg.connect()) {
            datodg = new DAtoDG(this, dg);

            //
            // 1) create the project node and the module nodes
            //
            Parameters params = createProjectStructure();

            //
            // 1.1) create the module dependencies
            //
            // createModuleDependencies(params);

            //
            // 2) module dependencies (resources, libraries, sources)
            //
            analyzeModuleResources(params);

            //
            // 2.1) library dependencies
            //
            // analyzeLibraryDependencies(params);

            //
            // 3.1) default type definitions (java.lang.Object, primitive types)
            //
            createDefaultTypes(params);

            //
            // 3) type definitions
            //
            analyzeTypeDeclarations(params);

            //
            // 4) type dependencies
            //
            analyzeTypeDependencies(params);

            //
            // 6) method & field definitions
            //
            analyzeMethodDeclarations(params);

            //
            // 7) method dependencies
            //
            analyzeMethodDependencies(params);

            //
            // 8) method calls
            analyzeMethodCalls(params);

        }
        catch (Throwable t) {
            logger.error(t, t);
            failed = true;
        }
        finally {

            //
            // 6) finalizeAnalysis
            //
            analysisDone(failed);
        }

        //
        // -1) the analysis is terminated
        //

    }

    // ----------------------------------------------------------------------
    // Properties
    // ----------------------------------------------------------------------

    public JavaParserPool getJavaParserPool(Module module) {
        return modulesRegistry.getJavaParserPool(module);
    }

    // ----------------------------------------------------------------------
    // Analysis
    // ----------------------------------------------------------------------

    private boolean isSerialized(String what) {
        return config.getParameters().getBoolean("serialize", false)
            || config.getParameters().getBoolean("serialize." + what, false);
    }

    // ----------------------------------------------------------------------

    protected Parameters createProjectStructure() {
        Parameters nparams = datodg.createProjectNode(project, Parameters.empty());

        // create the JDK library node
        String runtimeId = datodg.createLibraryNode(runtimeLibrary, nparams);

        // create the $Unresolved library node
        String unresolvedId = datodg.createLibraryNode(unresolvedLibrary, nparams);

        project.getModules().forEach(module -> {
            String moduleId = datodg.createModuleNode(module, nparams);

            datodg.createEdge(USES, moduleId, runtimeId, LIBRARY);
            datodg.createEdge(USES, moduleId, unresolvedId, LIBRARY);
        });

        project.getModules().forEach(module -> {
            String moduleId = modulesRegistry.getModuleId(module);
            module.getDependencies(false).forEach(dmodule -> {

                int isize = SetUtils.intersection(module.getUsedTypes(), dmodule.getTypes(true)).size();

                String dmoduleId = modulesRegistry.getModuleId(dmodule);

                Parameters edgeProps = Parameters.params()
                    .put_(EDGE_TYPE, DEPENDS_ON)
                    .put_(COUNT, isize);
                datodg.createEdge(USES, moduleId, dmoduleId, edgeProps);
            });
        });

        //dump(); // DEBUG

        return nparams;
    }

    protected void analyzeModuleResources(Parameters params) {
        // project.getModules()
        //     .forEach(module -> analyzeModuleResources(module, params));

        if (isSerialized("module.resources")) {
            project.getModules()
                .forEach(module -> analyzeModuleResources(module, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(project.getModules(),
                    module -> analyzeModuleResources(module, params));
        }
    }

    protected void analyzeModuleResources(Module module, Parameters params) {

        String moduleId = modulesRegistry.getModuleId(module);
        Parameters nparams = Parameters.params(
            MODULE_ID, moduleId
        ).add(params);

        module.getLibraries()
            .forEach(library -> { createLibraryDependency(module, library, nparams); });

        module.getResources()
            .forEach(resource -> { createResourceDependency(resource, nparams); });

        module.getSources()
            .forEach(source -> { createSourceDependency(source, nparams); });
    }

    protected void createResourceDependency(Resource resource, Parameters params) {
        if (isExcluded(resource.getPath())) return;

        String resourceId = datodg.createResourceNode(resource, params);
    }

    protected void createLibraryDependency(Module module, Library library, Parameters params) {
        String libraryId = datodg.createLibraryDependency(module, library, params);
    }

    // -- Modules

    // protected void createModuleDependencies(Parameters params) {
    //     project.getModules()
    //         .forEach(module -> {
    //             createModuleDependencies(module, params);
    //         });
    // }

    // protected void createModuleDependencies(Module module, Parameters params) {
    //     String moduleId = modulesRegistry.getModuleId(module);
    //     Parameters nparams = Parameters.params(
    //         MODULE_ID, moduleId
    //     ).add(params);
    //
    //     module.getDependencies(false)
    //         .forEach(dmodule -> { createModuleDependencies(module, dmodule, nparams); });
    // }

    // protected void createModuleDependencies(Module module, Module dmodule, Parameters params) {
    //     String moduleId = params.getString(MODULE_ID);
    //     String dependencyId = modulesRegistry.getModuleId(dmodule);
    //
    //     datodg.createEdge(USES, moduleId, dependencyId, DEPENDS_ON);
    // }

    // -- Sources

    protected void createSourceDependency(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        String sourceId = datodg.createSourceNode(source, params);
        modulesRegistry.registerSource(sourceId, source);
    }

    // ----------------------------------------------------------------------
    // analyzeLibraryDependencies
    // ----------------------------------------------------------------------

    // protected void analyzeLibraryDependencies(Parameters params) {
    //     project.getModules()
    //         .forEach(module -> {
    //             analyzeLibraryDependencies(module, params);
    //         });
    // }

    // protected void analyzeLibraryDependencies(Module module, Parameters params) {
    //     LibrariesDependencyGraph ldgraph = new LibrariesDependencyGraph();
    //     ldgraph.addAll(module.getLibraries());
    //
    //     module.getLibraries()
    //         .forEach(library -> {
    //             ldgraph.addDependencies(library, library.getDependencies());
    //         });
    //
    //     ldgraph.getDependencies()
    //         .forEach(dep -> {
    //             Library library = dep.getKey();
    //             Library dlibrary = dep.getValue();
    //             createLibraryDependency(library, dlibrary, params);
    //         });
    // }

    // protected void createLibraryDependency(Library library, Library dlibrary, Parameters params) {
    //
    //     String libraryId  = datodg.createLibraryNode(library, params);
    //     String dlibraryId = datodg.createLibraryNode(dlibrary, params);
    //     if (!libraryId.equals(dlibraryId))
    //         datodg.createEdge(USES, libraryId, dlibraryId, DEPENDS_ON);
    // }

    // ----------------------------------------------------------------------
    // analyzeTypeDefinitions
    // ----------------------------------------------------------------------

    protected void createDefaultTypes(Parameters params) {
        // "java.lang.Object"
        datodg.createTypeNode(ReferencedType.JAVA_LANG_OBJECT, runtimeLibrary, params);
        datodg.createTypeNode(ReferencedType.JAVA_LANG_VOID, runtimeLibrary, params);
        datodg.createTypeNode(ReferencedType.JAVA_LANG_CLASS, runtimeLibrary, params);

        // primitive types
        for (String primitiveType : JavaUtils.PRIMITIVE_TYPES) {
            RefType refType = new ReferencedType(primitiveType, runtimeLibrary);
            datodg.createTypeNode(refType, runtimeLibrary, params);
        }
        datodg.createTypeNode(ReferencedType.ARRAY, runtimeLibrary, params);
    }

    protected void analyzeTypeDeclarations(Parameters params) {
        project.getModules()
            .forEach(module -> analyzeTypeDeclarations(module, params));
    }

    protected void analyzeTypeDeclarations(Module module, Parameters params) {

        if (isSerialized("type.definitions")) {
            module.getSources()
                .forEach(source -> analyzeTypeDeclarations(source, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(module.getSources(),
                source -> analyzeTypeDeclarations(source, params));
        }
    }

    protected void analyzeTypeDeclarations(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        Parameters nparams = Parameters.params(
            MODULE_ID, modulesRegistry.getModuleId(source.getModule()),
            SOURCE_ID, modulesRegistry.getSourceId(source)
        ).add(params);

        // JavaTypeDeclarations jtd = new JavaTypeDeclarations(this);
        // jtd.analyze(source, nparams);
        ASTTypeDeclarations td = new ASTTypeDeclarations(this);
        td.analyze(source, nparams);
    }

    // ----------------------------------------------------------------------
    // Type dependencies
    // ----------------------------------------------------------------------

    protected void analyzeTypeDependencies(Parameters params) {
        project.getModules()
            .forEach(module -> analyzeTypeDependencies(module, params));
    }

    protected void analyzeTypeDependencies(Module module, Parameters params) {
        // module.getSources()
        //     .forEach(source -> analyzeTypeDependencies(source, params));

        if (isSerialized("type.dependencies")) {
            module.getSources()
                .forEach(source -> analyzeTypeDependencies(source, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(module.getSources(),
                source -> analyzeTypeDependencies(source, params));
        }
    }

    protected void analyzeTypeDependencies(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        Parameters nparams = Parameters.params(
            MODULE_ID, modulesRegistry.getModuleId(source.getModule()),
            SOURCE_ID, modulesRegistry.getSourceId(source)
        ).add(params);

        // JavaTypeDependencies jtd = new JavaTypeDependencies(this);
        // jtd.analyze(source, nparams);
        // ASTTypeDependencies td = new ASTTypeDependencies(this);
        // td.analyze(source, nparams);
        ASTVTypeDependencies td = new ASTVTypeDependencies(this);
        td.analyze(source, nparams);
    }

    // ----------------------------------------------------------------------
    // Method definitions
    // ----------------------------------------------------------------------

    protected void analyzeMethodDeclarations(Parameters params) {
        project.getModules()
            .forEach(module -> analyzeMethodDeclarations(module, params));
    }

    protected void analyzeMethodDeclarations(Module module, Parameters params) {
        // module.getSources()
        //     .forEach(source -> analyzeMethodDeclarations(source, params));

        if (isSerialized("method.definitions") || isSerialized("field.definitions")) {
            module.getSources()
                .forEach(source -> analyzeMethodDeclarations(source, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(module.getSources(),
                source -> analyzeMethodDeclarations(source, params));
        }
    }

    protected void analyzeMethodDeclarations(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        Parameters nparams = Parameters.params(
            MODULE_ID, modulesRegistry.getModuleId(source.getModule()),
            SOURCE_ID, modulesRegistry.getSourceId(source)
        ).add(params);

        ASTMethodDeclarations td = new ASTMethodDeclarations(this);
        td.analyze(source, nparams);
    }

    // ----------------------------------------------------------------------
    // Method dependencies
    // ----------------------------------------------------------------------

    protected void analyzeMethodDependencies(Parameters params) {
        project.getModules()
            .forEach(module -> analyzeMethodDependencies(module, params));
    }

    protected void analyzeMethodDependencies(Module module, Parameters params) {

        if (isSerialized("method.dependencies")) {
            module.getSources()
                .forEach(source -> analyzeMethodDependencies(source, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(module.getSources(),
                source -> analyzeMethodDependencies(source, params));
        }
    }

    protected void analyzeMethodDependencies(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        Parameters nparams = Parameters.params(
            MODULE_ID, modulesRegistry.getModuleId(source.getModule()),
            SOURCE_ID, modulesRegistry.getSourceId(source)
        ).add(params);

        ASTMethodDependencies td = new ASTMethodDependencies(this);
        td.analyze(source, nparams);
    }

    // ----------------------------------------------------------------------
    // Method calls
    // ----------------------------------------------------------------------

    protected void analyzeMethodCalls(Parameters params) {
        project.getModules()
            .forEach(module -> analyzeMethodCalls(module, params));
    }

    protected void analyzeMethodCalls(Module module, Parameters params) {

        if (isSerialized("method.calls")) {
            module.getSources()
                .forEach(source -> analyzeMethodCalls(source, params));
        }
        else {
            //Parallel
            new ParallelizeAnalysis()
                .forEach(module.getSources(),
                    source -> analyzeMethodCalls(source, params));
        }
    }

    protected void analyzeMethodCalls(Source source, Parameters params) {
        if (isExcluded(source.getPath())) return;

        Parameters nparams = Parameters.params(
            MODULE_ID, modulesRegistry.getModuleId(source.getModule()),
            SOURCE_ID, modulesRegistry.getSourceId(source)
        ).add(params);

        ASTVMethodCalls td = new ASTVMethodCalls(this);
        td.analyze(source, nparams);
    }

    // ----------------------------------------------------------------------
    // Done
    // ----------------------------------------------------------------------

    protected void analysisDone(boolean failed) {
        // finalize the tokens
        datodg.mergeTokens();
        datodg.deleteTokensWithoutRelationships();

        // cleanup of internal JavaParser data structures
        JavaParserFacade.clearInstances();

        // clear the internal caches
        // CacheManager.removeCache("maven");
        CacheManager.removeCaches(String.format("dependency.%s", project.getId()));

        if (isAborted())
            datodg.setStatus(STATUS_INVALID, REASON_ABORTED);
        else if (failed)
            datodg.setStatus(STATUS_INVALID, REASON_FAILED);
        else
            datodg.setStatus(STATUS_VALID, null);
    }

    // ----------------------------------------------------------------------
    // Implementation
    // ----------------------------------------------------------------------

    private boolean isExcluded(String path) {
        return pathFilter.accept(path);
    }

    public boolean isUnsolvedSymbol(String symbol) {
        return unresolvedTypes.contains(symbol);
    }

    void logUnregisteredType(Logger logger, RefType refType) {
        String typeName = refType.getName().getFullName();

        // if (unresolvedTypes.contains(typeName))
        //     return;
        // unresolvedTypes.add(typeName);

        String category = String.format("unresolvedType.%s", typeName);
        logger.errorc(category, "Unregistered type %s", typeName);
    }

    public void logUnsolvedSymbol(Logger logger, String symbol, String context) {
        // Skip unresolved type parameters 'T', 'O1', ...
        // if (symbol.length() <= 2)
        //     return;

        // Skip if it seems a 'namespace'
        // if (JavaUtils.isNamespace(symbol))
        //     return;

        // Skip if it seems a "identifier"
        if (JavaUtils.isIdentifier(symbol))
            return;

        // Skip already logged symbols
        // if (unresolvedSymbols.contains(symbol))
        //     return;
        // unresolvedSymbols.add(symbol);

        String category = String.format("unresolvedSymbols.%s", symbol);
        if (context == null)
            logger.warnc(category, "Unable to solve symbol %s", symbol);
        else
            logger.warnc(category, "Unable to solve symbol %s in %s", symbol, context);
    }

    public void logUnableToFindClassDeclaration(Logger logger, String symbol) {
        // if (noClassDefSymbols.contains(symbol))
        //     return;
        // noClassDefSymbols.add(symbol);

        String category = String.format("noDefClassDefSymbol.%s", symbol);
        logger.errorc(category, "Unable to find the class declaration for symbol %s", symbol);
    }

    public void logNotFullQualifiedName(Logger logger, String className) {
        logger.warnf("Class %s has not a full qualified name", className);
    }

    // public void logUnableToFindLibrary(String symbol, Source source) {
    //     // if (noLibrarySymbol.contains(symbol))
    //     //     return;
    //     // noLibrarySymbol.add(symbol);
    //
    //     String category = String.format("noLibrarySymbol.%s", symbol);
    //     logger.errorc(category, "Unable to find the library for symbol %s", symbol);
    // }

    // ----------------------------------------------------------------------
    // Listeners
    // ----------------------------------------------------------------------

    public DependencyAnalyzer addListener(AnalyzerListener l) {
        return this;
    }

    // ----------------------------------------------------------------------
    // End
    // ----------------------------------------------------------------------

}

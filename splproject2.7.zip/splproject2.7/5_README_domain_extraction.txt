Dear Corrado



As I mentioned to you last time , There is one patent that I am working on for SPL which is related to extracting the
domain model from monolithic application . you can read about domain model here : https://www.domainlanguage.com/ddd/  ,
https://www.simpleorientedarchitecture.com/book-review-domain-driven-design/





Domain-driven design  is one of the  approach that has been followed by Microsoft and IBM to refactor monolithic
application to micro service. Hence, instead of completely capture the domain model manually we can apply AI and
Embedding technique to extract this model.



I have worked with Ahmad to implement the community detection approach. It is not completed yet. I need to combine this
approach with DeepWalk to extract the vector representation of each class. Then we can refine the community detection
clusters with this DeepWalk matrix. In later step , we can apply Silwet method to evaluate the clusters. Other methods
can be reviewed here : https://www.ims.uni-stuttgart.de/document/team/schulte/theses/phd/algorithm.pdf

We can try Node2Vec as well as embedding technique .



Neo4j have a build in DeepWalk functionality, my previous implementation was by using deeplearning4j library.
It gives a very good result , however, it was hard to trackback which features that drives the result.

In this approach, we will use it to correct community detection result .





We can start this , once we have a good version of runtime model working well.